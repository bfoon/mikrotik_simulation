package main

// RouterOS menu tree definition. Every menu is described declaratively and the
// engine, API, REST, CLI and GUI are all generated from these definitions.
//
// Field spec format:  "name|default|attr,attr,..."
//   attrs: ro req hide bool int dur bytes ip prefix ref=/menu extra=a/b enum=a/b text

import "strings"

type Field struct {
	Name  string   `json:"n"`
	Def   string   `json:"d,omitempty"`
	Kind  string   `json:"k,omitempty"`
	RO    bool     `json:"ro,omitempty"`
	Req   bool     `json:"req,omitempty"`
	Hide  bool     `json:"hide,omitempty"`
	Ref   string   `json:"ref,omitempty"`
	Extra []string `json:"extra,omitempty"`
	Enum  []string `json:"enum,omitempty"`
}

type FlagDef struct {
	Ch    string `json:"c"`
	Name  string `json:"n"`
	Field string `json:"f"`
	Val   string `json:"v"`
}

type Menu struct {
	Path     string    `json:"path"`
	Title    string    `json:"title"`
	Single   bool      `json:"single,omitempty"`
	View     string    `json:"view,omitempty"`
	TypeVal  string    `json:"type,omitempty"`
	Fields   []*Field  `json:"fields"`
	Cols     []string  `json:"cols,omitempty"`
	Flags    []FlagDef `json:"flags,omitempty"`
	Unique   string    `json:"unique,omitempty"`
	NoAdd    bool      `json:"noAdd,omitempty"`
	NoRemove bool      `json:"noRemove,omitempty"`
	NoSet    bool      `json:"noSet,omitempty"`
	Dyn      bool      `json:"dyn,omitempty"`
	Detail   bool      `json:"detail,omitempty"`
	Ordered  bool      `json:"ordered,omitempty"`
	Cmds     []string  `json:"cmds,omitempty"`
	NoSave   bool      `json:"-"`
	std      bool
	fmap     map[string]*Field
}

func (m *Menu) F(name string) *Field { return m.fmap[name] }

func (m *Menu) Store() string {
	if m.View != "" {
		return m.View
	}
	return m.Path
}

func parseField(spec string) *Field {
	p := strings.SplitN(spec, "|", 3)
	f := &Field{Name: p[0], Kind: "str"}
	if len(p) > 1 {
		f.Def = p[1]
	}
	if len(p) > 2 {
		for _, a := range strings.Split(p[2], ",") {
			switch {
			case a == "ro":
				f.RO = true
			case a == "req":
				f.Req = true
			case a == "hide":
				f.Hide = true
			case a == "bool", a == "int", a == "dur", a == "bytes", a == "ip", a == "prefix", a == "text":
				f.Kind = a
			case strings.HasPrefix(a, "ref="):
				f.Ref = a[4:]
				f.Kind = "ref"
			case strings.HasPrefix(a, "extra="):
				f.Extra = strings.Split(a[6:], "/")
			case strings.HasPrefix(a, "enum="):
				f.Enum = strings.Split(a[5:], "/")
				f.Kind = "enum"
			}
		}
	}
	return f
}

func flags(s string) []FlagDef {
	if s == "" {
		return nil
	}
	var out []FlagDef
	for _, p := range strings.Split(s, ",") {
		kv := strings.SplitN(p, ":", 2)
		field := kv[1]
		val := "true"
		name := strings.ToUpper(field)
		if strings.Contains(field, "=") {
			fv := strings.SplitN(field, "=", 2)
			field, val = fv[0], fv[1]
			name = strings.ToUpper(val)
		}
		out = append(out, FlagDef{Ch: kv[0], Name: name, Field: field, Val: val})
	}
	return out
}

type mopt func(m *Menu)

func single() mopt             { return func(m *Menu) { m.Single = true } }
func view(base, t string) mopt { return func(m *Menu) { m.View = base; m.TypeVal = t } }
func cols(c string) mopt       { return func(m *Menu) { m.Cols = strings.Split(c, ",") } }
func flg(s string) mopt        { return func(m *Menu) { m.Flags = flags(s) } }
func uniq(f string) mopt       { return func(m *Menu) { m.Unique = f } }
func noadd() mopt              { return func(m *Menu) { m.NoAdd = true } }
func norm() mopt               { return func(m *Menu) { m.NoRemove = true } }
func noset() mopt              { return func(m *Menu) { m.NoSet = true } }
func dyn() mopt                { return func(m *Menu) { m.Dyn = true; m.NoAdd = true; m.NoSave = true } }
func detail() mopt             { return func(m *Menu) { m.Detail = true } }
func ordered() mopt            { return func(m *Menu) { m.Ordered = true } }
func cmds(c string) mopt       { return func(m *Menu) { m.Cmds = strings.Split(c, ",") } }
func nosave() mopt             { return func(m *Menu) { m.NoSave = true } }
func std() mopt                { return func(m *Menu) { m.std = true } }
func fl(specs ...string) mopt {
	return func(m *Menu) {
		for _, s := range specs {
			m.Fields = append(m.Fields, parseField(s))
		}
	}
}

var Menus []*Menu
var MenuMap = map[string]*Menu{}
var Dirs = map[string]bool{"": true}

func M(path, title string, opts ...mopt) *Menu {
	m := &Menu{Path: path, Title: title}
	for _, o := range opts {
		o(m)
	}
	if m.std {
		m.Fields = append(m.Fields, parseField("comment|"), parseField("disabled|false|bool"))
	}
	m.fmap = map[string]*Field{}
	for _, f := range m.Fields {
		m.fmap[f.Name] = f
	}
	Menus = append(Menus, m)
	MenuMap[path] = m
	return m
}

const ifStats = "rx-byte|0|ro,int;tx-byte|0|ro,int;rx-packet|0|ro,int;tx-packet|0|ro,int;rx-drop|0|ro,int;tx-drop|0|ro,int;tx-queue-drop|0|ro,int;rx-error|0|ro,int;tx-error|0|ro,int;fp-rx-byte|0|ro,int;fp-tx-byte|0|ro,int;fp-rx-packet|0|ro,int;fp-tx-packet|0|ro,int"

func split(s string) []string { return strings.Split(s, ";") }

const fwCommon = "chain||req;action|accept|enum=accept/drop/reject/jump/return/log/passthrough/tarpit/fasttrack-connection/add-src-to-address-list/add-dst-to-address-list/masquerade/src-nat/dst-nat/redirect/netmap/same/mark-connection/mark-packet/mark-routing/change-mss/notrack;src-address|;dst-address|;protocol|;src-port|;dst-port|;port|;in-interface|;out-interface|;in-interface-list|;out-interface-list|;src-address-list|;dst-address-list|;connection-state|;connection-nat-state|;connection-limit|;connection-mark|;packet-mark|;routing-mark|;limit|;tcp-flags|;icmp-options|;layer7-protocol|;content|;hotspot|;address-list|;address-list-timeout|;jump-target|;reject-with|;log|false|bool;log-prefix|;bytes|0|ro,int;packets|0|ro,int;invalid|false|ro,bool;dynamic|false|ro,bool"

func init() {
	// ---------------- SYSTEM ----------------
	M("/system/identity", "Identity", single(), fl("name|MikroTik"))
	M("/system/resource", "Resources", single(), noset(), fl("uptime||ro,dur", "version||ro", "build-time||ro", "factory-software||ro", "free-memory||ro,int", "total-memory||ro,int", "cpu||ro", "cpu-count||ro,int", "cpu-frequency||ro,int", "cpu-load||ro,int", "free-hdd-space||ro,int", "total-hdd-space||ro,int", "write-sect-since-reboot||ro,int", "write-sect-total||ro,int", "bad-blocks||ro", "architecture-name||ro", "board-name||ro", "platform||ro"), cmds("monitor"))
	M("/system/resource/cpu", "CPU", dyn(), norm(), noset(), cols("cpu,load,irq,disk"), fl("cpu||ro", "load||ro,int", "irq||ro,int", "disk||ro,int"))
	M("/system/routerboard", "RouterBOARD", single(), noset(), fl("routerboard||ro,bool", "board-name||ro", "model||ro", "serial-number||ro", "firmware-type||ro", "factory-firmware||ro", "current-firmware||ro", "upgrade-firmware||ro"), cmds("upgrade"))
	M("/system/routerboard/settings", "RouterBOARD Settings", single(), fl("auto-upgrade|false|bool", "boot-device|nand-if-fail-then-ethernet", "boot-protocol|bootp", "cpu-frequency|auto", "protected-routerboot|disabled", "silent-boot|false|bool"))
	M("/system/clock", "Clock", single(), fl("time||", "date||", "time-zone-autodetect|true|bool", "time-zone-name|Africa/Banjul", "gmt-offset|+00:00|ro", "dst-active|false|ro,bool"))
	M("/system/package", "Packages", noadd(), norm(), noset(), cols("name,version,build-time,size"), fl("name||ro", "version||ro", "build-time||ro", "size||ro", "scheduled||ro", "disabled|false|ro,bool", "available|false|ro,bool"), cmds("enable,disable,uninstall"))
	M("/system/package/update", "Package Update", single(), fl("channel|stable|enum=stable/long-term/testing/development", "installed-version||ro", "latest-version||ro", "status||ro"), cmds("check-for-updates,download,install"))
	M("/system/license", "License", single(), noset(), fl("software-id||ro", "nlevel||ro", "level||ro", "features||ro"))
	M("/system/health", "Health", dyn(), norm(), noset(), cols("name,value,type"), fl("name||ro", "value||ro", "type||ro"))
	M("/system/scheduler", "Scheduler", std(), uniq("name"), cols("name,start-date,start-time,interval,on-event,run-count"), flg("X:disabled"),
		fl("name||req", "start-date|", "start-time|startup", "interval|0s|dur", "on-event|", "owner|admin|ro", "policy|ftp,reboot,read,write,policy,test,password,sniff,sensitive,romon", "run-count|0|ro,int", "next-run||ro"))
	M("/system/script", "Scripts", uniq("name"), cols("name,owner,last-started,run-count"), cmds("run"),
		fl("name||req", "source||text", "owner|admin", "policy|ftp,reboot,read,write,policy,test,password,sniff,sensitive,romon", "dont-require-permissions|false|bool", "run-count|0|ro,int", "last-started||ro", "invalid|false|ro,bool", "comment|"))
	M("/system/script/job", "Jobs", dyn(), cols("script,owner,started"), fl("script||ro", "owner||ro", "started||ro", "type||ro"))
	M("/system/ntp/client", "NTP Client", single(), fl("enabled|false|bool", "mode|unicast", "servers|", "status|stopped|ro"))
	M("/system/ntp/server", "NTP Server", single(), fl("enabled|false|bool", "broadcast|false|bool", "multicast|false|bool", "manycast|false|bool"))
	M("/system/logging", "Logging", std(), cols("topics,action,prefix"), flg("X:disabled,I:invalid,*:default"), fl("topics|info", "action|memory", "prefix|", "default|false|ro,bool", "invalid|false|ro,bool"))
	M("/system/logging/action", "Logging Actions", uniq("name"), cols("name,target,remote"), fl("name||req", "target|memory|enum=memory/disk/echo/remote/email", "memory-lines|1000|int", "remote|", "remote-port|514|int", "default|false|ro,bool"))
	M("/system/note", "Note", single(), fl("note||text", "show-at-login|true|bool", "show-at-cli-login|false|bool"))
	M("/system/history", "History", dyn(), cols("action,by,policy,time"), fl("action||ro", "by||ro", "policy||ro", "time||ro", "undoable|false|ro,bool"))
	M("/log", "Log", dyn(), norm(), noset(), cols("time,topics,message"), fl("time||ro", "topics||ro", "message||ro"))

	M("/user", "Users", std(), uniq("name"), cols("name,group,address,last-logged-in"), flg("X:disabled"),
		fl("name||req", "group|full|ref=/user/group", "address|", "password||hide", "last-logged-in||ro", "expired|false|ro,bool", "inactivity-timeout|10m|dur", "inactivity-policy|none"))
	M("/user/group", "Groups", uniq("name"), cols("name,policy,skin"), fl("name||req", "policy|local,telnet,ssh,ftp,reboot,read,write,policy,test,winbox,password,web,sniff,sensitive,api,romon,rest-api", "skin|default", "comment|"))
	M("/user/active", "Active Users", dyn(), cols("when,name,address,via"), flg("R:radius"), fl("when||ro", "name||ro", "address||ro", "via||ro", "group||ro", "radius|false|ro,bool"))
	M("/user/settings", "User Settings", single(), fl("minimum-password-length|0|int", "minimum-categories|0|int"))

	// ---------------- INTERFACES ----------------
	ifBase := append([]string{"name||req", "default-name||ro", "type||ro", "mtu|1500", "actual-mtu|1500|ro,int", "l2mtu|1580|ro,int", "max-l2mtu|9578|ro,int", "mac-address||ro", "last-link-up-time||ro", "last-link-down-time||ro", "link-downs|0|ro,int"}, split(ifStats)...)
	ifBase = append(ifBase, "running|false|ro,bool", "slave|false|ro,bool", "dynamic|false|ro,bool", "inactive|false|ro,bool", "comment|", "disabled|false|bool")
	M("/interface", "Interfaces", noadd(), uniq("name"), cols("name,type,actual-mtu,l2mtu,tx-byte,rx-byte"), flg("D:dynamic,X:disabled,R:running,S:slave"), cmds("monitor-traffic,reset-counters,blink"), fl(ifBase...))
	M("/interface/ethernet", "Ethernet", view("/interface", "ether"), noadd(), norm(), uniq("name"), cols("name,mtu,mac-address,arp,switch"), flg("X:disabled,R:running,S:slave"), cmds("monitor,reset-counters,blink,reset-mac-address,cable-test"),
		fl("name||req", "default-name||ro", "mtu|1500", "l2mtu|1580|ro,int", "mac-address||", "orig-mac-address||ro", "arp|enabled|enum=enabled/disabled/proxy-arp/reply-only/local-proxy-arp", "arp-timeout|auto", "auto-negotiation|true|bool", "advertise|10M-baseT-half,10M-baseT-full,100M-baseT-half,100M-baseT-full,1G-baseT-half,1G-baseT-full", "speed|1G-baseT-full", "full-duplex|true|bool", "tx-flow-control|off", "rx-flow-control|off", "loop-protect|default", "switch|switch1|ro", "poe-out||ro", "running|false|ro,bool", "slave|false|ro,bool", "rx-byte|0|ro,int", "tx-byte|0|ro,int", "rx-packet|0|ro,int", "tx-packet|0|ro,int", "comment|", "disabled|false|bool"))
	M("/interface/bridge", "Bridge", view("/interface", "bridge"), uniq("name"), cols("name,mtu,mac-address,protocol-mode"), flg("X:disabled,R:running"),
		fl("name|bridge1", "mtu|auto", "actual-mtu|1500|ro,int", "l2mtu|65535|ro,int", "arp|enabled", "arp-timeout|auto", "mac-address||ro", "protocol-mode|rstp|enum=none/stp/rstp/mstp", "priority|0x8000", "auto-mac|true|bool", "admin-mac|", "ageing-time|5m|dur", "igmp-snooping|false|bool", "dhcp-snooping|false|bool", "fast-forward|true|bool", "vlan-filtering|false|bool", "ingress-filtering|true|bool", "running|false|ro,bool", "comment|", "disabled|false|bool"))
	M("/interface/bridge/port", "Bridge Ports", std(), cols("interface,bridge,horizon,pvid,role,status"), flg("I:inactive,X:disabled,D:dynamic,H:hw"),
		fl("interface||req,ref=/interface", "bridge||req,ref=/interface", "horizon|none", "pvid|1|int", "priority|0x80", "path-cost|10", "internal-path-cost|10", "edge|auto", "point-to-point|auto", "frame-types|admit-all", "ingress-filtering|true|bool", "trusted|false|bool", "hw|true|bool", "status||ro", "role||ro", "inactive|false|ro,bool", "dynamic|false|ro,bool"))
	M("/interface/bridge/host", "Bridge Hosts", dyn(), cols("mac-address,on-interface,bridge,age"), flg("X:disabled,I:invalid,D:dynamic,L:local,E:external"), fl("mac-address||ro", "on-interface||ro", "bridge||ro", "vid||ro", "age||ro", "local|false|ro,bool", "dynamic|true|ro,bool"))
	M("/interface/bridge/vlan", "Bridge VLANs", std(), cols("bridge,vlan-ids,tagged,untagged"), fl("bridge||req,ref=/interface", "vlan-ids||req", "tagged|", "untagged|", "current-tagged||ro", "current-untagged||ro", "dynamic|false|ro,bool"))
	M("/interface/vlan", "VLAN", view("/interface", "vlan"), uniq("name"), cols("name,mtu,arp,vlan-id,interface"), flg("X:disabled,R:running"),
		fl("name|vlan1", "mtu|1500", "actual-mtu|1500|ro,int", "l2mtu|1576|ro,int", "mac-address||ro", "arp|enabled", "arp-timeout|auto", "vlan-id||req,int", "interface||req,ref=/interface", "use-service-tag|false|bool", "loop-protect|default", "running|false|ro,bool", "comment|", "disabled|false|bool"))
	M("/interface/wireless", "Wireless", view("/interface", "wlan"), uniq("name"), cols("name,mode,ssid,band,frequency,channel-width"), flg("X:disabled,R:running"), cmds("scan,monitor,reset-configuration"),
		fl("name||req", "default-name||ro", "mtu|1500", "l2mtu|1600|ro,int", "mac-address||ro", "arp|enabled", "interface-type||ro", "mode|ap-bridge|enum=ap-bridge/bridge/station/station-bridge/station-pseudobridge/alignment-only/nstreme-dual-slave/wds-slave/monitor", "ssid|MikroTik", "band|2ghz-b/g/n", "frequency|auto", "channel-width|20/40mhz-XX", "country|etsi", "installation|indoor", "wireless-protocol|802.11", "security-profile|default|ref=/interface/wireless/security-profiles", "wps-mode|disabled", "hide-ssid|false|bool", "default-forwarding|true|bool", "default-authentication|true|bool", "tx-power-mode|default", "antenna-gain|3|int", "radio-name||ro", "running|false|ro,bool", "rx-byte|0|ro,int", "tx-byte|0|ro,int", "comment|", "disabled|false|bool"))
	M("/interface/wireless/registration-table", "Registration", dyn(), cols("interface,mac-address,uptime,signal-strength,tx-rate,rx-rate"), flg("A:ap,W:wds,B:bridge"),
		fl("interface||ro", "radio-name||ro", "mac-address||ro", "ap|false|ro,bool", "wds|false|ro,bool", "bridge|false|ro,bool", "rx-rate||ro", "tx-rate||ro", "packets||ro", "bytes||ro", "uptime||ro", "last-activity||ro", "signal-strength||ro", "signal-to-noise||ro", "tx-ccq||ro", "p-throughput||ro", "authentication-type||ro", "encryption||ro", "comment|"))
	M("/interface/wireless/security-profiles", "Security Profiles", uniq("name"), cols("name,mode,authentication-types,unicast-ciphers,group-ciphers"), flg("*:default"),
		fl("name||req", "mode|none|enum=none/static-keys-required/static-keys-optional/dynamic-keys", "authentication-types|", "unicast-ciphers|aes-ccm", "group-ciphers|aes-ccm", "wpa-pre-shared-key||hide", "wpa2-pre-shared-key|", "supplicant-identity|MikroTik", "default|false|ro,bool", "comment|"))
	M("/interface/wireless/access-list", "Access List", std(), cols("mac-address,interface,signal-range,authentication,forwarding"), fl("mac-address|", "interface|any", "signal-range|-120..120", "authentication|true|bool", "forwarding|true|bool", "ap-tx-limit|0", "client-tx-limit|0", "vlan-mode|default"))
	M("/interface/wifi", "WiFi", view("/interface", "wifi"), uniq("name"), cols("name,mac-address,configuration.ssid,channel.band,configuration.mode"), flg("X:disabled,R:running"), cmds("scan,monitor"),
		fl("name||req", "default-name||ro", "mtu|1500", "l2mtu|1560|ro,int", "mac-address||ro", "arp|enabled", "configuration.mode|ap|enum=ap/station/station-bridge", "configuration.ssid|MikroTik", "configuration.country|Etsi", "configuration.hide-ssid|false|bool", "channel.band|2ghz-ax|enum=2ghz-ax/2ghz-n/2ghz-g/5ghz-ax/5ghz-ac/5ghz-n/5ghz-a", "channel.width|20/40mhz", "channel.frequency|", "security.authentication-types|wpa2-psk,wpa3-psk", "security.passphrase|", "running|false|ro,bool", "rx-byte|0|ro,int", "tx-byte|0|ro,int", "comment|", "disabled|false|bool"))
	M("/interface/wifi/registration-table", "WiFi Registration", dyn(), cols("interface,ssid,mac-address,uptime,signal,tx-rate,rx-rate"),
		fl("interface||ro", "ssid||ro", "mac-address||ro", "uptime||ro", "last-activity||ro", "signal||ro", "auth-type||ro", "band||ro", "tx-rate||ro", "rx-rate||ro", "packets||ro", "bytes||ro", "authorized|true|ro,bool"))
	M("/interface/list", "Interface Lists", uniq("name"), cols("name,include,exclude"), flg("D:dynamic,*:builtin"), fl("name||req", "include|", "exclude|", "builtin|false|ro,bool", "dynamic|false|ro,bool", "comment|"))
	M("/interface/list/member", "Interface List Members", std(), cols("list,interface"), flg("X:disabled,D:dynamic"), fl("list||req,ref=/interface/list", "interface||req,ref=/interface", "dynamic|false|ro,bool"))
	M("/interface/pppoe-server/server", "PPPoE Servers", std(), cols("service-name,interface,max-mtu,max-mru,mrru,default-profile,authentication"), flg("X:disabled,I:invalid"),
		fl("service-name||req", "interface||req,ref=/interface", "max-mtu|auto", "max-mru|auto", "mrru|disabled", "authentication|pap,chap,mschap1,mschap2", "keepalive-timeout|10", "one-session-per-host|false|bool", "max-sessions|unlimited", "pado-delay|0", "default-profile|default|ref=/ppp/profile", "invalid|false|ro,bool"))
	M("/interface/pppoe-server", "PPPoE Server Interfaces", view("/interface", "pppoe-in"), noadd(), cols("name,user,service,remote-address,uptime"), flg("D:dynamic,X:disabled,R:running"),
		fl("name||ro", "user||ro", "service||ro", "remote-address||ro", "mtu||ro", "mru||ro", "encoding||ro", "uptime||ro", "running|false|ro,bool", "dynamic|false|ro,bool", "rx-byte|0|ro,int", "tx-byte|0|ro,int", "comment|", "disabled|false|bool"))
	M("/interface/pppoe-client", "PPPoE Client", view("/interface", "pppoe-out"), uniq("name"), cols("name,max-mtu,max-mru,mrru,interface,user"), flg("X:disabled,R:running"), cmds("monitor"),
		fl("name|pppoe-out1", "max-mtu|auto", "max-mru|auto", "mrru|disabled", "interface||req,ref=/interface", "user|", "password|", "profile|default|ref=/ppp/profile", "service-name|", "ac-name|", "add-default-route|false|bool", "default-route-distance|1|int", "dial-on-demand|false|bool", "use-peer-dns|false|bool", "allow|pap,chap,mschap1,mschap2", "keepalive-timeout|10", "running|false|ro,bool", "comment|", "disabled|false|bool"))
	M("/interface/l2tp-server/server", "L2TP Server", single(), fl("enabled|false|bool", "max-mtu|1450", "max-mru|1450", "authentication|pap,chap,mschap1,mschap2", "default-profile|default-encryption", "use-ipsec|no", "ipsec-secret|", "keepalive-timeout|30"))
	M("/interface/ovpn-server/server", "OVPN Server", single(), fl("enabled|false|bool", "port|1194", "mode|ip", "protocol|tcp", "certificate|none", "require-client-certificate|false|bool", "auth|sha1,md5,sha256,sha512", "cipher|blowfish128,aes128-cbc", "default-profile|default"))
	M("/interface/sstp-server/server", "SSTP Server", single(), fl("enabled|false|bool", "port|443", "certificate|none", "authentication|pap,chap,mschap1,mschap2", "default-profile|default", "tls-version|any"))
	M("/interface/pptp-server/server", "PPTP Server", single(), fl("enabled|false|bool", "max-mtu|1450", "max-mru|1450", "authentication|mschap1,mschap2", "default-profile|default-encryption", "keepalive-timeout|30"))
	M("/interface/eoip", "EoIP Tunnel", view("/interface", "eoip"), uniq("name"), cols("name,mtu,local-address,remote-address,tunnel-id"), flg("X:disabled,R:running"),
		fl("name|eoip-tunnel1", "mtu|auto", "mac-address||ro", "local-address|", "remote-address||req", "tunnel-id|0|int", "ipsec-secret|", "keepalive|10s,10", "running|false|ro,bool", "comment|", "disabled|false|bool"))
	M("/interface/wireguard", "WireGuard", view("/interface", "wg"), uniq("name"), cols("name,mtu,listen-port,private-key,public-key"), flg("X:disabled,R:running"),
		fl("name|wireguard1", "mtu|1420", "listen-port|13231|int", "private-key|", "public-key||ro", "running|false|ro,bool", "comment|", "disabled|false|bool"))
	M("/interface/wireguard/peers", "WireGuard Peers", std(), cols("interface,public-key,endpoint-address,endpoint-port,allowed-address"), fl("interface||req,ref=/interface", "public-key||req", "endpoint-address|", "endpoint-port|0|int", "allowed-address|", "persistent-keepalive|0s|dur", "preshared-key|", "last-handshake||ro", "rx||ro", "tx||ro", "current-endpoint-address||ro", "current-endpoint-port||ro"))

	// ---------------- IP ----------------
	M("/ip/address", "Addresses", std(), cols("address,network,interface"), flg("X:disabled,I:invalid,D:dynamic"),
		fl("address||req,prefix", "network|", "interface||req,ref=/interface", "actual-interface||ro", "invalid|false|ro,bool", "dynamic|false|ro,bool"))
	M("/ip/route", "Routes", std(), cols("dst-address,gateway,distance,routing-table"), flg("X:disabled,D:dynamic,A:active,c:connect,s:static,d:dhcp,v:vpn,y:copy"),
		fl("dst-address|0.0.0.0/0|prefix", "gateway|", "distance|1|int", "scope|30|int", "target-scope|10|int", "routing-table|main", "pref-src|", "check-gateway|", "vrf-interface|", "suppress-hw-offload|false|bool", "immediate-gw||ro", "local-address||ro", "active|false|ro,bool", "dynamic|false|ro,bool", "static|true|ro,bool", "connect|false|ro,bool", "dhcp|false|ro,bool", "vpn|false|ro,bool", "inactive|false|ro,bool", "ecmp|false|ro,bool", "hw-offloaded|false|ro,bool"))
	M("/ip/dns", "DNS", single(), cmds("flush-cache"), fl("servers|", "dynamic-servers||ro", "use-doh-server|", "verify-doh-cert|false|bool", "allow-remote-requests|false|bool", "max-udp-packet-size|4096|int", "query-server-timeout|2s|dur", "query-total-timeout|10s|dur", "max-concurrent-queries|100|int", "max-concurrent-tcp-sessions|20|int", "cache-size|2048KiB", "cache-max-ttl|1w|dur", "cache-used||ro"))
	M("/ip/dns/static", "DNS Static", std(), cols("name,regexp,type,address,ttl"), flg("X:disabled,D:dynamic"), fl("name|", "regexp|", "address|", "type|A|enum=A/AAAA/CNAME/FWD/MX/NS/NXDOMAIN/SRV/TXT", "cname|", "forward-to|", "text|", "ttl|1d|dur", "match-subdomain|false|bool", "dynamic|false|ro,bool"))
	M("/ip/dns/cache", "DNS Cache", dyn(), cols("name,type,data,ttl"), fl("name||ro", "type||ro", "data||ro", "ttl||ro", "static|false|ro,bool"))
	M("/ip/pool", "Pools", uniq("name"), cols("name,ranges,next-pool"), fl("name||req", "ranges||req", "next-pool|none", "comment|"))
	M("/ip/pool/used", "Used Addresses", dyn(), cols("pool,address,owner,info"), fl("pool||ro", "address||ro", "owner||ro", "info||ro"))
	M("/ip/dhcp-server", "DHCP Server", std(), uniq("name"), cols("name,interface,address-pool,lease-time"), flg("D:dynamic,X:disabled,I:invalid"), cmds("setup"),
		fl("name||req", "interface||req,ref=/interface", "address-pool|static-only", "lease-time|30m|dur", "authoritative|yes", "add-arp|false|bool", "always-broadcast|false|bool", "bootp-support|static", "conflict-detection|true|bool", "use-radius|no", "lease-script|", "relay|", "invalid|false|ro,bool", "dynamic|false|ro,bool"))
	M("/ip/dhcp-server/network", "DHCP Networks", cols("address,gateway,dns-server,domain"), flg("D:dynamic"), fl("address||req,prefix", "gateway|", "netmask|", "dns-server|", "domain|", "wins-server|", "ntp-server|", "dhcp-option|", "dynamic|false|ro,bool", "comment|"))
	M("/ip/dhcp-server/lease", "Leases", std(), cols("address,mac-address,host-name,server,status,last-seen"), flg("X:disabled,R:radius,D:dynamic,B:blocked"), cmds("make-static,check-status,send-reconfigure"),
		fl("address||req", "mac-address||req", "client-id|", "address-lists|", "server|all", "dhcp-option|", "rate-limit|", "lease-time|0s|dur", "block-access|false|bool", "always-broadcast|false|bool", "use-src-mac|false|bool", "insert-queue-before|", "status|waiting|ro", "expires-after||ro", "last-seen||ro", "active-address||ro", "active-mac-address||ro", "active-client-id||ro", "active-server||ro", "host-name||ro", "radius|false|ro,bool", "dynamic|false|ro,bool", "blocked|false|ro,bool"))
	M("/ip/dhcp-server/option", "DHCP Options", uniq("name"), cols("name,code,value"), fl("name||req", "code||req,int", "value|", "force|false|bool"))
	M("/ip/dhcp-client", "DHCP Client", std(), cols("interface,use-peer-dns,add-default-route,status,address"), flg("X:disabled,I:invalid,D:dynamic"), cmds("renew,release"),
		fl("interface||req,ref=/interface", "add-default-route|yes", "default-route-distance|1|int", "use-peer-dns|true|bool", "use-peer-ntp|true|bool", "dhcp-options|hostname,clientid", "script|", "status||ro", "address||ro", "gateway||ro", "dhcp-server||ro", "primary-dns||ro", "secondary-dns||ro", "expires-after||ro", "invalid|false|ro,bool", "dynamic|false|ro,bool"))
	M("/ip/dhcp-relay", "DHCP Relay", std(), uniq("name"), cols("name,interface,dhcp-server,local-address"), fl("name||req", "interface||req,ref=/interface", "dhcp-server||req", "local-address|0.0.0.0", "delay-threshold|none", "add-relay-info|false|bool", "invalid|false|ro,bool"))
	M("/ip/arp", "ARP", std(), cols("address,mac-address,interface,status"), flg("X:disabled,I:invalid,H:DHCP,D:dynamic,P:published,C:complete"),
		fl("address||req,ip", "mac-address|", "interface||req,ref=/interface", "published|false|bool", "status||ro", "invalid|false|ro,bool", "DHCP|false|ro,bool", "dynamic|false|ro,bool", "complete|true|ro,bool"))
	M("/ip/firewall/filter", "Filter Rules", std(), ordered(), detail(), cols("chain,action,src-address,dst-address,protocol,dst-port,in-interface,out-interface,bytes,packets"), flg("X:disabled,I:invalid,D:dynamic"), cmds("move,reset-counters,reset-counters-all"), fl(split(fwCommon)...))
	M("/ip/firewall/nat", "NAT", std(), ordered(), detail(), cols("chain,action,src-address,dst-address,protocol,dst-port,out-interface,to-addresses,to-ports,bytes,packets"), flg("X:disabled,I:invalid,D:dynamic"), cmds("move,reset-counters,reset-counters-all"), fl(append(split(fwCommon), "to-addresses|", "to-ports|")...))
	M("/ip/firewall/mangle", "Mangle", std(), ordered(), detail(), cols("chain,action,src-address,dst-address,protocol,new-packet-mark,new-connection-mark,bytes,packets"), flg("X:disabled,I:invalid,D:dynamic"), cmds("move,reset-counters,reset-counters-all"), fl(append(split(fwCommon), "new-connection-mark|", "new-packet-mark|", "new-routing-mark|", "new-mss|", "passthrough|true|bool")...))
	M("/ip/firewall/raw", "Raw", std(), ordered(), detail(), cols("chain,action,src-address,dst-address,protocol,bytes,packets"), flg("X:disabled,I:invalid,D:dynamic"), cmds("move,reset-counters,reset-counters-all"), fl(split(fwCommon)...))
	M("/ip/firewall/address-list", "Address Lists", std(), cols("list,address,creation-time,timeout"), flg("X:disabled,D:dynamic"), fl("list||req", "address||req", "timeout|", "creation-time||ro", "dynamic|false|ro,bool"))
	M("/ip/firewall/connection", "Connections", dyn(), cols("protocol,src-address,dst-address,tcp-state,timeout,orig-rate,repl-rate"), flg("E:expected,S:seen-reply,A:assured,C:confirmed,D:dying,F:fasttrack,s:srcnat,d:dstnat"),
		fl("protocol||ro", "src-address||ro", "dst-address||ro", "reply-src-address||ro", "reply-dst-address||ro", "tcp-state||ro", "timeout||ro", "orig-packets||ro", "orig-bytes||ro", "repl-packets||ro", "repl-bytes||ro", "orig-rate||ro", "repl-rate||ro", "connection-mark||ro", "assured|false|ro,bool", "confirmed|false|ro,bool", "seen-reply|false|ro,bool", "srcnat|false|ro,bool", "dstnat|false|ro,bool", "fasttrack|false|ro,bool", "expected|false|ro,bool", "dying|false|ro,bool"))
	M("/ip/firewall/layer7-protocol", "Layer7 Protocols", uniq("name"), cols("name,regexp"), fl("name||req", "regexp|", "comment|"))
	M("/ip/firewall/service-port", "Service Ports", noadd(), norm(), cols("name,ports"), flg("X:disabled,I:invalid"), fl("name||ro", "ports||ro", "sip-direct-media|true|bool", "invalid|false|ro,bool", "disabled|false|bool"))
	M("/ip/service", "IP Services", noadd(), norm(), uniq("name"), cols("name,port,address,certificate"), flg("X:disabled,I:invalid"),
		fl("name||ro", "port||int", "address|", "certificate|none", "tls-version|any", "vrf|main", "max-sessions|20|int", "proto|tcp|ro", "invalid|false|ro,bool", "dynamic|false|ro,bool", "disabled|false|bool"))
	M("/ip/neighbor", "Neighbors", dyn(), cols("interface,address,mac-address,identity,version,board"),
		fl("interface||ro", "address||ro", "address4||ro", "address6||ro", "mac-address||ro", "identity||ro", "platform||ro", "version||ro", "unpack||ro", "age||ro", "uptime||ro", "software-id||ro", "board||ro", "ipv6|false|ro,bool", "interface-name||ro", "system-description||ro", "system-caps||ro", "system-caps-enabled||ro", "discovered-by||ro"))
	M("/ip/neighbor/discovery-settings", "Discovery Settings", single(), fl("discover-interface-list|LAN", "protocol|cdp,lldp,mndp", "mode|tx-and-rx", "lldp-med-net-policy-vlan|disabled"))
	M("/ip/cloud", "IP Cloud", single(), cmds("force-update"), fl("ddns-enabled|false", "ddns-update-interval|none", "update-time|true|bool", "public-address||ro", "dns-name||ro", "status||ro", "back-to-home-vpn|revoked-and-disabled"))
	M("/ip/settings", "IP Settings", single(), fl("ip-forward|true|bool", "send-redirects|true|bool", "accept-source-route|false|bool", "accept-redirects|false|bool", "secure-redirects|true|bool", "rp-filter|no", "tcp-syncookies|false|bool", "max-neighbor-entries|8192|int", "arp-timeout|30s|dur", "icmp-rate-limit|10|int", "allow-fast-path|true|bool", "ipv4-fast-path-active|true|ro,bool"))
	M("/ip/ssh", "SSH Settings", single(), fl("strong-crypto|false|bool", "allow-none-crypto|false|bool", "forwarding-enabled|no", "always-allow-password-login|false|bool", "host-key-size|2048|int", "host-key-type|rsa"))
	M("/ip/upnp", "UPnP", single(), fl("enabled|false|bool", "allow-disable-external-interface|false|bool", "show-dummy-rule|true|bool"))
	M("/ip/proxy", "Web Proxy", single(), fl("enabled|false|bool", "port|8080|int", "anonymous|false|bool", "parent-proxy|::", "cache-administrator|webmaster", "max-cache-size|unlimited", "cache-on-disk|false|bool"))
	M("/ip/socks", "SOCKS", single(), fl("enabled|false|bool", "port|1080|int", "version|4", "connection-idle-timeout|2m|dur", "max-connections|200|int"))
	M("/ip/traffic-flow", "Traffic Flow", single(), fl("enabled|false|bool", "interfaces|all", "cache-entries|32k", "active-flow-timeout|30m|dur", "inactive-flow-timeout|15s|dur"))

	// ---------------- HOTSPOT ----------------
	M("/ip/hotspot", "Hotspot Servers", std(), uniq("name"), cols("name,interface,address-pool,profile,idle-timeout"), flg("X:disabled,I:invalid,S:HTTPS"), cmds("setup,reset-html"),
		fl("name||req", "interface||req,ref=/interface", "address-pool|none", "profile|default|ref=/ip/hotspot/profile", "idle-timeout|5m|dur", "keepalive-timeout|none", "login-timeout|none", "addresses-per-mac|2", "proxy-status||ro", "invalid|false|ro,bool", "HTTPS|false|ro,bool"))
	M("/ip/hotspot/profile", "Server Profiles", uniq("name"), cols("name,dns-name,hotspot-address,html-directory,rate-limit"), flg("*:default"),
		fl("name||req", "hotspot-address|", "dns-name|", "html-directory|hotspot", "html-directory-override|", "rate-limit|", "http-proxy|0.0.0.0:0", "smtp-server|0.0.0.0", "login-by|cookie,http-chap", "http-cookie-lifetime|3d|dur", "split-user-domain|false|bool", "use-radius|false|bool", "radius-accounting|true|bool", "radius-interim-update|received", "nas-port-type|wireless-802.11", "radius-default-domain|", "radius-location-id|", "radius-location-name|", "radius-mac-format|XX:XX:XX:XX:XX:XX", "trial-uptime-limit|30m|dur", "trial-uptime-reset|1d|dur", "trial-user-profile|default", "install-hotspot-queue|false|bool", "default|false|ro,bool"))
	M("/ip/hotspot/user", "Users", std(), uniq("name"), cols("server,name,address,profile,uptime,bytes-in,bytes-out"), flg("*:default,X:disabled,D:dynamic"), cmds("reset-counters"),
		fl("server|all|ref=/ip/hotspot,extra=all", "name||req", "password|", "address|", "mac-address|", "profile|default|ref=/ip/hotspot/user/profile", "routes|", "email|", "limit-uptime||dur", "limit-bytes-in||int", "limit-bytes-out||int", "limit-bytes-total||int", "uptime|0s|ro,dur", "bytes-in|0|ro,int", "bytes-out|0|ro,int", "packets-in|0|ro,int", "packets-out|0|ro,int", "dynamic|false|ro,bool", "default|false|ro,bool"))
	M("/ip/hotspot/user/profile", "User Profiles", uniq("name"), cols("name,shared-users,rate-limit,session-timeout"), flg("*:default"),
		fl("name||req", "address-pool|none", "idle-timeout|none", "keepalive-timeout|2m|dur", "status-autorefresh|1m|dur", "shared-users|1", "rate-limit|", "session-timeout||dur", "add-mac-cookie|true|bool", "mac-cookie-timeout|3d|dur", "address-list|", "transparent-proxy|false|bool", "open-status-page|always", "advertise|false|bool", "on-login||text", "on-logout||text", "parent-queue|none", "queue-type|default-small", "insert-queue-before|first", "incoming-filter|", "outgoing-filter|", "incoming-packet-mark|", "outgoing-packet-mark|", "default|false|ro,bool"))
	M("/ip/hotspot/active", "Active", dyn(), cols("server,user,address,mac-address,uptime,session-time-left,bytes-in,bytes-out"), flg("R:radius,B:blocked"), cmds("login"),
		fl("server||ro", "user||ro", "domain||ro", "address||ro", "mac-address||ro", "login-by||ro", "uptime||ro,dur", "session-time-left||ro,dur", "idle-time||ro,dur", "idle-timeout||ro", "keepalive-timeout||ro", "bytes-in|0|ro,int", "bytes-out|0|ro,int", "packets-in|0|ro,int", "packets-out|0|ro,int", "limit-bytes-in||ro,int", "limit-bytes-out||ro,int", "limit-bytes-total||ro,int", "radius|false|ro,bool", "blocked|false|ro,bool", "comment|"))
	M("/ip/hotspot/host", "Hosts", dyn(), cols("mac-address,address,to-address,server,uptime,idle-time"), flg("S:static,H:DHCP,D:dynamic,A:authorized,P:bypassed"), cmds("make-binding"),
		fl("mac-address||ro", "address||ro", "to-address||ro", "server||ro", "uptime||ro,dur", "idle-time||ro,dur", "idle-timeout||ro", "keepalive-timeout||ro", "host-dead-time||ro", "bytes-in|0|ro,int", "bytes-out|0|ro,int", "packets-in|0|ro,int", "packets-out|0|ro,int", "found-by||ro", "authorized|false|ro,bool", "bypassed|false|ro,bool", "DHCP|false|ro,bool", "dynamic|true|ro,bool", "static|false|ro,bool", "comment|"))
	M("/ip/hotspot/ip-binding", "IP Bindings", std(), cols("mac-address,address,to-address,server,type"), flg("X:disabled,P:bypassed,B:blocked,D:dynamic"),
		fl("mac-address|", "address|", "to-address|", "server|all", "type|regular|enum=regular/bypassed/blocked", "dynamic|false|ro,bool", "bypassed|false|ro,bool", "blocked|false|ro,bool"))
	M("/ip/hotspot/walled-garden", "Walled Garden", std(), cols("server,src-address,dst-host,dst-port,path,action,hits"), flg("X:disabled,D:dynamic"),
		fl("action|allow|enum=allow/deny", "server|", "src-address|", "dst-address|", "dst-host|", "dst-port|", "path|", "method|", "hits|0|ro,int", "dynamic|false|ro,bool"))
	M("/ip/hotspot/walled-garden/ip", "Walled Garden IP", std(), cols("server,src-address,dst-address,dst-host,protocol,dst-port,action"), flg("X:disabled,D:dynamic"),
		fl("action|accept|enum=accept/drop/reject", "server|", "src-address|", "dst-address|", "dst-host|", "protocol|", "dst-port|", "dynamic|false|ro,bool"))
	M("/ip/hotspot/cookie", "Cookies", dyn(), cols("user,domain,mac-address,expires-in"), fl("user||ro", "domain||ro", "mac-address||ro", "expires-in||ro,dur", "mac-cookie|false|ro,bool"))
	M("/ip/hotspot/service-port", "Service Ports", noadd(), norm(), cols("name,ports"), fl("name||ro", "ports||ro", "disabled|false|bool"))

	// ---------------- PPP ----------------
	M("/ppp/secret", "Secrets", std(), uniq("name"), cols("name,service,caller-id,password,profile,remote-address,last-logged-out"), flg("X:disabled"),
		fl("name||req", "password|", "service|any|enum=any/async/l2tp/ovpn/pppoe/pptp/sstp", "caller-id|", "profile|default|ref=/ppp/profile", "local-address|", "remote-address|", "routes|", "ipv6-routes|", "limit-bytes-in|0|int", "limit-bytes-out|0|int", "last-logged-out||ro", "last-caller-id||ro", "last-disconnect-reason||ro"))
	M("/ppp/profile", "Profiles", uniq("name"), cols("name,local-address,remote-address,bridge,rate-limit,only-one"), flg("*:default"),
		fl("name||req", "local-address|", "remote-address|", "remote-ipv6-prefix-pool|", "dhcpv6-pd-pool|", "bridge|", "bridge-learning|default", "incoming-filter|", "outgoing-filter|", "address-list|", "interface-list|", "dns-server|", "wins-server|", "use-ipv6|default", "use-mpls|default", "use-compression|default", "use-encryption|default", "use-upnp|default", "only-one|default", "change-tcp-mss|default", "rate-limit|", "parent-queue|", "queue-type|", "insert-queue-before|", "session-timeout||dur", "idle-timeout||dur", "on-up||text", "on-down||text", "default|false|ro,bool", "comment|"))
	M("/ppp/active", "Active Connections", dyn(), cols("name,service,caller-id,encoding,address,uptime"), flg("R:radius"),
		fl("name||ro", "service||ro", "caller-id||ro", "encoding||ro", "address||ro", "uptime||ro,dur", "session-id||ro", "limit-bytes-in||ro", "limit-bytes-out||ro", "radius|false|ro,bool", "comment|"))
	M("/ppp/aaa", "PPP Authentication&Accounting", single(), fl("use-radius|false|bool", "accounting|true|bool", "interim-update|0s|dur", "use-circuit-id-in-nas-port-id|false|bool", "enable-ipv6-accounting|false|bool"))

	// ---------------- QUEUES ----------------
	M("/queue/simple", "Simple Queues", std(), uniq("name"), ordered(), cols("name,target,max-limit,rate,total-bytes"), flg("X:disabled,I:invalid,D:dynamic"), cmds("move,reset-counters,reset-counters-all"),
		fl("name||req", "target||req", "dst|", "parent|none", "packet-marks|", "priority|8/8", "queue|default-small/default-small", "limit-at|0/0", "max-limit|0/0", "burst-limit|0/0", "burst-threshold|0/0", "burst-time|0s/0s", "bucket-size|0.1/0.1", "time|", "rate|0/0|ro", "packet-rate|0/0|ro", "queued-bytes|0/0|ro", "queued-packets|0/0|ro", "bytes|0/0|ro", "total-bytes|0|ro,int", "packets|0/0|ro", "total-packets|0|ro,int", "dropped|0/0|ro", "total-dropped|0|ro,int", "invalid|false|ro,bool", "dynamic|false|ro,bool"))
	M("/queue/tree", "Queue Tree", std(), uniq("name"), cols("name,parent,packet-mark,limit-at,max-limit,rate"), flg("X:disabled,I:invalid"), cmds("reset-counters,reset-counters-all"),
		fl("name||req", "parent||req", "packet-mark|", "limit-at|0", "queue|default-small", "priority|8|int", "max-limit|0", "burst-limit|0", "burst-threshold|0", "burst-time|0s|dur", "bucket-size|0.1", "rate|0|ro,int", "packet-rate|0|ro,int", "queued-bytes|0|ro,int", "queued-packets|0|ro,int", "bytes|0|ro,int", "packets|0|ro,int", "dropped|0|ro,int", "invalid|false|ro,bool"))
	M("/queue/type", "Queue Types", uniq("name"), cols("name,kind"), flg("*:default"), fl("name||req", "kind|pfifo|enum=bfifo/cake/fq-codel/mq-pfifo/none/pcq/pfifo/red/sfq", "pfifo-limit|50|int", "pcq-rate|0", "pcq-limit|50KiB", "pcq-classifier|", "pcq-total-limit|2000KiB", "default|false|ro,bool"))

	// ---------------- MISC ----------------
	M("/radius", "RADIUS", std(), cols("service,address,secret,authentication-port,accounting-port"), flg("X:disabled"),
		fl("service|", "called-id|", "domain|", "address||req", "secret|", "authentication-port|1812|int", "accounting-port|1813|int", "timeout|300ms", "accounting-backup|false|bool", "realm|", "src-address|0.0.0.0", "certificate|none", "protocol|udp"))
	M("/radius/incoming", "RADIUS Incoming", single(), fl("accept|false|bool", "port|3799|int"))
	M("/snmp", "SNMP", single(), fl("enabled|false|bool", "contact|", "location|", "engine-id-suffix|", "engine-id||ro", "trap-target|", "trap-community|public", "trap-version|1", "trap-generators|temp-exception", "trap-interfaces|"))
	M("/snmp/community", "SNMP Communities", uniq("name"), cols("name,addresses,security,read-access,write-access"), flg("*:default"), fl("name||req", "addresses|::/0", "security|none", "read-access|true|bool", "write-access|false|bool", "authentication-protocol|MD5", "encryption-protocol|DES", "default|false|ro,bool", "disabled|false|bool"))
	M("/certificate", "Certificates", uniq("name"), cols("name,common-name,subject-alt-name,fingerprint,trusted"), flg("K:private-key,L:crl,C:smart-card-key,A:authority,I:issued,R:revoked,E:expired,T:trusted"), cmds("sign,import,export-certificate"),
		fl("name||req", "common-name|", "country|", "state|", "locality|", "organization|", "unit|", "subject-alt-name|", "key-size|2048", "days-valid|365|int", "key-usage|", "trusted|false|bool", "fingerprint||ro", "issuer||ro", "invalid-before||ro", "invalid-after||ro", "expires-after||ro", "private-key|false|ro,bool", "authority|false|ro,bool", "issued|false|ro,bool", "expired|false|ro,bool"))
	M("/certificate/settings", "Certificate Settings", single(), fl("builtin-trust-anchors|trusted|enum=trusted/not-trusted", "crl-download|false|bool", "crl-use|false|bool", "crl-store|ram|enum=ram/system"))
	M("/file", "Files", uniq("name"), cols("name,type,size,last-modified"),
		fl("name||req", "type|file", "size|0|ro,int", "creation-time||ro", "last-modified||ro", "contents||text"))
	M("/tool/netwatch", "Netwatch", std(), cols("host,type,interval,timeout,status,since"), flg("X:disabled"),
		fl("host||req", "type|simple|enum=simple/icmp/tcp-conn/http-get/dns", "interval|10s|dur", "timeout|1s", "status|unknown|ro", "since||ro", "up-script||text", "down-script||text", "test-script||text"))
	M("/tool/bandwidth-server", "Bandwidth Server", single(), fl("enabled|true|bool", "authenticate|true|bool", "max-sessions|100|int", "allocate-udp-ports-from|2000|int"))
	M("/tool/mac-server", "MAC Server", single(), fl("allowed-interface-list|all"))
	M("/tool/mac-server/mac-winbox", "MAC WinBox Server", single(), fl("allowed-interface-list|all"))
	M("/tool/romon", "RoMON", single(), fl("enabled|false|bool", "id|00:00:00:00:00:00", "secrets|"))
	M("/tool/e-mail", "Email", single(), fl("server|0.0.0.0", "port|25|int", "from|<>", "user|", "password||hide", "tls|no"))
	M("/tool/graphing/interface", "Interface Graphing", std(), cols("interface,allow-address,store-on-disk"), fl("interface|all", "allow-address|0.0.0.0/0", "store-on-disk|true|bool"))
	M("/ipv6/address", "IPv6 Addresses", std(), cols("address,from-pool,interface,advertise"), flg("X:disabled,I:invalid,D:dynamic,G:global,L:link-local"),
		fl("address||req", "from-pool|", "interface||req,ref=/interface", "eui-64|false|bool", "advertise|true|bool", "no-dad|false|bool", "actual-interface||ro", "link-local|false|ro,bool", "global|false|ro,bool", "invalid|false|ro,bool", "dynamic|false|ro,bool"))
	M("/ipv6/settings", "IPv6 Settings", single(), fl("disable-ipv6|false|bool", "forward|true|bool", "accept-redirects|yes-if-forwarding-disabled", "accept-router-advertisements|yes-if-forwarding-disabled", "max-neighbor-entries|8192|int"))

	// ---------------- SIMULATOR (TikLab only) ----------------
	M("/sim/settings", "Simulator Settings", single(),
		fl("auto-hotspot-clients|false|bool", "max-hotspot-clients|8|int", "auto-pppoe-clients|true|bool", "lan-devices|4|int", "traffic-level|medium|enum=low/medium/high/extreme", "wan-online|true|bool", "boot-time|6s|dur", "auto-login-vouchers|true|bool",
			"pc-wifi|false|bool", "pc-wifi-interface|auto", "pc-wifi-password|", "pc-wifi-captive|true|bool"))
	M("/sim/client", "Virtual Clients", std(), cols("name,kind,mac-address,address,interface,port,status,hotspot-user,pppoe-secret"), flg("X:disabled,D:dynamic"), cmds("login,logout,connect,disconnect"),
		fl("name||req", "kind|phone|enum=phone/laptop/desktop/tablet/tv/iot/cpe/router", "mac-address|", "address||ro", "interface||req,ref=/interface", "port||ref=/interface", "status|disconnected|ro", "hotspot-user||ro", "pppoe-secret|", "usage|auto|enum=auto/idle/browsing/streaming/heavy", "dynamic|false|ro,bool", "pc-wifi|false|ro,bool", "pc-address||ro"))
	M("/sim/models", "Router Models", dyn(), norm(), noset(), cols("key,board,model,family,ports,current"),
		fl("key||ro", "board||ro", "model||ro", "family||ro", "ports||ro", "cpu||ro", "memory||ro", "wireless||ro", "description||ro", "current|false|ro,bool"))
	M("/sim/port", "Ports & Cables", noadd(), norm(), cols("interface,cable,speed,cable-color"), cmds("plug,unplug"),
		fl("interface||ro", "cable|true|bool", "speed|1G|enum=10M/100M/1G/2.5G/10G", "cable-color|blue|enum=blue/yellow/green/red/grey/white/orange/purple"))

	for _, m := range Menus {
		parts := strings.Split(strings.Trim(m.Path, "/"), "/")
		for i := 1; i < len(parts); i++ {
			Dirs["/"+strings.Join(parts[:i], "/")] = true
		}
		Dirs[m.Path] = true
	}
	for _, p := range []string{"/system", "/tool", "/ip", "/ipv6", "/routing", "/interface", "/ppp", "/queue", "/sim"} {
		Dirs[p] = true
	}
}

// Generic commands valid on list / single menus.
var listCmds = []string{"add", "comment", "disable", "enable", "export", "find", "get", "print", "remove", "set", "unset", "listen", "getall"}
var singleCmds = []string{"export", "get", "print", "set", "listen", "getall"}

// Top-level / special commands: path → description
var SpecialCmds = map[string]string{
	"/system/reboot":              "Reboot the router",
	"/system/shutdown":            "Shut the router down",
	"/system/reset-configuration": "Reset configuration to defaults",
	"/system/backup/save":         "Save configuration backup",
	"/system/backup/load":         "Load configuration backup",
	"/system/check-installation":  "Check installation",
	"/ping":                       "Send ICMP echo requests",
	"/tool/ping":                  "Send ICMP echo requests",
	"/tool/traceroute":            "Trace route to host",
	"/tool/bandwidth-test":        "Run bandwidth test",
	"/tool/fetch":                 "Fetch a file",
	"/export":                     "Export configuration",
	"/import":                     "Import script file",
	"/password":                   "Change password",
	"/quit":                       "Quit console",
	"/beep":                       "Beep",
	"/sim/power-on":               "Power on the simulated router",
	"/sim/generate-vouchers":      "Generate hotspot voucher users",
	"/sim/change-model":           "Switch to another router model (reboots)",
	"/sim/factory-defaults":       "Reset simulator to factory defaults",
}
