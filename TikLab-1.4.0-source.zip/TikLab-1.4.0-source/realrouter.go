package main

// Working with real MikroTik routers: test, clone (read-only) and send.
// TikLab prefers the RouterOS API and falls back to SSH when the API port is
// off or blocked. Files and hotspot pages go over FTP, or SCP when only SSH
// is open.

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"net"
	"path"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

type RealOpts struct {
	Host     string `json:"host"`
	User     string `json:"user"`
	Password string `json:"password"`
	APIPort  int    `json:"apiPort"`
	FTPPort  int    `json:"ftpPort"`
	SSHPort  int    `json:"sshPort"`
	Method   string `json:"method"` // auto | api | ssh
	TLS      bool   `json:"tls"`
	Files    bool   `json:"files"`
	Script   string `json:"script"`
	FileName string `json:"fileName"`
	Run      bool   `json:"run"`
	PagesDir string `json:"pagesDir"`
}

func (o *RealOpts) apiAddr() string {
	p := o.APIPort
	if p == 0 {
		p = 8728
		if o.TLS {
			p = 8729
		}
	}
	return net.JoinHostPort(o.Host, strconv.Itoa(p))
}
func (o *RealOpts) ftpAddr() string {
	return net.JoinHostPort(o.Host, strconv.Itoa(firstPort(o.FTPPort, 21)))
}
func (o *RealOpts) sshAddr() string {
	return net.JoinHostPort(o.Host, strconv.Itoa(firstPort(o.SSHPort, 22)))
}
func (o *RealOpts) useAPI() bool    { return o.Method != "ssh" }
func (o *RealOpts) mayUseSSH() bool { return o.Method != "api" }

// RealError carries what went wrong plus the port diagnosis.
type RealError struct {
	Msg  string
	Diag *Diagnosis
}

func (e *RealError) Error() string { return e.Msg }

// connect opens the API, or SSH when the API cannot be reached and the
// method allows it. Exactly one of the returned clients is non-nil.
func (o *RealOpts) connect(log func(string)) (*APIClient, *SSHClient, error) {
	var apiErr error
	if o.useAPI() {
		cl, err := dialAPI(o.apiAddr(), o.User, o.Password, o.TLS)
		if err == nil {
			return cl, nil, nil
		}
		apiErr = err
		if !o.mayUseSSH() || !isNetErr(err) {
			return nil, nil, o.fail(friendlyNetErr("API", o.apiAddr(), err).Error(), err)
		}
		log(friendlyNetErr("API", o.apiAddr(), err).Error() + ". Trying SSH instead.")
	}
	sc, err := sshDial(o.sshAddr(), o.User, o.Password)
	if err == nil {
		return nil, sc, nil
	}
	var msgs []string
	if apiErr != nil {
		msgs = append(msgs, friendlyNetErr("API", o.apiAddr(), apiErr).Error())
	}
	msgs = append(msgs, friendlyNetErr("SSH", o.sshAddr(), err).Error())
	return nil, nil, o.fail(strings.Join(msgs, ". "), err)
}

// fail builds a RealError with a port diagnosis. cause is passed on when it
// is a refusal by the router (wrong password, missing policy).
func (o *RealOpts) fail(msg string, cause error) error {
	var login error
	if cause != nil && !isNetErr(cause) {
		login = cause
	}
	return &RealError{Msg: msg, Diag: diagnoseRouter(*o, login)}
}

func str(v any) string {
	s, _ := v.(string)
	return s
}

// ---------------- probe ----------------

var reHTMLDir = regexp.MustCompile(`html-directory(?:-override)?=("[^"]*"|[^\s"]+)`)

func probeRouter(o RealOpts) (map[string]any, error) {
	var notes []string
	cl, sc, err := o.connect(func(s string) { notes = append(notes, s) })
	if err != nil {
		return nil, err
	}
	out := map[string]any{}
	var dirs []string
	if cl != nil {
		defer cl.Close()
		out["via"] = "API"
		if res, _, err := cl.Exec("/system/resource/print", nil, nil); err == nil && len(res) > 0 {
			out["board"] = res[0]["board-name"]
			out["version"] = res[0]["version"]
			out["uptime"] = res[0]["uptime"]
		}
		if id, _, err := cl.Exec("/system/identity/print", nil, nil); err == nil && len(id) > 0 {
			out["identity"] = id[0]["name"]
		}
		if rb, _, err := cl.Exec("/system/routerboard/print", nil, nil); err == nil && len(rb) > 0 && rb[0]["model"] != "" {
			out["model"] = rb[0]["model"]
		}
		if hp, _, err := cl.Exec("/ip/hotspot/profile/print", nil, nil); err == nil {
			for _, p := range hp {
				if d := firstNonEmpty(p["html-directory-override"], p["html-directory"]); d != "" {
					dirs = append(dirs, d)
				}
			}
		}
	} else {
		defer sc.Close()
		out["via"] = "SSH"
		info := sc.sysInfo()
		for k, v := range info {
			out[k] = v
		}
		dirs = sc.hotspotDirs()
	}
	if md := matchModel(firstNonEmpty(str(out["model"]), str(out["board"]))); md != nil {
		out["matchKey"], out["matchBoard"] = md.Key, md.Board
	} else if md := matchModel(str(out["board"])); md != nil {
		out["matchKey"], out["matchBoard"] = md.Key, md.Board
	}
	out["hotspotDirs"] = uniqStrings(dirs)
	if f, err := ftpDial(o.ftpAddr(), o.User, o.Password); err == nil {
		out["ftp"] = true
		f.Close()
	} else {
		out["ftp"] = false
		out["ftpError"] = friendlyNetErr("FTP", o.ftpAddr(), err).Error()
		if !isNetErr(err) {
			out["ftpError"] = "FTP answered but refused the login: " + err.Error()
		}
	}
	out["notes"] = notes
	return out, nil
}

func uniqStrings(in []string) []string {
	seen := map[string]bool{}
	out := []string{}
	for _, s := range in {
		s = strings.Trim(s, `"`)
		if s != "" && !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	return out
}

// ---------------- clone ----------------

// cloneRouter reads a real router's configuration without changing it and
// returns it as an import script. Hotspot pages are copied over FTP.
func (r *Router) cloneRouter(o RealOpts, log func(string)) (string, []string, error) {
	cl, sc, err := o.connect(log)
	if err != nil {
		return "", nil, err
	}
	var script string
	var dirs []string
	if cl != nil {
		defer cl.Close()
		script, dirs = r.cloneAPI(cl, o, log)
	} else {
		defer sc.Close()
		script, dirs, err = sc.cloneSSH(o, log)
		if err != nil {
			return "", nil, &RealError{Msg: err.Error()}
		}
	}
	var files []string
	if o.Files {
		files = r.copyPages(o, sc, uniqStrings(dirs), log)
	}
	return script, files, nil
}

func (r *Router) cloneAPI(cl *APIClient, o RealOpts, log func(string)) (string, []string) {
	var b strings.Builder
	model, ver := "", ""
	if res, _, err := cl.Exec("/system/resource/print", nil, nil); err == nil && len(res) > 0 {
		ver = strings.Fields(res[0]["version"] + " ?")[0]
		model = res[0]["board-name"]
	}
	if rb, _, err := cl.Exec("/system/routerboard/print", nil, nil); err == nil && len(rb) > 0 && rb[0]["model"] != "" {
		model = rb[0]["model"]
	}
	fmt.Fprintf(&b, "# %s cloned by TikLab from %s (RouterOS %s)\n", time.Now().Format("2006-01-02 15:04:05"), o.Host, ver)
	fmt.Fprintf(&b, "# by RouterOS %s\n# model = %s\n", ver, model)
	log(fmt.Sprintf("Connected to %s over the API (%s, RouterOS %s)", o.Host, model, ver))
	physByName := map[string]string{}
	if ifs, _, err := cl.Exec("/interface/print", nil, nil); err == nil {
		for _, it := range ifs {
			if dn := it["default-name"]; dn != "" {
				physByName[it["name"]] = dn
			}
		}
	}
	read := 0
	for _, p := range exportSeq {
		m := MenuMap[p]
		if m == nil || p == "/ip/service" {
			continue
		}
		items, _, err := cl.Exec(p+"/print", nil, nil)
		if err != nil {
			continue
		}
		read++
		lines := exportMenu(m, items, ExportOpts{Sensitive: true}, func(s string) (string, bool) { return s, true }, physByName, func(string) {})
		if len(lines) == 0 {
			continue
		}
		b.WriteString(p[0:1] + strings.ReplaceAll(p[1:], "/", " ") + "\n")
		for _, l := range lines {
			b.WriteString(l + "\n")
		}
	}
	log(fmt.Sprintf("Read %d menus over the API (read-only, nothing was changed on the router)", read))
	var dirs []string
	if hp, _, err := cl.Exec("/ip/hotspot/profile/print", nil, nil); err == nil {
		for _, p := range hp {
			if d := firstNonEmpty(p["html-directory-override"], p["html-directory"]); d != "" {
				dirs = append(dirs, d)
			}
		}
	}
	return b.String(), dirs
}

func (r *Router) copyPages(o RealOpts, sc *SSHClient, dirs []string, log func(string)) []string {
	var files []string
	if len(dirs) == 0 {
		log("No hotspot html-directory configured on the router, so no pages to copy")
		return nil
	}
	var f *FTPClient
	err := fmt.Errorf("not used")
	if o.Method != "ssh" {
		f, err = ftpDial(o.ftpAddr(), o.User, o.Password)
	}
	if err != nil {
		ftpMsg := friendlyNetErr("FTP", o.ftpAddr(), err).Error()
		if o.Method == "ssh" {
			ftpMsg = "SSH only was chosen"
		}
		if o.mayUseSSH() {
			if sc == nil {
				c, serr := sshDial(o.sshAddr(), o.User, o.Password)
				if serr != nil {
					log("Hotspot pages were not copied: " + ftpMsg + ", and " + friendlyNetErr("SSH", o.sshAddr(), serr).Error())
					return nil
				}
				sc = c
				defer c.Close()
			}
			if o.Method != "ssh" {
				log(ftpMsg + ". Copying the hotspot pages with SCP instead.")
			}
			return r.copyPagesSCP(sc, dirs, log)
		}
		log("Hotspot pages were not copied: " + ftpMsg + ". Turn FTP on with /ip service enable ftp and allow port 21 through the firewall.")
		return nil
	}
	defer f.Close()
	for _, d := range dirs {
		n := 0
		err := f.fetchTree(d, 64<<20, func(name string, data []byte) {
			r.mu.Lock()
			r.putFile(cleanPath(name), data)
			r.mu.Unlock()
			files = append(files, cleanPath(name))
			n++
		})
		msg := fmt.Sprintf("Copied %d files from %s via FTP", n, d)
		if err != nil {
			msg += " (" + err.Error() + ")"
		}
		log(msg)
	}
	return files
}

var reTerseName = regexp.MustCompile(`\bname=("(?:[^"\\]|\\.)*"|\S+)`)

// copyPagesSCP lists the router's files over SSH and downloads each file
// under the page folders with "scp -f".
func (r *Router) copyPagesSCP(sc *SSHClient, dirs []string, log func(string)) []string {
	out, err := sc.run("/file print terse", time.Minute)
	if err != nil {
		log("Hotspot pages were not copied: listing the router's files over SSH failed: " + err.Error())
		return nil
	}
	type ent struct {
		name string
		dir  bool
	}
	var all []ent
	for _, l := range strings.Split(out, "\n") {
		m := reTerseName.FindStringSubmatch(l)
		if m == nil {
			continue
		}
		name := m[1]
		if strings.HasPrefix(name, `"`) {
			if u, err := strconv.Unquote(name); err == nil {
				name = u
			} else {
				name = strings.Trim(name, `"`)
			}
		}
		all = append(all, ent{name, strings.Contains(l, "type=directory")})
	}
	var files []string
	for _, d := range dirs {
		d = cleanPath(d)
		n, total := 0, 0
		var failed []string
		for _, e := range all {
			if e.dir || !strings.HasPrefix(cleanPath(e.name), d+"/") {
				continue
			}
			data, err := sc.scpGet("/" + cleanPath(e.name))
			if err != nil {
				failed = append(failed, path.Base(e.name)+": "+err.Error())
				continue
			}
			if total += len(data); total > 64<<20 {
				failed = append(failed, "stopped at 64 MiB")
				break
			}
			r.mu.Lock()
			r.putFile(cleanPath(e.name), data)
			r.mu.Unlock()
			files = append(files, cleanPath(e.name))
			n++
		}
		msg := fmt.Sprintf("Copied %d files from %s via SCP", n, d)
		if n == 0 && len(failed) == 0 {
			msg = "The router has no files under " + d
		}
		if len(failed) > 0 {
			msg += " (" + strings.Join(failed[:min(len(failed), 3)], "; ") + ")"
		}
		log(msg)
	}
	return files
}

// ---------------- send ----------------

type pageFile struct {
	name string
	data []byte
	dir  bool
}

// sendToRouter uploads a script (and optionally a page folder) to a real
// router and optionally runs /import there.
func (r *Router) sendToRouter(o RealOpts, log func(string)) error {
	fname := path.Base(cleanPath(firstNonEmpty(o.FileName, "tiklab-config.rsc")))
	var list []pageFile
	if o.PagesDir != "" {
		dir := cleanPath(o.PagesDir)
		r.mu.Lock()
		for _, it := range r.filesUnder(dir) {
			list = append(list, pageFile{it["name"], fileBytes(it), it["type"] == "directory"})
		}
		r.mu.Unlock()
		sort.Slice(list, func(i, j int) bool { return list[i].name < list[j].name })
	}

	var sc *SSHClient
	sshTried := false
	getSSH := func() *SSHClient {
		if sc == nil && !sshTried && o.mayUseSSH() {
			sshTried = true
			c, err := sshDial(o.sshAddr(), o.User, o.Password)
			if err != nil {
				log(friendlyNetErr("SSH", o.sshAddr(), err).Error())
				return nil
			}
			sc = c
		}
		return sc
	}
	defer func() {
		if sc != nil {
			sc.Close()
		}
	}()

	var f *FTPClient
	var ferr error
	if o.Method == "ssh" {
		ferr = fmt.Errorf("not used")
	} else {
		f, ferr = ftpDial(o.ftpAddr(), o.User, o.Password)
		if ferr != nil {
			log(friendlyNetErr("FTP", o.ftpAddr(), ferr).Error())
		} else {
			defer f.Close()
		}
	}

	if o.Script != "" {
		uploaded := false
		if f != nil {
			if err := f.Stor(fname, []byte(o.Script)); err != nil {
				log("FTP upload of " + fname + " failed: " + err.Error())
			} else {
				uploaded = true
				log(fmt.Sprintf("Uploaded %s (%s) via FTP", fname, humanBytes(float64(len(o.Script)))))
			}
		}
		if !uploaded {
			if s := getSSH(); s != nil {
				if err := s.scpPut([]pageFile{{name: fname, data: []byte(o.Script)}}); err != nil {
					log("SCP upload of " + fname + " failed: " + err.Error())
				} else {
					uploaded = true
					log(fmt.Sprintf("Uploaded %s (%s) via SCP", fname, humanBytes(float64(len(o.Script)))))
				}
			}
		}
		if !uploaded && o.useAPI() {
			cl, err := dialAPI(o.apiAddr(), o.User, o.Password, o.TLS)
			if err == nil {
				if _, _, err := cl.Exec("/file/add", map[string]string{"name": fname, "contents": o.Script}, nil); err == nil {
					uploaded = true
					log("Uploaded " + fname + " through the API (/file add)")
				} else {
					log("API upload not supported on this RouterOS version: " + err.Error())
				}
				cl.Close()
			} else {
				log(friendlyNetErr("API", o.apiAddr(), err).Error())
			}
		}
		if !uploaded {
			return o.fail(fmt.Sprintf("could not upload %s: FTP, SCP and the API all failed. You can also drag the downloaded file into WinBox > Files", fname), nil)
		}
	}

	if len(list) > 0 {
		dir := cleanPath(o.PagesDir)
		switch {
		case f != nil:
			f.Mkd(dir)
			n := 0
			for _, x := range list {
				if x.dir {
					f.Mkd(x.name)
					continue
				}
				if err := f.Stor(x.name, x.data); err != nil {
					log("  " + x.name + ": " + err.Error())
					continue
				}
				n++
			}
			log(fmt.Sprintf("Uploaded %d hotspot page files into %s via FTP", n, dir))
		case getSSH() != nil:
			if err := sc.scpPut(append([]pageFile{{name: dir, dir: true}}, list...)); err != nil {
				log("SCP upload of " + dir + " failed: " + err.Error())
				return o.fail(fmt.Sprintf("hotspot pages could not be uploaded: %v", err), nil)
			}
			log(fmt.Sprintf("Uploaded the %s folder (%d files) via SCP", dir, countFiles(list)))
		default:
			return o.fail("hotspot pages need FTP or SSH, and neither is reachable", nil)
		}
	}

	if o.Run && o.Script != "" {
		time.Sleep(time.Second)
		if o.useAPI() {
			cl, err := dialAPI(o.apiAddr(), o.User, o.Password, o.TLS)
			if err == nil {
				defer cl.Close()
				if _, _, err = cl.Exec("/import", map[string]string{"file-name": fname}, nil); err != nil {
					log("Router reported: " + err.Error())
					return fmt.Errorf("the router stopped the import: %v", err)
				}
				log("Router ran /import file-name=" + fname + " successfully (API)")
				return nil
			}
			log(friendlyNetErr("API", o.apiAddr(), err).Error())
			if !isNetErr(err) {
				return o.fail(fmt.Sprintf("could not run /import: %v", friendlyNetErr("API", o.apiAddr(), err)), err)
			}
		}
		s := getSSH()
		if s == nil {
			return o.fail(fmt.Sprintf("the file is on the router, but /import could not be run because neither the API nor SSH is reachable. Run  /import file-name=%s  in a WinBox terminal", fname), nil)
		}
		res, err := s.run("/import file-name="+fname, 5*time.Minute)
		res = strings.TrimSpace(res)
		if res != "" {
			for _, l := range strings.Split(res, "\n") {
				log("Router: " + l)
			}
		}
		low := strings.ToLower(res)
		if err != nil && res == "" {
			return fmt.Errorf("/import over SSH failed: %v", err)
		}
		if strings.Contains(low, "successfully") && !strings.Contains(low, "error") {
			log("Router ran /import file-name=" + fname + " (SSH)")
			return nil
		}
		if strings.Contains(low, "failure") || strings.Contains(low, "error") || strings.Contains(low, "expected") || strings.Contains(low, "invalid") || strings.Contains(low, "bad command") {
			return fmt.Errorf("the router stopped the import, see its messages above")
		}
		log("Ran /import file-name=" + fname + " over SSH")
	}
	return nil
}

func countFiles(l []pageFile) int {
	n := 0
	for _, x := range l {
		if !x.dir {
			n++
		}
	}
	return n
}

// ---------------- SSH client ----------------

type SSHClient struct {
	c    *ssh.Client
	addr string
}

func sshDial(addr, user, pass string) (*SSHClient, error) {
	cfg := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.Password(pass),
			ssh.KeyboardInteractive(func(name, instr string, qs []string, echos []bool) ([]string, error) {
				ans := make([]string, len(qs))
				for i := range ans {
					ans[i] = pass
				}
				return ans, nil
			}),
		},
		// Lab tool: routers use self-generated host keys, so none is pinned.
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         6 * time.Second,
		Config: ssh.Config{
			// Older RouterOS v6 builds only offer these.
			KeyExchanges: []string{"curve25519-sha256", "curve25519-sha256@libssh.org", "ecdh-sha2-nistp256", "ecdh-sha2-nistp384", "ecdh-sha2-nistp521", "diffie-hellman-group14-sha256", "diffie-hellman-group14-sha1", "diffie-hellman-group1-sha1"},
			Ciphers:      []string{"aes128-gcm@openssh.com", "chacha20-poly1305@openssh.com", "aes128-ctr", "aes192-ctr", "aes256-ctr", "aes128-cbc", "3des-cbc"},
		},
	}
	c, err := ssh.Dial("tcp", addr, cfg)
	if err != nil {
		if strings.Contains(err.Error(), "unable to authenticate") {
			return nil, &Trap{Msg: "invalid user name or password (SSH)"}
		}
		return nil, err
	}
	return &SSHClient{c: c, addr: addr}, nil
}

func (s *SSHClient) Close() { s.c.Close() }

// run executes one RouterOS command line and returns its output with
// RouterOS's CRLF line ends turned into LF.
func (s *SSHClient) run(cmd string, timeout time.Duration) (string, error) {
	sess, err := s.c.NewSession()
	if err != nil {
		return "", err
	}
	defer sess.Close()
	buf := &lockedBuffer{}
	sess.Stdout = buf // the SSH library copies stdout and stderr in separate goroutines
	sess.Stderr = buf
	done := make(chan error, 1)
	go func() { done <- sess.Run(cmd) }()
	select {
	case err = <-done:
	case <-time.After(timeout):
		err = fmt.Errorf("no answer after %s", timeout)
	}
	out := strings.ReplaceAll(buf.String(), "\r\n", "\n")
	out = strings.ReplaceAll(out, "\r", "")
	if _, ok := err.(*ssh.ExitError); ok {
		err = nil // RouterOS sets an exit status on command errors; the text says what happened
	}
	return out, err
}

type lockedBuffer struct {
	mu sync.Mutex
	b  bytes.Buffer
}

func (l *lockedBuffer) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.b.Write(p)
}

func (l *lockedBuffer) String() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.b.String()
}

func (s *SSHClient) sysInfo() map[string]any {
	out := map[string]any{}
	res, _ := s.run(`:put [/system resource get version]; :put [/system resource get board-name]; :put [/system identity get name]; :put [/system resource get uptime]`, 20*time.Second)
	l := strings.Split(strings.TrimSpace(res), "\n")
	keys := []string{"version", "board", "identity", "uptime"}
	if len(l) == 4 {
		for i, k := range keys {
			out[k] = strings.TrimSpace(l[i])
		}
	} else { // unexpected output: ask one value at a time
		for i, q := range []string{"/system resource get version", "/system resource get board-name", "/system identity get name", "/system resource get uptime"} {
			if v, err := s.run(":put ["+q+"]", 10*time.Second); err == nil && !strings.Contains(strings.TrimSpace(v), "\n") {
				out[keys[i]] = strings.TrimSpace(v)
			}
		}
	}
	// CHR and x86 have no /system routerboard; the router then answers with an error text.
	if m, _ := s.run(`:put [/system routerboard get model]`, 10*time.Second); m != "" {
		m = strings.TrimSpace(m)
		low := strings.ToLower(m)
		bad := strings.Contains(m, "\n") || len(m) > 40
		for _, w := range []string{"error", "bad command", "no such", "syntax", "expected", "not supported", "unknown"} {
			bad = bad || strings.Contains(low, w)
		}
		if !bad {
			out["model"] = m
		}
	}
	return out
}

func (s *SSHClient) hotspotDirs() []string {
	res, _ := s.run(`/ip hotspot profile print terse`, 20*time.Second)
	var dirs []string
	for _, m := range reHTMLDir.FindAllStringSubmatch(res, -1) {
		dirs = append(dirs, strings.Trim(m[1], `"`))
	}
	return dirs
}

var reExportHdr = regexp.MustCompile(`(?m)^# .*by RouterOS`)

func (s *SSHClient) cloneSSH(o RealOpts, log func(string)) (string, []string, error) {
	info := s.sysInfo()
	ver := firstNonEmpty(strings.Fields(str(info["version"]) + " ")[0], "?")
	model := firstNonEmpty(str(info["model"]), str(info["board"]))
	log(fmt.Sprintf("Connected to %s over SSH (%s, RouterOS %s)", o.Host, firstNonEmpty(model, "unknown model"), ver))
	cmd := "/export show-sensitive"
	if strings.HasPrefix(ver, "6.") {
		cmd = "/export" // v6 includes passwords unless hide-sensitive is given
	}
	start := time.Now()
	out, err := s.run(cmd, 3*time.Minute)
	if err != nil {
		return "", nil, fmt.Errorf("export over SSH failed: %v", err)
	}
	if !reExportHdr.MatchString(out) && cmd != "/export" {
		if out2, err2 := s.run("/export", 3*time.Minute); err2 == nil && reExportHdr.MatchString(out2) {
			out = out2
			log("This RouterOS version does not know show-sensitive; used a plain /export")
		}
	}
	if !reExportHdr.MatchString(out) {
		return "", nil, fmt.Errorf("the router did not return an export over SSH. It answered: %s", trimTo(strings.TrimSpace(out), 200))
	}
	if i := strings.Index(out, "#"); i > 0 {
		out = out[i:]
	}
	lines := strings.Count(out, "\n")
	log(fmt.Sprintf("Ran %s over SSH: %d lines in %.1fs (read-only, nothing was changed on the router)", cmd, lines, time.Since(start).Seconds()))
	hdr := fmt.Sprintf("# %s cloned by TikLab from %s over SSH (RouterOS %s)\n", time.Now().Format("2006-01-02 15:04:05"), o.Host, ver)
	if !strings.Contains(out, "# model =") {
		if model != "" {
			hdr += "# model = " + model + "\n"
		}
	}
	dirs := s.hotspotDirs()
	return hdr + out, dirs, nil
}

// scpPut uploads files with the SCP protocol ("scp -t"), creating folders
// as needed. Names are paths relative to the router's file root.
func (s *SSHClient) scpPut(files []pageFile) error {
	sess, err := s.c.NewSession()
	if err != nil {
		return err
	}
	defer sess.Close()
	w, _ := sess.StdinPipe()
	rd, _ := sess.StdoutPipe()
	recursive := false
	for _, f := range files {
		if f.dir || strings.Contains(f.name, "/") {
			recursive = true
		}
	}
	cmd := "scp -t /"
	if recursive {
		cmd = "scp -r -t /"
	}
	if err := sess.Start(cmd); err != nil {
		return err
	}
	ack := func() error {
		b := make([]byte, 1)
		if _, err := io.ReadFull(rd, b); err != nil {
			return fmt.Errorf("the router closed the SCP session: %v", err)
		}
		if b[0] == 0 {
			return nil
		}
		var msg []byte
		for {
			if _, err := rd.Read(b); err != nil || b[0] == '\n' {
				break
			}
			msg = append(msg, b[0])
		}
		return fmt.Errorf("router: %s", strings.TrimSpace(string(msg)))
	}
	if err := ack(); err != nil {
		return err
	}
	var stack []string
	popTo := func(target []string) error {
		for len(stack) > len(target) || !hasPrefix(target, stack) {
			if _, err := io.WriteString(w, "E\n"); err != nil {
				return err
			}
			if err := ack(); err != nil {
				return err
			}
			stack = stack[:len(stack)-1]
		}
		return nil
	}
	pushTo := func(target []string) error {
		for len(stack) < len(target) {
			name := target[len(stack)]
			if _, err := fmt.Fprintf(w, "D0755 0 %s\n", name); err != nil {
				return err
			}
			if err := ack(); err != nil {
				return err
			}
			stack = append(stack, name)
		}
		return nil
	}
	for _, f := range files {
		parts := strings.Split(strings.Trim(f.name, "/"), "/")
		dir := parts[:len(parts)-1]
		if f.dir {
			dir = parts
		}
		if err := popTo(dir); err != nil {
			return err
		}
		if err := pushTo(dir); err != nil {
			return err
		}
		if f.dir {
			continue
		}
		if _, err := fmt.Fprintf(w, "C0644 %d %s\n", len(f.data), parts[len(parts)-1]); err != nil {
			return err
		}
		if err := ack(); err != nil {
			return err
		}
		w.Write(f.data)
		w.Write([]byte{0})
		if err := ack(); err != nil {
			return err
		}
	}
	if err := popTo(nil); err != nil {
		return err
	}
	w.Close()
	done := make(chan error, 1)
	go func() { done <- sess.Wait() }()
	select {
	case <-done:
	case <-time.After(10 * time.Second):
	}
	return nil
}

// scpGet downloads one file with the SCP protocol ("scp -f").
func (s *SSHClient) scpGet(name string) ([]byte, error) {
	sess, err := s.c.NewSession()
	if err != nil {
		return nil, err
	}
	defer sess.Close()
	w, _ := sess.StdinPipe()
	rd, _ := sess.StdoutPipe()
	if err := sess.Start("scp -f " + name); err != nil {
		return nil, err
	}
	br := bufio.NewReader(rd)
	w.Write([]byte{0})
	for {
		line, err := br.ReadString('\n')
		if err != nil {
			return nil, fmt.Errorf("the router closed the SCP session")
		}
		if len(line) > 0 && (line[0] == 1 || line[0] == 2) {
			return nil, fmt.Errorf("router: %s", strings.TrimSpace(line[1:]))
		}
		switch {
		case strings.HasPrefix(line, "T"):
			w.Write([]byte{0})
			continue
		case strings.HasPrefix(line, "C"):
			f := strings.SplitN(strings.TrimSpace(line), " ", 3)
			size, err := strconv.Atoi(f[min(1, len(f)-1)])
			if len(f) < 3 || err != nil || size < 0 || size > 64<<20 {
				return nil, fmt.Errorf("unexpected SCP header %q", trimTo(strings.TrimSpace(line), 40))
			}
			w.Write([]byte{0})
			data := make([]byte, size)
			if _, err := io.ReadFull(br, data); err != nil {
				return nil, err
			}
			br.ReadByte()
			w.Write([]byte{0})
			w.Close()
			return data, nil
		default:
			return nil, fmt.Errorf("unexpected SCP reply %q", trimTo(strings.TrimSpace(line), 40))
		}
	}
}

func hasPrefix(a, p []string) bool {
	if len(p) > len(a) {
		return false
	}
	for i := range p {
		if a[i] != p[i] {
			return false
		}
	}
	return true
}
