package main

// Interpreter for the RouterOS script language. Menu commands go through the
// same engine as the API and the old CLI; this file adds variables, scopes,
// control flow, expressions, functions, typed values and script jobs.

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type ScriptError struct {
	Msg    string
	Line   int
	Col    int
	Syntax bool
	User   bool // raised by :error
}

func (e *ScriptError) Error() string { return e.Msg }

// Where gives the message with its position, for the log.
func (e *ScriptError) Where() string {
	if e.Syntax || e.Line == 0 {
		return e.Msg
	}
	return fmt.Sprintf("%s (line %d column %d)", e.Msg, e.Line, e.Col)
}

type retSig struct{ v Value }

func (*retSig) Error() string { return "return outside of a function" }

var errCancelled = errors.New("interrupted")

type scope struct {
	vars   map[string]*Value
	glob   map[string]bool
	parent *scope
}

func newScope(parent *scope) *scope { return &scope{vars: map[string]*Value{}, parent: parent} }

type itemCtx struct {
	m  *Menu
	it Item
}

type Interp struct {
	r       *Router
	c       *CLI
	out     io.Writer
	cwd     string
	base    string // menu of the command whose arguments are being read
	jobName string
	job     *Job
	depth   int
	cancel  *atomic.Bool
	item    *itemCtx
}

func newInterp(r *Router, c *CLI) *Interp {
	return &Interp{r: r, c: c, out: c.out, cwd: c.cwd, cancel: &atomic.Bool{}}
}

func (in *Interp) cancelled() bool {
	return in.cancel.Load() || (in.c != nil && in.c.interrupt.Load())
}

// RunText parses and runs a script. Statements at the top level of the
// text share one scope, like a script file.
func (in *Interp) RunText(text string) error {
	b, err := parseScript(text)
	if err != nil {
		return err
	}
	err = in.execBlock(b, newScope(nil), true)
	if _, ok := err.(*retSig); ok {
		return nil
	}
	return err
}

func (in *Interp) execBlock(b *Block, sc *scope, show bool) error {
	for _, st := range b.Stmts {
		if in.cancelled() {
			return errCancelled
		}
		if _, err := in.execStmt(st, sc, show); err != nil {
			return err
		}
	}
	return nil
}

func (in *Interp) posErr(st *Stmt, err error) error {
	switch e := err.(type) {
	case *ScriptError:
		if e.Line > 0 || e.Syntax {
			return e
		}
		l, c := st.Src.lineCol(st.Pos)
		e.Line, e.Col = l, c
		return e
	case *retSig:
		return e
	}
	if err == errCancelled {
		return err
	}
	l, c := st.Src.lineCol(st.Pos)
	return &ScriptError{Msg: err.Error(), Line: l, Col: c}
}

func (in *Interp) execStmt(st *Stmt, sc *scope, show bool) (v Value, err error) {
	defer func() {
		if err != nil {
			err = in.posErr(st, err)
		}
	}()
	if st.Block != nil {
		return vNothing, in.execBlock(st.Block, newScope(sc), show)
	}
	if len(st.Args) == 0 {
		return vNothing, nil
	}
	a0 := st.Args[0]
	if a0.Key == "" && a0.Val == nil && strings.HasPrefix(a0.Bare, ":") {
		return in.builtin(a0.Bare, st, sc, show)
	}
	if a0.Key == "" && a0.Val != nil {
		v, err := in.eval(a0.Val, sc)
		if err != nil {
			return vNil, err
		}
		if v.K == KCode {
			return in.call(v.C, st.Args[1:], sc)
		}
		if len(st.Args) == 1 {
			return v, nil
		}
		return vNil, fmt.Errorf("expected command name")
	}
	return in.command(st, sc, show)
}

// ---------- variables ----------

func (r *Router) global(name string) *Value {
	r.gmu.Lock()
	defer r.gmu.Unlock()
	return r.globals[name]
}

func (r *Router) declareGlobal(name string) *Value {
	r.gmu.Lock()
	defer r.gmu.Unlock()
	if r.globals == nil {
		r.globals = map[string]*Value{}
	}
	g := r.globals[name]
	if g == nil {
		g = &Value{K: KNothing}
		r.globals[name] = g
	}
	return g
}

func (in *Interp) lookup(sc *scope, name string) *Value {
	for s := sc; s != nil; s = s.parent {
		if v, ok := s.vars[name]; ok {
			return v
		}
		if s.glob[name] {
			return in.r.declareGlobal(name)
		}
	}
	return in.r.global(name)
}

func (in *Interp) setVar(sc *scope, name string, v Value) {
	in.r.gmu.Lock()
	defer in.r.gmu.Unlock()
	for s := sc; s != nil; s = s.parent {
		if p, ok := s.vars[name]; ok {
			*p = v
			return
		}
		if s.glob[name] {
			break
		}
	}
	if g := in.r.globals[name]; g != nil {
		*g = v
		return
	}
	nv := v
	sc.vars[name] = &nv
}

func (in *Interp) getVar(sc *scope, name string) Value {
	p := in.lookup(sc, name)
	if p == nil {
		return vNothing
	}
	in.r.gmu.Lock()
	defer in.r.gmu.Unlock()
	return *p
}

// ---------- expressions ----------

func (in *Interp) eval(e Expr, sc *scope) (Value, error) {
	switch x := e.(type) {
	case ELit:
		return x.V, nil
	case EWord:
		if x.Where && in.item != nil {
			if v, ok := in.prop(x.S); ok {
				return v, nil
			}
		}
		return typeWord(x.S), nil
	case EStr:
		var b strings.Builder
		for _, p := range x.Parts {
			v, err := in.eval(p, sc)
			if err != nil {
				return vNil, err
			}
			b.WriteString(v.String())
		}
		return vStr(b.String()), nil
	case ECat:
		var b strings.Builder
		for _, p := range x.Parts {
			if w, ok := p.(EWord); ok {
				b.WriteString(w.S)
				continue
			}
			v, err := in.eval(p, sc)
			if err != nil {
				return vNil, err
			}
			b.WriteString(v.String())
		}
		return vStr(b.String()), nil
	case EVar:
		return in.getVar(sc, x.Name), nil
	case ECmd:
		return in.evalCmd(x.B, sc)
	case EBrace:
		a, err := in.arrayOf(x.B, sc)
		return vArr(a), err
	case EUn:
		v, err := in.eval(x.X, sc)
		if err != nil {
			return vNil, err
		}
		switch x.Op {
		case "!":
			return vBool(!truthy(v)), nil
		case "-":
			switch v.K {
			case KTime:
				return vTime(-v.D), nil
			default:
				n, ok := toNum(v)
				if !ok {
					return vNil, fmt.Errorf("cannot negate %s", v.K)
				}
				return vNum(-n), nil
			}
		}
	case EBin:
		return in.binary(x, sc)
	}
	return vNil, fmt.Errorf("syntax error")
}

func (in *Interp) evalCmd(b *Block, sc *scope) (Value, error) {
	v := vNothing
	for _, st := range b.Stmts {
		if in.cancelled() {
			return vNil, errCancelled
		}
		x, err := in.execStmt(st, sc, false)
		if err != nil {
			return vNil, err
		}
		v = x
	}
	return v, nil
}

func (in *Interp) arrayOf(b *Block, sc *scope) (*Arr, error) {
	a := newArr()
	for _, st := range b.Stmts {
		if st.Block != nil {
			x, err := in.arrayOf(st.Block, sc)
			if err != nil {
				return nil, err
			}
			a.List = append(a.List, vArr(x))
			continue
		}
		for _, arg := range st.Args {
			var v Value
			var err error
			switch {
			case arg.Val == nil:
				v = typeWord(arg.Bare)
			default:
				v, err = in.eval(arg.Val, sc)
			}
			if err != nil {
				return nil, err
			}
			if arg.Key != "" {
				a.Set(vStr(arg.Key), v)
			} else {
				a.List = append(a.List, v)
			}
		}
	}
	return a, nil
}

func (in *Interp) binary(x EBin, sc *scope) (Value, error) {
	l, err := in.eval(x.L, sc)
	if err != nil {
		return vNil, err
	}
	switch x.Op {
	case "&&", "and":
		if !truthy(l) {
			return vFalse, nil
		}
		r, err := in.eval(x.R, sc)
		return vBool(truthy(r)), err
	case "||", "or":
		if truthy(l) {
			return vTrue, nil
		}
		r, err := in.eval(x.R, sc)
		return vBool(truthy(r)), err
	case "->":
		var key Value
		if w, ok := x.R.(EWord); ok {
			key = typeWord(w.S)
			if key.K != KNum {
				key = vStr(w.S)
			}
		} else {
			key, err = in.eval(x.R, sc)
			if err != nil {
				return vNil, err
			}
		}
		if l.K != KArr {
			return vNil, nil
		}
		return l.A.Get(key), nil
	}
	r, err := in.eval(x.R, sc)
	if err != nil {
		return vNil, err
	}
	return binOp(x.Op, l, r)
}

func binOp(op string, l, r Value) (Value, error) {
	bad := func() (Value, error) {
		return vNil, fmt.Errorf("cannot %s %s and %s", op, l.K, r.K)
	}
	switch op {
	case ".":
		if l.K == KArr || r.K == KArr {
			return arrJoin(l, r), nil
		}
		return vStr(l.String() + r.String()), nil
	case ",":
		return arrJoin(l, r), nil
	case "=":
		return vBool(valEqual(l, r)), nil
	case "!=":
		return vBool(!valEqual(l, r)), nil
	case "<", ">", "<=", ">=":
		c, ok := cmpValues(l, r)
		if !ok {
			return vFalse, nil
		}
		switch op {
		case "<":
			return vBool(c < 0), nil
		case ">":
			return vBool(c > 0), nil
		case "<=":
			return vBool(c <= 0), nil
		}
		return vBool(c >= 0), nil
	case "~":
		re, err := regexp.Compile(r.String())
		if err != nil {
			return vFalse, nil
		}
		return vBool(re.MatchString(l.String())), nil
	case "in":
		_, n, err := parseCIDRish(r.String())
		if err != nil {
			return vFalse, nil
		}
		ip, _, _ := parseCIDRish(l.String())
		return vBool(ip != nil && n.Contains(ip)), nil
	case "+", "-":
		if l.K == KTime || r.K == KTime {
			a, ok1 := toTime(l)
			b, ok2 := toTime(r)
			if !ok1 || !ok2 {
				return bad()
			}
			if op == "-" {
				b = -b
			}
			return vTime(a + b), nil
		}
		if l.K == KIP && r.K == KNum {
			n := r.N
			if op == "-" {
				n = -n
			}
			v, _ := ipAdd(l.S, n)
			return v, nil
		}
		if l.K == KIP && r.K == KIP && op == "-" {
			a, _ := toNum(l)
			b, _ := toNum(r)
			return vNum(a - b), nil
		}
		a, ok1 := toNum(l)
		b, ok2 := toNum(r)
		if !ok1 || !ok2 {
			if l.K == KNil || l.K == KNothing {
				a, ok1 = 0, true
			}
			if !ok1 || !ok2 {
				return bad()
			}
		}
		if op == "-" {
			return vNum(a - b), nil
		}
		return vNum(a + b), nil
	case "*", "/", "%":
		if l.K == KTime && r.K == KNum {
			switch op {
			case "*":
				return vTime(l.D * time.Duration(r.N)), nil
			case "/":
				if r.N == 0 {
					return vNil, fmt.Errorf("division by zero")
				}
				return vTime(l.D / time.Duration(r.N)), nil
			}
		}
		a, ok1 := toNum(l)
		b, ok2 := toNum(r)
		if !ok1 || !ok2 {
			return bad()
		}
		switch op {
		case "*":
			return vNum(a * b), nil
		case "/":
			if b == 0 {
				return vNil, fmt.Errorf("division by zero")
			}
			return vNum(a / b), nil
		}
		if b == 0 {
			return vNil, fmt.Errorf("division by zero")
		}
		return vNum(a % b), nil
	case "&", "|", "^", "<<", ">>":
		a, ok1 := toNum(l)
		b, ok2 := toNum(r)
		if !ok1 || !ok2 {
			return bad()
		}
		switch op {
		case "&":
			return vNum(a & b), nil
		case "|":
			return vNum(a | b), nil
		case "^":
			return vNum(a ^ b), nil
		case "<<":
			return vNum(a << uint(b)), nil
		}
		return vNum(a >> uint(b)), nil
	}
	return bad()
}

func arrJoin(l, r Value) Value {
	a := newArr()
	add := func(v Value) {
		if v.K == KArr {
			c := v.A.clone()
			a.List = append(a.List, c.List...)
			for k, x := range c.Map {
				a.Set(vStr(k), x)
			}
		} else if v.K != KNil && v.K != KNothing {
			a.List = append(a.List, v)
		}
	}
	add(l)
	add(r)
	return vArr(a)
}

// ---------- functions ----------

func (in *Interp) call(code *Code, args []*Arg, caller *scope) (Value, error) {
	if code == nil || code.B == nil {
		return vNothing, nil
	}
	if in.depth > 100 {
		return vNil, fmt.Errorf("too deep recursion")
	}
	sc := newScope(nil)
	n := 0
	for _, a := range args {
		var v Value
		var err error
		switch {
		case a.Val == nil && a.Key == "":
			v = typeWord(a.Bare)
		default:
			v, err = in.eval(a.Val, caller)
		}
		if err != nil {
			return vNil, err
		}
		if a.Key != "" {
			x := v
			sc.vars[a.Key] = &x
		} else {
			n++
			x := v
			sc.vars[strconv.Itoa(n)] = &x
		}
	}
	in.depth++
	defer func() { in.depth-- }()
	oldBase := in.base
	in.base = ""
	defer func() { in.base = oldBase }()
	err := in.execBlock(code.B, sc, true)
	if rs, ok := err.(*retSig); ok {
		return rs.v, nil
	}
	return vNothing, err
}

func (in *Interp) codeOf(e Expr, sc *scope) (*Code, error) {
	switch x := e.(type) {
	case nil:
		return nil, nil
	case EBrace:
		return &Code{B: x.B}, nil
	}
	v, err := in.eval(e, sc)
	if err != nil {
		return nil, err
	}
	switch v.K {
	case KCode:
		return v.C, nil
	case KStr:
		b, err := parseScript(v.S)
		if err != nil {
			return nil, err
		}
		return &Code{B: b, Src: v.S}, nil
	case KNil, KNothing:
		return nil, nil
	}
	return nil, fmt.Errorf("expected code block")
}

// runCode runs a code block in a child scope (if/do/foreach bodies).
func (in *Interp) runCode(code *Code, sc *scope) error {
	if code == nil || code.B == nil {
		return nil
	}
	return in.execBlock(code.B, newScope(sc), true)
}

// ---------- where clauses and item properties ----------

func (in *Interp) prop(name string) (Value, bool) {
	ic := in.item
	raw, has := ic.it[name]
	if !has {
		if name == ".id" {
			return vNil, false
		}
		f := ic.m.F(name)
		if f == nil {
			return vNil, false
		}
		raw = f.Def
	}
	if strings.HasPrefix(name, "_") {
		return vNil, false
	}
	return typedProp(ic.m, name, raw), true
}

var listProps = map[string]bool{"policy": true, "servers": true, "dynamic-servers": true, "allowed-address": true}

// typedProp gives a stored property its RouterOS type.
func typedProp(m *Menu, key, raw string) Value {
	if key == ".id" {
		return vID(raw)
	}
	var f *Field
	if m != nil {
		f = m.F(key)
	}
	if listProps[key] || (key == "address" && m != nil && m.Path == "/ip/service") {
		if raw == "" {
			return vArr(newArr())
		}
		a := newArr()
		for _, p := range strings.Split(raw, ",") {
			a.List = append(a.List, typeWord(strings.TrimSpace(p)))
		}
		return vArr(a)
	}
	kind := ""
	if f != nil {
		kind = f.Kind
	}
	switch kind {
	case "bool":
		b, _ := normBool(raw)
		return vBool(b == "true")
	case "int", "bytes":
		if n, err := strconv.ParseInt(raw, 10, 64); err == nil {
			return vNum(n)
		}
		if n, ok := parseBytes(raw); ok {
			return vNum(n)
		}
		return vStr(raw)
	case "dur":
		if d, ok := parseROSTime(raw); ok {
			return vTime(d)
		}
		if d, ok := parseDur(raw); ok {
			return vTime(d)
		}
		return vStr(raw)
	case "ip":
		if raw != "" && reIPv4.MatchString(raw) {
			return Value{K: KIP, S: raw}
		}
	case "prefix":
		if raw != "" && rePrefix4.MatchString(raw) {
			return Value{K: KPrefix, S: raw}
		}
	case "":
		if raw == "true" || raw == "false" {
			return vBool(raw == "true")
		}
		if reNum.MatchString(raw) && len(raw) < 18 {
			n, _ := strconv.ParseInt(raw, 10, 64)
			return vNum(n)
		}
	}
	return vStr(raw)
}

func itemArray(m *Menu, it Item, proplist map[string]bool) *Arr {
	a := newArr()
	for k, v := range it {
		if strings.HasPrefix(k, "_") || (proplist != nil && !proplist[k] && k != ".id") {
			continue
		}
		a.Set(vStr(k), typedProp(m, k, v))
	}
	return a
}

type filter struct {
	key, op string
	val     Value
	raw     string
}

func (in *Interp) matches(m *Menu, it Item, filters []filter, where Expr, sc *scope) (bool, error) {
	for _, f := range filters {
		pv, ok := typedProp(m, f.key, it[f.key]), true
		if _, has := it[f.key]; !has && m.F(f.key) == nil && f.key != ".id" {
			ok = false
		}
		switch f.op {
		case "~":
			re, err := regexp.Compile(f.val.String())
			if err != nil || !ok || !re.MatchString(it[f.key]) {
				return false, nil
			}
		default:
			if !ok || !(valEqual(pv, f.val) || it[f.key] == f.raw) {
				return false, nil
			}
		}
	}
	if where == nil {
		return true, nil
	}
	old := in.item
	in.item = &itemCtx{m, it}
	v, err := in.eval(where, sc)
	in.item = old
	return truthy(v), err
}

// rows reads a menu's items (refreshed, as print sees them), copied.
func (in *Interp) rows(m *Menu) ([]Item, error) {
	var rows []Item
	_, err := in.r.Exec(in.ctx(), m.Path+"/print", nil, nil, func(it Item) {
		c := Item{}
		for k, v := range it {
			c[k] = v
		}
		rows = append(rows, c)
	})
	return rows, err
}

func (in *Interp) ctx() *Ctx {
	return &Ctx{User: in.c.user, Via: in.c.via, Addr: in.c.addr, Internal: in.c.internal}
}

// ---------- commands ----------

var cmdFlags = map[string]bool{"once": true, "compact": true, "verbose": true, "hide-sensitive": true, "show-sensitive": true, "dry-run": true, "as-value": true, "without-paging": true, "detail": true, "terse": true, "brief": true, "count-only": true, "value-list": true, "stats": true, "follow": true, "follow-only": true, "show-ids": true, "stats-detail": true, "oid": true, "append": true, "keep-result": false}

func (in *Interp) resolve(cur string, words []string) (path, cmd string, n int, err error) {
	c := in.c
	for n = 0; n < len(words); n++ {
		t := words[n]
		segs := []string{t}
		if strings.Contains(t, "/") {
			if strings.HasPrefix(t, "/") {
				cur = ""
			}
			segs = strings.Split(strings.Trim(t, "/"), "/")
			if t == "/" {
				segs = nil
			}
		}
		for si, s := range segs {
			if s == "" {
				continue
			}
			if s == ".." {
				if j := strings.LastIndex(cur, "/"); j >= 0 {
					cur = cur[:j]
				}
				continue
			}
			np := joinPath(cur, s)
			if isDir(np) {
				cur = np
				continue
			}
			if c.isCommand(cur, s) {
				if si != len(segs)-1 {
					return "", "", 0, fmt.Errorf("syntax error")
				}
				return cur, s, n + 1, nil
			}
			if full := c.abbrev(cur, s); full != "" {
				if isDir(joinPath(cur, full)) {
					cur = joinPath(cur, full)
					continue
				}
				return cur, full, n + 1, nil
			}
			return "", "", 0, fmt.Errorf("bad command name %s", s)
		}
	}
	return cur, "", n, nil
}

func (in *Interp) command(st *Stmt, sc *scope, show bool) (Value, error) {
	cur := in.cwd
	if in.base != "" {
		cur = in.base
	}
	var words []string
	for _, a := range st.Args {
		if a.Val != nil || a.Key != "" {
			break
		}
		words = append(words, a.Bare)
	}
	path, cmd, n, err := in.resolve(cur, words)
	if err != nil {
		return vNil, err
	}
	if cmd == "" {
		if n < len(st.Args) || st.Where != nil {
			return vNil, fmt.Errorf("expected command name")
		}
		if in.base == "" {
			in.cwd = path
		}
		return vNothing, nil
	}
	m := MenuMap[path]
	full := joinPath(path, cmd)

	args := map[string]string{}
	typed := map[string]Value{}
	flags := map[string]bool{}
	var filters []filter
	var pos []Value
	var rawPos []bool
	oldBase := in.base
	in.base = path
	defer func() { in.base = oldBase }()
	for _, a := range st.Args[n:] {
		switch {
		case a.Key != "":
			var v Value
			raw := ""
			if w, ok := a.Val.(EWord); ok {
				raw = w.S
				v = typeWord(w.S)
			} else if br, ok := a.Val.(EBrace); ok {
				raw = strings.TrimSpace(br.B.Text)
				v = vStr(raw)
			} else if c, ok := a.Val.(ECat); ok && len(c.Parts) > 0 {
				x, err := in.eval(c, sc)
				if err != nil {
					return vNil, err
				}
				v, raw = x, x.S
			} else {
				x, err := in.eval(a.Val, sc)
				if err != nil {
					return vNil, err
				}
				v, raw = x, x.argString()
			}
			if a.Op == "~" {
				filters = append(filters, filter{a.Key, "~", v, raw})
				continue
			}
			args[a.Key] = raw
			typed[a.Key] = v
		case a.Val == nil:
			if cmdFlags[a.Bare] || printFlags[a.Bare] {
				flags[a.Bare] = true
				args[a.Bare] = ""
				continue
			}
			pos = append(pos, vStr(a.Bare))
			rawPos = append(rawPos, true)
		default:
			v, err := in.eval(a.Val, sc)
			if err != nil {
				return vNil, err
			}
			pos = append(pos, v)
			rawPos = append(rawPos, false)
		}
	}
	posNames := positional[cmd]
	if m != nil && m.Single {
		if cmd == "get" {
			posNames = []string{"value-name"}
		} else {
			posNames = nil
		}
	}
	emptyTargets := false
	for i, v := range pos {
		if i >= len(posNames) {
			if cmd == "find" || cmd == "print" {
				continue
			}
			return vNil, fmt.Errorf("expected end of command")
		}
		name := posNames[i]
		if name == "numbers" && (v.K == KArr && v.A.Len() == 0 || v.K == KNil || v.K == KNothing) && !rawPos[i] {
			emptyTargets = true
		}
		args[name] = v.argString()
		typed[name] = v
	}
	switch cmd {
	case "set", "remove", "enable", "disable", "unset", "comment", "move", "reset-counters", "run", "make-static", "disconnect", "login", "logout":
		if emptyTargets && m != nil && !m.Single {
			return vNothing, nil
		}
	}

	// commands the interpreter implements itself
	switch {
	case full == "/tool/fetch":
		return in.fetch(args, flags, show)
	case full == "/file/read":
		return in.fileRead(args)
	case full == "/certificate/import":
		return in.certImport(args, show)
	case full == "/system/script/run":
		return in.scriptRun(m, args)
	case m != nil && cmd == "find":
		for k, v := range args {
			if k == "numbers" {
				continue
			}
			filters = append(filters, filter{k, "=", typed[k], v})
		}
		return in.find(m, filters, st.Where, sc)
	case m != nil && cmd == "get":
		return in.get(m, args)
	case m != nil && cmd == "print" && (flags["as-value"] || flags["value-list"] || args["file"] != "" || (!show && flags["count-only"])):
		return in.printValue(m, args, flags, filters, st.Where, sc)
	}

	c := in.c
	if m != nil && cmd == "print" && (st.Where != nil || len(filters) > 0) {
		where := st.Where
		c.pred = func(it Item) bool {
			ok, _ := in.matches(m, it, filters, where, sc)
			return ok
		}
		defer func() { c.pred = nil }()
	}
	oldCwd := c.cwd
	c.cwd = in.cwd
	ret, err := c.execArgs(path, cmd, args, flags, nil, show)
	c.cwd = oldCwd
	if err != nil {
		return vNil, err
	}
	switch {
	case cmd == "add" && strings.HasPrefix(ret, "*"):
		return vID(ret), nil
	case ret != "":
		return typeWord(ret), nil
	}
	return vNothing, nil
}

func (in *Interp) find(m *Menu, filters []filter, where Expr, sc *scope) (Value, error) {
	rows, err := in.rows(m)
	if err != nil {
		return vNil, err
	}
	a := newArr()
	for _, it := range rows {
		ok, err := in.matches(m, it, filters, where, sc)
		if err != nil {
			return vNil, err
		}
		if ok {
			a.List = append(a.List, vID(it[".id"]))
		}
	}
	return vArr(a), nil
}

func (in *Interp) get(m *Menu, args map[string]string) (Value, error) {
	name := args["value-name"]
	var row Item
	if m.Single {
		rows, err := in.rows(m)
		if err != nil {
			return vNil, err
		}
		if len(rows) > 0 {
			row = rows[0]
		}
	} else {
		spec := firstNonEmpty(args["numbers"], args[".id"])
		if spec == "" {
			return vNil, fmt.Errorf("no such item")
		}
		ids, err := in.c.resolveNums(m, spec)
		if err != nil {
			return vNil, err
		}
		id := strings.Split(ids, ",")[0]
		rows, err := in.rows(m)
		if err != nil {
			return vNil, err
		}
		for _, it := range rows {
			if it[".id"] == id {
				row = it
				break
			}
		}
		if row == nil {
			return vNil, fmt.Errorf("no such item")
		}
	}
	if row == nil {
		row = Item{}
	}
	if name == "" {
		return vArr(itemArray(m, row, nil)), nil
	}
	if raw, ok := row[name]; ok && !strings.HasPrefix(name, "_") {
		return typedProp(m, name, raw), nil
	}
	if f := m.F(name); f != nil {
		return typedProp(m, name, f.Def), nil
	}
	return vNil, fmt.Errorf("input does not match any value of value-name")
}

func (in *Interp) printValue(m *Menu, args map[string]string, flags map[string]bool, filters []filter, where Expr, sc *scope) (Value, error) {
	rows, err := in.rows(m)
	if err != nil {
		return vNil, err
	}
	for k, v := range args {
		if !printFlags[k] && k != "from" && k != "proplist" && k != "interval" && k != "file" && m.F(k) != nil {
			filters = append(filters, filter{k, "=", typeWord(v), v})
		}
	}
	var keep []Item
	for _, it := range rows {
		ok, err := in.matches(m, it, filters, where, sc)
		if err != nil {
			return vNil, err
		}
		if ok {
			keep = append(keep, it)
		}
	}
	if fn := args["file"]; fn != "" && !flags["as-value"] {
		var buf bytes.Buffer
		c := newCLI(in.r, in.c.user, in.c.via, in.c.addr, &buf, false)
		c.color = false
		c.internal = in.c.internal
		c.pred = func(it Item) bool {
			for _, k := range keep {
				if k[".id"] == it[".id"] {
					return true
				}
			}
			return false
		}
		delete(args, "file")
		if err := c.print(m, args, flags, nil, true); err != nil {
			return vNil, err
		}
		if !strings.Contains(fn, ".") {
			fn += ".txt"
		}
		in.r.mu.Lock()
		in.r.putFile(cleanPath(fn), buf.Bytes())
		in.r.mu.Unlock()
		return vNothing, nil
	}
	if flags["count-only"] {
		return vNum(int64(len(keep))), nil
	}
	var pl map[string]bool
	if p := args["proplist"]; p != "" {
		pl = map[string]bool{}
		for _, k := range strings.Split(p, ",") {
			pl[strings.TrimSpace(k)] = true
		}
	}
	if m.Single {
		if len(keep) == 0 {
			return vArr(newArr()), nil
		}
		return vArr(itemArray(m, keep[0], pl)), nil
	}
	a := newArr()
	for _, it := range keep {
		a.List = append(a.List, vArr(itemArray(m, it, pl)))
	}
	return vArr(a), nil
}

// scriptRun runs /system script items synchronously, each as its own job.
func (in *Interp) scriptRun(m *Menu, args map[string]string) (Value, error) {
	ids, err := in.c.resolveNums(m, firstNonEmpty(args["numbers"], args[".id"]))
	if err != nil {
		return vNil, err
	}
	for _, id := range strings.Split(ids, ",") {
		in.r.mu.Lock()
		it := in.r.findRef(m, id)
		var src, name string
		if it != nil {
			addInt(it, "run-count", 1)
			it["last-started"] = in.r.now().Format("2006-01-02 15:04:05")
			src, name = it["source"], it["name"]
		}
		in.r.mu.Unlock()
		if it == nil {
			return vNil, fmt.Errorf("no such item")
		}
		if in.depth > 20 {
			return vNil, fmt.Errorf("too deep recursion")
		}
		if err := in.r.runJob(src, in.c.user, name, in.out, in.depth+1); err != nil {
			return vNil, err
		}
	}
	return vNothing, nil
}

// ---------- jobs ----------

type Job struct {
	ID     string
	Script string
	Owner  string
	cancel atomic.Bool
}

func (r *Router) startJob(script, owner, typ string) *Job {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.jobs == nil {
		r.jobs = map[string]*Job{}
	}
	r.jobSeq++
	j := &Job{ID: fmt.Sprintf("*%X", r.jobSeq), Script: script, Owner: owner}
	r.jobs[j.ID] = j
	t := r.tbl("/system/script/job")
	t.Items = append(t.Items, Item{".id": j.ID, "script": script, "owner": owner, "started": r.now().Format("2006-01-02 15:04:05"), "type": typ})
	return j
}

func (r *Router) endJob(j *Job) {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.jobs, j.ID)
	t := r.tbl("/system/script/job")
	for i, it := range t.Items {
		if it[".id"] == j.ID {
			t.Items = append(t.Items[:i], t.Items[i+1:]...)
			break
		}
	}
}

// cancelJobs stops every running script (reboot, shutdown).
func (r *Router) cancelJobs() {
	for _, j := range r.jobs {
		j.cancel.Store(true)
	}
	r.tbl("/system/script/job").Items = nil
}

// runJob runs a script as a /system script job and logs an error like RouterOS.
func (r *Router) runJob(src, user, script string, out io.Writer, depth int) error {
	if out == nil {
		out = io.Discard
	}
	r.mu.Lock()
	running := r.state == "running"
	n := len(r.jobs)
	r.mu.Unlock()
	if !running {
		return fmt.Errorf("router is not running")
	}
	if n > 64 {
		return fmt.Errorf("too many scripts running")
	}
	typ := "command"
	if script != "" {
		typ = "script"
	}
	j := r.startJob(script, user, typ)
	defer r.endJob(j)
	return r.runInJob(j, src, user, script, out, depth)
}

func (r *Router) runInJob(j *Job, src, user, script string, out io.Writer, depth int) error {
	c := newCLI(r, user, "script", "", out, false)
	c.color = false
	c.script = true
	in := newInterp(r, c)
	in.jobName = script
	in.job = j
	in.cancel = &j.cancel
	in.depth = depth
	err := in.RunText(src)
	if err != nil && err != errCancelled {
		msg := err.Error()
		if se, ok := err.(*ScriptError); ok {
			msg = se.Where()
		}
		r.mu.Lock()
		if script != "" {
			r.log("script,error", "script error: %s (%s)", msg, script)
		} else {
			r.log("script,error", "script error: %s", msg)
		}
		r.mu.Unlock()
	}
	return err
}

// runScript keeps the old entry point: run a script in the background job style.
func (r *Router) runScript(src, user, name string) int {
	if err := r.runJob(src, user, name, nil, 0); err != nil {
		return 1
	}
	return 0
}

// execute starts a background job, as :execute does, and returns its id.
func (in *Interp) execute(src string, file string, asString bool) (Value, error) {
	if asString {
		var buf bytes.Buffer
		err := in.r.runJob(src, in.c.user, "", &buf, in.depth+1)
		if err != nil && err != errCancelled {
			if se, ok := err.(*ScriptError); ok && se.User {
				return vStr(buf.String()), nil
			}
		}
		return vStr(buf.String()), nil
	}
	in.r.mu.Lock()
	running := in.r.state == "running"
	in.r.mu.Unlock()
	if !running {
		return vNil, fmt.Errorf("router is not running")
	}
	j := in.r.startJob("", in.c.user, "command")
	user := in.c.user
	go func() {
		defer in.r.endJob(j)
		var buf bytes.Buffer
		var out io.Writer = io.Discard
		if file != "" {
			out = &buf
		}
		in.r.runInJob(j, src, user, "", out, 0)
		if file != "" {
			if !strings.Contains(file, ".") {
				file += ".txt"
			}
			in.r.mu.Lock()
			in.r.putFile(cleanPath(file), buf.Bytes())
			in.r.mu.Unlock()
		}
	}()
	return vID(j.ID), nil
}

func init() {
	delHooks["/system/script/job"] = func(r *Router, it Item, internal bool) error {
		if j := r.jobs[it[".id"]]; j != nil {
			j.cancel.Store(true)
		}
		return nil
	}
}

// ---------- the terminal ----------

var termMu sync.Mutex

// runTerminal runs what the user typed (one line or a pasted block).
func (c *CLI) runTerminal(text string) {
	in := c.interp
	if in == nil {
		in = newInterp(c.r, c)
		c.interp = in
	}
	in.out = c.out
	in.cwd = c.cwd
	in.cancel.Store(false)
	c.interrupt.Store(false)
	err := in.RunText(text)
	c.cwd = in.cwd
	if err != nil {
		c.errors++
		msg := err.Error()
		if se, ok := err.(*ScriptError); ok && !se.Syntax && strings.Contains(text, "\n") {
			msg = se.Where()
		}
		c.p("%s\n", c.col(cRed, msg))
	}
}

func sortedVarKeys(m map[string]*Value) []string {
	ks := make([]string, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

func parseCIDRish(s string) (net.IP, *net.IPNet, error) {
	s = strings.TrimSpace(s)
	if !strings.Contains(s, "/") {
		ip := net.ParseIP(s)
		if ip == nil {
			return nil, nil, fmt.Errorf("bad address")
		}
		bits := 32
		if ip.To4() == nil {
			bits = 128
		}
		return ip, &net.IPNet{IP: ip, Mask: net.CIDRMask(bits, bits)}, nil
	}
	return net.ParseCIDR(s)
}

// ---------- console: run a pasted script, cloud status ----------

var reLinkURL = regexp.MustCompile(`:local url "([^"]+)/api/agent/v1"`)

func (w *Web) cloudAPI(rw http.ResponseWriter, req *http.Request, op string) {
	r := w.r
	var body struct{ T, Text string }
	tok := req.URL.Query().Get("t")
	if req.Method == http.MethodPost {
		json.NewDecoder(req.Body).Decode(&body)
		if body.T != "" {
			tok = body.T
		}
	}
	s := w.session(tok)
	if s == nil || !s.local {
		jsonOut(rw, 200, map[string]any{"error": "not available"})
		return
	}
	if op == "script/run" {
		var buf bytes.Buffer
		c := newCLI(r, s.user, "winbox", s.addr, &buf, false)
		c.color = false
		c.script = true
		t0 := time.Now()
		err := r.runJob(body.Text, s.user, "", &buf, 0)
		out := map[string]any{"output": strings.ReplaceAll(buf.String(), "\r\n", "\n"), "ms": int(time.Since(t0) / time.Millisecond)}
		if err != nil {
			msg := err.Error()
			if se, ok := err.(*ScriptError); ok {
				msg = se.Where()
			}
			out["error"] = msg
		}
		jsonOut(rw, 200, out)
		return
	}
	r.mu.Lock()
	link := map[string]any{"installed": false}
	if sc := r.byName("/system/script", "taptap-link"); sc != nil {
		link["installed"] = true
		if m := reLinkURL.FindStringSubmatch(sc["source"]); m != nil {
			link["server"] = m[1]
		}
		link["runs"] = sc["run-count"]
		link["lastStarted"] = sc["last-started"]
		if sch := r.byName("/system/scheduler", "taptap-link"); sch != nil {
			link["interval"] = sch["interval"]
			link["enabled"] = !sch.B("disabled")
		}
	}
	var calls []fetchRec
	var lastPoll *fetchRec
	for i := len(r.fetchLog) - 1; i >= 0; i-- {
		f := r.fetchLog[i]
		calls = append(calls, f)
		if lastPoll == nil && strings.HasSuffix(f.URL, "/api/agent/v1/poll") {
			fc := f
			lastPoll = &fc
		}
	}
	if lastPoll != nil {
		link["lastPoll"] = int(time.Since(lastPoll.At).Seconds())
		link["lastOK"] = lastPoll.OK
		link["lastMsg"] = lastPoll.Msg
	}
	var tunnels []map[string]any
	for _, it := range r.list(MenuMap["/interface/wireguard"]) {
		t := map[string]any{"name": it["name"], "running": it.B("running"), "disabled": it.B("disabled"), "publicKey": it["public-key"], "comment": it["comment"]}
		var addrs []string
		for _, a := range r.list(MenuMap["/ip/address"]) {
			if a["interface"] == it["name"] {
				addrs = append(addrs, a["address"])
			}
		}
		t["addresses"] = addrs
		var peers []map[string]any
		for _, p := range r.list(MenuMap["/interface/wireguard/peers"]) {
			if p["interface"] == it["name"] {
				ep := p["endpoint-address"]
				if ep != "" && p["endpoint-port"] != "" && p["endpoint-port"] != "0" {
					ep = net.JoinHostPort(ep, p["endpoint-port"])
				}
				peers = append(peers, map[string]any{"endpoint": ep, "allowed": p["allowed-address"], "lastHandshake": p["last-handshake"], "rx": p["rx"], "tx": p["tx"], "comment": p["comment"], "disabled": p.B("disabled")})
			}
		}
		t["peers"] = peers
		tunnels = append(tunnels, t)
	}
	var tunNets []*net.IPNet
	for _, t := range tunnels {
		for _, a := range t["addresses"].([]string) {
			if _, n, err := net.ParseCIDR(a); err == nil {
				tunNets = append(tunNets, n)
			}
		}
	}
	var logins []string
	for _, l := range r.list(MenuMap["/log"]) {
		if !strings.Contains(l["message"], "logged in from") {
			continue
		}
		f := strings.Fields(l["message"])
		for i, x := range f {
			if x == "from" && i+1 < len(f) {
				if ip := net.ParseIP(f[i+1]); ip != nil {
					for _, n := range tunNets {
						if n.Contains(ip) {
							logins = append(logins, l["time"]+"  "+l["message"])
						}
					}
				}
			}
		}
	}
	// collapse repeated logins: TapTap logs in every few seconds
	var grouped []string
	count := 0
	for i, l := range logins {
		msg := l[strings.Index(l, "  ")+2:]
		count++
		if i+1 < len(logins) && logins[i+1][strings.Index(logins[i+1], "  ")+2:] == msg {
			continue
		}
		if count > 1 {
			l += fmt.Sprintf("  (×%d, last at this time)", count)
		}
		grouped = append(grouped, l)
		count = 0
	}
	logins = grouped
	if len(logins) > 6 {
		logins = logins[len(logins)-6:]
	}
	r.mu.Unlock()
	if len(calls) > 15 {
		calls = calls[:15]
	}
	jsonOut(rw, 200, map[string]any{"link": link, "tunnels": tunnels, "calls": calls, "logins": logins})
}
