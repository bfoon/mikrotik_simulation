package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Item map[string]string

func (it Item) Clone() Item {
	c := make(Item, len(it))
	for k, v := range it {
		c[k] = v
	}
	return c
}
func (it Item) B(k string) bool { return it[k] == "true" }

type Table struct {
	Items []Item `json:"items"`
	Next  int    `json:"next"`
}

type Trap struct {
	Msg string
	Cat int
}

func (t *Trap) Error() string { return t.Msg }
func trap(f string, a ...any) *Trap {
	return &Trap{Msg: fmt.Sprintf(f, a...)}
}

type Ctx struct {
	User        string
	Via         string
	Addr        string
	Done        <-chan struct{}
	Interactive bool
	Internal    bool
	Lenient     bool     // import mode: drop unknown/invalid parameters, update existing items
	Warnings    []string // filled in lenient mode
}

var reBadField = regexp.MustCompile(`(?:input does not match any value of|invalid value for argument|unknown parameter|can not set read-only property) (\S+)`)

// lenientArgs removes parameters the simulator does not know (import mode)
func (r *Router) lenientArgs(c *Ctx, m *Menu, args map[string]string) {
	for k := range args {
		if k == ".id" || k == "numbers" || k == "value-name" || k == ".proplist" || strings.HasPrefix(k, "_") {
			continue
		}
		f := m.F(k)
		if f == nil && m.View != "" {
			f = MenuMap[m.View].F(k)
		}
		if f == nil {
			c.Warnings = append(c.Warnings, "ignored unsupported parameter "+k)
			delete(args, k)
		} else if f.RO && !(m.Path == "/ip/hotspot/active" && k == "comment") {
			delete(args, k)
		}
	}
	if m.Path == "/ip/service" {
		for _, k := range []string{"port", "address", "vrf"} {
			if _, ok := args[k]; ok {
				c.Warnings = append(c.Warnings, "kept the simulator's own "+k+" for this service")
				delete(args, k)
			}
		}
		if v, ok := args["disabled"]; ok {
			if b, _ := normBool(v); b == "true" {
				if it := r.findRef(m, firstNonEmpty(args["numbers"], args[".id"])); it != nil && (it["name"] == "winbox" || it["name"] == "www") {
					c.Warnings = append(c.Warnings, "did not disable "+it["name"]+" so the TikLab console stays reachable")
					delete(args, "disabled")
				}
			}
		}
	}
}

// retryLenient drops the offending parameter and retries once per parameter
func (r *Router) retryLenient(c *Ctx, m *Menu, args map[string]string, err error, op func() error) error {
	for tries := 0; err != nil && tries < 6; tries++ {
		mt := reBadField.FindStringSubmatch(err.Error())
		if mt == nil {
			return err
		}
		k := mt[1]
		v, ok := args[k]
		if !ok {
			return err
		}
		if f := m.F(k); f != nil && f.Req {
			return err
		}
		c.Warnings = append(c.Warnings, fmt.Sprintf("ignored %s=%s (%s)", k, v, err.Error()))
		delete(args, k)
		err = op()
	}
	return err
}

type watcher struct {
	store string
	ch    chan Item
}

type Router struct {
	mu           sync.Mutex
	T            map[string]*Table
	Model        *Model
	Ver          string
	Opt          *Options
	boot         time.Time
	state        string // running | booting | off
	sim          *Sim
	dirty        bool
	dataDir      string
	watchers     map[int]*watcher
	nextW        int
	kickers      map[int]func()
	nextK        int
	clockOff     time.Duration
	epoch        int
	svc          *Services
	baseMAC      net.HardwareAddr
	macSeq       int
	sessions     int
	onSvc        func(name string)
	inRebuild    bool
	pendingModel string
	pendingKeep  bool
	gmu          sync.Mutex // script globals
	globals      map[string]*Value
	jobs         map[string]*Job
	jobSeq       int
	wg           *WGManager
	fetchLog     []fetchRec
	quit         chan struct{}
	lab          *labView // set by the network lab
	labRate      map[string][2]float64
	hw           *HostWifi
}

// ---------- helpers ----------

func (r *Router) tbl(store string) *Table {
	t := r.T[store]
	if t == nil {
		t = &Table{Next: 1}
		r.T[store] = t
	}
	return t
}

func (r *Router) list(m *Menu) []Item {
	t := r.tbl(m.Store())
	if m.View == "" {
		return t.Items
	}
	var out []Item
	for _, it := range t.Items {
		if it["type"] == m.TypeVal {
			out = append(out, it)
		}
	}
	return out
}

func (r *Router) single(path string) Item {
	m := MenuMap[path]
	t := r.tbl(path)
	if len(t.Items) == 0 {
		it := Item{}
		for _, f := range m.Fields {
			if f.Def != "" {
				it[f.Name] = f.Def
			}
		}
		t.Items = append(t.Items, it)
	}
	return t.Items[0]
}

// S returns single-menu value
func (r *Router) S(path, key string) string { return r.single(path)[key] }

func (r *Router) byName(path, name string) Item {
	m := MenuMap[path]
	for _, it := range r.list(m) {
		if it["name"] == name {
			return it
		}
	}
	return nil
}

func (r *Router) find(path string, fn func(Item) bool) []Item {
	m := MenuMap[path]
	var out []Item
	for _, it := range r.list(m) {
		if fn(it) {
			out = append(out, it)
		}
	}
	return out
}

func (r *Router) findRef(m *Menu, ref string) Item {
	ref = strings.TrimSpace(ref)
	if ref == "" {
		return nil
	}
	items := r.list(m)
	if strings.HasPrefix(ref, "*") {
		for _, it := range items {
			if strings.EqualFold(it[".id"], ref) {
				return it
			}
		}
		return nil
	}
	key := m.Unique
	if key == "" {
		key = "name"
	}
	for _, it := range items {
		if it[key] == ref {
			return it
		}
	}
	if m.Store() == "/interface" {
		for _, it := range items {
			if it["default-name"] == ref {
				return it
			}
		}
	}
	return nil
}

func (r *Router) targets(m *Menu, spec string) ([]Item, error) {
	if spec == "" {
		return nil, trap("no such item")
	}
	var out []Item
	for _, p := range strings.FieldsFunc(spec, func(c rune) bool { return c == ',' || c == ';' }) {
		it := r.findRef(m, p)
		if it == nil {
			return nil, trap("no such item")
		}
		out = append(out, it)
	}
	return out, nil
}

func (r *Router) newID(store string) string {
	t := r.tbl(store)
	id := fmt.Sprintf("*%X", t.Next)
	t.Next++
	return id
}

func (r *Router) markDirty() { r.dirty = true }

func (r *Router) notify(store string, it Item, dead bool) {
	for _, w := range r.watchers {
		if w.store == store {
			c := it.Clone()
			if dead {
				c = Item{".id": it[".id"], ".dead": "true"}
			}
			select {
			case w.ch <- c:
			default:
			}
		}
	}
}

// ---------- value normalisation ----------

var durRe = regexp.MustCompile(`^(?:(\d+)w)?(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?(?:(\d+)ms)?$`)

func parseDur(s string) (time.Duration, bool) {
	s = strings.TrimSpace(strings.ToLower(s))
	if s == "" {
		return 0, false
	}
	if n, err := strconv.ParseFloat(s, 64); err == nil {
		return time.Duration(n * float64(time.Second)), true
	}
	// d hh:mm:ss  or hh:mm:ss
	if strings.Contains(s, ":") {
		days := 0
		if strings.Contains(s, "d") {
			p := strings.SplitN(s, "d", 2)
			days, _ = strconv.Atoi(strings.TrimSpace(p[0]))
			s = strings.TrimSpace(p[1])
		}
		parts := strings.Split(s, ":")
		var tot int
		for _, p := range parts {
			n, err := strconv.Atoi(p)
			if err != nil {
				return 0, false
			}
			tot = tot*60 + n
		}
		if len(parts) == 2 {
			tot *= 60
		}
		return time.Duration(days*86400+tot) * time.Second, true
	}
	m := durRe.FindStringSubmatch(s)
	if m == nil || s == "" {
		return 0, false
	}
	mul := []time.Duration{7 * 24 * time.Hour, 24 * time.Hour, time.Hour, time.Minute, time.Second, time.Millisecond}
	var d time.Duration
	for i := 1; i <= 6; i++ {
		if m[i] != "" {
			n, _ := strconv.Atoi(m[i])
			d += time.Duration(n) * mul[i-1]
		}
	}
	return d, true
}

func fmtDur(d time.Duration) string {
	if d <= 0 {
		return "0s"
	}
	if d < time.Second {
		return fmt.Sprintf("%dms", d/time.Millisecond)
	}
	s := int64(d / time.Second)
	var b strings.Builder
	w := s / 604800
	s %= 604800
	dd := s / 86400
	s %= 86400
	h := s / 3600
	s %= 3600
	mi := s / 60
	s %= 60
	if w > 0 {
		fmt.Fprintf(&b, "%dw", w)
	}
	if dd > 0 {
		fmt.Fprintf(&b, "%dd", dd)
	}
	if h > 0 {
		fmt.Fprintf(&b, "%dh", h)
	}
	if mi > 0 {
		fmt.Fprintf(&b, "%dm", mi)
	}
	if s > 0 {
		fmt.Fprintf(&b, "%ds", s)
	}
	return b.String()
}

func durSecs(s string) int64 {
	d, ok := parseDur(s)
	if !ok {
		return 0
	}
	return int64(d / time.Second)
}

func parseBytes(s string) (int64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	mul := int64(1)
	switch strings.ToUpper(s[len(s)-1:]) {
	case "K":
		mul = 1024
	case "M":
		mul = 1024 * 1024
	case "G":
		mul = 1024 * 1024 * 1024
	case "T":
		mul = 1024 * 1024 * 1024 * 1024
	}
	if mul > 1 {
		s = s[:len(s)-1]
	}
	f, err := strconv.ParseFloat(s, 64)
	if err != nil || f < 0 {
		return 0, false
	}
	return int64(f * float64(mul)), true
}

func parseRate(s string) int64 {
	s = strings.TrimSpace(strings.TrimSuffix(strings.ToLower(s), "bps"))
	if s == "" {
		return 0
	}
	mul := 1.0
	switch s[len(s)-1] {
	case 'k':
		mul = 1000
	case 'm':
		mul = 1e6
	case 'g':
		mul = 1e9
	}
	if mul > 1 {
		s = s[:len(s)-1]
	}
	f, _ := strconv.ParseFloat(s, 64)
	return int64(f * mul)
}

func normBool(v string) (string, bool) {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "yes", "true", "on", "1":
		return "true", true
	case "no", "false", "off", "0", "":
		return "false", true
	}
	return "", false
}

func (r *Router) norm(m *Menu, f *Field, v string) (string, error) {
	bad := trap("invalid value for argument %s", f.Name)
	switch f.Kind {
	case "bool":
		b, ok := normBool(v)
		if !ok {
			return "", bad
		}
		return b, nil
	case "int":
		if v == "" {
			return "", nil
		}
		if _, err := strconv.ParseInt(v, 0, 64); err != nil {
			if n, ok := parseBytes(v); ok {
				return strconv.FormatInt(n, 10), nil
			}
			return "", bad
		}
		n, _ := strconv.ParseInt(v, 0, 64)
		return strconv.FormatInt(n, 10), nil
	case "dur":
		if v == "" || v == "none" {
			return v, nil
		}
		d, ok := parseDur(v)
		if !ok {
			return "", bad
		}
		return fmtDur(d), nil
	case "prefix":
		if v == "" {
			return "", nil
		}
		if !strings.Contains(v, "/") {
			ip := net.ParseIP(v)
			if ip == nil {
				return "", bad
			}
			if ip.To4() != nil {
				return v + "/32", nil
			}
			return v + "/128", nil
		}
		ip, _, err := net.ParseCIDR(v)
		if err != nil {
			return "", bad
		}
		_ = ip
		return v, nil
	case "ip":
		if v == "" {
			return "", nil
		}
		if net.ParseIP(v) == nil {
			return "", bad
		}
		return v, nil
	case "enum":
		for _, e := range f.Enum {
			if e == v {
				return v, nil
			}
		}
		if v == "" {
			return "", nil
		}
		return "", trap("input does not match any value of %s", f.Name)
	case "ref":
		if v == "" {
			if f.Req {
				return "", trap("input does not match any value of %s", f.Name)
			}
			return "", nil
		}
		for _, e := range f.Extra {
			if e == v {
				return v, nil
			}
		}
		rm := MenuMap[f.Ref]
		if rm == nil || r.findRef(rm, v) == nil {
			return "", trap("input does not match any value of %s", f.Name)
		}
		if strings.HasPrefix(v, "*") {
			return r.findRef(rm, v)["name"], nil
		}
		return r.findRef(rm, v)["name"], nil
	}
	return v, nil
}

func dupMsg(m *Menu) string {
	switch m.Path {
	case "/ip/hotspot/user":
		return "failure: already have user with this name for this server"
	case "/ppp/secret":
		return "failure: secret with the same name already exists"
	case "/user":
		return "failure: user with the same name already exists"
	}
	if m.Store() == "/interface" {
		return "failure: already have interface with such name"
	}
	return "failure: already have such name"
}

func (r *Router) checkUnique(m *Menu, self Item, val string) error {
	if m.Unique == "" || val == "" {
		return nil
	}
	store := m.Store()
	for _, it := range r.tbl(store).Items {
		if it != nil && &it != &self && it[".id"] != self[".id"] && it[m.Unique] == val {
			if m.Path == "/ip/hotspot/user" && self["server"] != "" && it["server"] != "" && self["server"] != it["server"] && it["server"] != "all" && self["server"] != "all" {
				continue
			}
			return trap("%s", dupMsg(m))
		}
	}
	return nil
}

// ---------- core operations (lock held) ----------

func (r *Router) addItem(m *Menu, args map[string]string, internal bool) (Item, error) {
	if m.NoAdd && !internal {
		return nil, trap("no such command")
	}
	it := Item{}
	if m.View != "" {
		base := MenuMap[m.View]
		for _, f := range base.Fields {
			if f.Def != "" {
				it[f.Name] = f.Def
			}
		}
		it["type"] = m.TypeVal
	}
	for _, f := range m.Fields {
		if f.Def != "" {
			it[f.Name] = f.Def
		}
	}
	for k, v := range args {
		if strings.HasPrefix(k, "_") || k == ".id" {
			if internal {
				it[k] = v
			}
			continue
		}
		f := m.F(k)
		if f == nil && m.View != "" {
			f = MenuMap[m.View].F(k)
		}
		if f == nil {
			if internal {
				it[k] = v
				continue
			}
			return nil, trap("unknown parameter %s", k)
		}
		if f.RO && !internal {
			return nil, trap("unknown parameter %s", k)
		}
		nv := v
		if !internal || f.Kind == "bool" {
			var err error
			nv, err = r.norm(m, f, v)
			if err != nil {
				return nil, err
			}
		}
		if nv == "" {
			delete(it, k)
		} else {
			it[k] = nv
		}
	}
	var miss []string
	for _, f := range m.Fields {
		if f.Req && it[f.Name] == "" {
			miss = append(miss, f.Name)
		}
	}
	if len(miss) > 0 {
		return nil, trap("missing value(s) of argument(s) %s", strings.Join(miss, ", "))
	}
	if m.Unique != "" {
		if it[m.Unique] == "" && m.Store() == "/interface" {
			it["name"] = r.autoName(m)
		}
		if err := r.checkUnique(m, it, it[m.Unique]); err != nil {
			return nil, err
		}
	}
	if it[".id"] == "" {
		it[".id"] = r.newID(m.Store())
	}
	if h := addHooks[m.Store()]; h != nil {
		if err := h(r, m, it); err != nil {
			return nil, err
		}
	}
	t := r.tbl(m.Store())
	t.Items = append(t.Items, it)
	if h := afterHooks[m.Store()]; h != nil {
		h(r, it)
	}
	if !it.B("dynamic") {
		r.markDirty()
	}
	r.notify(m.Store(), it, false)
	return it, nil
}

func (r *Router) autoName(m *Menu) string {
	base := m.TypeVal
	switch m.TypeVal {
	case "bridge":
		base = "bridge"
	case "vlan":
		base = "vlan"
	case "pppoe-out":
		base = "pppoe-out"
	}
	for i := 1; ; i++ {
		n := fmt.Sprintf("%s%d", base, i)
		if r.byName("/interface", n) == nil {
			return n
		}
	}
}

func (r *Router) setItem(m *Menu, it Item, args map[string]string, internal bool) error {
	if m.NoSet && !internal {
		return trap("no such command")
	}
	newVals := map[string]string{}
	for k, v := range args {
		if k == ".id" || k == "numbers" {
			continue
		}
		if strings.HasPrefix(k, "_") {
			if internal {
				newVals[k] = v
			}
			continue
		}
		f := m.F(k)
		if f == nil && m.View != "" {
			f = MenuMap[m.View].F(k)
		}
		if f == nil {
			if internal {
				newVals[k] = v
				continue
			}
			return trap("unknown parameter %s", k)
		}
		if f.RO && !internal && !(m.Path == "/ip/hotspot/active" && k == "comment") {
			if m.Path == "/system/clock" {
				newVals[k] = v
				continue
			}
			return trap("failure: can not set read-only property %s", k)
		}
		nv := v
		if !internal || f.Kind == "bool" {
			var err error
			nv, err = r.norm(m, f, v)
			if err != nil {
				return err
			}
		}
		newVals[k] = nv
	}
	if m.Unique != "" {
		if nv, ok := newVals[m.Unique]; ok {
			if nv == "" {
				return trap("invalid value for argument %s", m.Unique)
			}
			if err := r.checkUnique(m, it, nv); err != nil {
				return err
			}
		}
	}
	old := it.Clone()
	if h := setHooks[m.Store()]; h != nil && !internal {
		if err := h(r, m, it, newVals); err != nil {
			return err
		}
	}
	for k, v := range newVals {
		if v == "" {
			delete(it, k)
		} else {
			it[k] = v
		}
	}
	if old["name"] != "" && it["name"] != old["name"] {
		r.renameRefs(m.Store(), old["name"], it["name"])
	}
	if h := afterSetHooks[m.Store()]; h != nil {
		h(r, it, old)
	}
	if !it.B("dynamic") {
		r.markDirty()
	}
	r.notify(m.Store(), it, false)
	return nil
}

func (r *Router) removeItem(m *Menu, it Item, internal bool) error {
	if m.NoRemove && !internal {
		return trap("failure: can not remove this item")
	}
	if !internal && it["_default"] == "true" {
		return trap("failure: default item can not be removed")
	}
	if !internal && m.Store() == "/interface" && (it["type"] == "ether" || it["type"] == "wlan" || it["type"] == "wifi") {
		return trap("failure: can not remove %s interface", it["type"])
	}
	if h := delHooks[m.Store()]; h != nil {
		if err := h(r, it, internal); err != nil {
			return err
		}
	}
	t := r.tbl(m.Store())
	for i, x := range t.Items {
		if x[".id"] == it[".id"] {
			t.Items = append(t.Items[:i], t.Items[i+1:]...)
			break
		}
	}
	if h := afterDelHooks[m.Store()]; h != nil {
		h(r, it)
	}
	if !it.B("dynamic") {
		r.markDirty()
	}
	r.notify(m.Store(), it, true)
	return nil
}

// removeWhere removes items in store matching fn (internal use)
func (r *Router) removeWhere(path string, fn func(Item) bool) {
	m := MenuMap[path]
	for _, it := range append([]Item(nil), r.list(m)...) {
		if fn(it) {
			r.removeItem(m, it, true)
		}
	}
}

var renameFields = map[string][]string{
	"/interface": {"interface", "bridge", "in-interface", "out-interface", "on-interface", "port", "actual-interface", "parent"},
}

func (r *Router) renameRefs(store, old, nw string) {
	for _, m := range Menus {
		for _, f := range m.Fields {
			match := false
			if f.Ref != "" && MenuMap[f.Ref] != nil && MenuMap[f.Ref].Store() == store {
				match = true
			}
			for _, rf := range renameFields[store] {
				if rf == f.Name {
					match = true
				}
			}
			if !match {
				continue
			}
			for _, it := range r.list(m) {
				if it[f.Name] == old {
					it[f.Name] = nw
				}
			}
		}
	}
	if r.sim != nil {
		r.sim.renamed(old, nw)
	}
}

// output copy of an item restricted to menu fields
func (r *Router) out(m *Menu, it Item) Item {
	o := Item{}
	if !m.Single {
		o[".id"] = it[".id"]
	}
	for _, f := range m.Fields {
		if f.Hide {
			continue
		}
		if v, ok := it[f.Name]; ok && v != "" {
			o[f.Name] = v
		}
	}
	if m.Store() == "/interface" && m.Path != "/interface" {
		o["type"] = ""
		delete(o, "type")
	}
	return o
}

func orderedKeys(m *Menu, it Item) []string {
	var keys []string
	seen := map[string]bool{}
	if _, ok := it[".id"]; ok {
		keys = append(keys, ".id")
		seen[".id"] = true
	}
	if m != nil {
		for _, f := range m.Fields {
			if _, ok := it[f.Name]; ok && !seen[f.Name] {
				keys = append(keys, f.Name)
				seen[f.Name] = true
			}
		}
	}
	var rest []string
	for k := range it {
		if !seen[k] {
			rest = append(rest, k)
		}
	}
	sort.Strings(rest)
	return append(keys, rest...)
}

// ---------- API query evaluation ----------

func cmpVals(a, b string) int {
	fa, e1 := strconv.ParseFloat(a, 64)
	fb, e2 := strconv.ParseFloat(b, 64)
	if e1 == nil && e2 == nil {
		switch {
		case fa < fb:
			return -1
		case fa > fb:
			return 1
		}
		return 0
	}
	if da, ok := parseDur(a); ok && strings.ContainsAny(a, "smhdw") {
		if db, ok2 := parseDur(b); ok2 {
			switch {
			case da < db:
				return -1
			case da > db:
				return 1
			}
			return 0
		}
	}
	return strings.Compare(a, b)
}

func normQueryVal(v string) string {
	switch v {
	case "yes":
		return "true"
	case "no":
		return "false"
	}
	return v
}

func evalQuery(q []string, it Item) bool {
	if len(q) == 0 {
		return true
	}
	var st []bool
	for _, w := range q {
		w = strings.TrimPrefix(w, "?")
		if strings.HasPrefix(w, "=") {
			w = w[1:]
		}
		switch {
		case strings.HasPrefix(w, "#"):
			for _, op := range w[1:] {
				switch op {
				case '!':
					if len(st) > 0 {
						st[len(st)-1] = !st[len(st)-1]
					}
				case '&', '|':
					if len(st) >= 2 {
						a, b := st[len(st)-2], st[len(st)-1]
						st = st[:len(st)-2]
						if op == '&' {
							st = append(st, a && b)
						} else {
							st = append(st, a || b)
						}
					}
				case '.':
					if len(st) > 0 {
						st = append(st, st[len(st)-1])
					}
				default:
					if op >= '0' && op <= '9' {
						i := int(op - '0')
						if i < len(st) {
							st = append(st, st[i])
						}
					}
				}
			}
		case strings.HasPrefix(w, "-"):
			_, ok := it[w[1:]]
			st = append(st, !ok)
		case strings.HasPrefix(w, ">") || strings.HasPrefix(w, "<"):
			kv := strings.SplitN(w[1:], "=", 2)
			v, ok := it[kv[0]]
			res := false
			if ok && len(kv) == 2 {
				c := cmpVals(v, kv[1])
				res = (w[0] == '>' && c > 0) || (w[0] == '<' && c < 0)
			}
			st = append(st, res)
		default:
			kv := strings.SplitN(w, "=", 2)
			if len(kv) == 1 {
				_, ok := it[kv[0]]
				st = append(st, ok)
			} else {
				st = append(st, it[kv[0]] == normQueryVal(kv[1]) || it[kv[0]] == kv[1])
			}
		}
	}
	for _, b := range st {
		if !b {
			return false
		}
	}
	return true
}

// ---------- Exec ----------

func splitCmd(full string) (string, string) {
	full = "/" + strings.Trim(full, "/")
	i := strings.LastIndex(full, "/")
	if i <= 0 {
		return "", full[1:]
	}
	return full[:i], full[i+1:]
}

func hasCmd(m *Menu, cmd string) bool {
	base := listCmds
	if m.Single {
		base = singleCmds
	}
	for _, c := range base {
		if c == cmd {
			if m.Single && cmd == "set" && m.NoSet {
				return false
			}
			return true
		}
	}
	for _, c := range m.Cmds {
		if c == cmd {
			return true
		}
	}
	if (cmd == "move") && m.Ordered {
		return true
	}
	return false
}

// Exec executes a RouterOS command. emit is called for each !re reply.
func (r *Router) Exec(c *Ctx, full string, args map[string]string, q []string, emit func(Item)) (string, error) {
	if args == nil {
		args = map[string]string{}
	}
	full = "/" + strings.Trim(strings.ReplaceAll(full, " ", "/"), "/")
	if c.Done == nil {
		c.Done = make(chan struct{})
	}
	if fn, ok := specials[full]; ok {
		return fn(r, c, args, emit)
	}
	path, cmd := splitCmd(full)
	m := MenuMap[path]
	if m == nil {
		if Dirs[full] {
			return "", trap("no such command")
		}
		return "", trap("no such command prefix")
	}
	if fn, ok := specials[full]; ok {
		return fn(r, c, args, emit)
	}
	if !hasCmd(m, cmd) {
		return "", trap("no such command")
	}
	if cmd == "listen" {
		return r.listen(c, m, emit)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.state != "running" && !strings.HasPrefix(path, "/sim") && !c.Internal {
		return "", trap("router is not running")
	}
	if fn, ok := menuCmds[full]; ok {
		return fn(r, c, m, args, emit)
	}
	switch cmd {
	case "print", "getall":
		return r.print(c, m, args, q, emit)
	case "add":
		if m.Single {
			return "", trap("no such command")
		}
		placeBefore, hasPB := args["place-before"]
		if hasPB {
			if !m.Ordered {
				return "", trap("unknown parameter place-before")
			}
			delete(args, "place-before")
		}
		if c.Lenient {
			r.lenientArgs(c, m, args)
		}
		it, err := r.addItem(m, args, false)
		if err == nil && hasPB && placeBefore != "" {
			if d := r.findRef(m, strings.SplitN(placeBefore, ",", 2)[0]); d != nil {
				r.move(m, []Item{it}, d[".id"])
			}
		}
		if err != nil && c.Lenient {
			if strings.HasPrefix(err.Error(), "failure: already have") || strings.Contains(err.Error(), "already exists") {
				if ex := r.findRef(m, args[firstNonEmpty(m.Unique, "name")]); ex != nil {
					a := map[string]string{}
					for k, v := range args {
						if k != m.Unique {
							a[k] = v
						}
					}
					if err2 := r.setItem(m, ex, a, false); err2 == nil {
						c.Warnings = append(c.Warnings, "updated the existing "+itemSummary(ex))
						return ex[".id"], nil
					}
				}
			}
			err = r.retryLenient(c, m, args, err, func() error {
				var e error
				it, e = r.addItem(m, args, false)
				return e
			})
			if err != nil && strings.Contains(err.Error(), "already") {
				c.Warnings = append(c.Warnings, "already present, left unchanged ("+err.Error()+")")
				return "", nil
			}
		}
		if err != nil {
			return "", err
		}
		r.history("add", m, c.User)
		return it[".id"], nil
	case "set":
		if c.Lenient {
			r.lenientArgs(c, m, args)
		}
		if m.Single {
			err := r.setItem(m, r.single(m.Path), args, false)
			if err != nil && c.Lenient {
				err = r.retryLenient(c, m, args, err, func() error { return r.setItem(m, r.single(m.Path), args, false) })
			}
			return "", err
		}
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if err != nil {
			return "", err
		}
		for _, it := range ts {
			err := r.setItem(m, it, args, false)
			if err != nil && c.Lenient {
				x := it
				err = r.retryLenient(c, m, args, err, func() error { return r.setItem(m, x, args, false) })
			}
			if err != nil {
				return "", err
			}
		}
		r.history("set", m, c.User)
		return "", nil
	case "remove":
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if err != nil {
			return "", err
		}
		for _, it := range ts {
			if err := r.removeItem(m, it, false); err != nil {
				if t, ok := err.(*Trap); ok && t.Msg == "__handled" {
					continue
				}
				return "", err
			}
		}
		r.history("remove", m, c.User)
		return "", nil
	case "enable", "disable":
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if err != nil {
			return "", err
		}
		v := "false"
		if cmd == "disable" {
			v = "true"
		}
		for _, it := range ts {
			if m.F("disabled") == nil {
				return "", trap("no such command")
			}
			if err := r.setItem(m, it, map[string]string{"disabled": v}, true); err != nil {
				return "", err
			}
		}
		return "", nil
	case "comment":
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if err != nil {
			return "", err
		}
		for _, it := range ts {
			r.setItem(m, it, map[string]string{"comment": args["comment"]}, true)
		}
		return "", nil
	case "unset":
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if m.Single {
			ts, err = []Item{r.single(m.Path)}, nil
		}
		if err != nil {
			return "", err
		}
		vn := args["value-name"]
		f := m.F(vn)
		if f == nil {
			return "", trap("unknown parameter %s", vn)
		}
		for _, it := range ts {
			r.setItem(m, it, map[string]string{vn: f.Def}, true)
		}
		return "", nil
	case "get":
		var it Item
		if m.Single {
			it = r.single(m.Path)
			if h := refreshHooks[m.Path]; h != nil {
				h(r, it)
			}
		} else {
			ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
			if err != nil {
				return "", err
			}
			it = ts[0]
		}
		vn := args["value-name"]
		if vn == "" {
			return "", trap("missing value(s) of argument(s) value-name")
		}
		if vn == ".id" {
			return it[".id"], nil
		}
		if m.F(vn) == nil && vn != "type" {
			return "", trap("no such item")
		}
		return it[vn], nil
	case "find":
		var ids []string
		for _, it := range r.list(m) {
			if evalQuery(argsToQuery(args), it) {
				ids = append(ids, it[".id"])
			}
		}
		return strings.Join(ids, ";"), nil
	case "export":
		_, sens := args["show-sensitive"]
		return r.export(m.Path, sens), nil
	case "move":
		ts, err := r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
		if err != nil {
			return "", err
		}
		r.move(m, ts, args["destination"])
		return "", nil
	case "reset-counters", "reset-counters-all":
		var ts []Item
		if cmd == "reset-counters-all" {
			ts = r.list(m)
		} else {
			var err error
			ts, err = r.targets(m, firstNonEmpty(args[".id"], args["numbers"]))
			if err != nil {
				return "", err
			}
		}
		for _, it := range ts {
			resetCounters(m, it)
		}
		return "", nil
	}
	return "", trap("no such command")
}

func argsToQuery(args map[string]string) []string {
	var q []string
	for k, v := range args {
		if k == "where" || k == ".proplist" {
			continue
		}
		q = append(q, k+"="+v)
	}
	return q
}

func resetCounters(m *Menu, it Item) {
	for _, f := range m.Fields {
		if !f.RO {
			continue
		}
		switch {
		case f.Name == "uptime" && m.Path == "/ip/hotspot/user":
			it[f.Name] = "0s"
		case strings.Contains(f.Name, "byte") || strings.Contains(f.Name, "packet") || strings.Contains(f.Name, "drop") || strings.Contains(f.Name, "error") || f.Name == "bytes" || f.Name == "packets" || f.Name == "dropped":
			if strings.Contains(it[f.Name], "/") {
				it[f.Name] = "0/0"
			} else {
				it[f.Name] = "0"
			}
		}
	}
}

func firstNonEmpty(a ...string) string {
	for _, s := range a {
		if s != "" {
			return s
		}
	}
	return ""
}

func (r *Router) move(m *Menu, ts []Item, dest string) {
	t := r.tbl(m.Store())
	ids := map[string]bool{}
	for _, it := range ts {
		ids[it[".id"]] = true
	}
	var rest []Item
	for _, it := range t.Items {
		if !ids[it[".id"]] {
			rest = append(rest, it)
		}
	}
	pos := len(rest)
	if d := r.findRef(m, dest); d != nil {
		for i, it := range rest {
			if it[".id"] == d[".id"] {
				pos = i
			}
		}
	}
	out := append([]Item{}, rest[:pos]...)
	out = append(out, ts...)
	out = append(out, rest[pos:]...)
	t.Items = out
	r.markDirty()
}

func (r *Router) print(c *Ctx, m *Menu, args map[string]string, q []string, emit func(Item)) (string, error) {
	var items []Item
	if m.Single {
		it := r.single(m.Path)
		if h := refreshHooks[m.Path]; h != nil {
			h(r, it)
		}
		items = []Item{it}
	} else {
		if h := refreshHooks[m.Path]; h != nil {
			h(r, nil)
		}
		items = r.list(m)
	}
	var props []string
	if p := args[".proplist"]; p != "" {
		props = strings.Split(p, ",")
	}
	var from map[string]bool
	if f := args["from"]; f != "" {
		from = map[string]bool{}
		for _, x := range strings.Split(f, ",") {
			if it := r.findRef(m, x); it != nil {
				from[it[".id"]] = true
			}
		}
	}
	_, countOnly := args["count-only"]
	cnt := 0
	for _, it := range items {
		if from != nil && !from[it[".id"]] {
			continue
		}
		o := r.out(m, it)
		if !evalQuery(q, o) {
			continue
		}
		cnt++
		if countOnly {
			continue
		}
		if props != nil {
			p := Item{}
			for _, k := range props {
				k = strings.TrimSpace(k)
				if v, ok := o[k]; ok {
					p[k] = v
				}
			}
			o = p
		}
		emit(o)
	}
	if countOnly {
		return strconv.Itoa(cnt), nil
	}
	return "", nil
}

func (r *Router) listen(c *Ctx, m *Menu, emit func(Item)) (string, error) {
	r.mu.Lock()
	id := r.nextW
	r.nextW++
	w := &watcher{store: m.Store(), ch: make(chan Item, 256)}
	r.watchers[id] = w
	r.mu.Unlock()
	defer func() {
		r.mu.Lock()
		delete(r.watchers, id)
		r.mu.Unlock()
	}()
	for {
		select {
		case <-c.Done:
			return "", &Trap{Msg: "interrupted", Cat: 2}
		case it := <-w.ch:
			if m.View != "" && it[".dead"] == "" && it["type"] != m.TypeVal {
				continue
			}
			if it[".dead"] == "" {
				it = r.out(m, it)
			}
			emit(it)
		}
	}
}

func (r *Router) history(action string, m *Menu, user string) {
	if user == "" || user == "system" {
		return
	}
	h := r.tbl("/system/history")
	h.Items = append(h.Items, Item{".id": r.newID("/system/history"), "action": action + " " + m.Title, "by": user, "policy": "write", "time": r.now().Format("2006-01-02 15:04:05"), "undoable": "true"})
	if len(h.Items) > 100 {
		h.Items = h.Items[len(h.Items)-100:]
	}
}

// ---------- logging ----------

func (r *Router) now() time.Time { return time.Now().Add(r.clockOff) }

func (r *Router) log(topics, msg string, a ...any) {
	if len(a) > 0 {
		msg = fmt.Sprintf(msg, a...)
	}
	t := r.tbl("/log")
	it := Item{".id": r.newID("/log"), "time": r.now().Format("2006-01-02 15:04:05"), "topics": topics, "message": msg}
	t.Items = append(t.Items, it)
	if len(t.Items) > 1000 {
		t.Items = t.Items[len(t.Items)-1000:]
	}
	r.notify("/log", it, false)
	if r.Opt != nil && r.Opt.Verbose {
		fmt.Printf("  [log] %s %s\n", topics, msg)
	}
}

// ---------- auth ----------

func (r *Router) checkUser(name, pass, via, addr string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if i := strings.Index(name, "+"); i > 0 {
		name = name[:i]
	}
	u := r.byName("/user", name)
	if u == nil || u.B("disabled") || u["password"] != pass {
		r.log("system,error,critical", "login failure for user %s from %s via %s", name, addr, via)
		return trap("invalid user name or password (6)")
	}
	g := r.byName("/user/group", u["group"])
	if g != nil {
		pol := "," + g["policy"] + ","
		need := map[string]string{"api": "api", "api-ssl": "api", "telnet": "telnet", "ssh": "ssh", "winbox": "winbox", "web": "web", "rest": "rest-api"}[via]
		if need != "" && strings.Contains(pol, ",!"+need+",") {
			return trap("not enough permissions (9)")
		}
	}
	return nil
}

func (r *Router) userLogin(name, via, addr string) string {
	r.mu.Lock()
	defer r.mu.Unlock()
	if i := strings.Index(name, "+"); i > 0 {
		name = name[:i]
	}
	u := r.byName("/user", name)
	grp := "full"
	if u != nil {
		u["last-logged-in"] = r.now().Format("2006-01-02 15:04:05")
		grp = u["group"]
	}
	if via != "script" && via != "import" {
		r.log("system,info,account", "user %s logged in from %s via %s", name, firstNonEmpty(hostOnly(addr), addr), via)
	}
	it, _ := r.addItem(MenuMap["/user/active"], map[string]string{"when": r.now().Format("2006-01-02 15:04:05"), "name": name, "address": addr, "via": via, "group": grp, "radius": "false"}, true)
	if via != "rest" && via != "web" {
		r.log("system,info,account", "user %s logged in from %s via %s", name, addr, via)
	}
	return it[".id"]
}

func (r *Router) userLogout(id string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	m := MenuMap["/user/active"]
	if it := r.findRef(m, id); it != nil {
		if it["via"] != "rest" && it["via"] != "web" {
			r.log("system,info,account", "user %s logged out from %s via %s", it["name"], it["address"], it["via"])
		}
		r.removeItem(m, it, true)
	}
}

// kick registers a callback invoked when the router reboots (to drop sessions)
func (r *Router) onKick(fn func()) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	id := r.nextK
	r.nextK++
	r.kickers[id] = fn
	return id
}
func (r *Router) offKick(id int) {
	r.mu.Lock()
	delete(r.kickers, id)
	r.mu.Unlock()
}

// ---------- persistence ----------

type saved struct {
	App     string            `json:"app"`
	Model   string            `json:"model"`
	Saved   string            `json:"saved"`
	Tables  map[string]*Table `json:"tables"`
	BaseMAC string            `json:"base_mac"`
	MacSeq  int               `json:"mac_seq"`
}

func (r *Router) snapshot() []byte {
	s := saved{App: "TikLab " + AppVersion, Model: r.Model.Key, Saved: time.Now().Format(time.RFC3339), Tables: map[string]*Table{}, BaseMAC: r.baseMAC.String(), MacSeq: r.macSeq}
	for _, m := range Menus {
		if m.NoSave || m.View != "" {
			continue
		}
		t := r.T[m.Path]
		if t == nil {
			continue
		}
		nt := &Table{Next: t.Next}
		for _, it := range t.Items {
			if it.B("dynamic") && it["_keep"] != "true" {
				continue
			}
			nt.Items = append(nt.Items, it)
		}
		s.Tables[m.Path] = nt
	}
	b, _ := json.MarshalIndent(s, "", " ")
	return b
}

func (r *Router) save() {
	r.mu.Lock()
	if !r.dirty {
		r.mu.Unlock()
		return
	}
	b := r.snapshot()
	r.dirty = false
	r.mu.Unlock()
	p := filepath.Join(r.dataDir, "config.json")
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, b, 0644); err == nil {
		os.Rename(tmp, p)
	}
}

func (r *Router) loadSnapshot(b []byte) error {
	var s saved
	if err := json.Unmarshal(b, &s); err != nil {
		return err
	}
	if len(s.Tables) == 0 {
		return fmt.Errorf("empty config")
	}
	r.T = map[string]*Table{}
	for k, v := range s.Tables {
		if MenuMap[k] != nil {
			r.T[k] = v
		}
	}
	if mac, err := net.ParseMAC(s.BaseMAC); err == nil {
		r.baseMAC = mac
	}
	if s.MacSeq > 0 {
		r.macSeq = s.MacSeq
	}
	return nil
}

func (r *Router) load() bool {
	b, err := os.ReadFile(filepath.Join(r.dataDir, "config.json"))
	if err != nil {
		return false
	}
	if err := r.loadSnapshot(b); err != nil {
		fmt.Println("  ! config.json unreadable, starting with defaults:", err)
		return false
	}
	return true
}

// ---------- export ----------

func quoteVal(v string) string {
	if v == "" {
		return `""`
	}
	if strings.ContainsAny(v, " \t\"$[]{};\\=\n") {
		v = strings.ReplaceAll(v, `\`, `\\`)
		v = strings.ReplaceAll(v, `"`, `\"`)
		v = strings.ReplaceAll(v, "$", `\$`)
		v = strings.ReplaceAll(v, "\n", `\n`)
		v = strings.ReplaceAll(v, "\r", `\r`)
		return `"` + v + `"`
	}
	return v
}

func cliVal(f *Field, v string) string {
	if f != nil && f.Kind == "bool" {
		if v == "true" {
			return "yes"
		}
		return "no"
	}
	return v
}

// ---------- hooks registries ----------

type addHook func(r *Router, m *Menu, it Item) error
type setHook func(r *Router, m *Menu, it Item, nv map[string]string) error
type delHook func(r *Router, it Item, internal bool) error

var addHooks = map[string]addHook{}
var afterHooks = map[string]func(r *Router, it Item){}
var setHooks = map[string]setHook{}
var afterSetHooks = map[string]func(r *Router, it, old Item){}
var delHooks = map[string]delHook{}
var afterDelHooks = map[string]func(r *Router, it Item){}
var refreshHooks = map[string]func(r *Router, it Item){}

type specialFn func(r *Router, c *Ctx, args map[string]string, emit func(Item)) (string, error)
type menuCmdFn func(r *Router, c *Ctx, m *Menu, args map[string]string, emit func(Item)) (string, error)

var specials = map[string]specialFn{}
var menuCmds = map[string]menuCmdFn{}
