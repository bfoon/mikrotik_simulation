package main

// Configuration transfer: RouterOS-valid export, tolerant import of real
// router exports, model/interface detection, and cloning a real router.

import (
	"fmt"
	"io"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// ---------------- sections & order ----------------

type exportSection struct {
	Key   string   `json:"key"`
	Title string   `json:"title"`
	Paths []string `json:"paths"`
}

var ExportSections = []exportSection{
	{"interfaces", "Interfaces, bridges, VLANs and lists", []string{"/interface/bridge", "/interface/ethernet", "/interface/eoip", "/interface/wireguard", "/interface/vlan", "/interface/pppoe-client", "/interface/list", "/interface/bridge/port", "/interface/bridge/vlan", "/interface/list/member", "/interface/wireguard/peers", "/ip/neighbor/discovery-settings"}},
	{"wireless", "Wireless and Wi-Fi", []string{"/interface/wireless/security-profiles", "/interface/wireless", "/interface/wireless/access-list", "/interface/wifi"}},
	{"ip", "IP addresses, routes, DNS and services", []string{"/ip/settings", "/ipv6/settings", "/ip/address", "/ip/arp", "/ip/cloud", "/ip/dns", "/ip/dns/static", "/ip/route", "/ip/upnp", "/ip/proxy", "/ip/socks", "/ip/ssh", "/ip/traffic-flow", "/ipv6/address"}},
	{"dhcp", "DHCP and address pools", []string{"/ip/pool", "/ip/dhcp-server", "/ip/dhcp-server/option", "/ip/dhcp-client", "/ip/dhcp-relay", "/ip/dhcp-server/lease", "/ip/dhcp-server/network"}},
	{"firewall", "Firewall and NAT", []string{"/ip/firewall/address-list", "/ip/firewall/layer7-protocol", "/ip/firewall/filter", "/ip/firewall/mangle", "/ip/firewall/nat", "/ip/firewall/raw", "/ip/firewall/service-port"}},
	{"hotspot", "Hotspot servers, profiles and walled garden", []string{"/ip/hotspot/profile", "/ip/hotspot/user/profile", "/ip/hotspot", "/ip/hotspot/ip-binding", "/ip/hotspot/service-port", "/ip/hotspot/walled-garden", "/ip/hotspot/walled-garden/ip"}},
	{"vouchers", "Hotspot users (vouchers)", []string{"/ip/hotspot/user"}},
	{"ppp", "PPP profiles, PPPoE server and secrets", []string{"/ppp/profile", "/interface/l2tp-server/server", "/interface/ovpn-server/server", "/interface/pppoe-server/server", "/interface/pptp-server/server", "/interface/sstp-server/server", "/ppp/aaa", "/ppp/secret"}},
	{"queues", "Queues", []string{"/queue/type", "/queue/simple", "/queue/tree"}},
	{"system", "System, users and logging", []string{"/user/group", "/system/logging/action", "/system/clock", "/system/identity", "/system/logging", "/system/note", "/system/ntp/client", "/system/ntp/server", "/system/routerboard/settings", "/user", "/user/settings"}},
	{"scripts", "Scripts and scheduler", []string{"/system/scheduler", "/system/script"}},
	{"tools", "RADIUS, SNMP and tools", []string{"/radius", "/radius/incoming", "/snmp/community", "/snmp", "/tool/bandwidth-server", "/tool/e-mail", "/tool/graphing/interface", "/tool/mac-server", "/tool/mac-server/mac-winbox", "/tool/netwatch", "/tool/romon"}},
	{"services", "IP service ports (careful: affects access)", []string{"/ip/service"}},
}

// order in which RouterOS-style exports list menus (dependencies first)
var exportSeq = []string{
	"/interface/bridge", "/interface/ethernet", "/interface/eoip", "/interface/wireguard", "/interface/vlan", "/interface/pppoe-client", "/interface/list",
	"/interface/wireless/security-profiles", "/interface/wireless", "/interface/wireless/access-list", "/interface/wifi",
	"/ip/hotspot/profile", "/ip/hotspot/user/profile", "/ip/pool", "/ip/dhcp-server", "/ip/dhcp-server/option", "/ip/hotspot", "/ppp/profile", "/queue/type", "/queue/simple", "/queue/tree",
	"/snmp/community", "/system/logging/action", "/user/group",
	"/interface/bridge/port", "/interface/bridge/vlan", "/ip/neighbor/discovery-settings", "/ip/settings", "/ipv6/settings",
	"/interface/l2tp-server/server", "/interface/ovpn-server/server", "/interface/pppoe-server/server", "/interface/pptp-server/server", "/interface/sstp-server/server",
	"/interface/list/member", "/interface/wireguard/peers",
	"/ip/address", "/ip/arp", "/ip/cloud", "/ip/dhcp-client", "/ip/dhcp-relay", "/ip/dhcp-server/lease", "/ip/dhcp-server/network", "/ip/dns", "/ip/dns/static",
	"/ip/firewall/address-list", "/ip/firewall/layer7-protocol", "/ip/firewall/filter", "/ip/firewall/mangle", "/ip/firewall/nat", "/ip/firewall/raw", "/ip/firewall/service-port",
	"/ip/hotspot/ip-binding", "/ip/hotspot/service-port", "/ip/hotspot/user", "/ip/hotspot/walled-garden", "/ip/hotspot/walled-garden/ip",
	"/ip/proxy", "/ip/route", "/ip/service", "/ip/socks", "/ip/ssh", "/ip/traffic-flow", "/ip/upnp", "/ipv6/address",
	"/ppp/aaa", "/ppp/secret", "/radius", "/radius/incoming", "/snmp",
	"/system/clock", "/system/identity", "/system/logging", "/system/note", "/system/ntp/client", "/system/ntp/server", "/system/routerboard/settings", "/system/scheduler", "/system/script",
	"/tool/bandwidth-server", "/tool/e-mail", "/tool/graphing/interface", "/tool/mac-server", "/tool/mac-server/mac-winbox", "/tool/netwatch", "/tool/romon", "/user", "/user/settings",
}

var sectionOf = map[string]string{}

func init() {
	for _, s := range ExportSections {
		for _, p := range s.Paths {
			sectionOf[p] = s.Key
		}
	}
}

var sensitiveFields = map[string]bool{"password": true, "wpa-pre-shared-key": true, "wpa2-pre-shared-key": true, "security.passphrase": true, "secret": true, "private-key": true, "preshared-key": true, "ipsec-secret": true, "secrets": true}

// fields that reference interfaces (checked when mapping to another model)
var ifaceFields = []string{"interface", "bridge", "in-interface", "out-interface", "parent", "port", "actual-interface"}

var physRe = regexp.MustCompile(`^(ether\d+|combo\d+|sfp\d+|sfp-sfpplus\d+|sfp28-\d+|qsfp28-\d+-\d+|wlan\d+|wifi\d+)$`)

// ---------------- export ----------------

type ExportOpts struct {
	Sections  []string `json:"sections"`
	Sensitive bool     `json:"sensitive"`
	Target    string   `json:"target"`
	Full      bool     `json:"full"`
	Wrap      bool     `json:"wrap"`
	FileName  string   `json:"fileName"`
	Prefix    string   `json:"-"`
}

type ExportResult struct {
	Script   string   `json:"script"`
	Warnings []string `json:"warnings"`
	Lines    int      `json:"lines"`
	Skipped  int      `json:"skipped"`
	Target   string   `json:"target"`
}

func rosQuote(v string) string {
	need := v == ""
	var b strings.Builder
	for _, ch := range []byte(v) {
		switch {
		case ch == '"' || ch == '\\' || ch == '$':
			b.WriteByte('\\')
			b.WriteByte(ch)
			need = true
		case ch == '\n':
			b.WriteString(`\n`)
			need = true
		case ch == '\r':
			b.WriteString(`\r`)
			need = true
		case ch == '\t':
			b.WriteString(`\t`)
			need = true
		case ch >= 0x80 || ch < 0x20:
			fmt.Fprintf(&b, "\\%02X", ch)
			need = true
		case ch == ' ' || ch == ';' || ch == '[' || ch == ']' || ch == '{' || ch == '}' || ch == '=' || ch == '?' || ch == '#':
			b.WriteByte(ch)
			need = true
		default:
			b.WriteByte(ch)
		}
	}
	if need {
		return `"` + b.String() + `"`
	}
	return b.String()
}

func isDefaultItem(m *Menu, it Item) bool {
	if it["_default"] == "true" || it["default"] == "true" || it["builtin"] == "true" {
		return true
	}
	if m.Path == "/user/group" && (it["name"] == "read" || it["name"] == "write" || it["name"] == "full") {
		return true
	}
	if m.Path == "/ip/hotspot/user" && it["name"] == "default-trial" {
		return true
	}
	if (m.Path == "/ppp/profile") && (it["name"] == "default" || it["name"] == "default-encryption") {
		return true
	}
	if (m.Path == "/ip/hotspot/profile" || m.Path == "/ip/hotspot/user/profile" || m.Path == "/interface/wireless/security-profiles") && it["name"] == "default" {
		return true
	}
	return false
}

// exportMenu renders one menu's items as RouterOS commands.
// mapIf maps physical interface default-names to target names ("" = missing).
func exportMenu(m *Menu, items []Item, opt ExportOpts, mapIf func(string) (string, bool), physByName map[string]string, warn func(string)) []string {
	var lines []string
	kvs := func(it Item, skip map[string]bool, keep map[string]bool) []string {
		var keys []string
		base := baseline(it)
		for _, f := range m.Fields {
			if f.RO || f.Hide || skip[f.Name] {
				continue
			}
			v, ok := it[f.Name]
			if !ok {
				continue
			}
			if sensitiveFields[f.Name] && !opt.Sensitive {
				continue
			}
			if v == f.Def && !keep[f.Name] {
				continue
			}
			if base != nil && !keep[f.Name] {
				if bv, ok := base[f.Name]; ok && bv == v || !ok && v == f.Def {
					continue
				}
			}
			if v == "" && f.Def == "" && !keep[f.Name] {
				continue
			}
			keys = append(keys, f.Name)
		}
		sort.Strings(keys)
		var out []string
		for _, k := range keys {
			out = append(out, k+"="+rosQuote(cliVal(m.F(k), it[k])))
		}
		return out
	}
	// remap interface references; returns false if the item must be skipped
	remap := func(it Item) (Item, bool) {
		c := it.Clone()
		for _, fname := range ifaceFields {
			v := c[fname]
			if v == "" {
				continue
			}
			var parts []string
			for _, x := range strings.Split(v, ",") {
				neg := strings.HasPrefix(x, "!")
				x = strings.TrimPrefix(x, "!")
				phys := physByName[x]
				if phys == "" && physRe.MatchString(x) {
					phys = x
				}
				if phys != "" {
					t, ok := mapIf(phys)
					if !ok {
						return nil, false
					}
					if x == phys {
						x = t
					}
				}
				if neg {
					x = "!" + x
				}
				parts = append(parts, x)
			}
			c[fname] = strings.Join(parts, ",")
		}
		return c, true
	}
	keep := map[string]bool{}
	if m.Unique != "" {
		keep[m.Unique] = true
	}
	for _, f := range m.Fields {
		if f.Req {
			keep[f.Name] = true
		}
	}
	if m.Single {
		if len(items) == 0 {
			return nil
		}
		if p := kvs(items[0], nil, nil); len(p) > 0 {
			lines = append(lines, "set "+strings.Join(p, " "))
		}
		return lines
	}
	defaults := 0
	for _, it := range items {
		if isDefaultItem(m, it) {
			defaults++
		}
	}
	for _, it := range items {
		if it["dynamic"] == "true" {
			continue
		}
		switch {
		case m.Path == "/interface/ethernet" || m.Path == "/interface/wireless" || m.Path == "/interface/wifi":
			dn := firstNonEmpty(it["default-name"], it["name"])
			t, ok := mapIf(dn)
			if !ok {
				if p := kvs(it, map[string]bool{"name": it["name"] == dn, "mac-address": true}, nil); len(p) > 0 {
					warn(fmt.Sprintf("%s settings skipped: %s does not exist on the target router", dn, dn))
				}
				continue
			}
			skip := map[string]bool{"mac-address": true, "orig-mac-address": true}
			if it["name"] == dn {
				skip["name"] = true
			}
			if it["auto-negotiation"] != "false" && (it["_spd0"] == "" || it["speed"] == it["_spd0"]) {
				skip["speed"], skip["advertise"] = true, true
			}
			c := it.Clone()
			if c["name"] == dn {
				c["name"] = t
			}
			if p := kvs(c, skip, nil); len(p) > 0 {
				lines = append(lines, fmt.Sprintf("set [ find default-name=%s ] %s", t, strings.Join(p, " ")))
			}
		case m.NoAdd:
			if p := kvs(it, map[string]bool{"name": true}, nil); len(p) > 0 && it["name"] != "" {
				lines = append(lines, fmt.Sprintf("set %s %s", rosQuote(it["name"]), strings.Join(p, " ")))
			}
		case isDefaultItem(m, it):
			if p := kvs(it, map[string]bool{"name": true}, nil); len(p) > 0 {
				switch {
				case it["name"] != "":
					lines = append(lines, fmt.Sprintf("set [ find name=%s ] %s", rosQuote(it["name"]), strings.Join(p, " ")))
				case defaults == 1:
					lines = append(lines, fmt.Sprintf("set [ find default=yes ] %s", strings.Join(p, " ")))
				}
			}
		case m.Path == "/user":
			if it["name"] == "admin" {
				continue
			}
			p := kvs(it, map[string]bool{"password": true}, keep)
			lines = append(lines, "add "+strings.Join(p, " "))
			warn(fmt.Sprintf("user %s exported without a password: set it on the router with /user set %s password=...", it["name"], it["name"]))
		default:
			c, ok := remap(it)
			if !ok {
				warn(fmt.Sprintf("%s: skipped an entry that uses an interface missing on the target (%s)", m.Path, itemSummary(it)))
				continue
			}
			lines = append(lines, "add "+strings.Join(kvs(c, nil, keep), " "))
		}
	}
	return lines
}

func itemSummary(it Item) string {
	for _, k := range []string{"name", "interface", "address", "chain", "comment"} {
		if v := it[k]; v != "" {
			return k + "=" + v
		}
	}
	return it[".id"]
}

func wrapLine(l string) string {
	if len(l) <= 90 {
		return l
	}
	// break between parameters, never inside quotes
	var out strings.Builder
	cur := 0
	inq := false
	last := 0
	for i := 0; i < len(l); i++ {
		switch l[i] {
		case '\\':
			i++
		case '"':
			inq = !inq
		case ' ':
			if !inq && i-last > 0 {
				if cur+(i-last) > 84 && cur > 0 {
					out.WriteString("\\\n    ")
					cur = 4
				}
				out.WriteString(l[last : i+1])
				cur += i + 1 - last
				last = i + 1
			}
		}
	}
	if cur+(len(l)-last) > 84 && cur > 0 {
		out.WriteString("\\\n    ")
	}
	out.WriteString(l[last:])
	return out.String()
}

// exportScript builds a RouterOS script. Lock held.
func (r *Router) exportScript(opt ExportOpts) ExportResult {
	res := ExportResult{}
	want := map[string]bool{}
	for _, s := range opt.Sections {
		want[s] = true
	}
	all := len(want) == 0
	target := r.Model
	if t := lookupModel(opt.Target); t != nil {
		target = t
	}
	res.Target = target.Key
	te, ts, tw := target.portNames()
	tset := map[string]bool{}
	for _, n := range append(append(te, ts...), tw...) {
		tset[n] = true
	}
	sameHW := target.Key == r.Model.Key
	mapIf := func(dn string) (string, bool) {
		if sameHW || tset[dn] {
			return dn, true
		}
		// wlanN <-> wifiN between wireless generations
		if strings.HasPrefix(dn, "wlan") && tset["wifi"+dn[4:]] {
			return "wifi" + dn[4:], true
		}
		if strings.HasPrefix(dn, "wifi") && tset["wlan"+dn[4:]] {
			return "wlan" + dn[4:], true
		}
		return "", false
	}
	physByName := map[string]string{}
	for _, it := range r.list(MenuMap["/interface"]) {
		if dn := it["default-name"]; dn != "" {
			physByName[it["name"]] = dn
		}
	}
	warnSet := map[string]bool{}
	warn := func(s string) {
		if !warnSet[s] {
			warnSet[s] = true
			res.Warnings = append(res.Warnings, s)
		}
	}
	var b strings.Builder
	now := r.now()
	ver := strings.Fields(r.Ver)[0]
	fname := firstNonEmpty(opt.FileName, "tiklab-config.rsc")
	fmt.Fprintf(&b, "# %s by RouterOS %s\n", now.Format("2006-01-02 15:04:05"), ver)
	fmt.Fprintf(&b, "# software id = %s\n#\n", r.S("/system/license", "software-id"))
	if target.RouterBoard {
		fmt.Fprintf(&b, "# model = %s\n", target.Name)
	}
	fmt.Fprintf(&b, "# exported from TikLab %s (simulated %s)\n", AppVersion, r.Model.Board)
	if !sameHW {
		fmt.Fprintf(&b, "# interfaces mapped for target %s (%s)\n", target.Board, target.Name)
	}
	if !opt.Sensitive {
		b.WriteString("# passwords and keys are NOT included (export without sensitive data)\n")
	}
	if opt.Full {
		fmt.Fprintf(&b, `#
# HOW TO APPLY ON A REAL ROUTER (replaces its whole configuration):
#   1. Upload this file to the router: drag it into WinBox > Files, or copy it with FTP.
#   2. Open a terminal on the router and run:
#        /system reset-configuration no-defaults=yes skip-backup=yes run-after-reset=%s
#   3. The router reboots and applies this file. Wait about a minute, then reconnect
#      with WinBox using the MAC address or the new IP address.
#   After a no-defaults reset the admin password is empty. Set one:  /user set admin password=...
#
# To ADD this configuration to a router that is already set up, run instead:
#   /import file-name=%s verbose=yes
#
# wait for interfaces to come up after the reset
:delay 15s
`, fname, fname)
	} else {
		fmt.Fprintf(&b, "#\n# To apply: upload to the router, then run  /import file-name=%s verbose=yes\n", fname)
	}
	for _, p := range exportSeq {
		m := MenuMap[p]
		if m == nil {
			continue
		}
		if opt.Prefix != "" && opt.Prefix != "/" && !strings.HasPrefix(p, opt.Prefix) {
			continue
		}
		sec := sectionOf[p]
		if !(all && sec != "services") && !want[sec] {
			continue
		}
		var items []Item
		if m.Single {
			it := r.single(p)
			items = []Item{it}
		} else {
			items = r.list(m)
		}
		lines := exportMenu(m, items, opt, mapIf, physByName, warn)
		if len(lines) == 0 {
			continue
		}
		b.WriteString(p[0:1] + strings.ReplaceAll(p[1:], "/", " ") + "\n")
		for _, l := range lines {
			if opt.Wrap {
				l = wrapLine(l)
			}
			b.WriteString(l + "\n")
			res.Lines++
		}
	}
	if opt.Full {
		b.WriteString(":log info \"TikLab configuration applied\"\n")
	}
	res.Script = b.String()
	return res
}

// legacy helper used by CLI / API export
func (r *Router) export(prefix string, sensitive bool) string {
	return r.exportScript(ExportOpts{Prefix: prefix, Sensitive: sensitive, Wrap: true, Sections: allSectionKeys(prefix == "/ip/service")}).Script
}

func allSectionKeys(withServices bool) []string {
	var out []string
	for _, s := range ExportSections {
		if s.Key == "services" && !withServices {
			continue
		}
		out = append(out, s.Key)
	}
	return out
}

// ---------------- import ----------------

type ImportLine struct {
	Line   int    `json:"line"`
	Text   string `json:"text"`
	Status string `json:"status"`
	Msg    string `json:"msg,omitempty"`
}

type ImportReport struct {
	Commands int          `json:"commands"`
	OK       int          `json:"ok"`
	Warn     int          `json:"warn"`
	Err      int          `json:"err"`
	Skipped  int          `json:"skipped"`
	Lines    []ImportLine `json:"lines"`
	Mode     string       `json:"mode"`
	Model    string       `json:"model"`
	Duration string       `json:"duration"`
}

type logical struct {
	line int
	text string
}

// splitScript joins continuation lines and multi-line { } blocks.
func splitScript(text string) []logical {
	text = strings.ReplaceAll(text, "\r\n", "\n")
	text = strings.ReplaceAll(text, "\r", "\n")
	raw := strings.Split(text, "\n")
	var out []logical
	var cur strings.Builder
	start := 0
	depth := 0
	inq := false
	for i, l := range raw {
		if cur.Len() == 0 {
			start = i + 1
			l = strings.TrimLeft(l, " \t")
		} else {
			l = strings.TrimLeft(l, " \t")
		}
		// track quotes/braces to know whether the statement continues
		cont := false
		for j := 0; j < len(l); j++ {
			switch l[j] {
			case '\\':
				if j == len(l)-1 {
					cont = true
				}
				j++
			case '"':
				inq = !inq
			case '{':
				if !inq {
					depth++
				}
			case '}':
				if !inq {
					depth--
				}
			}
		}
		if cont {
			cur.WriteString(l[:len(l)-1])
			continue
		}
		cur.WriteString(l)
		if depth > 0 || inq {
			cur.WriteString("\n")
			continue
		}
		out = append(out, logical{start, cur.String()})
		cur.Reset()
		depth = 0
	}
	if cur.Len() > 0 {
		out = append(out, logical{start, cur.String()})
	}
	return out
}

type ImportOpts struct {
	Mapping map[string]string // interface -> new name ("" = skip lines using it)
	User    string
	Replace bool
	Model   string
}

var ifTokRe = regexp.MustCompile(`\b(ether\d+|combo\d+|sfp-sfpplus\d+|sfp28-\d+|sfp\d+|wlan\d+|wifi\d+)\b`)

// importScript runs a RouterOS script line by line in lenient mode.
func (r *Router) importScript(text string, opt ImportOpts, internal bool) *ImportReport {
	t0 := time.Now()
	rep := &ImportReport{}
	c := newCLI(r, firstNonEmpty(opt.User, "admin"), "import", "", io.Discard, false)
	c.color = false
	c.script = true
	c.lenient = true
	c.internal = internal
	for _, lg := range splitScript(text) {
		line := strings.TrimSpace(lg.text)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		short := line
		if len(short) > 300 {
			short = short[:300] + "…"
		}
		add := func(st, msg string) {
			rep.Lines = append(rep.Lines, ImportLine{Line: lg.line, Text: short, Status: st, Msg: msg})
			switch st {
			case "ok":
				rep.OK++
			case "warning":
				rep.Warn++
			case "error":
				rep.Err++
			case "skipped":
				rep.Skipped++
			}
		}
		// interface mapping
		if len(opt.Mapping) > 0 {
			skip := ""
			line = ifTokRe.ReplaceAllStringFunc(line, func(tok string) string {
				if nv, ok := opt.Mapping[tok]; ok {
					if nv == "" {
						skip = tok
						return tok
					}
					return nv
				}
				return tok
			})
			if skip != "" && !strings.HasPrefix(line, "/") {
				rep.Commands++
				add("skipped", skip+" is not mapped to an interface of this router")
				continue
			}
		}
		if strings.HasPrefix(line, ":") {
			rep.Commands++
			f := strings.Fields(line)[0]
			switch f {
			case ":delay":
				add("ok", "delay skipped while importing")
			case ":log", ":put", ":local", ":global", ":set":
				if _, err := c.runOne(line, true); err != nil {
					add("warning", err.Error())
				} else {
					add("ok", "")
				}
			default:
				add("skipped", "script statement "+f+" is not supported by the simulator's import")
			}
			continue
		}
		for _, part := range splitTop(line) {
			part = strings.TrimSpace(part)
			if part == "" {
				continue
			}
			pathOnly := strings.HasPrefix(part, "/") && !strings.Contains(part, "=") && len(strings.Fields(part)) <= 4
			c.warnings = nil
			_, err := c.runOne(part, true)
			if pathOnly && err == nil && c.warnings == nil {
				continue // menu change, not counted
			}
			rep.Commands++
			if err != nil {
				msg := err.Error()
				if c.cwd == "/unsupported" && !strings.HasPrefix(part, "/") {
					add("skipped", "belongs to a menu the simulator does not have")
				} else if strings.HasPrefix(msg, "bad command name") || strings.HasPrefix(msg, "expected command name") {
					add("skipped", "not available in the simulator ("+msg+")")
					// keep following lines from running in the wrong menu
					if strings.HasPrefix(part, "/") {
						c.cwd = "/unsupported"
					}
				} else {
					add("error", msg)
				}
				continue
			}
			if len(c.warnings) > 0 {
				add("warning", strings.Join(c.warnings, "; "))
			} else {
				add("ok", "")
			}
		}
	}
	r.mu.Lock()
	for _, hp := range r.list(MenuMap["/ip/hotspot/profile"]) {
		d := cleanPath(firstNonEmpty(hp["html-directory-override"], hp["html-directory"]))
		if d != "" && r.byName("/file", d+"/login.html") == nil {
			rep.Lines = append(rep.Lines, ImportLine{Line: 0, Text: "/ip hotspot profile " + hp["name"], Status: "warning", Msg: "the login pages folder " + d + " is not in Files yet: upload it (Hotspot Pages > Upload, FTP, or clone the router with pages). The default pages are shown until then."})
			rep.Warn++
		}
	}
	r.rebuildRoutes()
	if r.sim != nil {
		r.sim.updateLinks()
	}
	r.syncSimPorts()
	r.markDirty()
	r.log("system,info", "configuration imported: %d commands, %d errors, %d warnings", rep.Commands, rep.Err, rep.Warn)
	r.mu.Unlock()
	rep.Duration = time.Since(t0).Round(time.Millisecond).String()
	return rep
}

// applyImport optionally switches model / clears config (like a reset with
// run-after-reset), then imports the script.
func (r *Router) applyImport(text string, opt ImportOpts) *ImportReport {
	if !opt.Replace && opt.Model == "" {
		rep := r.importScript(text, opt, false)
		rep.Mode = "merge"
		r.mu.Lock()
		rep.Model = r.Model.Key
		r.mu.Unlock()
		return rep
	}
	r.mu.Lock()
	r.log("system,info", "configuration import requested (router restarts)")
	r.state = "booting"
	r.epoch++
	kick := make([]func(), 0, len(r.kickers))
	for _, k := range r.kickers {
		kick = append(kick, k)
	}
	r.mu.Unlock()
	for _, k := range kick {
		k()
	}
	r.mu.Lock()
	if m := lookupModel(opt.Model); m != nil && m.Key != r.Model.Key {
		mc := *m
		mc.Serial = r.Model.Serial
		r.Model = &mc
	}
	if opt.Replace {
		keep := map[string]*Table{}
		for _, p := range []string{"/user", "/ip/service", "/file", "/sim/settings", "/sim/port"} {
			if t := r.T[p]; t != nil {
				keep[p] = t
			}
		}
		r.factoryDefaultsMode(r.Opt.Password, false)
		for p, t := range keep {
			r.T[p] = t
		}
	} else {
		r.factoryDefaultsMode(r.Opt.Password, true)
	}
	r.syncSimPorts()
	r.syncServices()
	r.clearDynamic()
	r.mu.Unlock()
	rep := r.importScript(text, opt, true)
	rep.Mode = map[bool]string{true: "replace", false: "merge"}[opt.Replace]
	r.mu.Lock()
	rep.Model = r.Model.Key
	r.mu.Unlock()
	r.finishBoot()
	return rep
}

// ---------------- analysis ----------------

type ScriptInfo struct {
	Lines        int      `json:"lines"`
	Commands     int      `json:"commands"`
	Version      string   `json:"version"`
	ModelLine    string   `json:"modelLine"`
	MatchKey     string   `json:"matchKey"`
	MatchBoard   string   `json:"matchBoard"`
	Interfaces   []string `json:"interfaces"`
	Missing      []string `json:"missing"`
	MissingIfSw  []string `json:"missingIfSwitched"`
	Menus        []string `json:"menus"`
	Unsupported  []string `json:"unsupported"`
	FullConfig   bool     `json:"fullConfig"`
	Sensitive    bool     `json:"sensitiveHidden"`
	Current      string   `json:"current"`
	CurrentBoard string   `json:"currentBoard"`
	Available    []string `json:"available"`
	Binary       bool     `json:"binary"`
}

var (
	reModel   = regexp.MustCompile(`(?m)^#\s*model\s*=\s*(\S+)`)
	reVersion = regexp.MustCompile(`(?m)^#.*by RouterOS\s+(\S+)`)
)

func normModel(s string) string {
	s = strings.ToLower(s)
	var b strings.Builder
	for _, c := range s {
		if (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '+' {
			b.WriteRune(c)
		}
	}
	return b.String()
}

func matchModel(name string) *Model {
	n := normModel(name)
	if n == "" {
		return nil
	}
	var best *Model
	bestLen := 0
	for _, k := range ModelOrder {
		m := Models[k]
		for _, cand := range []string{m.Name, m.Board} {
			c := normModel(cand)
			if c == n {
				return m
			}
			if (strings.HasPrefix(n, c) || strings.HasPrefix(c, n)) && len(c) > bestLen && len(c) >= 6 {
				best, bestLen = m, len(c)
			}
		}
	}
	return best
}

func (r *Router) analyzeScript(text string) ScriptInfo {
	var si ScriptInfo
	if strings.Contains(text[:min(len(text), 512)], "\x00") || !strings.Contains(text, "/") && len(text) > 0 && !strings.Contains(text, "add") {
		si.Binary = strings.Contains(text[:min(len(text), 512)], "\x00")
	}
	if m := reModel.FindStringSubmatch(text); m != nil {
		si.ModelLine = m[1]
		if md := matchModel(m[1]); md != nil {
			si.MatchKey, si.MatchBoard = md.Key, md.Board
		}
	}
	if m := reVersion.FindStringSubmatch(text); m != nil {
		si.Version = m[1]
	}
	si.Sensitive = !strings.Contains(text, "password=") && (strings.Contains(text, "/ip hotspot user") || strings.Contains(text, "/ppp secret"))
	menus := map[string]bool{}
	unsupported := map[string]bool{}
	ifs := map[string]bool{}
	logicals := splitScript(text)
	si.Lines = strings.Count(text, "\n") + 1
	for _, lg := range logicals {
		l := strings.TrimSpace(lg.text)
		if l == "" || strings.HasPrefix(l, "#") {
			continue
		}
		if strings.HasPrefix(l, "/") {
			fields := strings.Fields(l)
			var segs []string
			for _, f := range fields {
				if strings.Contains(f, "=") || f == "add" || f == "set" || f == "remove" || strings.HasPrefix(f, "[") {
					break
				}
				segs = append(segs, strings.Trim(f, "/"))
			}
			p := "/" + strings.Join(strings.FieldsFunc(strings.Join(segs, "/"), func(c rune) bool { return c == '/' }), "/")
			if MenuMap[p] != nil {
				menus[p] = true
			} else if !Dirs[p] && specials[p] == nil {
				unsupported[p] = true
			}
			if len(fields) <= len(segs) {
				continue
			}
		}
		si.Commands++
		for _, m := range ifTokRe.FindAllString(l, -1) {
			ifs[m] = true
		}
	}
	si.FullConfig = menus["/interface/bridge"] || menus["/ip/address"] || si.ModelLine != ""
	si.Interfaces = sortedKeysNatural(ifs)
	si.Menus = sortedKeys(menus)
	si.Unsupported = sortedKeys(unsupported)
	si.Current, si.CurrentBoard = r.Model.Key, r.Model.Board
	have := map[string]bool{}
	for _, it := range r.list(MenuMap["/interface"]) {
		have[it["name"]] = true
		if dn := it["default-name"]; dn != "" {
			have[dn] = true
		}
		si.Available = append(si.Available, it["name"])
	}
	sort.Slice(si.Available, func(i, j int) bool { return naturalLess(si.Available[i], si.Available[j]) })
	for n := range ifs {
		if !have[n] {
			si.Missing = append(si.Missing, n)
		}
	}
	sort.Slice(si.Missing, func(i, j int) bool { return naturalLess(si.Missing[i], si.Missing[j]) })
	if md := lookupModel(si.MatchKey); md != nil {
		e, s, w := md.portNames()
		hw := map[string]bool{}
		for _, n := range append(append(e, s...), w...) {
			hw[n] = true
		}
		for n := range ifs {
			if !hw[n] {
				si.MissingIfSw = append(si.MissingIfSw, n)
			}
		}
		sort.Slice(si.MissingIfSw, func(i, j int) bool { return naturalLess(si.MissingIfSw[i], si.MissingIfSw[j]) })
	}
	return si
}

func naturalLess(a, b string) bool {
	ra := regexp.MustCompile(`^(\D*)(\d+)$`)
	ma, mb := ra.FindStringSubmatch(a), ra.FindStringSubmatch(b)
	if ma != nil && mb != nil && ma[1] == mb[1] {
		x, _ := strconv.Atoi(ma[2])
		y, _ := strconv.Atoi(mb[2])
		return x < y
	}
	return a < b
}

func sortedKeysNatural(m map[string]bool) []string {
	out := sortedKeys(m)
	sort.Slice(out, func(i, j int) bool { return naturalLess(out[i], out[j]) })
	return out
}
