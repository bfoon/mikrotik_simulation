package main

// Commands that reach the real network: /tool fetch, :resolve (in builtins),
// /certificate import for the trust store fetch uses, and /file read.

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"strconv"
	"strings"
	"time"
)

var reHdrSplit = regexp.MustCompile(`,\s*([A-Za-z0-9-]+)\s*:`)

func splitHeaders(s string) []string {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	idx := reHdrSplit.FindAllStringIndex(s, -1)
	var out []string
	start := 0
	for _, m := range idx {
		out = append(out, s[start:m[0]])
		start = m[0] + 1
	}
	return append(out, s[start:])
}

// certPool is the trust store /tool fetch uses: the PC's roots (RouterOS 7.19
// "builtin-trust-anchors") plus certificates imported with trusted=yes.
func (r *Router) certPool() *x509.CertPool {
	pool, err := x509.SystemCertPool()
	if err != nil || pool == nil {
		pool = x509.NewCertPool()
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if s := r.single("/certificate/settings"); s != nil && s["builtin-trust-anchors"] == "not-trusted" {
		pool = x509.NewCertPool()
	}
	for _, it := range r.list(MenuMap["/certificate"]) {
		if it["_pem"] != "" && it.B("trusted") {
			pool.AppendCertsFromPEM([]byte(it["_pem"]))
		}
	}
	return pool
}

// routerOnline tells whether the simulated router has a way out: running and
// with an active default route, so unplugging the WAN in the simulator cuts
// fetch off like on a real router.
func (r *Router) routerOnline() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.state != "running" {
		return false
	}
	if r.lab != nil && !r.lab.online {
		return false
	}
	for _, it := range r.list(MenuMap["/ip/route"]) {
		if it["dst-address"] == "0.0.0.0/0" && !it.B("disabled") && (it.B("active") || it["active"] == "") {
			return true
		}
	}
	return false
}

type fetchRec struct {
	At     time.Time `json:"at"`
	Method string    `json:"method"`
	URL    string    `json:"url"`
	OK     bool      `json:"ok"`
	Msg    string    `json:"msg"`
	Ms     int       `json:"ms"`
	Job    string    `json:"job"`
}

func (r *Router) noteFetch(rec fetchRec) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.fetchLog = append(r.fetchLog, rec)
	if len(r.fetchLog) > 40 {
		r.fetchLog = r.fetchLog[len(r.fetchLog)-40:]
	}
}

func (in *Interp) fetch(a map[string]string, flags map[string]bool, show bool) (v Value, err error) {
	t0 := time.Now()
	defer func() {
		u := a["url"]
		if i := strings.IndexAny(u, "?"); i >= 0 {
			u = u[:i]
		}
		msg := "finished"
		if err != nil {
			msg = err.Error()
		}
		in.r.noteFetch(fetchRec{At: time.Now(), Method: strings.ToUpper(firstNonEmpty(a["http-method"], "get")), URL: u, OK: err == nil, Msg: msg, Ms: int(time.Since(t0) / time.Millisecond), Job: in.jobName})
	}()
	u := a["url"]
	if u == "" {
		addr := a["address"]
		if addr == "" {
			return vNil, fmt.Errorf("failure: url or address must be given")
		}
		mode := firstNonEmpty(a["mode"], "http")
		u = mode + "://" + addr
		if a["port"] != "" {
			u += ":" + a["port"]
		}
		u += "/" + strings.TrimPrefix(a["src-path"], "/")
	}
	pu, err := url.Parse(u)
	if err != nil || pu.Host == "" {
		return vNil, fmt.Errorf("failure: invalid url")
	}
	if pu.Scheme != "http" && pu.Scheme != "https" {
		return vNil, fmt.Errorf("failure: %s is not supported by the simulator's fetch", pu.Scheme)
	}
	if !in.r.routerOnline() {
		time.Sleep(time.Second)
		return vNil, fmt.Errorf("failure: connection timeout (the simulated router has no active default route)")
	}
	duration := 0 * time.Second
	if d, ok := parseROSTime(a["duration"]); ok {
		duration = d
	}
	idle := 10 * time.Second
	if d, ok := parseROSTime(a["idle-timeout"]); ok && d > 0 {
		idle = d
	}
	method := strings.ToUpper(firstNonEmpty(a["http-method"], "get"))
	var body io.Reader
	if a["http-data"] != "" || method == "POST" || method == "PUT" {
		body = strings.NewReader(a["http-data"])
	}
	ctx := context.Background()
	var cancel context.CancelFunc
	if duration > 0 {
		ctx, cancel = context.WithTimeout(ctx, duration)
	} else {
		ctx, cancel = context.WithTimeout(ctx, 10*time.Minute)
	}
	defer cancel()
	go func() {
		t := time.NewTicker(100 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				if in.cancelled() {
					cancel()
					return
				}
			}
		}
	}()
	req, err := http.NewRequestWithContext(ctx, method, u, body)
	if err != nil {
		return vNil, fmt.Errorf("failure: %v", err)
	}
	req.Header.Set("User-Agent", "Mikrotik/7.x Fetch")
	if body != nil {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	for _, h := range splitHeaders(a["http-header-field"]) {
		if k, v, ok := strings.Cut(h, ":"); ok {
			req.Header.Set(strings.TrimSpace(k), strings.TrimSpace(v))
		}
	}
	if a["user"] != "" {
		req.SetBasicAuth(a["user"], a["password"])
	}
	check := firstNonEmpty(a["check-certificate"], "no")
	tlsCfg := &tls.Config{InsecureSkipVerify: check == "no"}
	if check != "no" {
		tlsCfg.RootCAs = in.r.certPool()
	}
	redirects := 0
	if n, err := strconv.Atoi(a["http-max-redirect-count"]); err == nil {
		redirects = n
	}
	tr := &http.Transport{
		Proxy:                 http.ProxyFromEnvironment,
		TLSClientConfig:       tlsCfg,
		DialContext:           (&net.Dialer{Timeout: idle}).DialContext,
		TLSHandshakeTimeout:   idle,
		ResponseHeaderTimeout: idle,
		DisableKeepAlives:     true,
	}
	client := &http.Client{Transport: tr, CheckRedirect: func(_ *http.Request, via []*http.Request) error {
		if len(via) > redirects {
			return http.ErrUseLastResponse
		}
		return nil
	}}
	t1 := time.Now()
	resp, err := client.Do(req)
	if err != nil {
		return vNil, fetchErr(err, pu)
	}
	defer resp.Body.Close()
	limit := int64(16 << 20)
	data, err := io.ReadAll(io.LimitReader(&idleReader{r: resp.Body, idle: idle}, limit))
	if err != nil {
		return vNil, fetchErr(err, pu)
	}
	if resp.StatusCode >= 300 {
		return vNil, fmt.Errorf("failure: closing connection: <%d %s> %s", resp.StatusCode, http.StatusText(resp.StatusCode), hostPortOf(pu))
	}
	el := time.Since(t1)
	output := a["output"]
	if output == "" {
		output = "file"
	}
	res := newArr()
	res.Set(vStr("status"), vStr("finished"))
	res.Set(vStr("downloaded"), vNum(int64(len(data)+1023)/1024))
	res.Set(vStr("total"), vNum(int64(len(data)+1023)/1024))
	res.Set(vStr("duration"), vTime(el.Truncate(time.Second)))
	switch output {
	case "user", "user-with-headers":
		res.Set(vStr("data"), vStr(string(data)))
	case "file":
		name := a["dst-path"]
		if name == "" {
			name = path.Base(pu.Path)
			if name == "" || name == "/" || name == "." {
				name = "index.html"
			}
		}
		in.r.mu.Lock()
		in.r.putFile(cleanPath(name), data)
		in.r.mu.Unlock()
	}
	in.r.mu.Lock()
	in.r.log("fetch,info", "Download from %s FINISHED", pu.Host)
	in.r.mu.Unlock()
	if flags["as-value"] {
		return vArr(res), nil
	}
	if show {
		fmt.Fprintf(in.out, "      status: finished\n  downloaded: %dKiB\n       total: %dKiB\n    duration: %ds\n", (len(data)+1023)/1024, (len(data)+1023)/1024, int(el.Seconds()))
		if output == "user" {
			fmt.Fprintf(in.out, "        data: %s\n", strings.TrimSpace(string(data)))
		}
	}
	return vNothing, nil
}

type idleReader struct {
	r    io.Reader
	idle time.Duration
}

func (i *idleReader) Read(p []byte) (int, error) { return i.r.Read(p) }

func hostPortOf(u *url.URL) string {
	h := u.Hostname()
	if ips, err := net.LookupHost(h); err == nil && len(ips) > 0 {
		h = ips[0]
	}
	port := u.Port()
	if port == "" {
		port = map[string]string{"http": "80", "https": "443"}[u.Scheme]
	}
	return net.JoinHostPort(h, port)
}

func fetchErr(err error, u *url.URL) error {
	msg := err.Error()
	var x509Err x509.UnknownAuthorityError
	var hostErr x509.HostnameError
	var invErr x509.CertificateInvalidError
	switch {
	case errors.As(err, &x509Err):
		return fmt.Errorf("failure: SSL: no trusted CA certificate found (6)")
	case errors.As(err, &hostErr):
		return fmt.Errorf("failure: SSL: hostname does not match certificate (6)")
	case errors.As(err, &invErr):
		return fmt.Errorf("failure: SSL: certificate is not valid (6)")
	case errors.Is(err, context.DeadlineExceeded) || strings.Contains(msg, "timeout") || strings.Contains(msg, "deadline"):
		return fmt.Errorf("failure: connection timeout")
	case strings.Contains(msg, "no such host"):
		return fmt.Errorf("failure: could not resolve dns name")
	case strings.Contains(msg, "refused"):
		return fmt.Errorf("failure: connection refused")
	case strings.Contains(msg, "context canceled"):
		return errCancelled
	}
	return fmt.Errorf("failure: %s", msg)
}

// fileRead implements /file read file= offset= chunk-size= as-value (RouterOS 7.13).
func (in *Interp) fileRead(a map[string]string) (Value, error) {
	name := cleanPath(a["file"])
	in.r.mu.Lock()
	it := in.r.byName("/file", name)
	var data []byte
	if it != nil {
		data = fileBytes(it)
	}
	in.r.mu.Unlock()
	if it == nil {
		return vNil, fmt.Errorf("failure: no such file")
	}
	off, _ := strconv.Atoi(firstNonEmpty(a["offset"], "0"))
	size, _ := strconv.Atoi(firstNonEmpty(a["chunk-size"], "4096"))
	if size > 32768 {
		size = 32768
	}
	if off > len(data) {
		off = len(data)
	}
	end := min(len(data), off+size)
	res := newArr()
	res.Set(vStr("data"), vStr(string(data[off:end])))
	res.Set(vStr("offset"), vNum(int64(off)))
	return vArr(res), nil
}

// certImport adds every certificate of a PEM file to /certificate.
func (in *Interp) certImport(a map[string]string, show bool) (Value, error) {
	name := cleanPath(a["file-name"])
	in.r.mu.Lock()
	defer in.r.mu.Unlock()
	it := in.r.byName("/file", name)
	if it == nil {
		return vNil, fmt.Errorf("failure: no such file")
	}
	data := fileBytes(it)
	trusted := a["trusted"] != "no"
	n := 0
	for {
		var blk *pem.Block
		blk, data = pem.Decode(data)
		if blk == nil {
			break
		}
		if blk.Type != "CERTIFICATE" {
			continue
		}
		cert, err := x509.ParseCertificate(blk.Bytes)
		if err != nil {
			continue
		}
		sum := sha256.Sum256(cert.Raw)
		fp := hex.EncodeToString(sum[:])
		dup := false
		for _, c := range in.r.list(MenuMap["/certificate"]) {
			if c["fingerprint"] == fp {
				dup = true
			}
		}
		if dup {
			continue
		}
		cname := strings.TrimSuffix(path.Base(name), path.Ext(name)) + "_" + strconv.Itoa(n)
		args := map[string]string{"name": cname, "common-name": cert.Subject.CommonName}
		item, err := in.r.addItem(MenuMap["/certificate"], args, true)
		if err != nil {
			continue
		}
		item["fingerprint"] = fp
		item["trusted"] = map[bool]string{true: "true", false: "false"}[trusted]
		item["_pem"] = string(pem.EncodeToMemory(blk))
		if cert.IsCA {
			item["authority"] = "true"
		}
		item["invalid-before"] = cert.NotBefore.Format("2006-01-02 15:04:05")
		item["invalid-after"] = cert.NotAfter.Format("2006-01-02 15:04:05")
		n++
	}
	in.r.dirty = true
	if show {
		fmt.Fprintf(in.out, "     certificates-imported: %d\n     private-keys-imported: 0\n            files-imported: 1\n       decryption-failures: 0\n  keys-with-no-certificate: 0\n", n)
	}
	return vNothing, nil
}

var _ = bytes.NewReader
