'use strict';
/* TikLab — Network Lab: routers, switches, the internet and end devices on one
   workbench. Drag devices in from the left, drag from a port to a port to run a
   cable, drag a plugged cable end to move or pull it out, double-click a router
   to configure it in this console. */

const LAB = { st: null, sel: null, color: 'blue', showAddr: store.get('lab.addr', true), anim: store.get('lab.anim', true), models: null, model: store.get('lab.model', 'hap-ac2'), w: null, view: store.get('lab.view', null), fresh: new Set(), pending: [] };
const SVGNS = 'http://www.w3.org/2000/svg';
const RCOL = ['#0F7B8A', '#8a63d2', '#e8892d', '#2ea05a', '#d24a3f', '#2f6fd6', '#c2558a', '#9b8a1a'];
const DOWN_C = '#F0B429', UP_C = '#6fd6e8';
const END_KINDS = [['pc', 'PC'], ['laptop', 'Laptop'], ['phone', 'Phone'], ['tablet', 'Tablet'], ['tv', 'Smart TV'], ['printer', 'Printer'], ['camera', 'Camera'], ['iot', 'Smart plug'], ['server', 'Server']];
const KIND_LABEL = Object.fromEntries([...END_KINDS, ['router', 'Router'], ['switch', 'Switch'], ['internet', 'Internet']]);

function sv(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) if (v != null && v !== false) el.setAttribute(k, v);
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(k));
  return el;
}
function routerColor(d) {
  if (!d) return RCOL[0];
  if (d.primary) return RCOL[0];
  const n = parseInt(String(d.id).replace(/\D/g, ''), 10) || 1;
  return RCOL[1 + (n % (RCOL.length - 1))];
}
async function labCall(op, body) {
  const q = '?t=' + encodeURIComponent(S.labT || '');
  try {
    const r = await (await fetch('/lab/' + op + q, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {})).json();
    return r;
  } catch { return { error: 'connection lost' }; }
}
function labDev(id) { return LAB.st && LAB.st.devices.find(d => d.id === id); }
function labRouters() { return (LAB.st ? LAB.st.devices : []).filter(d => d.kind === 'router'); }

// ---------- device icons (40×40, centred) ----------
const DICON = {
  pc: '<rect x="-15" y="-14" width="30" height="20" rx="2"/><path d="M-5 6l-2 7h14l-2-7M-9 13h18"/>',
  laptop: '<rect x="-12" y="-12" width="24" height="16" rx="1.5"/><path d="M-17 8h34l-3 4h-28z"/>',
  phone: '<rect x="-8" y="-16" width="16" height="32" rx="3"/><path d="M-3 -12.5h6"/><circle cx="0" cy="12" r="1.3"/>',
  tablet: '<rect x="-13" y="-16" width="26" height="32" rx="3"/><circle cx="0" cy="12.5" r="1.3"/>',
  tv: '<rect x="-18" y="-13" width="36" height="22" rx="1.5"/><path d="M-9 13l2-4M9 13l-2-4M-12 13h24"/>',
  printer: '<path d="M-10 -6v-9h20v9"/><rect x="-16" y="-6" width="32" height="14" rx="2"/><path d="M-10 4v9h20v-9"/><path d="M-6 8h12"/><circle cx="11" cy="-1" r="1"/>',
  camera: '<path d="M-15 -8h20l5 4v8l-5 4h-20z"/><circle cx="-5" cy="0" r="4"/><path d="M-6 8v6h-6"/>',
  iot: '<rect x="-12" y="-12" width="24" height="24" rx="6"/><path d="M-4 -5v5M4 -5v5"/><path d="M-3 6h6"/>',
  server: '<rect x="-14" y="-15" width="28" height="9" rx="1.5"/><rect x="-14" y="-4" width="28" height="9" rx="1.5"/><rect x="-14" y="7" width="28" height="9" rx="1.5"/><path d="M-9 -10.5h6M-9 .5h6M-9 11.5h6"/><circle cx="9" cy="-10.5" r="1"/><circle cx="9" cy=".5" r="1"/><circle cx="9" cy="11.5" r="1"/>',
  switch: '<rect x="-16" y="-8" width="32" height="16" rx="2"/><path d="M-11 -2h4M-4 -2h4M3 -2h4M10 -2h2M-11 3h22"/>',
  internet: '<circle cx="0" cy="0" r="13"/><path d="M-13 0h26M0 -13c6 6 6 20 0 26M0 -13c-6 6-6 20 0 26M-11 -7h22M-11 7h22"/>',
  router: '<rect x="-16" y="-6" width="32" height="13" rx="2"/><path d="M-11 0h3M-5 0h3M1 0h3"/><path d="M10 -6v-8M14 -6v-6"/>',
};
function iconSvg(kind, size = 26) { return `<svg viewBox="-20 -20 40 40" width="${size}" height="${size}" class="lab-ico">${DICON[kind] || DICON.pc}</svg>`; }

// ---------- geometry: where every port sits on a device ----------
function labGeo(d) {
  const ps = d.ports || [], out = {};
  if (d.kind === 'router') {
    const eth = ps.filter(p => p.kind !== 'wlan'), wl = ps.filter(p => p.kind === 'wlan');
    const rows = eth.length > 12 ? 2 : 1, cols = Math.max(1, Math.ceil(eth.length / rows));
    const W = Math.max(184, 36 + cols * 23), H = rows === 2 ? 92 : 72;
    eth.forEach((p, i) => {
      const col = rows === 2 ? Math.floor(i / 2) : i, row = rows === 2 ? i % 2 : 0;
      const x = -W / 2 + 18 + col * 23 + 9, y = H / 2 - 19 - (rows - 1 - row) * 23;
      out[p.id] = { x, y, ax: x, ay: y + 6, face: 'down', p };
    });
    wl.forEach((p, j) => { const x = W / 2 - 20 - j * 20; out[p.id] = { x, y: -H / 2, ax: x, ay: -H / 2 - 17, face: 'up', p, ant: true }; });
    return { w: W, h: H, ports: out };
  }
  if (d.kind === 'switch') {
    const n = ps.length, rows = n > 16 ? 2 : 1, cols = Math.ceil(n / rows);
    const W = 52 + cols * 17, H = rows === 2 ? 58 : 40;
    ps.forEach((p, i) => {
      const col = rows === 2 ? Math.floor(i / 2) : i, row = rows === 2 ? i % 2 : 0;
      const x = -W / 2 + 42 + col * 17 + 6, y = H / 2 - 13 - (rows - 1 - row) * 18;
      out[p.id] = { x, y, ax: x, ay: y + 5, face: 'down', p };
    });
    return { w: W, h: H, ports: out };
  }
  if (d.kind === 'internet') {
    out.net = { x: 0, y: 34, ax: 0, ay: 40, face: 'down', p: ps[0] || { id: 'net', kind: 'net', name: 'internet' } };
    return { w: 150, h: 84, ports: out };
  }
  const W = 62, H = 54;
  for (const p of ps) {
    if (p.kind === 'wifi') out[p.id] = { x: 0, y: -H / 2, ax: 0, ay: -H / 2 - 6, face: 'up', p };
    else out[p.id] = { x: 0, y: H / 2, ax: 0, ay: H / 2 + 6, face: 'down', p };
  }
  return { w: W, h: H, ports: out };
}
function anchor(id, port) {
  const d = labDev(id); if (!d) return null;
  const g = labGeo(d), p = g.ports[port]; if (!p) return null;
  return { x: d.x + p.ax, y: d.y + p.ay, face: p.face, kind: p.p.kind };
}
function linksAt(dev, port) { return (LAB.st ? LAB.st.links : []).filter(l => (l.a.dev === dev && l.a.port === port) || (l.b.dev === dev && l.b.port === port)); }
function multiPort(d, p) { return d.kind === 'internet' || (p && p.kind === 'wlan'); }
function radioKind(k) { return k === 'wlan' || k === 'wifi'; }
function peerOf(lk, dev, port) { return lk.a.dev === dev && lk.a.port === port ? lk.b : lk.a; }
function endName(e) { const d = labDev(e.dev); if (!d) return e.dev; const p = (d.ports || []).find(x => x.id === e.port); return d.kind === 'router' || d.kind === 'switch' ? `${d.name} ${p ? p.name : e.port}` : d.name; }

function cablePath(a, b, sw) {
  const L = Math.hypot(b.x - a.x, b.y - a.y);
  const sag = 30 + Math.min(150, L * .24);
  const ca = a.face === 'up' ? -sag : sag, cb = b.face === 'up' ? -sag : sag;
  const ox = sw ? sw.ox : 0, oy = sw ? sw.oy : 0;
  return `M${a.x.toFixed(1)} ${a.y.toFixed(1)} C${(a.x + ox).toFixed(1)} ${(a.y + ca + oy).toFixed(1)} ${(b.x + ox).toFixed(1)} ${(b.y + cb + oy).toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}`;
}
function radioPath(a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1, off = Math.min(46, L * .12);
  const mx = (a.x + b.x) / 2 - dy / L * off, my = (a.y + b.y) / 2 + dx / L * off;
  return `M${a.x.toFixed(1)} ${a.y.toFixed(1)} Q${mx.toFixed(1)} ${my.toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}`;
}
// where a radio link leaves a device: the edge of its body facing the other end
function radioEdge(dev, toward) {
  const d = labDev(dev); if (!d) return null;
  const g = labGeo(d), hw = g.w / 2 + 3, hh = g.h / 2 + 3;
  const dx = toward.x - d.x, dy = toward.y - d.y;
  if (!dx && !dy) return { x: d.x, y: d.y - hh };
  const t = Math.min(hw / Math.abs(dx || 1e-9), hh / Math.abs(dy || 1e-9));
  return { x: d.x + dx * t, y: d.y + dy * t };
}
function radioEnds(lk) {
  const da = labDev(lk.a.dev), db = labDev(lk.b.dev); if (!da || !db) return null;
  return [radioEdge(lk.a.dev, db), radioEdge(lk.b.dev, da)];
}
function linkD(lk) {
  if (lk.kind === 'wifi') { const e = radioEnds(lk); return e && e[0] && e[1] ? radioPath(e[0], e[1]) : ''; }
  const a = anchor(lk.a.dev, lk.a.port), b = anchor(lk.b.dev, lk.b.port);
  if (!a || !b) return '';
  return cablePath(a, b, LAB.sway[lk.id]);
}

// ---------- the window ----------
function openLab() {
  if (!S.labT) return toast('The Network Lab belongs to the simulator: log in to 127.0.0.1', true);
  const dr = deskRect();
  openWin('lab', 'Network Lab', { w: dr.width - 20, h: dr.height - 16, x: 10, y: 8 }, w => {
    w.global = true; LAB.w = w; store.set('lab.open', true);
    const svg = sv('svg', { class: 'lab-svg', tabindex: 0, 'aria-label': 'Network canvas' });
    const defs = sv('defs');
    defs.innerHTML = `<pattern id="labDots" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="#34404c"/></pattern>
      <linearGradient id="labMetal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#55616e"/><stop offset=".07" stop-color="#3f4a56"/><stop offset="1" stop-color="#262e37"/></linearGradient>
      <linearGradient id="labWhite" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".08" stop-color="#eef1f4"/><stop offset="1" stop-color="#cfd6dc"/></linearGradient>
      <radialGradient id="labCloud" cx=".5" cy=".35" r=".7"><stop offset="0" stop-color="#3d5a73"/><stop offset="1" stop-color="#25323f"/></radialGradient>
      <filter id="labGlow" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`;
    const bg = sv('rect', { class: 'lab-bg', x: -50000, y: -50000, width: 100000, height: 100000, fill: 'url(#labDots)' });
    const vp = sv('g', { class: 'lab-vp' });
    const L = { tunnels: sv('g'), links: sv('g'), packets: sv('g', { class: 'lab-packets' }), nodes: sv('g'), plugs: sv('g'), over: sv('g') };
    vp.append(bg, L.tunnels, L.links, L.packets, L.nodes, L.plugs, L.over);
    svg.append(defs, vp);
    LAB.svg = svg; LAB.vp = vp; LAB.L = L; LAB.nodeEls = new Map(); LAB.linkEls = new Map(); LAB.sway = {}; LAB.dots = []; LAB.tunEls = new Map();

    const palette = h('div', { class: 'lab-pal' });
    const insp = h('aside', { class: 'lab-insp' });
    const tools = h('div', { class: 'lab-tools' });
    const stage = h('div', { class: 'lab-stage' }, svg, h('div', { class: 'lab-legend' }, h('span', null, h('i', { style: { background: DOWN_C } }), 'toward the devices'), h('span', null, h('i', { style: { background: UP_C } }), 'toward the internet'), h('span', null, h('i', { class: 'wl' }), 'Wi-Fi')));
    const hint = h('div', { class: 'lab-hint', hidden: true });
    stage.append(hint);
    LAB.hint = hint; LAB.insp = insp; LAB.stage = stage;
    w.body.classList.add('lab-body');
    w.body.append(h('div', { class: 'lab' }, palette, h('div', { class: 'lab-mid' }, tools, stage), insp));
    buildPalette(palette); buildTools(tools); bindCanvas();
    if (!LAB.view) LAB.view = { x: 0, y: 0, k: 1, auto: true };
    applyView();
    w.every(1000, labPoll);
    let raf = 0, last = performance.now();
    const frame = now => { const dt = Math.min(.05, (now - last) / 1000); last = now; if (!w.el.classList.contains('parked') && !w.el.classList.contains('minimized')) labFrame(dt); raf = requestAnimationFrame(frame); };
    raf = requestAnimationFrame(frame);
    const keys = e => labKey(e); addEventListener('keydown', keys);
    w.closers.push(() => { cancelAnimationFrame(raf); removeEventListener('keydown', keys); LAB.w = null; LAB.nodeEls = new Map(); LAB.linkEls = new Map(); LAB.dots = []; if (S.t) store.set('lab.open', false); });
    renderInspector();
  });
}

function buildPalette(el) {
  const sec = (title, ...kids) => h('section', null, h('h4', null, title), ...kids);
  const tile = (kind, label, extra) => {
    const t = h('div', { class: 'lab-tile', tabindex: 0, role: 'button', 'data-kind': kind, title: 'Drag onto the canvas, or press Enter to add', html: iconSvg(kind, 30) + `<span>${esc(label)}</span>` });
    Object.assign(t.dataset, extra || {});
    t.addEventListener('pointerdown', e => paletteDrag(e, t));
    t.onkeydown = e => { if (e.key === 'Enter') labAddAt(t.dataset, null); };
    return t;
  };
  const msel = h('select', { class: 'lab-model', 'aria-label': 'Router model' });
  const rtile = tile('router', 'MikroTik router');
  const fill = async () => {
    const r = LAB.models || await labCall('models'); LAB.models = r;
    msel.innerHTML = '';
    const fams = {}; (r.models || []).forEach(m => (fams[m.family] = fams[m.family] || []).push(m));
    for (const [f, ms] of Object.entries(fams)) { const og = h('optgroup', { label: f }); ms.forEach(m => og.append(h('option', { value: m.key, selected: m.key === LAB.model }, `${m.board}  ·  ${m.ether}${m.sfp ? '+' + m.sfp + ' SFP' : ''}${m.wireless ? ' · Wi-Fi' : ''}`))); msel.append(og); }
  };
  msel.onchange = () => { LAB.model = msel.value; store.set('lab.model', LAB.model); };
  fill();
  el.append(
    sec('Routers', rtile, msel, h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', id: 'labOwnLan', checked: store.get('lab.ownlan', true), onchange: e => store.set('lab.ownlan', e.target.checked) }), 'Give it its own LAN subnet')),
    sec('Network', tile('switch', '8-port switch', { ports: 8 }), tile('switch', '24-port switch', { ports: 24 }), tile('internet', 'Internet')),
    sec('Devices', h('div', { class: 'lab-grid' }, END_KINDS.map(([k, l]) => tile(k, l)))),
    h('p', { class: 'lab-pal-note' }, 'Every router here is a full simulated router with its own configuration, services and ports on this PC.')
  );
}

function buildTools(el) {
  const btn = (label, fn, title) => { const b = h('button', { title: title || label }, label); b.onclick = fn; return b; };
  const sw = h('div', { class: 'lab-swatches', role: 'radiogroup', 'aria-label': 'Cable colour for new cables' });
  for (const [n, c] of Object.entries(CABLE)) {
    const b = h('button', { class: 'sw' + (n === LAB.color ? ' on' : ''), style: { background: c }, title: n + ' cable', 'aria-label': n + ' cable', role: 'radio' });
    b.onclick = () => { LAB.color = n; $$('.sw', sw).forEach(x => x.classList.toggle('on', x === b)); };
    sw.append(b);
  }
  const tAddr = h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', checked: LAB.showAddr, onchange: e => { LAB.showAddr = e.target.checked; store.set('lab.addr', LAB.showAddr); LAB.svg.classList.toggle('noaddr', !LAB.showAddr); } }), 'Addresses');
  const tAnim = h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', checked: LAB.anim, onchange: e => { LAB.anim = e.target.checked; store.set('lab.anim', LAB.anim); } }), 'Traffic');
  const tmpl = btn('Sample networks', e => {
    const r = e.target.getBoundingClientRect();
    showPop(r.left, r.bottom + 4, 'Add a sample network', 'built around your main router', [
      ['Home: phone, laptop, TV and a PC', () => labTemplate('home')],
      ['Office: switch, PCs, printer and a server', () => labTemplate('office')],
      ['Hotspot towers: two hAP towers with phones', () => labTemplate('towers')],
      ['Chain: router behind router behind router', () => labTemplate('chain')],
    ]);
  });
  el.append(btn('Fit', () => labFit(true), 'Fit the whole network in view'), btn('−', () => labZoom(1 / 1.2), 'Zoom out'), btn('+', () => labZoom(1.2), 'Zoom in'),
    h('span', { class: 'lab-sep' }), h('span', { class: 'lab-lbl' }, 'New cables'), sw, h('span', { class: 'lab-sep' }), tAddr, tAnim, h('span', { class: 'grow' }), tmpl);
}

// ---------- view: pan and zoom ----------
function applyView() { const v = LAB.view; LAB.vp.setAttribute('transform', `translate(${v.x.toFixed(1)} ${v.y.toFixed(1)}) scale(${v.k.toFixed(4)})`); LAB.svg.classList.toggle('noaddr', !LAB.showAddr); LAB.svg.classList.toggle('far', v.k < .55); }
function saveView() { const v = LAB.view; store.set('lab.view', { x: v.x, y: v.y, k: v.k }); }
function toWorld(cx, cy) { const r = LAB.svg.getBoundingClientRect(), v = LAB.view; return { x: (cx - r.left - v.x) / v.k, y: (cy - r.top - v.y) / v.k }; }
function labZoom(f, cx, cy) {
  const r = LAB.svg.getBoundingClientRect(), v = LAB.view;
  if (cx == null) { cx = r.left + r.width / 2; cy = r.top + r.height / 2; }
  const k = Math.max(.25, Math.min(2.6, v.k * f)), wx = (cx - r.left - v.x) / v.k, wy = (cy - r.top - v.y) / v.k;
  v.x = cx - r.left - wx * k; v.y = cy - r.top - wy * k; v.k = k; v.auto = false; applyView(); saveView();
}
function labBounds() {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const d of LAB.st.devices) { const g = labGeo(d); x0 = Math.min(x0, d.x - g.w / 2 - 30); y0 = Math.min(y0, d.y - g.h / 2 - 40); x1 = Math.max(x1, d.x + g.w / 2 + 150); y1 = Math.max(y1, d.y + g.h / 2 + 70); }
  return { x0, y0, x1, y1 };
}
function labFit(animate) {
  if (!LAB.st || !LAB.st.devices.length) return;
  const b = labBounds(), r = LAB.svg.getBoundingClientRect(); if (!r.width) return;
  const k = Math.max(.3, Math.min(1.25, Math.min(r.width / (b.x1 - b.x0), r.height / (b.y1 - b.y0))));
  const to = { x: r.width / 2 - (b.x0 + b.x1) / 2 * k, y: r.height / 2 - (b.y0 + b.y1) / 2 * k, k };
  const from = { ...LAB.view };
  if (!animate || matchMedia('(prefers-reduced-motion: reduce)').matches) { Object.assign(LAB.view, to, { auto: false }); applyView(); saveView(); return; }
  const t0 = performance.now();
  const step = now => { const t = Math.min(1, (now - t0) / 380), e = 1 - Math.pow(1 - t, 3); for (const k2 of ['x', 'y', 'k']) LAB.view[k2] = from[k2] + (to[k2] - from[k2]) * e; applyView(); if (t < 1) requestAnimationFrame(step); else { LAB.view.auto = false; saveView(); } };
  requestAnimationFrame(step);
}

// ---------- polling and drawing ----------
async function labPoll() {
  if (LAB.busy) return;
  LAB.busy = true;
  let r = await labCall('state');
  if (r && r.expired && await labRelogin()) r = await labCall('state');
  LAB.busy = false;
  if (!r || r.error || !r.devices) return;
  const prev = LAB.st;
  if (LAB.drag && prev) { const d = r.devices.find(x => x.id === LAB.drag.id); if (d) { d.x = LAB.drag.d.x; d.y = LAB.drag.d.y; } }
  for (const p of LAB.pending) { const d = r.devices.find(x => x.id === p.id); if (d) { d.x = p.x; d.y = p.y; } }
  LAB.st = r;
  labRender();
  if (LAB.view.auto) labFit(false);
  if (!prev) renderInspector(); else refreshInspector();
  renderRouterChip();
}

function labRender() {
  const st = LAB.st, L = LAB.L;
  const seenN = new Set();
  for (const d of st.devices) {
    seenN.add(d.id);
    const key = d.kind + '|' + d.name + '|' + d.model + '|' + (d.ports || []).map(p => p.id + ':' + p.name + ':' + p.kind).join(',');
    let n = LAB.nodeEls.get(d.id);
    if (!n || n.key !== key) {
      const g = buildNode(d);
      if (n) n.g.replaceWith(g); else L.nodes.append(g);
      if (!n && LAB.fresh.has(d.id)) { g.classList.add('born'); LAB.fresh.delete(d.id); }
      n = { g, key }; LAB.nodeEls.set(d.id, n);
    }
    placeNode(d);
    updateNode(d, n.g);
  }
  for (const [id, n] of LAB.nodeEls) if (!seenN.has(id)) { n.g.remove(); LAB.nodeEls.delete(id); }
  const seenL = new Set();
  for (const lk of st.links) {
    seenL.add(lk.id);
    let e = LAB.linkEls.get(lk.id);
    if (!e) {
      e = buildLink(lk); LAB.linkEls.set(lk.id, e); L.links.append(e.g); L.plugs.append(e.plugs);
      if (LAB.fresh.has(lk.id)) { e.g.classList.add('drawn'); LAB.fresh.delete(lk.id); }
    }
    updateLink(lk, e);
  }
  for (const [id, e] of LAB.linkEls) if (!seenL.has(id)) { e.g.remove(); e.plugs.remove(); LAB.linkEls.delete(id); }
  drawTunnels();
  labHops();
  const routers = labRouters().length, ends = st.devices.filter(d => END_KINDS.some(k => k[0] === d.kind)).length;
  LAB.hint.hidden = routers > 1 || ends > 0;
  if (!LAB.hint.hidden && !LAB.hint.firstChild) LAB.hint.append(h('b', null, 'Build a network'), h('span', null, 'Drag a router or a device from the left onto the canvas. Then drag from a port to another port to run a cable — a phone joins a router by dragging from its Wi-Fi to the router’s antenna.'));
}

function placeNode(d) { const n = LAB.nodeEls.get(d.id); if (n) n.g.setAttribute('transform', `translate(${d.x.toFixed(1)} ${d.y.toFixed(1)})`); }

function buildNode(d) {
  const g = sv('g', { class: 'lab-node k-' + d.kind, 'data-id': d.id, tabindex: 0 });
  const geo = labGeo(d), W = geo.w, H = geo.h;
  g.append(sv('rect', { class: 'sel-ring', x: -W / 2 - 7, y: -H / 2 - 7, width: W + 14, height: H + 14, rx: 12 }));
  if (d.kind === 'router') {
    const white = /hap|cap|wap|audience|chateau|ax/.test(d.model || '') && !/rb5009|ccr|crs|rb4011|hex/.test(d.model || '');
    g.append(sv('rect', { class: 'body', x: -W / 2, y: -H / 2, width: W, height: H, rx: white ? 12 : 7, fill: white ? 'url(#labWhite)' : 'url(#labMetal)', stroke: white ? '#9aa4ae' : '#161b21' }));
    g.append(sv('rect', { x: -W / 2, y: -H / 2 + 6, width: 4, height: H - 12, rx: 2, fill: routerColor(d) }));
    const ink = white ? '#2b3440' : '#eef2f5', silk = white ? '#5d6873' : '#9fabb7';
    g.append(sv('text', { class: 'r-name', x: -W / 2 + 13, y: -H / 2 + 19, fill: ink }, d.name));
    g.append(sv('text', { class: 'r-model', x: -W / 2 + 13, y: -H / 2 + 31, fill: silk }, d.board || d.model || ''));
    g.append(sv('circle', { class: 'led pwr', 'data-sys': 'pwr', cx: W / 2 - 14, cy: -H / 2 + 14, r: 3.2 }));
    g.append(sv('g', { class: 'r-globe', transform: `translate(${W / 2 - 30} ${-H / 2 + 14})` }, sv('circle', { r: 5.2 }), sv('path', { d: 'M-5.2 0h10.4M0 -5.2c2.6 2.6 2.6 7.8 0 10.4M0 -5.2c-2.6 2.6-2.6 7.8 0 10.4' })));
    for (const [id, p] of Object.entries(geo.ports)) {
      const pg = sv('g', { class: 'lab-port k-' + p.p.kind, 'data-port': id });
      if (p.ant) {
        pg.append(sv('path', { class: 'ant', d: `M${p.x} ${p.y}v-13`, stroke: white ? '#8b96a1' : '#1b2128' }), sv('circle', { class: 'ant-tip', cx: p.x, cy: p.y - 15, r: 3.6 }), sv('circle', { class: 'hot', cx: p.x, cy: p.y - 15, r: 9 }));
        pg.append(sv('rect', { class: 'led off', 'data-led': 'link', x: p.x - 3, y: p.y + 4, width: 6, height: 3, rx: 1 }));
      } else {
        const sfp = p.p.kind === 'sfp';
        pg.append(sv('rect', { class: 'sock', x: p.x - (sfp ? 9 : 8), y: p.y - (sfp ? 4.5 : 6), width: sfp ? 18 : 16, height: sfp ? 9 : 12, rx: 1.5, fill: sfp ? '#0b0e11' : '#0d1115', stroke: sfp ? '#8e9aa6' : (white ? '#9aa4ae' : '#56636f') }));
        if (!sfp) pg.append(sv('path', { d: `M${p.x - 5} ${p.y - 4}h10`, stroke: '#b8963a', 'stroke-width': 1.2 }));
        pg.append(sv('rect', { class: 'led off', 'data-led': 'link', x: p.x - 8, y: p.y - 11, width: 5, height: 3, rx: 1 }), sv('rect', { class: 'led off', 'data-led': 'act', x: p.x + 3, y: p.y - 11, width: 5, height: 3, rx: 1 }));
        const num = /^ether(\d+)$/.exec(id); g.append(sv('text', { class: 'p-num', x: p.x, y: p.y + 15.5, fill: silk }, num ? num[1] : id.replace('sfp-sfpplus', 'sfp+').replace(/^sfp(\d)$/, 'sfp$1')));
        pg.append(sv('rect', { class: 'hot', x: p.x - 11, y: p.y - 12, width: 22, height: 26, rx: 4 }));
      }
      g.append(pg);
    }
    g.append(sv('g', { class: 'stubs' }));
    g.append(sv('text', { class: 'n-addr r-sub', x: -W / 2 + 2, y: H / 2 + 16 }));
  } else if (d.kind === 'switch') {
    g.append(sv('rect', { class: 'body', x: -W / 2, y: -H / 2, width: W, height: H, rx: 5, fill: 'url(#labMetal)', stroke: '#161b21' }));
    g.append(sv('g', { transform: `translate(${-W / 2 + 20} ${-H / 2 + 14}) scale(.55)`, class: 'sw-ico' }));
    g.lastChild.innerHTML = DICON.switch;
    g.append(sv('text', { class: 'n-name', x: -W / 2, y: -H / 2 - 8 }, d.name));
    for (const [id, p] of Object.entries(geo.ports)) {
      const pg = sv('g', { class: 'lab-port k-ether', 'data-port': id });
      pg.append(sv('rect', { class: 'sock', x: p.x - 6, y: p.y - 5, width: 12, height: 10, rx: 1.2, fill: '#0d1115', stroke: '#56636f' }), sv('rect', { class: 'led off', 'data-led': 'link', x: p.x - 6, y: p.y - 9, width: 4, height: 2.5, rx: .8 }), sv('rect', { class: 'led off', 'data-led': 'act', x: p.x + 2, y: p.y - 9, width: 4, height: 2.5, rx: .8 }), sv('rect', { class: 'hot', x: p.x - 8.5, y: p.y - 10, width: 17, height: 20, rx: 3 }));
      g.append(pg);
    }
  } else if (d.kind === 'internet') {
    g.append(sv('path', { class: 'body cloud', d: 'M-52 26c-20 0-26-26-6-32-2-20 26-30 38-14 8-18 40-16 42 6 24-4 32 30 8 40z', fill: 'url(#labCloud)', stroke: '#5f87a8' }));
    g.append(sv('g', { class: 'globe', transform: 'translate(0 2) scale(.9)' })); g.lastChild.innerHTML = DICON.internet;
    g.append(sv('text', { class: 'n-name c', x: 0, y: -40 }, d.name));
    const p = geo.ports.net, pg = sv('g', { class: 'lab-port k-net', 'data-port': 'net' });
    pg.append(sv('rect', { class: 'sock', x: -11, y: p.y - 6, width: 22, height: 12, rx: 2.5, fill: '#0d1115', stroke: '#5f87a8' }), sv('rect', { class: 'led link', 'data-led': 'link', x: -3, y: p.y - 3, width: 6, height: 3, rx: 1 }), sv('rect', { class: 'hot', x: -18, y: p.y - 14, width: 36, height: 28, rx: 5 }));
    g.append(pg);
  } else {
    g.append(sv('rect', { class: 'body tile', x: -W / 2, y: -H / 2, width: W, height: H, rx: 10 }));
    g.append(sv('g', { class: 'd-ico' })); g.lastChild.innerHTML = DICON[d.kind] || DICON.pc;
    g.append(sv('circle', { class: 'st-dot', cx: W / 2 - 8, cy: -H / 2 + 8, r: 4 }));
    for (const [id, p] of Object.entries(geo.ports)) {
      const pg = sv('g', { class: 'lab-port k-' + p.p.kind, 'data-port': id });
      if (p.p.kind === 'wifi') pg.append(sv('path', { class: 'wf', d: `M${p.x - 7} ${p.y - 1}a10 10 0 0 1 14 0M${p.x - 4} ${p.y + 2}a5.5 5.5 0 0 1 8 0` }), sv('circle', { class: 'hot', cx: p.x, cy: p.y - 3, r: 10 }));
      else pg.append(sv('rect', { class: 'sock', x: p.x - 7, y: p.y - 4, width: 14, height: 9, rx: 1.5, fill: '#0d1115', stroke: '#56636f' }), sv('rect', { class: 'hot', x: p.x - 11, y: p.y - 8, width: 22, height: 20, rx: 4 }));
      g.append(pg);
    }
    g.append(sv('text', { class: 'n-name', x: W / 2 + 10, y: -6 }, d.name), sv('text', { class: 'n-addr', x: W / 2 + 10, y: 8 }), sv('text', { class: 'n-st', x: W / 2 + 10, y: 21 }));
  }
  if (d.kind === 'router') g.append(sv('text', { class: 'cur-tag', x: -W / 2 + 2, y: -H / 2 - 9 }, 'open in the console'));
  const inner = sv('g', { class: 'in' });
  while (g.firstChild) inner.append(g.firstChild);
  g.append(inner);
  return g;
}

function setText(el, t) { if (el && el.textContent !== t) el.textContent = t; }
function updateNode(d, g) {
  g.classList.toggle('sel', !!(LAB.sel && LAB.sel.type === 'dev' && LAB.sel.id === d.id));
  g.classList.toggle('cur', !!(d.kind === 'router' && S.rid === d.id));
  if (d.kind === 'router') {
    g.classList.toggle('off', d.state !== 'running'); g.classList.toggle('online', !!d.online);
    g.classList.toggle('booting', d.state === 'booting');
    const geo = labGeo(d), stubs = $('.stubs', g); stubs.innerHTML = ''; let nstub = 0;
    for (const p of d.ports || []) {
      const pg = g.querySelector(`.lab-port[data-port="${CSS.escape(p.id)}"]`); if (!pg) continue;
      const link = pg.querySelector('[data-led=link]'); link.setAttribute('class', 'led ' + (p.up ? 'link' : 'off'));
      pg.classList.toggle('disabled', !!p.disabled);
      if (p.virtual && !linksAt(d.id, p.id).length) {
        const q = geo.ports[p.id];
        stubs.append(sv('g', { class: 'stub', 'data-port': p.id }, sv('path', { d: `M${q.x} ${q.y + 6}c0 10 3 16 6 20`, stroke: CABLE.grey, 'stroke-width': 4.5, fill: 'none', 'stroke-linecap': 'round', 'stroke-dasharray': '2 4.5' }), sv('circle', { cx: q.x + 7, cy: q.y + 31, r: 6, class: 'stub-end' }), sv('text', { x: q.x + 7, y: q.y + 33.5, class: 'stub-t' }, '…')));
        nstub++;
      }
    }
    const up = (d.uplinks || []).find(u => u.addr) || (d.uplinks || [])[0];
    const lan = (d.ports || []).find(p => p.addr && !(up && up.iface === p.name));
    let sub = d.state !== 'running' ? (d.state === 'booting' ? 'starting…' : 'powered off') : [up && up.addr ? 'WAN ' + up.addr.split('/')[0] : '', lan ? 'LAN ' + lan.addr : ''].filter(Boolean).join('   ');
    const at = $('.n-addr', g); setText(at, sub); at.setAttribute('y', geo.h / 2 + (nstub ? 52 : 17));
  } else if (d.kind === 'switch') {
    for (const p of d.ports || []) {
      const pg = g.querySelector(`.lab-port[data-port="${CSS.escape(p.id)}"]`); if (!pg) continue;
      const lk = linksAt(d.id, p.id)[0];
      pg.querySelector('[data-led=link]').setAttribute('class', 'led ' + (lk && lk.up ? 'link' : 'off'));
    }
  } else if (d.kind !== 'internet') {
    const st = d.status || { status: 'unplugged' };
    g.classList.toggle('off', !!d.off);
    const cls = d.off ? 'off' : st.online ? 'ok' : st.status === 'login page' ? 'warn' : st.status === 'blocked' ? 'bad' : st.status === 'connected' ? 'local' : 'none';
    $('.st-dot', g).setAttribute('class', 'st-dot ' + cls);
    setText($('.n-addr', g), st.addr && st.addr !== 'public address' ? st.addr : st.addr ? 'public address' : '');
    const words = { 'login page': 'hotspot login page', connected: st.online ? 'online' + (st.user ? ' · ' + st.user : '') : 'no internet', unplugged: 'not connected', 'no link': 'no link', off: 'switched off', blocked: 'blocked', 'getting an address': 'getting an address…' };
    setText($('.n-st', g), d.off ? 'switched off' : words[st.status] || st.status);
  }
}

function buildLink(lk) {
  const g = sv('g', { class: 'lab-link' + (lk.kind === 'wifi' ? ' wifi' : ''), 'data-link': lk.id });
  const shadow = sv('path', { class: 'lk-shadow' }), core = sv('path', { class: 'lk-core' }), shine = sv('path', { class: 'lk-shine' }), hit = sv('path', { class: 'lk-hit' });
  g.append(shadow, core, shine, hit);
  const plugs = sv('g', { class: 'lab-plugs', 'data-link': lk.id });
  return { g, shadow, core, shine, hit, plugs, len: 0, acc: [0, 0] };
}
function plugAt(a, col) {
  if (!a) return '';
  const dir = a.face === 'up' ? -1 : 1, dark = shade(col, -45);
  return `<rect x="${(a.x - 5.5).toFixed(1)}" y="${(dir > 0 ? a.y - 7 : a.y - 4).toFixed(1)}" width="11" height="11" rx="2" fill="${col}" stroke="${dark}"/><rect x="${(a.x - 3.5).toFixed(1)}" y="${(dir > 0 ? a.y - 8 : a.y + 4).toFixed(1)}" width="7" height="3" fill="#d9c27a" opacity=".9"/>`;
}
function updateLink(lk, e) {
  const d = linkD(lk);
  const col = CABLE[lk.color] || CABLE.blue;
  if (e.d !== d) { e.d = d; for (const p of [e.shadow, e.core, e.shine, e.hit]) p.setAttribute('d', d); e.len = 0; }
  e.g.classList.toggle('down', !lk.up);
  e.g.classList.toggle('sel', !!(LAB.sel && LAB.sel.type === 'link' && LAB.sel.id === lk.id));
  e.g.classList.toggle('lifted', !!(LAB.conn && LAB.conn.lift === lk.id));
  e.plugs.classList.toggle('lifted', !!(LAB.conn && LAB.conn.lift === lk.id));
  if (lk.kind === 'wifi') { e.core.setAttribute('stroke', lk.up ? '#9ad7ff' : '#6b7783'); e.plugs.innerHTML = ''; return; }
  e.core.setAttribute('stroke', lk.up ? col : shade(col, -60));
  e.shadow.setAttribute('stroke', shade(col, -70));
  const pk = d + col;
  if (e.pk !== pk) { e.pk = pk; e.plugs.innerHTML = plugAt(anchor(lk.a.dev, lk.a.port), col) + plugAt(anchor(lk.b.dev, lk.b.port), col); }
}
function relinkDev(id) {
  for (const lk of LAB.st.links) if (lk.a.dev === id || lk.b.dev === id) { const e = LAB.linkEls.get(lk.id); e && updateLink(lk, e); }
  const d = labDev(id); if (d && d.kind === 'router') { const n = LAB.nodeEls.get(id); n && updateNode(d, n.g); }
}

// TapTap / WireGuard tunnels: a dotted arc to the internet while handshakes are fresh
function drawTunnels() {
  const L = LAB.L.tunnels, inet = LAB.st.devices.find(d => d.kind === 'internet');
  const want = new Map();
  for (const d of labRouters()) for (const [i, t] of (d.tunnel || []).entries()) want.set(d.id + ':' + i, { d, t, i });
  for (const [k, el] of LAB.tunEls) if (!want.has(k)) { el.remove(); LAB.tunEls.delete(k); }
  for (const [k, { d, t, i }] of want) {
    let el = LAB.tunEls.get(k);
    if (!el) { el = sv('g', { class: 'lab-tun' }, sv('path'), sv('text', { class: 'tun-t' })); L.append(el); LAB.tunEls.set(k, el); }
    const g = labGeo(d), a = { x: d.x + g.w / 2 - 6, y: d.y - g.h / 2 }, b = inet ? { x: inet.x + 60, y: inet.y - 6 } : { x: d.x + 160, y: d.y - 160 };
    const mx = (a.x + b.x) / 2 + 70 + i * 26, my = Math.min(a.y, b.y) - 50 - i * 18;
    el.firstChild.setAttribute('d', `M${a.x} ${a.y} Q${mx} ${my} ${b.x} ${b.y}`);
    const tt = el.lastChild; tt.setAttribute('x', mx - 20); tt.setAttribute('y', my + 18); setText(tt, (/taptap/i.test(t.comment + t.iface) ? 'TapTap tunnel' : 'WireGuard') + ' · ' + t.iface);
  }
}

// hop distance from the internet, so packets know which way is "down"
function labHops() {
  const st = LAB.st, dist = {}, q = [];
  for (const d of st.devices) if (d.kind === 'internet') { dist[d.id] = 0; q.push(d.id); }
  while (q.length) { const x = q.shift(); for (const lk of st.links) { if (!lk.up) continue; const o = lk.a.dev === x ? lk.b.dev : lk.b.dev === x ? lk.a.dev : null; if (o && dist[o] == null) { dist[o] = dist[x] + 1; q.push(o); } } }
  LAB.dist = dist;
}

// ---------- animation ----------
function labFrame(dt) {
  if (!LAB.st) return;
  // cable sway after a drag
  for (const [id, s] of Object.entries(LAB.sway)) {
    s.vx += (-70 * s.ox - 7 * s.vx) * dt; s.vy += (-70 * s.oy - 7 * s.vy) * dt;
    s.ox += s.vx * dt; s.oy += s.vy * dt;
    const lk = LAB.st.links.find(l => l.id === id), e = LAB.linkEls.get(id);
    if (lk && e) updateLink(lk, e);
    if (Math.abs(s.ox) + Math.abs(s.oy) + Math.abs(s.vx) + Math.abs(s.vy) < .05 && !s.hold) delete LAB.sway[id];
  }
  // packets
  const layer = LAB.L.packets, reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (LAB.anim && !reduce) {
    for (const lk of LAB.st.links) {
      const e = LAB.linkEls.get(lk.id); if (!e || !lk.up || (LAB.conn && LAB.conn.lift === lk.id)) continue;
      [lk.ab, lk.ba].forEach((bps, dir) => {
        if (!(bps > 0)) return;
        e.acc[dir] += dt * Math.min(9, .5 + Math.log10(1 + bps / 2000) * 1.7);
        while (e.acc[dir] >= 1) {
          e.acc[dir] -= 1;
          if (LAB.dots.length > 420) break;
          if (!e.len) { try { e.len = e.core.getTotalLength(); } catch { e.len = 0; } }
          if (!e.len) break;
          const da = LAB.dist[lk.a.dev] ?? 99, db = LAB.dist[lk.b.dev] ?? 99;
          const down = dir === 0 ? da <= db : db <= da;
          const c = sv('circle', { r: (1.7 + Math.min(2.3, Math.log10(1 + bps / 1e5))).toFixed(2), fill: down ? DOWN_C : UP_C, class: 'pk' });
          layer.append(c);
          LAB.dots.push({ c, e, dir, t: 0, sp: (150 + Math.min(120, Math.log10(1 + bps) * 14)) / e.len });
        }
      });
    }
  }
  for (let i = LAB.dots.length - 1; i >= 0; i--) {
    const p = LAB.dots[i];
    p.t += dt * p.sp;
    if (p.t >= 1 || !p.e.g.isConnected || !LAB.anim) { p.c.remove(); LAB.dots.splice(i, 1); continue; }
    const len = p.e.len || 1, at = p.e.core.getPointAtLength((p.dir === 0 ? p.t : 1 - p.t) * len);
    p.c.setAttribute('cx', at.x.toFixed(1)); p.c.setAttribute('cy', at.y.toFixed(1));
  }
  // activity LEDs
  LAB.ledT = (LAB.ledT || 0) + dt;
  if (LAB.ledT > .09) {
    LAB.ledT = 0;
    for (const d of LAB.st.devices) {
      const n = LAB.nodeEls.get(d.id); if (!n) continue;
      if (d.kind === 'router') for (const p of d.ports || []) {
        const el = n.g.querySelector(`.lab-port[data-port="${CSS.escape(p.id)}"] [data-led=act]`); if (!el) continue;
        const pr = p.up ? Math.min(.95, .03 + Math.log10(1 + ((p.rx || 0) + (p.tx || 0)) / 1000) * .2) : 0;
        el.setAttribute('class', 'led ' + (Math.random() < pr ? 'act' : 'off'));
      }
      if (d.kind === 'switch') for (const p of d.ports || []) {
        const lk = linksAt(d.id, p.id)[0], el = n.g.querySelector(`.lab-port[data-port="${CSS.escape(p.id)}"] [data-led=act]`); if (!el) continue;
        const bps = lk && lk.up ? lk.ab + lk.ba : 0, pr = bps ? Math.min(.95, .03 + Math.log10(1 + bps / 1000) * .2) : 0;
        el.setAttribute('class', 'led ' + (Math.random() < pr ? 'act' : 'off'));
      }
    }
  }
}

// ---------- canvas interaction ----------
function hitPort(target) {
  const pg = target.closest('.lab-port'), ng = target.closest('.lab-node');
  if (!pg || !ng) return null;
  return { dev: ng.dataset.id, port: pg.dataset.port };
}
function bindCanvas() {
  const svg = LAB.svg;
  svg.addEventListener('wheel', e => { e.preventDefault(); labZoom(Math.exp(-e.deltaY * .0016), e.clientX, e.clientY); }, { passive: false });
  svg.addEventListener('pointerdown', e => {
    if (e.button === 2) return;
    hideTip(); $('#pop').hidden = true;
    const port = hitPort(e.target);
    if (port) return startConnect(e, port);
    const stub = e.target.closest('.stub');
    if (stub) { const n = stub.closest('.lab-node'), d = labDev(n.dataset.id), p = (d.ports || []).find(x => x.id === stub.dataset.port); return showPop(e.clientX, e.clientY, `Simulated devices on ${p ? p.name : stub.dataset.port}`, 'from the Simulator window, not on this canvas', [['Unplug them, free the port', async () => { await labCall('virtual', { id: d.id, port: p ? p.name : stub.dataset.port }); labPoll(); }]]); }
    const ng = e.target.closest('.lab-node');
    if (ng) return startMove(e, ng.dataset.id);
    const lg = e.target.closest('.lab-link');
    if (lg) { labSelect({ type: 'link', id: lg.dataset.link }); return; }
    startPan(e);
  });
  svg.addEventListener('keydown', e => {
    const ng = e.target.closest && e.target.closest('.lab-node');
    if (ng && e.key === 'Enter') openDevice(ng.dataset.id);
    if (ng && e.key === ' ') { e.preventDefault(); labSelect({ type: 'dev', id: ng.dataset.id }); }
  });
  svg.addEventListener('contextmenu', e => {
    const ng = e.target.closest('.lab-node'), lg = e.target.closest('.lab-link');
    if (!ng && !lg) return;
    e.preventDefault();
    if (lg && !ng) { labSelect({ type: 'link', id: lg.dataset.link }); const lk = LAB.st.links.find(l => l.id === lg.dataset.link); return showPop(e.clientX, e.clientY, 'Cable', lk ? endName(lk.a) + ' ↔ ' + endName(lk.b) : '', [['Unplug', () => labUnlink(lg.dataset.link)]]); }
    const d = labDev(ng.dataset.id); if (!d) return;
    labSelect({ type: 'dev', id: d.id });
    showPop(e.clientX, e.clientY, d.name, KIND_LABEL[d.kind] + (d.board ? ' · ' + d.board : ''), devActions(d));
  });
  svg.addEventListener('pointermove', e => {
    if (LAB.drag || LAB.conn || LAB.pan) return;
    const port = hitPort(e.target);
    if (port) return showTip(e, portTip(port));
    const stub = e.target.closest('.stub'); if (stub) return showTip(e, 'Simulated devices plugged in from the Simulator window.<br><span class="dim">click to unplug them</span>');
    const lg = e.target.closest('.lab-link');
    if (lg) { const lk = LAB.st && LAB.st.links.find(l => l.id === lg.dataset.link); if (lk) return showTip(e, `<b>${esc(endName(lk.a))}</b> ↔ <b>${esc(endName(lk.b))}</b><br>${lk.up ? 'link up' : 'no link'} · ${lk.kind === 'wifi' ? 'Wi-Fi' : (lk.color || 'blue') + ' cable'}<br><span class="dim">→</span> ${fmtBps(lk.ab)} &nbsp; <span class="dim">←</span> ${fmtBps(lk.ba)}<br><span class="dim">drag a plug to move it · right-click to unplug</span>`); }
    hideTip();
  });
  svg.addEventListener('pointerleave', hideTip);
}
function portTip(pt) {
  const d = labDev(pt.dev); if (!d) return '';
  const p = (d.ports || []).find(x => x.id === pt.port) || { name: pt.port, kind: '' };
  const lks = linksAt(pt.dev, pt.port);
  const peers = lks.map(l => esc(endName(peerOf(l, pt.dev, pt.port)))).join('<br>');
  const state = d.kind === 'router' ? (p.disabled ? 'disabled' : p.up ? 'link up' + (p.speed ? ' · ' + esc(p.speed) + 'bps' : '') : lks.length ? 'no link' : 'no cable') : '';
  const kind = { ether: 'Ethernet', sfp: 'SFP', wlan: 'radio', wifi: 'Wi-Fi', nic: 'Ethernet', net: 'uplink' }[p.kind] || '';
  return `<b>${esc(d.name)} · ${esc(p.name)}</b> <span class="dim">${kind}</span>${state ? '<br>' + state : ''}${p.addr ? '<br>' + esc(p.addr) : ''}${peers ? '<br><span class="dim">to</span> ' + peers : ''}${d.kind === 'router' && p.up ? `<br><span class="dim">rx</span> ${fmtBps(p.rx)} <span class="dim">tx</span> ${fmtBps(p.tx)}` : ''}<br><span class="dim">${lks.length && !multiPort(d, p) ? 'drag the plug to move or pull it out' : 'drag from here to connect'}</span>`;
}

function startPan(e) {
  const sx = e.clientX, sy = e.clientY, v0 = { ...LAB.view }; let moved = false;
  LAB.svg.setPointerCapture(e.pointerId); LAB.pan = true; LAB.svg.classList.add('panning');
  const mv = ev => { const dx = ev.clientX - sx, dy = ev.clientY - sy; if (Math.abs(dx) + Math.abs(dy) > 3) moved = true; LAB.view.x = v0.x + dx; LAB.view.y = v0.y + dy; LAB.view.auto = false; applyView(); };
  const up = () => { LAB.svg.removeEventListener('pointermove', mv); LAB.svg.removeEventListener('pointerup', up); LAB.pan = false; LAB.svg.classList.remove('panning'); if (!moved) labSelect(null); else saveView(); };
  LAB.svg.addEventListener('pointermove', mv); LAB.svg.addEventListener('pointerup', up);
}

function startMove(e, id) {
  const d = labDev(id); if (!d) return;
  const w0 = toWorld(e.clientX, e.clientY), x0 = d.x, y0 = d.y; let moved = false, lx = d.x, ly = d.y;
  LAB.svg.setPointerCapture(e.pointerId);
  LAB.drag = { id, d };
  const mv = ev => {
    const w = toWorld(ev.clientX, ev.clientY);
    const nx = Math.round(x0 + w.x - w0.x), ny = Math.round(y0 + w.y - w0.y);
    if (!moved && Math.hypot(nx - x0, ny - y0) < 4) return;
    moved = true; LAB.svg.classList.add('moving');
    d.x = nx; d.y = ny; placeNode(d);
    for (const lk of LAB.st.links) if (lk.a.dev === id || lk.b.dev === id) { const s = LAB.sway[lk.id] || (LAB.sway[lk.id] = { ox: 0, oy: 0, vx: 0, vy: 0 }); s.vx -= (nx - lx) * 2.2; s.vy -= (ny - ly) * 1.2; s.vx = Math.max(-260, Math.min(260, s.vx)); s.vy = Math.max(-200, Math.min(200, s.vy)); }
    lx = nx; ly = ny;
    relinkDev(id); drawTunnels();
  };
  const up = async () => {
    LAB.svg.removeEventListener('pointermove', mv); LAB.svg.removeEventListener('pointerup', up); LAB.svg.classList.remove('moving');
    if (!moved) {
      LAB.drag = null;
      const now = performance.now(), tap = LAB.lastTap;
      LAB.lastTap = { id, t: now };
      if (tap && tap.id === id && now - tap.t < 420) { LAB.lastTap = null; return openDevice(id); }
      labSelect({ type: 'dev', id }); return;
    }
    const p = { id, x: d.x, y: d.y }; LAB.pending.push(p); LAB.drag = null;
    await labCall('move', p); LAB.pending.splice(LAB.pending.indexOf(p), 1);
  };
  LAB.svg.addEventListener('pointermove', mv); LAB.svg.addEventListener('pointerup', up);
}

// drag from a port: a new cable, or pick up the plug that is already there
function startConnect(e, src) {
  const sd = labDev(src.dev); if (!sd) return;
  const sp = (sd.ports || []).find(p => p.id === src.port); if (!sp) return;
  const existing = linksAt(src.dev, src.port);
  let fixed = src, lift = null, color = LAB.color;
  if (existing.length && !multiPort(sd, sp)) { lift = existing[0]; fixed = peerOf(lift, src.dev, src.port); color = lift.color || 'blue'; }
  const fd = labDev(fixed.dev), fp = (fd.ports || []).find(p => p.id === fixed.port);
  if (!fd || !fp) return;
  const radio = radioKind(fp.kind), col = radio ? '#9ad7ff' : (CABLE[color] || CABLE.blue);
  LAB.svg.setPointerCapture(e.pointerId);
  const band = sv('g', { class: 'band' + (radio ? ' wifi' : '') }, sv('path', { class: 'lk-shadow', stroke: shade(col, -70) }), sv('path', { class: 'lk-core', stroke: col }), sv('circle', { r: 5, fill: col, class: 'band-end' }));
  LAB.L.over.append(band);
  LAB.conn = { fixed, lift, color };
  if (lift) { const e2 = LAB.linkEls.get(lift.id); e2 && updateLink(lift, e2); }
  // which ports can take this cable
  const cands = [];
  for (const d of LAB.st.devices) {
    if (d.id === fixed.dev) continue;
    const g = labGeo(d);
    for (const [pid, q] of Object.entries(g.ports)) {
      const p = q.p; if (radioKind(p.kind) !== radio) continue;
      if (radio && p.kind === fp.kind) continue; // radio to device, not radio to radio
      const used = linksAt(d.id, pid).filter(l => !lift || l.id !== lift.id);
      if (used.length && !multiPort(d, p)) continue;
      const isEnd = !['router', 'switch', 'internet'].includes(d.kind);
      if (isEnd && LAB.st.links.some(l => (l.a.dev === d.id || l.b.dev === d.id) && (!lift || l.id !== lift.id))) continue;
      cands.push({ dev: d.id, port: pid });
    }
  }
  const candKey = new Set(cands.map(c => c.dev + '/' + c.port));
  $$('.lab-port', LAB.svg).forEach(pg => { const k = pg.closest('.lab-node').dataset.id + '/' + pg.dataset.port; pg.classList.toggle('cand', candKey.has(k)); pg.classList.toggle('nocand', !candKey.has(k)); });
  LAB.svg.classList.add('connecting');
  let snap = null, moved = false;
  const fa = anchor(fixed.dev, fixed.port);
  const draw = w => {
    let to = { x: w.x, y: w.y, face: fa.face === 'up' ? 'up' : 'down' };
    snap = null; let best = 30 / LAB.view.k;
    for (const c of cands) { const a = anchor(c.dev, c.port); const dd = Math.hypot(a.x - w.x, a.y - w.y); if (dd < best) { best = dd; snap = c; to = a; } }
    $$('.lab-port.snap', LAB.svg).forEach(x => x.classList.remove('snap'));
    if (snap) { const n = LAB.nodeEls.get(snap.dev); n && n.g.querySelector(`.lab-port[data-port="${CSS.escape(snap.port)}"]`).classList.add('snap'); }
    const dpath = radio ? radioPath(fa, to) : cablePath(fa, { ...to, face: snap ? to.face : 'down' });
    band.children[0].setAttribute('d', dpath); band.children[1].setAttribute('d', dpath);
    band.children[2].setAttribute('cx', to.x); band.children[2].setAttribute('cy', to.y);
  };
  draw(toWorld(e.clientX, e.clientY));
  const mv = ev => { moved = true; hideTip(); draw(toWorld(ev.clientX, ev.clientY)); };
  const up = async ev => {
    LAB.svg.removeEventListener('pointermove', mv); LAB.svg.removeEventListener('pointerup', up);
    band.remove(); LAB.svg.classList.remove('connecting');
    $$('.lab-port', LAB.svg).forEach(pg => pg.classList.remove('cand', 'nocand', 'snap'));
    let target = snap;
    if (!target) {
      // dropped on a device: take its first free matching port
      const el = document.elementFromPoint(ev.clientX, ev.clientY), ng = el && el.closest && el.closest('.lab-node');
      if (ng && ng.dataset.id !== fixed.dev) target = pickPort(ng.dataset.id, cands, fixed);
    }
    LAB.conn = null;
    if (!moved) { if (lift) { const e2 = LAB.linkEls.get(lift.id); e2 && updateLink(lift, e2); } labSelect({ type: 'dev', id: src.dev }); return; }
    if (lift) {
      if (target && target.dev === src.dev && target.port === src.port) { labRender(); return; }
      await labCall('unlink', { id: lift.id });
      if (!target) { toast(`Unplugged ${endName(src)}`); LAB.st.links = LAB.st.links.filter(l => l.id !== lift.id); labRender(); labPoll(); return; }
    }
    if (!target) { labRender(); return; }
    const r = await labCall('link', { aDev: fixed.dev, aPort: fixed.port, bDev: target.dev, bPort: target.port, color });
    if (r.error) toast(r.error, true); else { LAB.fresh.add(r.id); labSelect({ type: 'link', id: r.id }); }
    labPoll();
  };
  LAB.svg.addEventListener('pointermove', mv); LAB.svg.addEventListener('pointerup', up);
}
function pickPort(devId, cands, from) {
  const mine = cands.filter(c => c.dev === devId); if (!mine.length) return null;
  const fromDev = labDev(from.dev), d = labDev(devId);
  if (d.kind === 'router') {
    // the internet goes into ether1; everything else into the first free LAN port
    const wan = mine.find(c => c.port === 'ether1');
    if (fromDev && (fromDev.kind === 'internet' || fromDev.kind === 'router' && wanFree(devId))) return wan || mine[0];
    return mine.find(c => c.port !== 'ether1') || mine[0];
  }
  return mine[0];
}
function wanFree(devId) { return !linksAt(devId, 'ether1').length; }

// ---------- palette drag ----------
function paletteDrag(e, tile) {
  if (e.button !== 0) return;
  e.preventDefault();
  const ghost = h('div', { class: 'lab-ghost', html: tile.innerHTML });
  document.body.append(ghost);
  let moved = false;
  const pos = ev => { ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px'; };
  pos(e);
  const mv = ev => { moved = true; pos(ev); const over = LAB.stage.contains(document.elementFromPoint(ev.clientX, ev.clientY)); ghost.classList.toggle('ok', over); };
  const up = ev => {
    removeEventListener('pointermove', mv); removeEventListener('pointerup', up); ghost.remove();
    const over = LAB.stage.contains(document.elementFromPoint(ev.clientX, ev.clientY));
    if (!moved) return labAddAt(tile.dataset, null);
    if (over) labAddAt(tile.dataset, toWorld(ev.clientX, ev.clientY));
  };
  addEventListener('pointermove', mv); addEventListener('pointerup', up);
}
async function labAddAt(ds, at) {
  if (!LAB.st) return;
  if (!at) { const r = LAB.svg.getBoundingClientRect(); at = toWorld(r.left + r.width / 2 + (Math.random() - .5) * 160, r.top + r.height / 2 + (Math.random() - .5) * 100); }
  const body = { kind: ds.kind, x: Math.round(at.x), y: Math.round(at.y) };
  if (ds.kind === 'router') { body.model = LAB.model; body.ownLan = store.get('lab.ownlan', true); }
  if (ds.ports) body.ports = +ds.ports;
  let ph = null;
  if (ds.kind === 'router') { ph = sv('g', { class: 'lab-boot', transform: `translate(${body.x} ${body.y})` }, sv('rect', { x: -92, y: -36, width: 184, height: 72, rx: 8 }), sv('text', { x: 0, y: 4 }, 'booting RouterOS…')); LAB.L.over.append(ph); }
  const r = await labCall('add', body);
  ph && ph.remove();
  if (r.error) return toast(r.error, true);
  LAB.fresh.add(r.id);
  await labPoll();
  labSelect({ type: 'dev', id: r.id });
  return r.id;
}

// ---------- selection, keys, actions ----------
function openDevice(id) {
  const d = labDev(id); if (!d) return;
  labSelect({ type: 'dev', id });
  if (d.kind === 'router') switchRouter(d.id);
  else if (d.status && d.status.status === 'login page') hotspotLoginDialog(d);
}
function labSelect(s) {
  LAB.sel = s;
  if (LAB.st) { for (const d of LAB.st.devices) { const n = LAB.nodeEls.get(d.id); n && n.g.classList.toggle('sel', !!s && s.type === 'dev' && s.id === d.id); } for (const [id, e] of LAB.linkEls) e.g.classList.toggle('sel', !!s && s.type === 'link' && s.id === id); }
  renderInspector();
}
function labKey(e) {
  if (!LAB.w || !LAB.w.el.classList.contains('active') || LAB.w.el.classList.contains('parked')) return;
  if (e.target.closest('input,select,textarea')) return;
  if (e.key === 'Escape') labSelect(null);
  if ((e.key === 'Delete' || e.key === 'Backspace') && LAB.sel) {
    e.preventDefault();
    if (LAB.sel.type === 'link') labUnlink(LAB.sel.id);
    else { const d = labDev(LAB.sel.id); d && labRemove(d); }
  }
  if (e.key === 'f' || e.key === 'F') labFit(true);
}
async function labUnlink(id) { const r = await labCall('unlink', { id }); if (r.error) return toast(r.error, true); if (LAB.sel && LAB.sel.id === id) labSelect(null); labPoll(); }
async function labRemove(d) {
  if (d.primary) return toast('The main router stays in the lab', true);
  if (d.kind === 'router' && !confirm(`Remove ${d.name}? Its configuration and files are deleted.`)) return;
  if (S.rid === d.id) await switchRouter(labRouters().find(x => x.primary).id);
  const r = await labCall('remove', { id: d.id }); if (r.error) return toast(r.error, true);
  if (S.desks[d.id]) { Object.values(S.desks[d.id].wins || {}).forEach(w => { w.timers.forEach(clearInterval); w.closers.forEach(f => { try { f(); } catch { } }); w.el.remove(); }); delete S.desks[d.id]; }
  labSelect(null); labPoll();
}
async function labPower(d, action) { const r = await labCall('power', { id: d.id, action }); if (r.error) toast(r.error, true); setTimeout(labPoll, 300); }
function devActions(d) {
  const a = [];
  if (d.kind === 'router') {
    a.push(['Configure in this console', () => switchRouter(d.id)], ['Open a terminal', async () => { if (await switchRouter(d.id)) openTerminal(); }]);
    if (d.state === 'running') a.push(['Reboot', () => labPower(d, 'reboot')], ['Power off', () => labPower(d, 'off')]); else a.push(['Power on', () => labPower(d, 'on')]);
  } else if (d.kind !== 'switch' && d.kind !== 'internet') {
    if (d.status && d.status.status === 'login page') a.push(['Log in to the hotspot…', () => hotspotLoginDialog(d)]);
    a.push([d.off ? 'Switch on' : 'Switch off', () => labPower(d, d.off ? 'on' : 'off')]);
  }
  if (!d.primary) a.push(['Remove', () => labRemove(d)]);
  return a;
}

// ---------- inspector ----------
function inspKey() {
  const s = LAB.sel; if (!s || !LAB.st) return 'none:' + (LAB.st ? JSON.stringify([LAB.st.devices.map(d => [d.name, d.state, d.online, d.status && d.status.online]), LAB.st.links.length, S.rid]) : '');
  if (s.type === 'link') { const lk = LAB.st.links.find(l => l.id === s.id); return lk ? 'l:' + JSON.stringify([lk.up, lk.color]) : 'gone'; }
  const d = labDev(s.id); if (!d) return 'gone';
  return 'd:' + JSON.stringify([d.name, d.state, d.online, d.via, d.off, d.status, d.uplinks, (d.ports || []).map(p => [p.up, p.addr, p.disabled]), linksAt(d.id, '').length, LAB.st.links.filter(l => l.a.dev === d.id || l.b.dev === d.id).map(l => l.id + l.up), S.rid, d.tunnel && d.tunnel.length]);
}
function refreshInspector() {
  if (LAB.insp && LAB.insp.contains(document.activeElement) && document.activeElement.matches('input,select')) { refreshLive(); return; }
  if (inspKey() !== LAB.inspKey) renderInspector(); else refreshLive();
}
function refreshLive() {
  const s = LAB.sel; if (!s || !LAB.st) return;
  if (s.type === 'link') { const lk = LAB.st.links.find(l => l.id === s.id); if (!lk) return; setText($('[data-live=ab]', LAB.insp), fmtBps(lk.ab)); setText($('[data-live=ba]', LAB.insp), fmtBps(lk.ba)); return; }
  const d = labDev(s.id); if (!d) return;
  for (const p of d.ports || []) { const el = LAB.insp.querySelector(`[data-live-port="${CSS.escape(p.id)}"]`); el && setText(el, p.up ? fmtBps((p.rx || 0) + (p.tx || 0)) : ''); }
  if (d.status) { setText($('[data-live=down]', LAB.insp), fmtBps(d.status.down)); }
}
function renderInspector() {
  const el = LAB.insp; if (!el) return;
  LAB.inspKey = inspKey();
  el.innerHTML = '';
  const s = LAB.sel, st = LAB.st;
  if (!st) { el.append(h('div', { class: 'li-empty' }, 'Loading the lab…')); return; }
  if (!s) return el.append(inspOverview());
  if (s.type === 'link') { const lk = st.links.find(l => l.id === s.id); if (!lk) { LAB.sel = null; return el.append(inspOverview()); } return el.append(inspLink(lk)); }
  const d = labDev(s.id); if (!d) { LAB.sel = null; return el.append(inspOverview()); }
  el.append(d.kind === 'router' ? inspRouter(d) : d.kind === 'switch' || d.kind === 'internet' ? inspPlain(d) : inspEnd(d));
}
function nameEditor(d) {
  const inp = h('input', { class: 'li-name', value: d.name, 'aria-label': 'Name', spellcheck: 'false' });
  const save = async () => { const v = inp.value.trim(); if (!v || v === d.name) { inp.value = d.name; return; } const r = await labCall('rename', { id: d.id, name: v }); if (r.error) toast(r.error, true); else { d.name = v; labPoll(); if (S.rid === d.id) refreshInfo(); } };
  inp.onkeydown = e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { inp.value = d.name; inp.blur(); } };
  inp.onblur = save;
  return inp;
}
function row(k, v, cls) { return h('div', { class: 'li-row ' + (cls || '') }, h('span', { class: 'k' }, k), h('span', { class: 'v' }, v)); }
function inspOverview() {
  const st = LAB.st, routers = labRouters(), ends = st.devices.filter(d => END_KINDS.some(k => k[0] === d.kind));
  const online = ends.filter(d => d.status && d.status.online).length;
  const box = h('div', { class: 'li' }, h('h3', null, 'Your network'),
    h('div', { class: 'li-stats' }, h('div', null, h('b', null, routers.length), h('span', null, routers.length === 1 ? 'router' : 'routers')), h('div', null, h('b', null, ends.length), h('span', null, ends.length === 1 ? 'device' : 'devices')), h('div', null, h('b', null, st.links.length), h('span', null, st.links.length === 1 ? 'connection' : 'connections'))),
    ends.length ? h('p', { class: 'li-p' }, `${online} of ${ends.length} devices reach the internet.`) : null,
    h('h4', null, 'Routers'),
    h('div', { class: 'li-list' }, routers.map(d => { const b = h('button', { class: 'li-rt' + (S.rid === d.id ? ' cur' : '') }, h('i', { style: { background: routerColor(d) } }), h('span', null, h('b', null, d.name), h('small', null, `${d.board || d.model} · ${d.state !== 'running' ? d.state : d.online ? 'online' : 'offline'}`)), h('em', null, S.rid === d.id ? 'configuring' : 'Configure')); b.onclick = () => switchRouter(d.id); return b; })),
    h('h4', null, 'How it works'),
    h('ul', { class: 'li-help' }, h('li', null, 'Drag from a port to another port to run a cable. Drop on a device to use its first free port.'), h('li', null, 'Drag a plugged cable end to move it, or drop it on empty canvas to pull it out.'), h('li', null, 'Phones and laptops join a router over Wi-Fi: drag from their Wi-Fi to the router’s antenna.'), h('li', null, 'Double-click a router to configure it here; the console switches to that router.'), h('li', null, 'Delete removes the selection; F fits the network in view.')));
  return box;
}
function inspRouter(d) {
  const cur = S.rid === d.id;
  const cfg = h('button', { class: 'primary li-cfg', disabled: d.state !== 'running' && !cur }, cur ? 'Configuring this router' : 'Configure in this console');
  cfg.onclick = () => cur ? openDashboard() : switchRouter(d.id);
  const up = d.uplinks || [];
  const ports = h('table', { class: 'li-ports' }, h('tbody', null, (d.ports || []).map(p => {
    const lks = linksAt(d.id, p.id), peer = lks.map(l => endName(peerOf(l, d.id, p.id))).join(', ');
    return h('tr', { class: p.up ? 'up' : '' }, h('td', null, h('i', { class: 'li-led' + (p.up ? ' on' : '') }), p.name), h('td', { class: 'peer', title: peer }, peer || (p.virtual ? 'simulated devices' : p.kind === 'wlan' ? 'no clients' : '—')), h('td', { class: 'mono', 'data-live-port': p.id }, p.up ? fmtBps((p.rx || 0) + (p.tx || 0)) : ''));
  })));
  const sv2 = d.services || {}, host = (S.info && S.info.hostIP) || location.hostname;
  const acts = h('div', { class: 'li-acts' }, devActions(d).filter(a => !/^Configure/.test(a[0])).map(([l, f]) => { const b = h('button', { class: /Remove/.test(l) ? 'danger' : '' }, l); b.onclick = f; return b; }));
  return h('div', { class: 'li' },
    h('div', { class: 'li-head' }, h('i', { class: 'li-swatch', style: { background: routerColor(d) } }), nameEditor(d)),
    h('div', { class: 'li-sub' }, `${d.board || ''}${d.primary ? ' · main router' : ''}`),
    cfg,
    row('State', d.state === 'running' ? 'running' : d.state || 'off'),
    row('Internet', d.state !== 'running' ? '—' : d.online ? 'online ' + (d.via ? '(' + d.via.replace(/^via /, 'via ') + ')' : '') : (d.via || 'offline'), d.online ? 'ok' : 'bad'),
    up.map(u => row('Uplink ' + u.iface, u.mode === 'none' ? 'no DHCP server on that cable' : (u.addr || 'asking for an address…') + (u.from ? ' from ' + (labDev(u.from) ? labDev(u.from).name : u.from) : ''))),
    (d.tunnel || []).length ? row('Tunnel', d.tunnel.map(t => t.iface).join(', ') + ' up', 'ok') : null,
    h('h4', null, 'Ports'), ports,
    h('h4', null, 'Reach it from other tools'),
    h('div', { class: 'li-svc mono' }, [['API', sv2.api], ['Web', sv2.www], ['SSH', sv2.ssh]].filter(x => x[1]).map(([k, v]) => h('span', null, k + ' ', h('b', null, host + ':' + v)))),
    h('p', { class: 'li-p dim' }, 'The TapTap app and other RouterOS tools connect to these ports on this PC.'),
    acts);
}
function inspEnd(d) {
  const st = d.status || { status: 'unplugged' }, via = st.via && labDev(st.via);
  const usage = h('select', { 'aria-label': 'What the device does' }, ['auto', 'idle', 'browsing', 'streaming', 'heavy'].map(u => h('option', { value: u }, { auto: 'Typical use', idle: 'Idle', browsing: 'Browsing', streaming: 'Streaming video', heavy: 'Downloading a lot' }[u])));
  usage.onchange = async () => { const r = await labCall('usage', { id: d.id, usage: usage.value }); if (r.error) toast(r.error, true); };
  if (st.status === 'connected' || st.status === 'login page') labCall('client', { id: d.id }).then(r => { if (r.client) usage.value = r.client.usage || 'auto'; });
  const acts = h('div', { class: 'li-acts' });
  if (st.status === 'login page') { const b = h('button', { class: 'primary' }, 'Log in to the hotspot…'); b.onclick = () => hotspotLoginDialog(d); acts.append(b); }
  if (st.user) { const b = h('button', null, 'Log out of the hotspot'); b.onclick = async () => { const r = await labCall('hslogout', { id: d.id }); if (r.error) toast(r.error, true); labPoll(); }; acts.append(b); }
  for (const [l, f] of devActions(d)) if (!/hotspot/.test(l)) { const b = h('button', { class: /Remove/.test(l) ? 'danger' : '' }, l); b.onclick = f; acts.append(b); }
  const viaBtn = via ? h('button', { class: 'linkish' }, via.name) : null; if (viaBtn) viaBtn.onclick = () => switchRouter(via.id);
  const word = d.off ? 'switched off' : st.online ? 'online' : st.status === 'connected' ? 'on the network, no internet' : st.status === 'login page' ? 'waiting at the hotspot login page' : st.status;
  return h('div', { class: 'li' },
    h('div', { class: 'li-head' }, h('span', { class: 'li-ico', html: iconSvg(d.kind, 28) }), nameEditor(d)),
    h('div', { class: 'li-sub' }, KIND_LABEL[d.kind]),
    row('Status', word, st.online ? 'ok' : st.status === 'login page' ? 'warn' : ''),
    st.addr ? row('Address', st.addr) : null,
    via ? row('Served by', viaBtn) : null,
    st.user ? row('Hotspot user', st.user) : null,
    row('MAC', h('span', { class: 'mono' }, d.mac || '')),
    st.status === 'connected' || st.status === 'login page' ? row('Using it for', usage) : null,
    !LAB.st.links.some(l => l.a.dev === d.id || l.b.dev === d.id) ? h('p', { class: 'li-p' }, (d.ports || []).some(p => p.kind === 'wifi') ? 'Drag from its Wi-Fi symbol to a router’s antenna, or from its Ethernet port to a router or switch port.' : 'Drag from its Ethernet port to a router or switch port.') : null,
    acts);
}
function inspPlain(d) {
  const used = LAB.st.links.filter(l => l.a.dev === d.id || l.b.dev === d.id).length;
  const acts = h('div', { class: 'li-acts' }, devActions(d).map(([l, f]) => { const b = h('button', { class: /Remove/.test(l) ? 'danger' : '' }, l); b.onclick = f; return b; }));
  return h('div', { class: 'li' }, h('div', { class: 'li-head' }, h('span', { class: 'li-ico', html: iconSvg(d.kind, 28) }), nameEditor(d)),
    h('div', { class: 'li-sub' }, d.kind === 'switch' ? `${(d.ports || []).length}-port switch` : 'Internet uplink'),
    row(d.kind === 'switch' ? 'Ports in use' : 'Connections', d.kind === 'switch' ? `${used} of ${(d.ports || []).length}` : String(used)),
    h('p', { class: 'li-p' }, d.kind === 'switch' ? 'A plain unmanaged switch: everything plugged in shares one network, and DHCP comes from the router on it.' : 'A router plugged in here gets an address from your PC’s network, like a modem. Switch the internet off in the Simulator window to see what happens downstream.'),
    acts);
}
function inspLink(lk) {
  const sw = h('div', { class: 'lab-swatches' }, Object.entries(CABLE).map(([n, c]) => { const b = h('button', { class: 'sw' + (n === (lk.color || 'blue') ? ' on' : ''), style: { background: c }, title: n, 'aria-label': n + ' cable' }); b.onclick = async () => { await labCall('color', { id: lk.id, color: n }); labPoll(); }; return b; }));
  const un = h('button', { class: 'danger' }, 'Unplug'); un.onclick = () => labUnlink(lk.id);
  return h('div', { class: 'li' }, h('h3', null, lk.kind === 'wifi' ? 'Wi-Fi connection' : 'Cable'),
    row('From', endName(lk.a)), row('To', endName(lk.b)),
    row('Link', lk.up ? 'up' : 'down — one end is off or disabled', lk.up ? 'ok' : 'bad'),
    row('→ ' + labDev(lk.b.dev)?.name, h('span', { 'data-live': 'ab', class: 'mono' }, fmtBps(lk.ab))),
    row('← ' + labDev(lk.a.dev)?.name, h('span', { 'data-live': 'ba', class: 'mono' }, fmtBps(lk.ba))),
    lk.kind === 'wifi' ? null : h('h4', null, 'Colour'), lk.kind === 'wifi' ? null : sw,
    h('div', { class: 'li-acts' }, un));
}

// ---------- hotspot login as a lab device ----------
async function hotspotLoginDialog(d) {
  const r = await labCall('vouchers', { id: d.id });
  if (r.error) return toast(r.error, true);
  const users = r.users || [];
  const w = openWin('lablogin:' + d.id, `Log in ${d.name} to the hotspot`, { w: 420, h: 230 }, w => {
    w.global = true;
    const sel = h('select'); users.forEach(u => sel.append(h('option', { value: u.name }, `${u.name}  (${u.profile}${u.limit ? ', ' + u.limit : ''})`)));
    const pass = h('input', { type: 'text', placeholder: 'password' });
    const fill = () => { const u = users.find(x => x.name === sel.value); pass.value = u ? (u.password || '') : ''; };
    sel.onchange = fill; fill();
    const stl = h('div', { class: 'status' });
    const ok = h('button', { class: 'primary' }, 'Log in'), cancel = h('button', {}, 'Cancel');
    ok.onclick = async () => { const x = await labCall('hslogin', { id: d.id, user: sel.value, password: pass.value }); if (x.error) { stl.innerHTML = ''; stl.append(h('span', { class: 'err' }, x.error)); } else { w.close(); toast(`${d.name} logged in as ${sel.value}`); labPoll(); } };
    cancel.onclick = () => w.close();
    w.body.append(h('div', { class: 'dlg' }, h('div', { class: 'dlg-main' }, h('p', { class: 'muted', style: { margin: '12px 14px 4px' } }, `The hotspot of ${r.routerName} holds ${d.name} at its login page.`), users.length ? h('div', { class: 'form' }, h('label', null, 'Voucher'), sel, h('label', null, 'Password'), pass) : h('p', { style: { margin: '6px 14px' } }, 'There are no hotspot users on that router yet: add some under IP → Hotspot → Users, or generate vouchers in the Simulator window.'), stl), h('div', { class: 'dlg-btns' }, users.length ? ok : null, cancel)));
  });
  return w;
}

// ---------- sample networks ----------
async function labTemplate(kind) {
  if (!LAB.st) return;
  const st = () => LAB.st, r1 = st().devices.find(d => d.primary);
  const used = (id, p) => linksAt(id, p).length > 0;
  const freeEth = id => { const d = labDev(id); return (d.ports || []).filter(p => (p.kind === 'ether' || p.kind === 'sfp') && p.id !== 'ether1' && !used(id, p.id)).map(p => p.id); };
  const radio = id => { const d = labDev(id); const p = (d.ports || []).find(p => p.kind === 'wlan'); return p && p.id; };
  // a free spot near (x, y): nothing placed within a device's footprint
  const placed = [];
  const spot = (x, y, k) => {
    const wide = k === 'router' || k === 'switch' ? 250 : 165;
    for (let i = 0; i < 40; i++) {
      const yy = y + Math.floor(i / 2) * 105, xx = x + (i % 2 ? 60 : 0);
      const busy = [...st().devices.map(d => ({ x: d.x, y: d.y, w: d.kind === 'router' || d.kind === 'switch' ? 250 : d.kind === 'internet' ? 180 : 165 })), ...placed].some(o => Math.abs(o.x - xx) < (o.w + wide) / 2 - 10 && Math.abs(o.y - yy) < 95);
      if (!busy) { placed.push({ x: xx, y: yy, w: wide }); return [xx, yy]; }
    }
    return [x, y];
  };
  const add = async (k, x, y, extra) => { [x, y] = spot(x, y, k); const r = await labCall('add', { kind: k, x: Math.round(x), y: Math.round(y), ...(extra || {}) }); if (r.error) { toast(r.error, true); throw r; } LAB.fresh.add(r.id); return r.id; };
  const link = async (a, ap, b, bp, color) => { const r = await labCall('link', { aDev: a, aPort: ap, bDev: b, bPort: bp, color: color || LAB.color }); if (!r.error) LAB.fresh.add(r.id); return r; };
  const refresh = async () => { const r = await labCall('state'); if (r.devices) { LAB.st = r; labRender(); } };
  const X = r1.x, Y = r1.y;
  toast('Building the sample network…');
  try {
    if (!st().devices.some(d => d.kind === 'internet') || !used(r1.id, 'ether1')) {
      let inet = st().devices.find(d => d.kind === 'internet');
      const iid = inet ? inet.id : await add('internet', X, Y - 210);
      if (!used(r1.id, 'ether1')) await link(r1.id, 'ether1', iid, 'net', 'blue');
    }
    if (kind === 'home') {
      const fe = freeEth(r1.id), rd = radio(r1.id);
      if (rd) { for (const [k, dx] of [['phone', -190], ['laptop', 0], ['tablet', 190]]) { const id = await add(k, X + dx, Y + 240); await link(id, 'wifi', r1.id, rd); } }
      if (fe[0]) { const id = await add('tv', X + 380, Y + 90); await link(id, 'eth', r1.id, fe[0], 'grey'); }
      if (fe[1]) { const id = await add('pc', X - 400, Y + 90); await link(id, 'eth', r1.id, fe[1], 'green'); }
    } else if (kind === 'office') {
      const fe = freeEth(r1.id); if (!fe[0]) return toast('Free an Ethernet port on ' + r1.name + ' first', true);
      const sw = await add('switch', X, Y + 200, { ports: 8 }); await link(r1.id, fe[0], sw, 'p1', 'yellow');
      const swd = (await refresh(), labDev(sw));
      const kinds = ['pc', 'pc', 'pc', 'printer', 'server'];
      for (let i = 0; i < kinds.length; i++) { const id = await add(kinds[i], swd.x - 380 + i * 190, swd.y + 170); await link(id, 'eth', sw, 'p' + (i + 2), i === 4 ? 'red' : 'blue'); }
    } else if (kind === 'towers' || kind === 'chain') {
      const fe = freeEth(r1.id); if (!fe[0]) return toast('Free an Ethernet port on ' + r1.name + ' first', true);
      const plan = kind === 'towers' ? [['Tower-North', X - 330, Y + 250, r1.id, fe[0]], ['Tower-South', X + 330, Y + 250, r1.id, fe[1] || null]] : [['Branch', X + 60, Y + 250, r1.id, fe[0]], ['Shop', X + 120, Y + 500, null, null]];
      const ids = [];
      for (const [name, x, y, upId, upPort] of plan) {
        const pr = ids.length && kind === 'chain' ? ids[ids.length - 1] : upId;
        if (!pr) continue;
        const id = await add('router', x, y, { model: 'hap-ac2', name, ownLan: true }); ids.push(id);
        await refresh();
        const port = kind === 'chain' && ids.length > 1 ? freeEth(pr)[0] : upPort;
        if (port) await link(pr, port, id, 'ether1', 'yellow');
      }
      await refresh();
      for (const id of ids) {
        const d = labDev(id), rd = radio(id);
        if (kind === 'towers' && rd) for (const [k, dx] of [['phone', -175], ['phone', 0], ['laptop', 175]]) { const p = await add(k, d.x + dx - 30, d.y + 210); await link(p, 'wifi', id, rd); }
        if (kind === 'chain') { const fe2 = freeEth(id); if (fe2[0]) { const p = await add('pc', d.x + 290, d.y + 40); await link(p, 'eth', id, fe2[0], 'green'); } }
      }
    }
  } catch (e) { /* toast shown */ }
  await labPoll();
  labFit(true);
  if (kind === 'towers') toast('The phones wait at the towers’ hotspot login page: select one and log it in.');
}

// ---------- the router chip in the top bar ----------
function renderRouterChip() {
  const chip = $('#routerChip'); if (!chip) return;
  if (!S.labT) { chip.hidden = true; return; }
  const routers = labRouters();
  const cur = routers.find(d => d.id === S.rid);
  chip.hidden = false;
  chip.style.setProperty('--rc', routerColor(cur || { primary: true }));
  chip.innerHTML = `<i></i><span>${esc(cur ? cur.name : (S.info && S.info.identity) || 'router')}</span><svg viewBox="0 0 10 10"><path d="M2 4l3 3 3-3"/></svg>`;
  $('#app').style.setProperty('--rc', routerColor(cur || { primary: true }));
}
async function routerChipMenu(e) {
  if (!LAB.st) { const r = await labCall('state'); if (r.devices) LAB.st = r; }
  const r = e.currentTarget.getBoundingClientRect();
  const acts = labRouters().map(d => [(S.rid === d.id ? '● ' : '') + d.name + (d.state !== 'running' ? ' (' + d.state + ')' : ''), () => switchRouter(d.id)]);
  acts.push(['Open the Network Lab', () => openLab()]);
  showPop(r.left, r.bottom + 4, 'Switch router', 'each router keeps its own windows', acts);
}

// ---------- one console, many routers ----------
// Every router keeps its own desk: its windows (terminals stay connected) are
// parked when you switch away and come back when you switch to it again.
async function labRelogin() {
  if (!S.primaryCred) return false;
  try {
    const r = await post('/gui/login', { host: '127.0.0.1', user: S.primaryCred.user, password: S.primaryCred.pass });
    if (r.error || !r.t) return false;
    S.labT = r.t;
    if (S.rid === 'r1' || !S.base) S.t = r.t; else if (S.desks.r1) S.desks.r1.t = r.t;
    return true;
  } catch { return false; }
}
async function routerLogin(d, pass, user) {
  try { return await post(d.base + '/gui/login', { host: '127.0.0.1', user: user || 'admin', password: pass || '' }); } catch { return { error: d.name + ' is not answering' }; }
}
function askRouterPassword(d, msg) {
  return new Promise(res => {
    openWin('labpw:' + d.id, 'Log in to ' + d.name, { w: 400, h: 200 }, w => {
      w.global = true;
      const user = h('input', { value: 'admin', spellcheck: 'false' }), pass = h('input', { type: 'password', placeholder: 'password' });
      const st = h('div', { class: 'status' }, msg ? h('span', { class: 'err' }, msg) : '');
      const ok = h('button', { class: 'primary' }, 'Log in'), cancel = h('button', {}, 'Cancel');
      let done = false;
      ok.onclick = () => { done = true; w.close(); res({ user: user.value.trim(), pass: pass.value }); };
      cancel.onclick = () => w.close();
      w.closers.push(() => { if (!done) res(null); });
      pass.onkeydown = e => e.key === 'Enter' && ok.onclick();
      w.body.append(h('div', { class: 'dlg' }, h('div', { class: 'dlg-main' }, h('p', { class: 'muted', style: { margin: '12px 14px 4px' } }, `${d.name} has a password on its admin user.`), h('div', { class: 'form' }, h('label', null, 'Login'), user, h('label', null, 'Password'), pass), st), h('div', { class: 'dlg-btns' }, ok, cancel)));
      setTimeout(() => pass.focus(), 30);
    });
  });
}
async function switchRouter(id) {
  if (!LAB.st) { const r = await labCall('state'); if (r.devices) LAB.st = r; }
  const d = labDev(id);
  if (!d) { toast('That router is not in the lab', true); return false; }
  if (S.rid === id) { const w = S.wins.dash; if (w) { w.el.classList.remove('minimized'); focusWin(w); } else openDashboard(); return true; }
  if (d.state === 'failed') { toast(d.name + ' did not start', true); return false; }
  let desk = S.desks[id];
  if (desk && desk.t) {
    // still logged in?
    let ok = false;
    try { const r = await (await fetch(d.base + '/gui/info?t=' + encodeURIComponent(desk.t))).json(); ok = !r.error && !r.expired; if (ok) desk.info = { ...desk.info, ...r }; } catch { }
    if (!ok) desk.t = null;
  }
  if (!desk || !desk.t) {
    let cred = desk && desk.cred || { user: 'admin', pass: '' };
    let r = d.primary && S.primaryCred ? await routerLogin(d, S.primaryCred.pass, S.primaryCred.user) : await routerLogin(d, cred.pass, cred.user);
    for (let tries = 0; r.error && tries < 3; tries++) {
      if (!/password|login|denied|invalid/i.test(r.error)) { toast(r.error, true); return false; }
      const c = await askRouterPassword(d, tries ? r.error : '');
      if (!c) return false;
      cred = c; r = await routerLogin(d, c.pass, c.user);
    }
    if (r.error) { toast(r.error, true); return false; }
    if (d.primary) S.labT = r.t;
    desk = { ...(desk || { wins: {} }), t: r.t, info: r, base: d.base, cred };
  }
  // park this router's windows, bring the other router's back
  const keep = {}, park = {};
  for (const [k, w] of Object.entries(S.wins)) (w.global ? keep : park)[k] = w;
  Object.values(park).forEach(w => w.el.classList.add('parked'));
  if (S.rid) S.desks[S.rid] = { ...(S.desks[S.rid] || {}), t: S.t, info: S.info, base: S.base, wins: park };
  S.rid = id; S.t = desk.t; S.info = desk.info; S.base = desk.base; S.state = 'running';
  S.wins = { ...keep, ...(desk.wins || {}) };
  S.desks[id] = desk;
  Object.values(S.wins).forEach(w => w.el.classList.remove('parked'));
  $('#overlay').hidden = true;
  renderTop(); renderMenu(); renderRouterChip(); renderTasks();
  const top = $('#top'); top.classList.remove('switched'); void top.offsetWidth; top.classList.add('switched');
  if (!Object.keys(desk.wins || {}).length) openDashboard(); else { const w = Object.values(desk.wins).sort((a, b) => (+a.el.style.zIndex) - (+b.el.style.zIndex)).pop(); w && focusWin(w); }
  refreshInfo(); topStats(); pollState();
  if (LAB.w && LAB.st) { labRender(); refreshInspector(); }
  toast(`Now configuring ${d.name}`);
  return true;
}
let reloginP = null;
function reloginCurrent() {
  if (reloginP) return reloginP;
  reloginP = (async () => {
    const id = S.rid, desk = S.desks[id] || {}, cred = desk.cred || { user: 'admin', pass: '' };
    const r = await routerLogin({ base: S.base, name: S.info && S.info.identity || 'the router' }, cred.pass, cred.user);
    if (!r.error && r.t) { S.t = r.t; S.desks[id] = { ...desk, t: r.t }; }
    else { toast('Logged out of ' + ((S.info && S.info.identity) || 'that router') + ': ' + r.error, true); await switchRouter('r1'); }
  })().finally(() => { reloginP = null; });
  return reloginP;
}
function closeAllDesks() {
  for (const desk of Object.values(S.desks)) for (const w of Object.values(desk.wins || {})) { if (S.wins[w.id] === w) continue; w.timers.forEach(clearInterval); w.closers.forEach(f => { try { f(); } catch { } }); w.el.remove(); }
  S.desks = {}; S.base = ''; S.rid = null; S.labT = null; S.primaryCred = null; LAB.st = null;
  const chip = $('#routerChip'); if (chip) chip.hidden = true;
}
