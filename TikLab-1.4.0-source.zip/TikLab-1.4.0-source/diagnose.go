package main

// Connection diagnostics for real routers: when TikLab cannot reach a router
// it checks the usual MikroTik ports, works out what is in the way and
// writes the RouterOS commands that fix it.

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// discovery is the MNDP listener, when discovery is on.
var discovery *MNDP

type PortCheck struct {
	Svc    string `json:"svc"`
	Name   string `json:"name"`
	Port   int    `json:"port"`
	State  string `json:"state"` // open | refused | silent | unreachable | error
	Detail string `json:"detail,omitempty"`
	Ms     int    `json:"ms"`
	Need   string `json:"need,omitempty"` // what TikLab uses it for
}

type FixStep struct {
	Title string `json:"title"`
	Text  string `json:"text,omitempty"`
	Cmd   string `json:"cmd,omitempty"`
	Undo  string `json:"undo,omitempty"` // removes what Cmd added
}

type Diagnosis struct {
	Host     string      `json:"host"`
	LocalIP  string      `json:"localIp,omitempty"`
	LocalNet string      `json:"localNet,omitempty"`
	SameNet  bool        `json:"sameNet"`
	Self     bool        `json:"self,omitempty"`
	Ports    []PortCheck `json:"ports"`
	MikroTik string      `json:"mikrotik,omitempty"` // evidence, e.g. "FTP greeting: MikroTik 7.12"
	Other    string      `json:"other,omitempty"`    // evidence it is not a MikroTik
	Headline string      `json:"headline"`
	Explain  []string    `json:"explain"`
	Fix      []FixStep   `json:"fix"`
	MAC      string      `json:"mac,omitempty"`    // from this PC's ARP table
	ARPRead  bool        `json:"arpRead"`          // the ARP table could be read
	Vendor   string      `json:"vendor,omitempty"` // "MikroTik" when the MAC prefix is MikroTik's
	Seen     string      `json:"seen,omitempty"`   // MNDP: identity/board/version seen at this address
	Others   []string    `json:"others,omitempty"` // MikroTiks seen by discovery at other addresses
	SSH      bool        `json:"ssh"`              // SSH answered, so TikLab can work over SSH
	API      string      `json:"api"`              // state of the API port
}

// netErrKind sorts a dial error into the states shown to the user. It works
// on the error text as well, because Windows reports these differently.
func netErrKind(err error) string {
	if err == nil {
		return "open"
	}
	var ne net.Error
	msg := strings.ToLower(err.Error())
	switch {
	case strings.Contains(msg, "refused"):
		return "refused"
	case strings.Contains(msg, "no route to host"), strings.Contains(msg, "unreachable"), strings.Contains(msg, "no such host"):
		return "unreachable"
	case errors.As(err, &ne) && ne.Timeout(), strings.Contains(msg, "timeout"), strings.Contains(msg, "timed out"), strings.Contains(msg, "did not properly respond"):
		return "silent"
	}
	return "error"
}

// isNetErr reports whether err came from the network rather than from the
// router (a login refusal, for instance).
func isNetErr(err error) bool {
	if err == nil {
		return false
	}
	if _, ok := err.(*Trap); ok {
		return false
	}
	k := netErrKind(err)
	return k == "refused" || k == "silent" || k == "unreachable" || strings.Contains(strings.ToLower(err.Error()), "connection reset") || strings.Contains(err.Error(), "EOF")
}

// friendlyNetErr turns a dial error into a sentence.
func friendlyNetErr(what, addr string, err error) error {
	if err == nil {
		return nil
	}
	if t, ok := err.(*Trap); ok {
		return fmt.Errorf("%s login to %s was refused by the router: %s", what, addr, t.Msg)
	}
	switch netErrKind(err) {
	case "silent":
		return fmt.Errorf("no reply from %s (%s): the packets are being dropped on the way or by the router", addr, what)
	case "refused":
		return fmt.Errorf("%s refused the connection (%s): that service is off or on another port", addr, what)
	case "unreachable":
		return fmt.Errorf("%s cannot be reached from this PC (%s): %v", addr, what, err)
	}
	return fmt.Errorf("%s to %s failed: %v", what, addr, err)
}

var reFTPVer = regexp.MustCompile(`MikroTik ([0-9][0-9.a-z]*)`)

func checkPort(host string, pc *PortCheck, timeout time.Duration) {
	start := time.Now()
	c, err := net.DialTimeout("tcp", net.JoinHostPort(host, strconv.Itoa(pc.Port)), timeout)
	pc.Ms = int(time.Since(start) / time.Millisecond)
	pc.State = netErrKind(err)
	if err != nil {
		if pc.State == "error" || pc.State == "unreachable" {
			pc.Detail = err.Error()
		}
		return
	}
	defer c.Close()
	switch pc.Svc {
	case "ftp", "ssh":
		c.SetReadDeadline(time.Now().Add(1500 * time.Millisecond))
		buf := make([]byte, 200)
		n, _ := c.Read(buf)
		pc.Detail = strings.TrimSpace(strings.SplitN(string(buf[:n]), "\n", 2)[0])
	}
}

func localRoute(host string) (ip net.IP, ipnet *net.IPNet) {
	c, err := net.Dial("udp", net.JoinHostPort(host, "9")) // no packet is sent
	if err != nil {
		return nil, nil
	}
	ip = c.LocalAddr().(*net.UDPAddr).IP
	c.Close()
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if n, ok := a.(*net.IPNet); ok && n.IP.Equal(ip) {
			return ip, &net.IPNet{IP: n.IP.Mask(n.Mask), Mask: n.Mask}
		}
	}
	return ip, nil
}

// diagnoseRouter checks the router's management ports and explains the result.
// loginErr is the error from the last attempt, if any.
func diagnoseRouter(o RealOpts, loginErr error) *Diagnosis {
	d := &Diagnosis{Host: o.Host, Explain: []string{}, Fix: []FixStep{}}
	apiPort := o.APIPort
	if apiPort == 0 {
		apiPort = 8728
	}
	ftpPort := firstPort(o.FTPPort, 21)
	sshPort := firstPort(o.SSHPort, 22)
	d.Ports = []PortCheck{
		{Svc: "api", Name: "API", Port: apiPort, Need: "clone, test, run /import"},
		{Svc: "api-ssl", Name: "API-SSL", Port: 8729, Need: "same as API, encrypted"},
		{Svc: "ssh", Name: "SSH", Port: sshPort, Need: "fallback for clone, send and /import"},
		{Svc: "ftp", Name: "FTP", Port: ftpPort, Need: "files and hotspot pages"},
		{Svc: "winbox", Name: "WinBox", Port: 8291},
		{Svc: "www", Name: "WebFig", Port: 80},
		{Svc: "telnet", Name: "Telnet", Port: 23},
	}
	if o.TLS && apiPort == 8729 {
		d.Ports[0].Port, d.Ports[1].Port = 8728, 8729
		d.Ports[0].Need, d.Ports[1].Need = "", "clone, test, run /import (TLS)"
	}
	ip := net.ParseIP(o.Host)
	if ip == nil {
		if ips, err := net.LookupIP(o.Host); err == nil && len(ips) > 0 {
			ip = ips[0]
		} else {
			d.Headline = "TikLab could not find the address " + o.Host + "."
			d.Explain = append(d.Explain, "Type the router's IP address, for example 192.168.88.1.")
			return d
		}
	}
	host := ip.String()
	if lip, lnet := localRoute(host); lip != nil {
		d.LocalIP = lip.String()
		if lnet != nil {
			d.LocalNet = lnet.String()
			d.SameNet = lnet.Contains(ip)
		}
		if lip.Equal(ip) {
			d.Self = true
		}
	}
	var wg sync.WaitGroup
	for i := range d.Ports {
		wg.Add(1)
		go func(pc *PortCheck) {
			defer wg.Done()
			checkPort(host, pc, 4*time.Second)
		}(&d.Ports[i])
	}
	wg.Wait()
	if d.SameNet && !d.Self {
		d.MAC, d.ARPRead = arpLookup(host)
		if isMikroTikMAC(d.MAC) {
			d.Vendor = "MikroTik"
		}
	}
	if discovery != nil {
		for _, n := range discovery.List() {
			if n.TikLab {
				continue
			}
			desc := strings.TrimSpace(fmt.Sprintf("%s (%s, RouterOS %s)", n.Identity, firstNonEmpty(n.Board, n.Platform), strings.Fields(n.Version + " ")[0]))
			if n.IP == host || (d.MAC != "" && strings.EqualFold(n.MAC, d.MAC)) {
				d.Seen = desc
				d.Vendor = "MikroTik"
			} else if n.IP != "" {
				d.Others = append(d.Others, n.IP+": "+desc)
			}
		}
		sort.Strings(d.Others)
	}

	state := map[string]string{}
	var open []string
	unreachable := 0
	for _, p := range d.Ports {
		state[p.Svc] = p.State
		if p.State == "open" {
			open = append(open, fmt.Sprintf("%s (%d)", p.Name, p.Port))
		}
		if p.State == "unreachable" {
			unreachable++
		}
		if p.Svc == "ftp" && p.Detail != "" {
			if m := reFTPVer.FindStringSubmatch(p.Detail); m != nil {
				d.MikroTik = "the FTP greeting says RouterOS " + m[1]
			} else if strings.HasPrefix(p.Detail, "220") {
				d.Other = "the FTP greeting is \"" + trimTo(p.Detail, 60) + "\""
			}
		}
		if p.Svc == "ssh" && p.Detail != "" {
			if strings.Contains(p.Detail, "ROSSSH") {
				if d.MikroTik == "" {
					d.MikroTik = "the SSH server identifies as RouterOS"
				}
			} else if strings.HasPrefix(p.Detail, "SSH-") && d.Other == "" {
				d.Other = "the SSH server identifies as \"" + trimTo(p.Detail, 40) + "\""
			}
		}
	}
	if d.MikroTik != "" {
		d.Other = ""
	}
	apiSvc := "api"
	if o.TLS {
		apiSvc = "api-ssl"
	}
	d.API = state[apiSvc]
	d.SSH = state["ssh"] == "open" && d.Other == ""
	me := firstNonEmpty(d.LocalIP, "this PC's address")
	sshRefused := loginErr != nil && strings.Contains(loginErr.Error(), "(SSH)")
	if sshRefused {
		d.SSH = false
	}
	allow := fmt.Sprintf(`/ip firewall filter add chain=input action=accept protocol=tcp src-address=%s dst-port=8728,8729,21,22 comment="TikLab access" place-before=[:pick [find chain=input dynamic=no] 0]`, me)
	allowStep := FixStep{
		Title: "Let this PC through the router's firewall",
		Text:  "In WinBox, open New Terminal and paste this. It accepts the API, FTP and SSH ports from " + me + " only, placed above your drop rules.",
		Cmd:   allow,
		Undo:  `/ip firewall filter remove [find comment="TikLab access"]`,
	}
	sshStep := FixStep{
		Title: "Connect over SSH instead",
		Text:  fmt.Sprintf("SSH (port %d) answered, so set Connect using to SSH, or leave it on Automatic. Clone, send and /import all work over SSH. Hotspot pages still need FTP.", sshPort),
	}
	lanStep := FixStep{
		Title: "Connect from the LAN side",
		Text:  "Plug this PC into one of the router's LAN ports (ether2 and up on a default setup) or join its Wi-Fi, and use the router's LAN address, usually 192.168.88.1. The default firewall allows management from there.",
	}
	checkAddr := FixStep{
		Title: "Check the router's address",
		Text:  "In WinBox, open IP > Addresses and compare it with " + o.Host + ". From this PC, run  ping " + o.Host + "  in a Command Prompt.",
	}

	switch {
	case d.Self && len(open) == 0:
		d.Headline = o.Host + " is this PC's own address, not the router's."
		d.Explain = append(d.Explain, "Enter the router's address instead. In WinBox it is under IP > Addresses; on a default setup it is 192.168.88.1.")
		d.addOthers()
		return d

	case d.API == "open":
		if loginErr == nil || isNetErr(loginErr) {
			d.Headline = fmt.Sprintf("The router answers on the API port (%d).", d.Ports[0].Port)
			if loginErr != nil {
				d.Explain = append(d.Explain, "The connection dropped after it was made: "+loginErr.Error()+". Try again; if it keeps happening, check that the port really is the MikroTik API and not another service.")
			}
			break
		}
		msg := loginErr.Error()
		if t, ok := loginErr.(*Trap); ok {
			msg = t.Msg
		}
		low := strings.ToLower(msg)
		switch {
		case strings.Contains(low, "not allowed") || strings.Contains(low, "policy"):
			d.Headline = "The router accepted the password but this user is not allowed to use the API."
			d.Explain = append(d.Explain, "RouterOS answered: "+msg+". The user's group needs the api and read policies, sensitive to read passwords, ftp for files and write for /import. The built-in full group has all of them.")
			d.Fix = append(d.Fix, FixStep{Title: "Use a user in the full group", Text: "This shows which group the user is in. Either log in as a user of the full group, or add the missing policies to the user's group under System > Users > Groups.", Cmd: `/user print where name="` + o.User + `"`})
		case strings.Contains(low, "invalid user") || strings.Contains(low, "password") || strings.Contains(low, "cannot log in"):
			d.Headline = "The router rejected the user name or password."
			d.Explain = append(d.Explain, "RouterOS answered: "+msg+". User names and passwords are case-sensitive. A user can also be limited to certain addresses (System > Users > Allowed Address), which gives the same answer.")
			d.Fix = append(d.Fix, FixStep{Title: "Check the user on the router", Text: "This shows the group and any Allowed Address. The address must include " + me + ", or be empty.", Cmd: `/user print detail where name="` + o.User + `"`})
		default:
			d.Headline = "The router answered but stopped the login."
			d.Explain = append(d.Explain, "RouterOS answered: "+msg)
		}

	case d.API == "refused" && state["winbox"] != "open" && state["ssh"] != "open" && d.MikroTik == "" && d.Vendor == "" && d.Seen == "":
		d.Headline = "A device at " + o.Host + " answered, but it refuses every MikroTik port."
		d.Explain = append(d.Explain, fmt.Sprintf("WinBox (8291), the API (%d) and SSH (%d) all refused the connection. A MikroTik normally keeps at least WinBox open, so this is probably another device, such as a PC, a printer or the ISP's box. If it is the router, all of its services are turned off.", d.Ports[0].Port, sshPort))
		d.Fix = append(d.Fix, checkAddr, lanStep)

	case d.API == "refused":
		d.Headline = fmt.Sprintf("The router answered, but refused the API port (%d).", d.Ports[0].Port)
		d.Explain = append(d.Explain, "The API service is turned off, set to a different port, or limited to other addresses. Some setups turn it off on purpose.")
		d.Fix = append(d.Fix, FixStep{Title: "Turn the API service on", Text: "This shows the services and their ports. If the api row has an address under Available From, it must include " + me + ".", Cmd: "/ip service print\n/ip service enable api"})
		if d.SSH {
			d.Fix = append(d.Fix, sshStep)
		}

	case d.API == "silent" && len(open) > 0 && sshRefused:
		d.Headline = fmt.Sprintf("The API port gets no reply, and SSH (port %d) refused the login.", sshPort)
		d.Explain = append(d.Explain, "TikLab tried SSH because the API port did not answer. SSH answered but rejected the user name or password. They are case-sensitive, and a user can be limited to certain addresses (System > Users > Allowed Address).")
		d.Fix = append(d.Fix, allowStep, FixStep{Title: "Check the user on the router", Text: "This shows the group and any Allowed Address. The address must include " + me + ", or be empty.", Cmd: `/user print detail where name="` + o.User + `"`})

	case d.API == "silent" && len(open) > 0:
		d.Headline = fmt.Sprintf("The router is reachable (%s answered), but the API port gets no reply.", strings.Join(open, ", "))
		d.Explain = append(d.Explain, "Something on the router drops the API traffic. Usually this is a firewall rule in the input chain that only allows some ports. It can also be the API service limited to certain addresses (IP > Services > api > Available From).")
		if d.SSH {
			d.Fix = append(d.Fix, sshStep)
		}
		d.Fix = append(d.Fix, allowStep, FixStep{Title: "Check the service's allowed addresses", Text: "If the api row has an address under Available From, add " + me + " to it, keeping the existing addresses (comma separated).", Cmd: "/ip service print"})

	case len(open) == 0 && d.SameNet && d.ARPRead && d.MAC == "" && d.Seen == "":
		d.Headline = "Nothing answered at " + o.Host + ". No device on this network seems to use that address."
		d.Explain = append(d.Explain, fmt.Sprintf("This PC (%s) is on the same network (%s) and asked who has %s, but no device replied, not even at the network level. The router is off, unplugged, or has a different address.", me, d.LocalNet, o.Host))
		d.Fix = append(d.Fix, checkAddr, lanStep)

	case len(open) == 0 && unreachable > 0 && !d.SameNet:
		d.Headline = "This PC has no way to reach " + o.Host + "."
		d.Explain = append(d.Explain, "The PC reported: "+firstNonEmpty(d.Ports[0].Detail, "network unreachable")+". It is not on the router's network and has no route to it.")
		d.Fix = append(d.Fix, checkAddr, lanStep)

	case len(open) == 0:
		d.Headline = "The router is there, but it ignores every management port."
		if d.MAC == "" && d.Seen == "" {
			d.Headline = "Nothing at " + o.Host + " answered on any MikroTik port."
		}
		switch {
		case d.Seen != "":
			d.Explain = append(d.Explain, "TikLab sees "+d.Seen+" at this address through MikroTik discovery, so the address is right.")
		case d.MAC != "":
			v := ""
			if d.Vendor != "" {
				v = ", a MikroTik network card"
			}
			d.Explain = append(d.Explain, fmt.Sprintf("A device with MAC address %s%s answered when this PC looked for %s, so the address is in use.", d.MAC, v, o.Host))
		}
		if d.SameNet {
			d.Explain = append(d.Explain, fmt.Sprintf("This PC (%s) is on the same network (%s), so the packets reach the router, but it silently drops them. That is what the default MikroTik firewall does on the internet port (ether1): it only allows management from the LAN ports.", me, d.LocalNet))
			d.Explain = append(d.Explain, "This often happens when the router's ether1 gets its address from another router or the ISP box, and this PC is plugged into that same network.")
			d.Fix = append(d.Fix, lanStep, allowStep, checkAddr)
		} else {
			d.Explain = append(d.Explain, fmt.Sprintf("This PC (%s) is on a different network, so the traffic goes through a gateway. A firewall on the way, or on the router itself, is dropping it, or the address is wrong.", me))
			d.Fix = append(d.Fix, checkAddr, lanStep, allowStep)
		}

	default:
		d.Headline = fmt.Sprintf("The API port (%d) could not be checked: %s", d.Ports[0].Port, d.Ports[0].Detail)
	}

	if loginErr == nil && (d.API == "silent" || d.API == "unreachable") && !sshRefused && !d.Self {
		d.Explain = append([]string{"Your user name and password were not checked: the connection stopped before the login."}, d.Explain...)
	}
	if d.Self && len(open) > 0 {
		d.Explain = append(d.Explain, o.Host+" is this PC's own address. That is fine if a CHR or another TikLab runs on this PC; otherwise enter the router's address.")
	}
	d.addOthers()
	if d.Other != "" && d.MikroTik == "" && len(open) > 0 {
		d.Explain = append(d.Explain, "The device at "+o.Host+" may not be a MikroTik: "+d.Other+".")
	} else if d.MikroTik != "" {
		d.Explain = append(d.Explain, "It is a MikroTik: "+d.MikroTik+".")
	}
	if o.Files && state["ftp"] != "open" && d.API == "open" {
		d.Fix = append(d.Fix, FixStep{Title: "Turn on FTP to copy hotspot pages", Text: "Hotspot pages and other files are copied over FTP (port " + strconv.Itoa(ftpPort) + "), which did not answer.", Cmd: "/ip service enable ftp"})
	}
	return d
}

func firstPort(p, def int) int {
	if p > 0 {
		return p
	}
	return def
}

func trimTo(s string, n int) string {
	if len(s) > n {
		return s[:n] + "…"
	}
	return s
}

func (d *Diagnosis) addOthers() {
	if len(d.Others) == 0 || d.Seen != "" || d.API == "open" {
		return
	}
	d.Explain = append(d.Explain, "MikroTik discovery sees other routers on this network: "+strings.Join(d.Others, "; ")+". If one of them is the router you mean, use that address.")
}

var reMAC = regexp.MustCompile(`(?i)\b([0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b`)

// arpLookup returns the MAC address this PC has learned for ip. ok is false
// when the ARP table could not be read at all.
func arpLookup(ip string) (mac string, ok bool) {
	norm := func(m string) string {
		m = strings.ToUpper(strings.ReplaceAll(m, "-", ":"))
		if m == "00:00:00:00:00:00" || m == "FF:FF:FF:FF:FF:FF" {
			return ""
		}
		return m
	}
	if runtime.GOOS == "linux" {
		b, err := os.ReadFile("/proc/net/arp")
		if err != nil {
			return "", false
		}
		for _, l := range strings.Split(string(b), "\n") {
			f := strings.Fields(l)
			if len(f) >= 4 && f[0] == ip && f[2] != "0x0" {
				return norm(f[3]), true
			}
		}
		return "", true
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	args := []string{"-a", ip}
	if runtime.GOOS != "windows" {
		args = []string{"-n", ip}
	}
	out, err := exec.CommandContext(ctx, "arp", args...).CombinedOutput()
	if len(out) == 0 && err != nil {
		return "", false
	}
	for _, l := range strings.Split(string(out), "\n") {
		if strings.Contains(l, ip) {
			if m := reMAC.FindString(l); m != "" {
				return norm(m), true
			}
		}
	}
	return "", true
}

// Address blocks registered to MikroTik (Routerboard.com / MikroTikls SIA).
var mikrotikOUI = map[string]bool{
	"00:0C:42": true, "4C:5E:0C": true, "D4:CA:6D": true, "E4:8D:8C": true, "6C:3B:6B": true,
	"CC:2D:E0": true, "64:D1:54": true, "2C:C8:1B": true, "B8:69:F4": true, "74:4D:28": true,
	"48:8F:5A": true, "C4:AD:34": true, "DC:2C:6E": true, "18:FD:74": true, "08:55:31": true,
	"78:9A:18": true, "F4:1E:57": true, "48:A9:8A": true, "D4:01:C3": true, "04:F4:1C": true,
}

func isMikroTikMAC(mac string) bool {
	return len(mac) >= 8 && mikrotikOUI[strings.ToUpper(mac[:8])]
}
