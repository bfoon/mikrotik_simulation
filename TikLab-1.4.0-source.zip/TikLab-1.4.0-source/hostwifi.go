package main

// "Wi-Fi on this PC": when the simulated router has a radio, the PC's own
// Wi-Fi adapter can broadcast the same SSID (Windows Mobile Hotspot, or
// NetworkManager on Linux). Phones that join appear in the simulator as
// wireless clients with their real MAC address, get the simulator's hotspot
// login page, and log in with real vouchers. On Linux, run as root, devices
// that have not logged in are really held back (iptables) until they do.

import (
	"bufio"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type HostClient struct {
	MAC      string `json:"mac"`
	IP       string `json:"ip"`
	Name     string `json:"name"`
	SimAddr  string `json:"simAddress"`
	User     string `json:"user"`
	Since    string `json:"since"`
	LoggedIn bool   `json:"loggedIn"`
}

type HostWifiCaps struct {
	OS         string   `json:"os"`
	Supported  bool     `json:"supported"`
	Method     string   `json:"method"`
	Reason     string   `json:"reason,omitempty"`
	Devices    []string `json:"devices,omitempty"`
	Captive    bool     `json:"captive"` // unpaid devices can be blocked
	CaptiveWhy string   `json:"captiveWhy,omitempty"`
	Needs      string   `json:"needs,omitempty"` // what the user can do about it
}

type apConfig struct {
	SSID, Pass, Band string
}

type apBackend interface {
	probe() HostWifiCaps
	start(c apConfig) (string, error) // returns this PC's address on the hotspot network
	stop() error
	clients() ([]HostClient, error)
	device() string
	restoreHint() string
}

type HostWifi struct {
	gone    atomic.Bool // the router left the network lab
	r       *Router
	stepMu  sync.Mutex
	mu      sync.Mutex
	be      apBackend
	caps    *HostWifiCaps
	capsAt  time.Time
	State   string       `json:"state"` // off | starting | on | stopping | failed
	Detail  string       `json:"detail"`
	Radio   string       `json:"radio"`
	SSID    string       `json:"ssid"`
	Pass    string       `json:"pass"`
	Open    bool         `json:"open"`   // the simulated SSID has no password
	PCPass  bool         `json:"pcPass"` // the PC needed a password the router does not have
	PCIP    string       `json:"pcIp"`
	Clients []HostClient `json:"clients"`
	Captive bool         `json:"captive"`
	applied string
	ipByMAC map[string]string
	macByIP map[string]string
	seen    map[string]time.Time
	allowed string
	failAt  time.Time
}

func newHostWifi(r *Router) *HostWifi {
	hw := &HostWifi{r: r, State: "off", ipByMAC: map[string]string{}, macByIP: map[string]string{}, seen: map[string]time.Time{}}
	switch {
	case os.Getenv("TIKLAB_FAKE_WIFI") != "":
		hw.be = &fakeAP{dev: os.Getenv("TIKLAB_FAKE_WIFI")}
	case runtime.GOOS == "windows":
		hw.be = &winAP{dir: r.dataDir, connected: map[string]bool{}}
	case runtime.GOOS == "linux":
		hw.be = &nmAP{}
	default:
		hw.be = &noAP{}
	}
	return hw
}

func (hw *HostWifi) Caps(refresh bool) HostWifiCaps {
	hw.mu.Lock()
	c := hw.caps
	fresh := c != nil && time.Since(hw.capsAt) < 30*time.Second
	hw.mu.Unlock()
	if c != nil && fresh && !refresh {
		return *c
	}
	nc := hw.be.probe()
	hw.mu.Lock()
	hw.caps, hw.capsAt = &nc, time.Now()
	hw.mu.Unlock()
	return nc
}

// wanted reads what the simulated router asks for.
type wifiWant struct {
	on                bool
	why               string
	radio, ssid, pass string
	band              string
	open              bool
	captive           bool
	bridge            string
}

func (r *Router) pcWifiWant() wifiWant {
	r.mu.Lock()
	defer r.mu.Unlock()
	w := wifiWant{}
	st := r.single("/sim/settings")
	if st == nil || !st.B("pc-wifi") {
		w.why = "switched off"
		return w
	}
	w.captive = st.B("pc-wifi-captive")
	if r.state != "running" {
		w.why = "the simulated router is " + map[string]string{"booting": "starting", "off": "switched off"}[r.state]
		return w
	}
	type cand struct {
		name, ssid, pass, band string
		open, hs, is24         bool
	}
	hsBridges := map[string]bool{}
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if !h.B("disabled") {
			hsBridges[h["interface"]] = true
		}
	}
	bridgeOf := map[string]string{}
	for _, p := range r.list(MenuMap["/interface/bridge/port"]) {
		if !p.B("disabled") {
			bridgeOf[p["interface"]] = p["bridge"]
		}
	}
	var cands []cand
	for _, it := range r.list(MenuMap["/interface/wireless"]) {
		if it.B("disabled") || !strings.HasPrefix(it["mode"], "ap") {
			continue
		}
		c := cand{name: it["name"], ssid: it["ssid"], band: it["band"], open: true}
		if sp := r.byName("/interface/wireless/security-profiles", it["security-profile"]); sp != nil && sp["mode"] == "dynamic-keys" && sp["wpa2-pre-shared-key"] != "" {
			c.pass, c.open = sp["wpa2-pre-shared-key"], false
		}
		c.hs = hsBridges[bridgeOf[it["name"]]] || hsBridges[it["name"]]
		c.is24 = strings.HasPrefix(it["band"], "2ghz")
		cands = append(cands, c)
	}
	for _, it := range r.list(MenuMap["/interface/wifi"]) {
		if it.B("disabled") || firstNonEmpty(it["configuration.mode"], "ap") != "ap" {
			continue
		}
		c := cand{name: it["name"], ssid: it["configuration.ssid"], band: it["channel.band"], open: it["security.passphrase"] == ""}
		c.pass = it["security.passphrase"]
		c.hs = hsBridges[bridgeOf[it["name"]]] || hsBridges[it["name"]]
		c.is24 = strings.HasPrefix(it["channel.band"], "2ghz")
		cands = append(cands, c)
	}
	if len(cands) == 0 {
		w.why = "the simulated router has no enabled Wi-Fi access point"
		return w
	}
	pick := st["pc-wifi-interface"]
	sort.SliceStable(cands, func(i, j int) bool {
		if cands[i].hs != cands[j].hs {
			return cands[i].hs
		}
		return cands[i].is24 && !cands[j].is24
	})
	c := cands[0]
	for _, x := range cands {
		if x.name == pick {
			c = x
		}
	}
	w.on, w.radio, w.ssid, w.pass, w.open = true, c.name, c.ssid, c.pass, c.open
	w.band = "2.4"
	if strings.HasPrefix(c.band, "5ghz") {
		w.band = "5"
	}
	w.bridge = firstNonEmpty(bridgeOf[c.name], c.name)
	if w.ssid == "" {
		w.ssid = "MikroTik"
	}
	return w
}

// pcPassword is the password the PC uses when the simulated SSID is open but
// the PC cannot broadcast an open network (Windows Mobile Hotspot).
func (r *Router) pcPassword() string {
	r.mu.Lock()
	defer r.mu.Unlock()
	st := r.single("/sim/settings")
	if st == nil {
		return "tiklab-wifi"
	}
	if p := st["pc-wifi-password"]; len(p) >= 8 {
		return p
	}
	n, _ := rand.Int(rand.Reader, big.NewInt(9000))
	p := fmt.Sprintf("tiklab%04d", n.Int64()+1000)
	st["pc-wifi-password"] = p
	r.markDirty()
	return p
}

// loop applies the wanted state and follows the devices, every 2 seconds.
func (hw *HostWifi) loop() {
	for {
		func() {
			defer func() {
				if p := recover(); p != nil {
					fmt.Println("  ! pc wi-fi error:", p)
				}
			}()
			hw.step()
		}()
		if hw.gone.Load() {
			hw.mu.Lock()
			st := hw.State
			hw.mu.Unlock()
			if st == "off" || st == "" || st == "failed" {
				return
			}
		}
		time.Sleep(2 * time.Second)
	}
}

// pcWifiOwner is the router whose SSID this PC broadcasts.
var pcWifiOwner atomic.Pointer[HostWifi]

func (hw *HostWifi) step() {
	hw.stepMu.Lock()
	defer hw.stepMu.Unlock()
	w := hw.r.pcWifiWant()
	sig := ""
	if w.on {
		sig = strings.Join([]string{w.radio, w.ssid, w.pass, w.band}, "\x00")
	}
	hw.mu.Lock()
	applied, state, failAt := hw.applied, hw.State, hw.failAt
	hw.mu.Unlock()
	switch {
	case !w.on && (state == "on" || state == "starting" || state == "failed" && applied != ""):
		hw.set("stopping", "")
		err := hw.be.stop()
		pcWifiOwner.CompareAndSwap(hw, nil)
		hw.clearClients()
		hw.firewall(nil, false)
		hw.mu.Lock()
		hw.applied, hw.State, hw.Detail, hw.PCIP = "", "off", w.why, ""
		if err != nil {
			hw.Detail = err.Error()
		}
		hw.mu.Unlock()
		return
	case !w.on:
		hw.mu.Lock()
		hw.State, hw.Detail = "off", w.why
		hw.mu.Unlock()
		return
	case sig != applied && !(state == "failed" && applied == sig && time.Since(failAt) < 60*time.Second):
		// one PC, one hotspot: the first router of the network lab to ask gets it
		if !pcWifiOwner.CompareAndSwap(nil, hw) && pcWifiOwner.Load() != hw {
			o := pcWifiOwner.Load()
			o.mu.Lock()
			ssid := o.SSID
			o.mu.Unlock()
			hw.mu.Lock()
			hw.State, hw.Detail = "off", fmt.Sprintf("this PC is already broadcasting %q for another router in the network lab: switch it off there first", ssid)
			hw.mu.Unlock()
			return
		}
		caps := hw.Caps(false)
		if !caps.Supported {
			hw.mu.Lock()
			hw.State, hw.Detail, hw.applied, hw.failAt = "failed", caps.Reason, sig, time.Now()
			hw.mu.Unlock()
			return
		}
		cfg := apConfig{SSID: w.ssid, Pass: w.pass, Band: w.band}
		pcPass := false
		if w.open && hw.needsPassword() {
			cfg.Pass, pcPass = hw.r.pcPassword(), true
		}
		hw.set("starting", "")
		hw.mu.Lock()
		hw.Radio, hw.SSID, hw.Pass, hw.Open, hw.PCPass = w.radio, cfg.SSID, cfg.Pass, w.open, pcPass
		hw.mu.Unlock()
		ip, err := hw.be.start(cfg)
		hw.mu.Lock()
		hw.applied = sig
		if err != nil {
			hw.State, hw.Detail, hw.failAt = "failed", err.Error(), time.Now()
			hw.mu.Unlock()
			pcWifiOwner.CompareAndSwap(hw, nil)
			hw.r.mu.Lock()
			hw.r.log("wireless,warning", "this PC could not broadcast %q: %v", cfg.SSID, err)
			hw.r.mu.Unlock()
			return
		}
		hw.State, hw.Detail, hw.PCIP = "on", "", ip
		hw.mu.Unlock()
		hw.r.mu.Lock()
		hw.r.log("wireless,info", "this PC is broadcasting %q for %s", cfg.SSID, w.radio)
		hw.r.mu.Unlock()
	}
	hw.mu.Lock()
	on := hw.State == "on"
	hw.mu.Unlock()
	if on {
		hw.follow(w)
	}
}

func (hw *HostWifi) needsPassword() bool {
	_, win := hw.be.(*winAP)
	return win
}

func (hw *HostWifi) set(state, detail string) {
	hw.mu.Lock()
	hw.State, hw.Detail = state, detail
	hw.mu.Unlock()
}

// follow mirrors the PC's hotspot devices into the simulator.
func (hw *HostWifi) follow(w wifiWant) {
	cl, err := hw.be.clients()
	if err != nil {
		return
	}
	now := time.Now()
	r := hw.r
	r.mu.Lock()
	present := map[string]bool{}
	for i := range cl {
		c := &cl[i]
		c.MAC = strings.ToUpper(c.MAC)
		if _, err := net.ParseMAC(c.MAC); err != nil {
			continue
		}
		present[c.MAC] = true
		sc := r.sim.clientByMAC(c.MAC)
		if sc == nil {
			name := c.Name
			if name == "" || name == "*" {
				name = "Phone-" + strings.ReplaceAll(c.MAC[9:], ":", "")
			}
			name = uniqueClientName(r, name)
			var err error
			sc, err = r.addItem(MenuMap["/sim/client"], map[string]string{"name": name, "kind": "phone", "mac-address": c.MAC, "interface": w.bridge, "port": w.radio, "dynamic": "true", "usage": "browsing", "pc-wifi": "true", "_auto": "pc-wifi"}, true)
			if err != nil {
				continue
			}
			r.log("wireless,info", "%s (%s) joined %q on this PC", name, c.MAC, w.ssid)
		}
		sc["pc-address"] = c.IP
		sc["pc-wifi"] = "true"
		if sc["status"] != "connected" {
			r.sim.clientConnect(sc)
		}
		c.Name = sc["name"]
		c.SimAddr = sc["address"]
		c.User = sc["hotspot-user"]
		c.LoggedIn = c.User != ""
		if b := hw.bypassed(c.MAC); b {
			c.LoggedIn = true
		}
	}
	// devices that left the PC's network leave the simulation too
	for _, sc := range r.list(MenuMap["/sim/client"]) {
		if sc["pc-wifi"] == "true" && !present[strings.ToUpper(sc["mac-address"])] {
			r.sim.clientDisconnect(sc, "left the PC's Wi-Fi")
			r.removeItem(MenuMap["/sim/client"], sc, true)
			r.log("wireless,info", "%s (%s) left the PC's Wi-Fi", sc["name"], sc["mac-address"])
		}
	}
	r.mu.Unlock()
	canBlock := hw.Caps(false).Captive
	hw.mu.Lock()
	hw.ipByMAC, hw.macByIP = map[string]string{}, map[string]string{}
	for _, c := range cl {
		if c.IP != "" {
			hw.ipByMAC[c.MAC] = c.IP
			hw.macByIP[c.IP] = c.MAC
		}
		if _, ok := hw.seen[c.MAC]; !ok {
			hw.seen[c.MAC] = now
		}
	}
	for i := range cl {
		cl[i].Since = fmtDur(now.Sub(hw.seen[cl[i].MAC]).Truncate(time.Second))
	}
	sort.Slice(cl, func(i, j int) bool { return cl[i].Name < cl[j].Name })
	hw.Clients = cl
	hw.Captive = w.captive && canBlock
	hw.mu.Unlock()
	allowed := []string{}
	for _, c := range cl {
		if c.LoggedIn {
			allowed = append(allowed, c.MAC)
		}
	}
	hw.firewall(allowed, w.captive)
}

func (hw *HostWifi) bypassed(mac string) bool {
	for _, b := range hw.r.list(MenuMap["/ip/hotspot/ip-binding"]) {
		if strings.EqualFold(b["mac-address"], mac) && b["type"] == "bypassed" && !b.B("disabled") {
			return true
		}
	}
	return false
}

func uniqueClientName(r *Router, name string) string {
	base, n := name, 2
	for r.byName("/sim/client", name) != nil {
		name = fmt.Sprintf("%s-%d", base, n)
		n++
	}
	return name
}

func (hw *HostWifi) clearClients() {
	r := hw.r
	r.mu.Lock()
	for _, sc := range r.list(MenuMap["/sim/client"]) {
		if sc["pc-wifi"] == "true" {
			r.sim.clientDisconnect(sc, "the PC's Wi-Fi was switched off")
			r.removeItem(MenuMap["/sim/client"], sc, true)
		}
	}
	r.mu.Unlock()
	hw.mu.Lock()
	hw.Clients = nil
	hw.ipByMAC, hw.macByIP = map[string]string{}, map[string]string{}
	hw.mu.Unlock()
}

// MACForIP tells the captive portal which real device sent a request.
func (hw *HostWifi) MACForIP(ip string) string {
	if hw == nil {
		return ""
	}
	hw.mu.Lock()
	defer hw.mu.Unlock()
	if m := hw.macByIP[ip]; m != "" {
		return m
	}
	if hw.State == "on" && hw.inSubnet(ip) {
		if mac, ok := arpLookup(ip); ok && mac != "" {
			hw.macByIP[ip] = mac
			return mac
		}
	}
	return ""
}

func (hw *HostWifi) inSubnet(ip string) bool {
	a, b := net.ParseIP(ip).To4(), net.ParseIP(hw.PCIP).To4()
	return a != nil && b != nil && a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && !a.Equal(b)
}

// FromHotspot reports whether a request comes from a device on the PC's Wi-Fi.
func (hw *HostWifi) FromHotspot(ip string) bool {
	if hw == nil {
		return false
	}
	hw.mu.Lock()
	defer hw.mu.Unlock()
	return hw.State == "on" && hw.PCIP != "" && hw.inSubnet(ip)
}

func (hw *HostWifi) Snapshot() map[string]any {
	caps := hw.Caps(false)
	hw.mu.Lock()
	defer hw.mu.Unlock()
	return map[string]any{"caps": caps, "state": hw.State, "detail": hw.Detail, "radio": hw.Radio, "ssid": hw.SSID, "pass": hw.Pass, "open": hw.Open, "pcPass": hw.PCPass, "pcIp": hw.PCIP, "clients": append([]HostClient{}, hw.Clients...), "captive": hw.Captive, "device": hw.be.device(), "restore": hw.be.restoreHint()}
}

// ---------- captive firewall (Linux, root) ----------

func (hw *HostWifi) firewall(allowed []string, captive bool) {
	dev := hw.be.device()
	caps := hw.Caps(false)
	if runtime.GOOS != "linux" || dev == "" || !caps.Captive {
		return
	}
	sig := ""
	if captive && allowed != nil {
		sort.Strings(allowed)
		sig = strings.Join(allowed, ",")
		hw.mu.Lock()
		sig += "|" + hw.PCIP + "|" + strconv.Itoa(hw.r.portalPort())
		hw.mu.Unlock()
	}
	hw.mu.Lock()
	if sig == hw.allowed {
		hw.mu.Unlock()
		return
	}
	hw.allowed = sig
	pcip := hw.PCIP
	hw.mu.Unlock()
	ipt := func(a ...string) error { return exec.Command("iptables", a...).Run() }
	// clean up our chains
	ipt("-t", "nat", "-D", "PREROUTING", "-i", dev, "-j", "TIKLAB_HS")
	ipt("-D", "FORWARD", "-i", dev, "-j", "TIKLAB_HSF")
	ipt("-t", "nat", "-F", "TIKLAB_HS")
	ipt("-t", "nat", "-X", "TIKLAB_HS")
	ipt("-F", "TIKLAB_HSF")
	ipt("-X", "TIKLAB_HSF")
	if !captive || allowed == nil || pcip == "" {
		return
	}
	port := strconv.Itoa(hw.r.portalPort())
	ipt("-t", "nat", "-N", "TIKLAB_HS")
	ipt("-N", "TIKLAB_HSF")
	for _, mac := range allowed {
		ipt("-t", "nat", "-A", "TIKLAB_HS", "-m", "mac", "--mac-source", mac, "-j", "RETURN")
		ipt("-A", "TIKLAB_HSF", "-m", "mac", "--mac-source", mac, "-j", "RETURN")
	}
	ipt("-t", "nat", "-A", "TIKLAB_HS", "-p", "tcp", "--dport", "80", "-j", "DNAT", "--to-destination", pcip+":"+port)
	ipt("-A", "TIKLAB_HSF", "-p", "udp", "--dport", "53", "-j", "RETURN")
	ipt("-A", "TIKLAB_HSF", "-j", "REJECT")
	ipt("-t", "nat", "-I", "PREROUTING", "-i", dev, "-j", "TIKLAB_HS")
	ipt("-I", "FORWARD", "-i", dev, "-j", "TIKLAB_HSF")
}

func (r *Router) portalPort() int {
	if r.svc == nil {
		return 80
	}
	if p := r.svc.port("www"); p > 0 {
		return p
	}
	return 80
}

// ---------- backends ----------

type noAP struct{}

func (noAP) probe() HostWifiCaps {
	return HostWifiCaps{OS: runtime.GOOS, Reason: "Broadcasting Wi-Fi from this PC works on Windows 10/11 and on Linux with NetworkManager."}
}
func (noAP) start(apConfig) (string, error) {
	return "", fmt.Errorf("not supported on %s", runtime.GOOS)
}
func (noAP) stop() error                    { return nil }
func (noAP) clients() ([]HostClient, error) { return nil, nil }
func (noAP) device() string                 { return "" }
func (noAP) restoreHint() string            { return "" }

// fakeAP turns an existing network interface into a stand-in for a Wi-Fi
// access point (TIKLAB_FAKE_WIFI=<interface>), for testing without a radio.
type fakeAP struct {
	dev string
}

func (f *fakeAP) probe() HostWifiCaps {
	c := HostWifiCaps{OS: runtime.GOOS, Supported: true, Method: "test interface " + f.dev, Devices: []string{f.dev}}
	c.Captive, c.CaptiveWhy = linuxCaptive()
	return c
}

func (f *fakeAP) start(apConfig) (string, error) {
	ifc, err := net.InterfaceByName(f.dev)
	if err != nil {
		return "", err
	}
	addrs, _ := ifc.Addrs()
	for _, a := range addrs {
		if n, ok := a.(*net.IPNet); ok && n.IP.To4() != nil {
			return n.IP.String(), nil
		}
	}
	return "", fmt.Errorf("%s has no IPv4 address", f.dev)
}

func (f *fakeAP) stop() error         { return nil }
func (f *fakeAP) device() string      { return f.dev }
func (f *fakeAP) restoreHint() string { return "" }
func (f *fakeAP) clients() ([]HostClient, error) {
	return linuxNeighbours(f.dev, ""), nil
}

func linuxCaptive() (bool, string) {
	if os.Geteuid() != 0 {
		return false, "Run TikLab as root (sudo) to hold back devices that have not logged in. Without it, phones get the login page but can browse before logging in."
	}
	if _, err := exec.LookPath("iptables"); err != nil {
		return false, "iptables is not installed, so devices that have not logged in cannot be held back."
	}
	return true, ""
}

// linuxNeighbours lists devices on dev from the ARP table, with names from
// NetworkManager's DHCP leases when there are any.
func linuxNeighbours(dev, leases string) []HostClient {
	names := map[string]string{}
	if leases != "" {
		if b, err := os.ReadFile(leases); err == nil {
			for _, l := range strings.Split(string(b), "\n") {
				f := strings.Fields(l)
				if len(f) >= 4 {
					names[strings.ToUpper(f[1])] = f[3]
				}
			}
		}
	}
	var out []HostClient
	b, err := os.ReadFile("/proc/net/arp")
	if err != nil {
		return nil
	}
	for _, l := range strings.Split(string(b), "\n")[1:] {
		f := strings.Fields(l)
		if len(f) < 6 || f[5] != dev || f[2] == "0x0" || f[3] == "00:00:00:00:00:00" {
			continue
		}
		mac := strings.ToUpper(f[3])
		out = append(out, HostClient{MAC: mac, IP: f[0], Name: names[mac]})
	}
	return out
}

// nmAP uses NetworkManager (nmcli) on Linux.
type nmAP struct {
	dev string
}

const nmConn = "TikLab-Hotspot"

func nmcli(args ...string) (string, error) {
	out, err := exec.Command("nmcli", args...).CombinedOutput()
	s := strings.TrimSpace(string(out))
	if err != nil {
		if s == "" {
			s = err.Error()
		}
		return s, fmt.Errorf("%s", s)
	}
	return s, nil
}

func (n *nmAP) probe() HostWifiCaps {
	c := HostWifiCaps{OS: "linux", Method: "NetworkManager"}
	if _, err := exec.LookPath("nmcli"); err != nil {
		c.Reason = "NetworkManager (nmcli) is not installed. Install it, or start a hotspot yourself and set the SSID to the simulated one."
		return c
	}
	out, err := nmcli("-t", "-f", "DEVICE,TYPE,STATE", "device", "status")
	if err != nil {
		c.Reason = "nmcli failed: " + err.Error()
		return c
	}
	for _, l := range strings.Split(out, "\n") {
		f := strings.Split(l, ":")
		if len(f) >= 2 && f[1] == "wifi" {
			c.Devices = append(c.Devices, f[0])
		}
	}
	if len(c.Devices) == 0 {
		c.Reason = "This PC has no Wi-Fi adapter that NetworkManager manages."
		return c
	}
	for _, d := range c.Devices {
		if ap, _ := nmcli("-t", "-f", "WIFI-PROPERTIES.AP", "device", "show", d); strings.Contains(ap, ":yes") {
			n.dev = d
			break
		}
	}
	if n.dev == "" {
		c.Reason = "The Wi-Fi adapter (" + strings.Join(c.Devices, ", ") + ") cannot act as an access point."
		return c
	}
	c.Supported = true
	c.Captive, c.CaptiveWhy = linuxCaptive()
	return c
}

func (n *nmAP) start(c apConfig) (string, error) {
	if n.dev == "" {
		n.probe()
		if n.dev == "" {
			return "", fmt.Errorf("no Wi-Fi adapter that can be an access point")
		}
	}
	nmcli("connection", "delete", nmConn)
	band := "bg"
	if c.Band == "5" {
		band = "a"
	}
	args := []string{"connection", "add", "type", "wifi", "ifname", n.dev, "con-name", nmConn, "autoconnect", "no", "ssid", c.SSID,
		"802-11-wireless.mode", "ap", "802-11-wireless.band", band, "ipv4.method", "shared", "ipv6.method", "ignore"}
	if c.Pass != "" {
		args = append(args, "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", c.Pass)
	}
	if _, err := nmcli(args...); err != nil {
		return "", err
	}
	if _, err := nmcli("connection", "up", nmConn); err != nil {
		if band == "a" {
			nmcli("connection", "modify", nmConn, "802-11-wireless.band", "bg")
			if _, err2 := nmcli("connection", "up", nmConn); err2 == nil {
				return n.addr(), nil
			}
		}
		return "", err
	}
	time.Sleep(time.Second)
	return n.addr(), nil
}

func (n *nmAP) addr() string {
	if ifc, err := net.InterfaceByName(n.dev); err == nil {
		addrs, _ := ifc.Addrs()
		for _, a := range addrs {
			if ip, ok := a.(*net.IPNet); ok && ip.IP.To4() != nil {
				return ip.IP.String()
			}
		}
	}
	return "10.42.0.1"
}

func (n *nmAP) stop() error {
	nmcli("connection", "down", nmConn)
	_, err := nmcli("connection", "delete", nmConn)
	if err != nil && strings.Contains(err.Error(), "unknown connection") {
		return nil
	}
	return nil
}

func (n *nmAP) clients() ([]HostClient, error) {
	return linuxNeighbours(n.dev, "/var/lib/NetworkManager/dnsmasq-"+n.dev+".leases"), nil
}

func (n *nmAP) device() string      { return n.dev }
func (n *nmAP) restoreHint() string { return "" }

// ---------- Windows: Mobile Hotspot through WinRT, driven by PowerShell ----------

type winAP struct {
	dir       string
	saved     bool
	names     map[string]string
	namesAt   time.Time
	connected map[string]bool
}

const psPrelude = `$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
try { [Console]::OutputEncoding=[Text.Encoding]::UTF8 } catch {}
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$ms=[System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1}
$opM=$ms|Where-Object{$_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation` + "`" + `1'}|Select-Object -First 1
$actM=$ms|Where-Object{$_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'}|Select-Object -First 1
function AwaitOp($o,[Type]$t){$k=$opM.MakeGenericMethod($t).Invoke($null,@($o));$null=$k.Wait(25000);$k.Result}
function AwaitAct($a){$k=$actM.Invoke($null,@($a));$null=$k.Wait(25000)}
$NI=[Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]
$TMT=[Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
$RT=[Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
$o=[ordered]@{}
$p=$NI::GetInternetConnectionProfile()
if($p -eq $null){$p=$NI::GetConnectionProfiles()|Where-Object{$_.NetworkAdapter -ne $null -and $_.GetNetworkConnectivityLevel() -ne 'None'}|Select-Object -First 1}
if($p -eq $null){$o.ok=$false;$o.error='no-connection';$o|ConvertTo-Json -Compress;exit}
$o.capability=[string]$TMT::GetTetheringCapabilityFromConnectionProfile($p)
$tm=$TMT::CreateFromConnectionProfile($p)
$cfg=$tm.GetCurrentAccessPointConfiguration()
$o.ssid=$cfg.Ssid
$o.state=[string]$tm.TetheringOperationalState
$o.ok=$true
`

func powershell(script string) (map[string]any, error) {
	ps := "powershell.exe"
	if p, err := exec.LookPath("powershell.exe"); err == nil {
		ps = p
	}
	cmd := exec.Command(ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "-")
	cmd.Stdin = strings.NewReader(script)
	hideWindow(cmd)
	out, err := cmd.CombinedOutput()
	s := strings.TrimSpace(string(out))
	var res map[string]any
	if i := strings.LastIndex(s, "\n{"); i >= 0 {
		s = s[i+1:]
	}
	if jerr := json.Unmarshal([]byte(s), &res); jerr != nil {
		if err == nil {
			err = fmt.Errorf("unexpected answer from PowerShell: %s", trimTo(s, 200))
		}
		return nil, fmt.Errorf("PowerShell failed: %v %s", err, trimTo(s, 300))
	}
	return res, nil
}

// psQuote passes text to PowerShell as base64 UTF-8, so names in any language
// survive the console code page.
func psQuote(s string) string {
	return "([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + base64.StdEncoding.EncodeToString([]byte(s)) + "')))"
}

func (w *winAP) probe() HostWifiCaps {
	c := HostWifiCaps{OS: "windows", Method: "Windows Mobile Hotspot", CaptiveWhy: "On Windows, phones get the login page but can browse before logging in: Windows does not let other programs filter its hotspot traffic."}
	res, err := powershell(psPrelude + "$o|ConvertTo-Json -Compress")
	if err != nil {
		c.Reason = err.Error()
		return c
	}
	if ok, _ := res["ok"].(bool); !ok {
		c.Reason = "Windows needs a network connection to share before it can start Mobile Hotspot (Settings > Network & internet > Mobile hotspot). Connect this PC to Wi-Fi or Ethernet first."
		return c
	}
	capab, _ := res["capability"].(string)
	switch capab {
	case "Enabled":
		c.Supported = true
	case "DisabledByGroupPolicy":
		c.Reason = "Mobile Hotspot is turned off by your organisation's policy on this PC."
	case "DisabledByHardwareLimitation":
		c.Reason = "This PC's Wi-Fi adapter cannot run Mobile Hotspot."
	default:
		c.Reason = "Windows reports Mobile Hotspot as " + capab + "."
	}
	return c
}

func (w *winAP) savedFile() string { return w.dir + string(os.PathSeparator) + "pc-hotspot-before.txt" }

func (w *winAP) start(c apConfig) (string, error) {
	band := ""
	if c.Band == "5" {
		band = "FiveGigahertz"
	} else if c.Band == "2.4" {
		band = "TwoPointFourGigahertz"
	}
	script := psPrelude + `
$o.prevSsid=$cfg.Ssid
$o.prevPass=$cfg.Passphrase
$cfg.Ssid=` + psQuote(c.SSID) + `
$cfg.Passphrase=` + psQuote(c.Pass) + `
try { if(` + psQuote(band) + ` -ne ''){ $cfg.Band=` + psQuote(band) + ` } } catch {}
AwaitAct ($tm.ConfigureAccessPointAsync($cfg))
if([string]$tm.TetheringOperationalState -eq 'On'){ AwaitOp ($tm.StopTetheringAsync()) $RT | Out-Null; Start-Sleep -Milliseconds 800 }
$r=AwaitOp ($tm.StartTetheringAsync()) $RT
$o.result=[string]$r.Status
$o.message=[string]$r.AdditionalErrorMessage
$o.state=[string]$tm.TetheringOperationalState
$o|ConvertTo-Json -Compress`
	res, err := powershell(script)
	if err != nil {
		return "", err
	}
	if ok, _ := res["ok"].(bool); !ok {
		return "", fmt.Errorf("Windows needs a network connection to share before Mobile Hotspot can start")
	}
	if !w.saved {
		if _, err := os.Stat(w.savedFile()); err != nil {
			prev := fmt.Sprintf("%v\n%v\n", res["prevSsid"], res["prevPass"])
			os.WriteFile(w.savedFile(), []byte(prev), 0600)
		}
		w.saved = true
	}
	result, _ := res["result"].(string)
	if result != "Success" {
		msg := map[string]string{
			"WiFiDeviceOff":              "Wi-Fi is switched off on this PC. Turn it on and try again.",
			"OperationInProgress":        "Windows is still switching Mobile Hotspot; it is retried in a moment.",
			"NetworkLimitedConnectivity": "the connection Windows would share has no internet; Windows refuses to start Mobile Hotspot.",
		}[result]
		if msg == "" {
			msg = "Windows answered " + result
			if m, _ := res["message"].(string); m != "" {
				msg += ": " + m
			}
		}
		return "", fmt.Errorf("%s", msg)
	}
	for i := 0; i < 20; i++ {
		if ip := windowsHotspotIP(); ip != "" {
			return ip, nil
		}
		time.Sleep(500 * time.Millisecond)
	}
	return "192.168.137.1", nil
}

func (w *winAP) stop() error {
	script := psPrelude + `
if([string]$tm.TetheringOperationalState -ne 'Off'){ $r=AwaitOp ($tm.StopTetheringAsync()) $RT; $o.result=[string]$r.Status }
`
	if b, err := os.ReadFile(w.savedFile()); err == nil {
		l := strings.SplitN(string(b), "\n", 3)
		if len(l) >= 2 && l[0] != "" && l[0] != "<nil>" {
			script += `$cfg.Ssid=` + psQuote(l[0]) + "\n"
			if len(l[1]) >= 8 {
				script += `$cfg.Passphrase=` + psQuote(l[1]) + "\n"
			}
			script += "try { AwaitAct ($tm.ConfigureAccessPointAsync($cfg)) } catch {}\n"
		}
	}
	script += "$o|ConvertTo-Json -Compress"
	_, err := powershell(script)
	if err == nil {
		os.Remove(w.savedFile())
		w.saved = false
	}
	return err
}

func (w *winAP) clients() ([]HostClient, error) {
	arp := windowsARP()
	fresh := false
	for mac := range arp {
		if _, ok := w.names[mac]; !ok {
			fresh = true
		}
	}
	if fresh || time.Since(w.namesAt) > 60*time.Second {
		w.namesAt = time.Now()
		if w.names == nil {
			w.names = map[string]string{}
		}
		for mac := range arp {
			if _, ok := w.names[mac]; !ok {
				w.names[mac] = ""
			}
		}
		res, err := powershell(psPrelude + `
$l=@()
try { foreach($c in $tm.GetTetheringClients()){ $n=''; try { $n=($c.HostNames|Select-Object -First 1).DisplayName } catch {}; $l+=[ordered]@{mac=$c.MacAddress;name=$n} } } catch {}
$o.clients=$l
$o|ConvertTo-Json -Compress -Depth 4`)
		if err == nil {
			var list []any
			switch x := res["clients"].(type) {
			case []any:
				list = x
			case map[string]any:
				list = []any{x}
			}
			for _, e := range list {
				m, _ := e.(map[string]any)
				mac := strings.ToUpper(strings.ReplaceAll(fmt.Sprint(m["mac"]), "-", ":"))
				name, _ := m["name"].(string)
				w.names[mac] = strings.TrimSuffix(strings.TrimSuffix(name, ".mshome.net"), ".")
				w.connected[mac] = true
			}
		}
	}
	var out []HostClient
	for mac, ip := range arp {
		out = append(out, HostClient{MAC: mac, IP: ip, Name: w.names[mac]})
	}
	return out, nil
}

func (w *winAP) device() string { return "" }
func (w *winAP) restoreHint() string {
	return "When you switch it off, Windows Mobile Hotspot gets back the name and password it had before."
}

var reWinARP = regexp.MustCompile(`(?m)^\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})\s+dynamic`)

func windowsARP() map[string]string {
	out := map[string]string{}
	cmd := exec.Command("arp", "-a")
	hideWindow(cmd)
	b, err := cmd.Output()
	if err != nil {
		return out
	}
	for _, m := range reWinARP.FindAllStringSubmatch(string(b), -1) {
		if strings.HasPrefix(m[1], "192.168.137.") {
			out[strings.ToUpper(strings.ReplaceAll(m[2], "-", ":"))] = m[1]
		}
	}
	return out
}

// windowsHotspotIP finds this PC's address on the Mobile Hotspot network.
func windowsHotspotIP() string {
	ifs, _ := net.Interfaces()
	for _, ifc := range ifs {
		addrs, _ := ifc.Addrs()
		for _, a := range addrs {
			if n, ok := a.(*net.IPNet); ok && n.IP.To4() != nil && strings.HasPrefix(n.IP.String(), "192.168.137.") {
				return n.IP.String()
			}
		}
	}
	return ""
}

var _ = bufio.NewReader

// ---------- console API ----------

func (w *Web) pcWifiAPI(rw http.ResponseWriter, req *http.Request) {
	r := w.r
	q := req.URL.Query()
	tok := q.Get("t")
	var body struct {
		T        string
		On       *bool
		Radio    *string
		Captive  *bool
		Password *string
		Refresh  bool
	}
	if req.Method == http.MethodPost {
		json.NewDecoder(req.Body).Decode(&body)
		if body.T != "" {
			tok = body.T
		}
	}
	s := w.session(tok)
	if s == nil || !s.local || r.hw == nil {
		jsonOut(rw, 200, map[string]any{"error": "not available"})
		return
	}
	r.mu.Lock()
	st := r.single("/sim/settings")
	if st != nil && req.Method == http.MethodPost {
		if body.On != nil {
			st["pc-wifi"] = map[bool]string{true: "true", false: "false"}[*body.On]
		}
		if body.Radio != nil {
			st["pc-wifi-interface"] = firstNonEmpty(*body.Radio, "auto")
		}
		if body.Captive != nil {
			st["pc-wifi-captive"] = map[bool]string{true: "true", false: "false"}[*body.Captive]
		}
		if body.Password != nil {
			if p := strings.TrimSpace(*body.Password); len(p) >= 8 && len(p) <= 63 || p == "" {
				st["pc-wifi-password"] = p
			}
		}
		r.markDirty()
	}
	var radios []map[string]any
	for _, it := range r.list(MenuMap["/interface/wireless"]) {
		open := true
		if sp := r.byName("/interface/wireless/security-profiles", it["security-profile"]); sp != nil && sp["mode"] == "dynamic-keys" && sp["wpa2-pre-shared-key"] != "" {
			open = false
		}
		radios = append(radios, map[string]any{"name": it["name"], "ssid": it["ssid"], "band": it["band"], "open": open, "disabled": it.B("disabled")})
	}
	for _, it := range r.list(MenuMap["/interface/wifi"]) {
		radios = append(radios, map[string]any{"name": it["name"], "ssid": it["configuration.ssid"], "band": it["channel.band"], "open": it["security.passphrase"] == "", "disabled": it.B("disabled")})
	}
	want := map[string]any{}
	if st != nil {
		want = map[string]any{"on": st.B("pc-wifi"), "radio": st["pc-wifi-interface"], "captive": st.B("pc-wifi-captive"), "password": st["pc-wifi-password"]}
	}
	r.mu.Unlock()
	if body.Refresh {
		r.hw.Caps(true)
	}
	if req.Method == http.MethodPost {
		go r.hw.step()
		time.Sleep(300 * time.Millisecond)
	}
	out := r.hw.Snapshot()
	out["want"] = want
	out["radios"] = radios
	if ip, _ := out["pcIp"].(string); ip != "" {
		u := "http://" + ip
		if p := r.portalPort(); p != 80 {
			u += ":" + strconv.Itoa(p)
		}
		out["portal"] = u + "/login"
	}
	if ssid, _ := out["ssid"].(string); ssid != "" {
		pass, _ := out["pass"].(string)
		out["wifiQR"] = wifiQR(ssid, pass)
	}
	if exe, err := os.Executable(); err == nil && runtime.GOOS == "windows" {
		out["firewallCmd"] = `netsh advfirewall firewall add rule name="TikLab" dir=in action=allow program="` + exe + `" enable=yes profile=any`
	}
	jsonOut(rw, 200, out)
}
