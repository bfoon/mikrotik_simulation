package main

// The network lab: several simulated routers, switches, an internet uplink
// and end devices (PCs, phones, ...) on one canvas, wired with cables.
//
// Every router in the lab is a complete simulated router with its own
// configuration, services and ports on this PC. Cables are not decoration:
// a router port is up only when its cable leads to something alive, routers
// get DHCP addresses from the router they are plugged into, PCs and phones
// become clients of the router serving their network (lease, hotspot login,
// traffic), routers see each other in /ip neighbor, and internet access
// follows the path: a router behind a hotspot it has not logged in to, or
// behind an unplugged uplink, is offline (and so is its TapTap Link).

import (
	"crypto/rand"
	"encoding/json"
	"fmt"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type LabDevice struct {
	ID      string  `json:"id"`
	Kind    string  `json:"kind"` // router | switch | internet | pc | laptop | phone | tablet | tv | printer | camera | iot | server
	Name    string  `json:"name"`
	X       float64 `json:"x"`
	Y       float64 `json:"y"`
	Model   string  `json:"model,omitempty"`
	Index   int     `json:"index,omitempty"` // routers: which block of ports on this PC
	Ports   int     `json:"ports,omitempty"` // switches
	MAC     string  `json:"mac,omitempty"`   // end devices
	Primary bool    `json:"primary,omitempty"`
	Off     bool    `json:"off,omitempty"` // end devices switched off

	r    *Router
	web  *Web
	mndp *MNDP
}

type LabEnd struct {
	Dev  string `json:"dev"`
	Port string `json:"port"`
}

type LabLink struct {
	ID    string `json:"id"`
	A     LabEnd `json:"a"`
	B     LabEnd `json:"b"`
	Kind  string `json:"kind"` // cable | wifi
	Color string `json:"color,omitempty"`
}

type Lab struct {
	mu      sync.Mutex
	path    string
	dir     string
	opts    *Options
	Devices []*LabDevice `json:"devices"`
	Links   []*LabLink   `json:"links"`
	Seq     int          `json:"seq"`
	primary *Router
	view    map[string]any // last computed state for the console
	vmu     sync.Mutex
	tmu     sync.Mutex // one tick at a time
	dirty   bool
}

// labView is what the lab tells one router about its cables.
type labView struct {
	dhcp   map[string]labLease // dhcp-client interface -> lease
	online bool
	via    string // how it reaches the internet, for display
}

type labLease struct {
	Mode string // isp | router | none
	Addr string
	GW   string
	DNS  string
	From string
}

func newLab(primary *Router, o *Options) *Lab {
	l := &Lab{primary: primary, opts: o, dir: primary.dataDir, path: filepath.Join(primary.dataDir, "lab.json")}
	return l
}

func (l *Lab) dev(id string) *LabDevice {
	for _, d := range l.Devices {
		if d.ID == id {
			return d
		}
	}
	return nil
}

func (l *Lab) nextID(prefix string) string {
	for {
		l.Seq++
		id := fmt.Sprintf("%s%d", prefix, l.Seq)
		if l.dev(id) == nil {
			return id
		}
	}
}

func (l *Lab) start() {
	b, err := os.ReadFile(l.path)
	if err == nil {
		json.Unmarshal(b, l)
	}
	var prim *LabDevice
	for _, d := range l.Devices {
		if d.Primary {
			prim = d
		}
	}
	r := l.primary
	if prim == nil {
		r.mu.Lock()
		name := r.S("/system/identity", "name")
		cable := r.sim.cablePlugged("ether1")
		r.mu.Unlock()
		prim = &LabDevice{ID: "r1", Kind: "router", Name: name, X: 520, Y: 300, Primary: true}
		l.Devices = append([]*LabDevice{prim}, l.Devices...)
		if l.dev("inet") == nil {
			l.Devices = append(l.Devices, &LabDevice{ID: "inet", Kind: "internet", Name: "Internet", X: 520, Y: 90})
			if cable {
				l.Links = append(l.Links, &LabLink{ID: "l-wan", A: LabEnd{"r1", "ether1"}, B: LabEnd{"inet", "net"}, Kind: "cable", Color: "blue"})
			}
		}
		l.dirty = true
	}
	prim.r = r
	prim.Model = r.Model.Key
	prim.web = r.svc.web
	for _, d := range l.Devices {
		if d.Kind == "router" && !d.Primary {
			if err := l.bootRouter(d, false); err != nil {
				fmt.Println("  ! lab router", d.Name, "could not start:", err)
			}
		}
	}
	if n := len(l.routers()); n > 1 {
		fmt.Printf("  - network lab: %d routers, %d devices, %d cables (Network Lab in the console)\n", n, len(l.Devices), len(l.Links))
	}
	l.save()
	go l.loop()
}

func (l *Lab) routers() []*LabDevice {
	var out []*LabDevice
	for _, d := range l.Devices {
		if d.Kind == "router" && d.r != nil {
			out = append(out, d)
		}
	}
	return out
}

func (l *Lab) save() {
	l.mu.Lock()
	b, _ := json.MarshalIndent(l, "", " ")
	l.dirty = false
	l.mu.Unlock()
	tmp := l.path + ".tmp"
	if os.WriteFile(tmp, b, 0644) == nil {
		os.Rename(tmp, l.path)
	}
}

func (l *Lab) saveAll() {
	l.save()
	l.mu.Lock()
	rs := l.routers()
	l.mu.Unlock()
	for _, d := range rs {
		d.r.mu.Lock()
		d.r.dirty = true
		d.r.mu.Unlock()
		d.r.save()
	}
}

// labMACs holds the interface MACs of every lab router in this process, so
// real MNDP packets between them are ignored (cables decide who sees whom).
var labMACs sync.Map

// ---------- routers in the lab ----------

func (l *Lab) usedIndex(i int) bool {
	for _, d := range l.Devices {
		if d.Kind == "router" && (d.Index == i || d.Primary && i == l.opts.Instance) {
			return true
		}
	}
	return false
}

// bootRouter starts a lab router: its own data folder, configuration and
// services, on its own block of ports.
func (l *Lab) bootRouter(d *LabDevice, fresh bool) error {
	md := lookupModel(d.Model)
	if md == nil {
		md = lookupModel("hap-ac2")
	}
	dir := filepath.Join(l.dir, "lab", d.ID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	o := *l.opts
	o.Data = dir
	o.Instance = d.Index
	o.Identity = d.Name
	o.Password = ""
	r := &Router{T: map[string]*Table{}, Opt: &o, Ver: o.Version, state: "booting", watchers: map[int]*watcher{}, kickers: map[int]func(){}, dataDir: dir}
	mdc := *md
	r.Model = &mdc
	r.sim = newSim(r)
	loaded := !fresh && r.load()
	if loaded {
		if b, err := os.ReadFile(filepath.Join(dir, "config.json")); err == nil {
			var s struct{ Model string }
			json.Unmarshal(b, &s)
			if m := lookupModel(s.Model); m != nil {
				mc := *m
				r.Model = &mc
			}
		}
	}
	if r.baseMAC == nil || !loaded {
		mac := make(net.HardwareAddr, 6)
		rand.Read(mac)
		mac[0], mac[1], mac[2] = 0x48, 0xA9, 0x8A
		mac[5] &= 0xC0
		r.baseMAC = mac
	}
	r.Model.Serial = fmt.Sprintf("HD%X", []byte(r.baseMAC[3:6]))
	if !loaded {
		r.factoryDefaults("")
		if it := r.single("/system/identity"); it != nil {
			it["name"] = d.Name
		}
		// a lab router has no imaginary devices: its cables are the lab's
		if st := r.single("/sim/settings"); st != nil {
			st["lan-devices"] = "0"
			st["auto-pppoe-clients"] = "false"
			st["auto-hotspot-clients"] = "false"
		}
		for _, p := range r.list(MenuMap["/sim/port"]) {
			p["cable"] = "false"
		}
	} else {
		r.syncSimPorts()
	}
	r.single("/sim/settings")
	r.clearDynamic()
	r.boot = time.Now()
	r.state = "running"
	r.log("system,info", "router rebooted")
	d.Model = r.Model.Key

	var mndp *MNDP
	if !o.NoMNDP {
		mndp = startMNDP(r)
	}
	web := newWeb(r, mndp)
	sv := &Services{r: r, web: web, s: map[string]*svcState{}, bind: o.Bind}
	sv.tlsCfg = tlsConfig(dir, "tiklab.local")
	sv.keys = sshHostKeys(dir)
	r.svc = sv
	r.onSvc = sv.apply
	off := d.Index * 10
	defaults := map[string]int{"api": 8728 + off, "api-ssl": 8729 + off, "www": 8080 + off, "www-ssl": 8443 + off, "winbox": 8291 + off, "ssh": 2222 + off, "telnet": 2323 + off, "ftp": 2121 + off}
	for name, def := range defaults {
		if it := r.byName("/ip/service", name); it != nil {
			it["port"] = strconv.Itoa(def)
		}
	}
	for _, name := range []string{"winbox", "www", "www-ssl", "api", "api-ssl", "ssh", "telnet", "ftp"} {
		it := r.byName("/ip/service", name)
		if it == nil {
			continue
		}
		want, _ := strconv.Atoi(it["port"])
		if !it.B("disabled") {
			sv.start(name, want)
		} else {
			sv.s[name] = &svcState{name: name, status: "disabled"}
		}
	}
	r.syncServices()
	r.markDirty()
	r.hw = newHostWifi(r)
	go r.hw.loop()
	r.startLoops()
	d.r, d.web, d.mndp = r, web, mndp
	return nil
}

func (l *Lab) stopRouter(d *LabDevice) {
	r := d.r
	if r == nil {
		return
	}
	r.mu.Lock()
	r.state = "off"
	r.cancelJobs()
	st := r.single("/sim/settings")
	st["pc-wifi"] = "false"
	r.mu.Unlock()
	if r.hw != nil {
		r.hw.gone.Store(true)
	}
	if r.quit != nil {
		close(r.quit)
	}
	if d.mndp != nil {
		d.mndp.stop()
	}
	for _, name := range []string{"winbox", "www", "www-ssl", "api", "api-ssl", "ssh", "telnet", "ftp"} {
		r.svc.stop(name)
	}
	d.r = nil
}

// ownLAN moves a new router's networks off the factory 192.168.88.0/24 and
// 10.5.50.0/24, so routers plugged into each other do not clash.
func ownLAN(r *Router, n int) {
	lan := fmt.Sprintf("192.168.%d", 88+n)
	hs := fmt.Sprintf("10.5.%d", 50+n)
	src := fmt.Sprintf(`/ip address set [find address="192.168.88.1/24"] address=%[1]s.1/24
/ip address set [find address="10.5.50.1/24"] address=%[2]s.1/24
/ip pool set [find name="dhcp_pool0"] ranges=%[1]s.10-%[1]s.254
/ip pool set [find name="hs-pool-1"] ranges=%[2]s.2-%[2]s.254
/ip dhcp-server network set [find address="192.168.88.0/24"] address=%[1]s.0/24 gateway=%[1]s.1 dns-server=%[1]s.1
/ip dhcp-server network set [find address="10.5.50.0/24"] address=%[2]s.0/24 gateway=%[2]s.1 dns-server=%[2]s.1
/ip dns static set [find name="router.lan"] address=%[1]s.1
/ip firewall nat set [find src-address="10.5.50.0/24"] src-address=%[2]s.0/24
/ip hotspot profile set [find name="hsprof1"] hotspot-address=%[2]s.1
/queue simple set [find name="LAN-total"] target=%[1]s.0/24
`, lan, hs)
	r.runJob(src, "admin", "", nil, 0)
}

// ---------- ports ----------

type labPort struct {
	ID    string `json:"id"`   // stable: default-name for routers
	Name  string `json:"name"` // what the router calls it now
	Kind  string `json:"kind"` // ether | sfp | wlan | net | nic | wifi
	Speed string `json:"speed,omitempty"`
}

func (l *Lab) portsOf(d *LabDevice) []labPort {
	switch d.Kind {
	case "router":
		if d.r == nil {
			return nil
		}
		r := d.r
		r.mu.Lock()
		defer r.mu.Unlock()
		var out []labPort
		for _, it := range r.list(MenuMap["/interface/ethernet"]) {
			k := "ether"
			if strings.HasPrefix(it["default-name"], "sfp") || strings.HasPrefix(it["default-name"], "qsfp") {
				k = "sfp"
			}
			sp := ""
			if p := r.sim.portOf(it["name"]); p != nil {
				sp = p["speed"]
			}
			out = append(out, labPort{ID: firstNonEmpty(it["default-name"], it["name"]), Name: it["name"], Kind: k, Speed: sp})
		}
		for _, p := range []string{"/interface/wireless", "/interface/wifi"} {
			for _, it := range r.list(MenuMap[p]) {
				out = append(out, labPort{ID: firstNonEmpty(it["default-name"], it["name"]), Name: it["name"], Kind: "wlan"})
			}
		}
		return out
	case "switch":
		n := d.Ports
		if n == 0 {
			n = 8
		}
		var out []labPort
		for i := 1; i <= n; i++ {
			out = append(out, labPort{ID: fmt.Sprintf("p%d", i), Name: fmt.Sprintf("port %d", i), Kind: "ether"})
		}
		return out
	case "internet":
		return []labPort{{ID: "net", Name: "internet", Kind: "net"}}
	}
	ports := []labPort{{ID: "eth", Name: "Ethernet", Kind: "nic"}}
	if d.Kind == "phone" || d.Kind == "tablet" || d.Kind == "laptop" || d.Kind == "tv" || d.Kind == "iot" || d.Kind == "camera" {
		ports = append(ports, labPort{ID: "wifi", Name: "Wi-Fi", Kind: "wifi"})
	}
	if d.Kind == "phone" || d.Kind == "tablet" {
		ports = ports[1:]
	}
	return ports
}

// ---------- the simulation ----------

func (l *Lab) loop() {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	n := 0
	for range t.C {
		func() {
			defer func() {
				if p := recover(); p != nil {
					fmt.Println("  ! lab error:", p)
				}
			}()
			l.tick()
		}()
		n++
		l.mu.Lock()
		dirty := l.dirty
		l.mu.Unlock()
		if dirty || n%30 == 0 {
			l.save()
		}
	}
}

type rPort struct {
	id, name, mac, l3 string
	running, disabled bool
	cable, labCable   bool
	rx, tx            float64
	radio             bool
}

type rSnap struct {
	d         *LabDevice
	r         *Router
	running   bool
	identity  string
	version   string
	board     string
	uptime    string
	ports     map[string]*rPort // by stable id
	byName    map[string]*rPort
	ifMAC     map[string]string
	addrs     map[string][]string // l3 interface -> addresses
	dhcpSrv   map[string]string   // interface -> server name
	dhcpNet   []Item
	clients   []Item // dhcp clients
	routes    []Item
	hotspot   map[string]bool // hotspot interfaces
	authMACs  map[string]bool
	labCl     map[string]Item // existing lab sim clients by key
	clRate    map[string][2]float64
	state     string
	svcPorts  map[string]int
	wanOnline bool
	pppoeSrv  map[string]bool
	l3of      map[string]string // interface -> l3 interface
}

func (l *Lab) snapshot(d *LabDevice) *rSnap {
	r := d.r
	r.mu.Lock()
	defer r.mu.Unlock()
	s := &rSnap{d: d, r: r, running: r.state == "running", ports: map[string]*rPort{}, byName: map[string]*rPort{}, ifMAC: map[string]string{}, addrs: map[string][]string{},
		dhcpSrv: map[string]string{}, hotspot: map[string]bool{}, authMACs: map[string]bool{}, labCl: map[string]Item{}, pppoeSrv: map[string]bool{}, l3of: map[string]string{}}
	s.identity = r.S("/system/identity", "name")
	s.state = r.state
	s.clRate = map[string][2]float64{}
	if r.svc != nil {
		s.svcPorts = map[string]int{}
		for _, n := range []string{"api", "api-ssl", "winbox", "www", "ssh", "telnet"} {
			s.svcPorts[n] = r.svc.port(n)
		}
	}
	s.version = r.Ver
	s.board = r.Model.Board
	s.uptime = fmtDur(time.Since(r.boot).Truncate(time.Second))
	st := r.single("/sim/settings")
	s.wanOnline = st == nil || st.B("wan-online")
	bridgeOf := map[string]string{}
	bridgeOn := map[string]bool{}
	for _, it := range r.list(MenuMap["/interface"]) {
		s.ifMAC[it["name"]] = it["mac-address"]
		if it["type"] == "bridge" {
			bridgeOn[it["name"]] = !it.B("disabled")
		}
	}
	for _, p := range r.list(MenuMap["/interface/bridge/port"]) {
		if !p.B("disabled") && bridgeOn[p["bridge"]] {
			bridgeOf[p["interface"]] = p["bridge"]
		}
	}
	l3 := func(n string) string {
		if b := bridgeOf[n]; b != "" {
			return b
		}
		return n
	}
	for _, it := range r.list(MenuMap["/interface"]) {
		s.l3of[it["name"]] = l3(it["name"])
	}
	for _, it := range r.list(MenuMap["/interface"]) {
		t := it["type"]
		if t != "ether" && t != "wlan" && t != "wifi" {
			continue
		}
		id := firstNonEmpty(it["default-name"], it["name"])
		p := &rPort{id: id, name: it["name"], mac: it["mac-address"], l3: l3(it["name"]), running: it.B("running"), disabled: it.B("disabled"), radio: t != "ether"}
		if sp := r.sim.portOf(it["name"]); sp != nil {
			p.cable = sp.B("cable")
			p.labCable = sp["_labcable"] == "1"
		} else {
			p.cable = true
		}
		if rt := r.sim.rates[it["name"]]; rt != nil {
			p.rx, p.tx = rt.RxBps, rt.TxBps
		}
		s.ports[id] = p
		s.byName[it["name"]] = p
	}
	for _, a := range r.list(MenuMap["/ip/address"]) {
		if !a.B("disabled") && !a.B("invalid") {
			s.addrs[a["interface"]] = append(s.addrs[a["interface"]], a["address"])
		}
	}
	for _, ds := range r.list(MenuMap["/ip/dhcp-server"]) {
		if !ds.B("disabled") {
			s.dhcpSrv[ds["interface"]] = ds["name"]
		}
	}
	s.dhcpNet = append(s.dhcpNet, r.list(MenuMap["/ip/dhcp-server/network"])...)
	for _, dc := range r.list(MenuMap["/ip/dhcp-client"]) {
		if !dc.B("disabled") {
			s.clients = append(s.clients, Item{"interface": dc["interface"]})
		}
	}
	for _, rt := range r.list(MenuMap["/ip/route"]) {
		if rt["dst-address"] == "0.0.0.0/0" && !rt.B("disabled") {
			s.routes = append(s.routes, Item{"gateway": rt["gateway"], "active": rt["active"]})
		}
	}
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if !h.B("disabled") {
			s.hotspot[h["interface"]] = true
		}
	}
	for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
		s.authMACs[strings.ToUpper(a["mac-address"])] = true
	}
	for _, b := range r.list(MenuMap["/ip/hotspot/ip-binding"]) {
		if b["type"] == "bypassed" && !b.B("disabled") {
			s.authMACs[strings.ToUpper(b["mac-address"])] = true
		}
	}
	for _, c := range r.list(MenuMap["/sim/client"]) {
		if k := c["_lab"]; k != "" {
			cp := Item{}
			for k2, v := range c {
				cp[k2] = v
			}
			s.labCl[k] = cp
			if rt := r.sim.rt[c[".id"]]; rt != nil {
				s.clRate[k] = [2]float64{rt.down, rt.up}
			}
		}
	}
	for _, ps := range r.list(MenuMap["/interface/pppoe-server/server"]) {
		if !ps.B("disabled") {
			s.pppoeSrv[ps["interface"]] = true
		}
	}
	return s
}

// union-find
type uf map[string]string

func (u uf) find(x string) string {
	if _, ok := u[x]; !ok {
		u[x] = x
	}
	for u[x] != x {
		u[x] = u[u[x]]
		x = u[x]
	}
	return x
}
func (u uf) union(a, b string) { u[u.find(a)] = u.find(b) }

type wantClient struct {
	key, name, kind, mac, iface, port string
}

type labDevState struct {
	Status string  `json:"status"`
	Addr   string  `json:"addr,omitempty"`
	Via    string  `json:"via,omitempty"`
	User   string  `json:"user,omitempty"`
	Online bool    `json:"online"`
	Down   float64 `json:"down"`
	Up     float64 `json:"up"`
}

func ipInPrefix(ip, prefix string) bool {
	_, n, err := net.ParseCIDR(prefix)
	a := net.ParseIP(ip)
	return err == nil && a != nil && n.Contains(a)
}

func addrOnly(cidr string) string { return strings.SplitN(cidr, "/", 2)[0] }

func (l *Lab) tick() {
	l.tmu.Lock()
	defer l.tmu.Unlock()
	l.mu.Lock()
	devs := append([]*LabDevice{}, l.Devices...)
	links := append([]*LabLink{}, l.Links...)
	l.mu.Unlock()
	byID := map[string]*LabDevice{}
	snaps := map[string]*rSnap{}
	for _, d := range devs {
		byID[d.ID] = d
		if d.Kind == "router" && d.r != nil {
			snaps[d.ID] = l.snapshot(d)
		}
	}
	alive := func(dev string) bool {
		d := byID[dev]
		if d == nil {
			return false
		}
		if d.Kind == "router" {
			s := snaps[dev]
			return s != nil && s.running
		}
		return !d.Off
	}
	portOK := func(e LabEnd) bool {
		if s := snaps[e.Dev]; s != nil {
			p := s.ports[e.Port]
			return p != nil && !p.disabled
		}
		return true
	}
	// 1. which router ports have cables, and are they live
	wantCable := map[string]map[string]bool{} // dev -> port id -> peer alive
	linkUp := map[string]bool{}
	for _, lk := range links {
		up := alive(lk.A.Dev) && alive(lk.B.Dev) && portOK(lk.A) && portOK(lk.B)
		linkUp[lk.ID] = up
		for _, pair := range [][2]LabEnd{{lk.A, lk.B}, {lk.B, lk.A}} {
			me, peer := pair[0], pair[1]
			if snaps[me.Dev] == nil || lk.Kind == "wifi" {
				continue
			}
			if wantCable[me.Dev] == nil {
				wantCable[me.Dev] = map[string]bool{}
			}
			wantCable[me.Dev][me.Port] = alive(peer.Dev) && portOK(peer)
		}
	}
	// 2. broadcast domains
	node := func(e LabEnd) string {
		d := byID[e.Dev]
		if d == nil {
			return ""
		}
		switch d.Kind {
		case "router":
			s := snaps[e.Dev]
			if s == nil || s.ports[e.Port] == nil {
				return ""
			}
			return "R/" + e.Dev + "/" + s.ports[e.Port].l3
		case "switch":
			return "S/" + e.Dev
		case "internet":
			return "I/" + e.Dev
		}
		return "E/" + e.Dev
	}
	u := uf{}
	for _, lk := range links {
		if !linkUp[lk.ID] {
			continue
		}
		a, b := node(lk.A), node(lk.B)
		if a != "" && b != "" {
			u.union(a, b)
		}
	}
	members := map[string][]string{}
	for x := range u {
		members[u.find(x)] = append(members[u.find(x)], x)
	}
	for k := range members {
		sort.Strings(members[k])
	}
	domainOf := func(n string) []string {
		if _, ok := u[n]; !ok {
			return nil
		}
		return members[u.find(n)]
	}
	// physical segments: like the domains, but without bridging inside routers,
	// so we know which port of a router a device is really plugged into
	pnode := func(e LabEnd) string {
		if d := byID[e.Dev]; d != nil && d.Kind == "router" {
			return "P/" + e.Dev + "/" + e.Port
		}
		return node(e)
	}
	seg := uf{}
	for _, lk := range links {
		if !linkUp[lk.ID] {
			continue
		}
		a, b := pnode(lk.A), pnode(lk.B)
		if a != "" && b != "" {
			seg.union(a, b)
		}
	}
	// the port of router dev whose segment holds the node "from"
	portInto := func(dev, from string) string {
		s := snaps[dev]
		if s == nil {
			return ""
		}
		if _, ok := seg[from]; !ok {
			return ""
		}
		want := seg.find(from)
		ids := make([]string, 0, len(s.ports))
		for id := range s.ports {
			ids = append(ids, id)
		}
		sort.Strings(ids)
		for _, id := range ids {
			n := "P/" + dev + "/" + id
			if _, ok := seg[n]; ok && seg.find(n) == want {
				return s.ports[id].name
			}
		}
		return ""
	}
	// the physical port a router uses for an l3 interface (its cabled member)
	physOf := func(dev, l3 string) string {
		s := snaps[dev]
		for _, lk := range links {
			for _, e := range []LabEnd{lk.A, lk.B} {
				if e.Dev == dev && s != nil && s.ports[e.Port] != nil && s.ports[e.Port].l3 == l3 && linkUp[lk.ID] {
					return "P/" + dev + "/" + e.Port
				}
			}
		}
		return ""
	}
	labManaged := map[string]map[string]bool{} // dev -> l3 interfaces with lab cables
	for _, lk := range links {
		for _, e := range []LabEnd{lk.A, lk.B} {
			if s := snaps[e.Dev]; s != nil && s.ports[e.Port] != nil {
				if labManaged[e.Dev] == nil {
					labManaged[e.Dev] = map[string]bool{}
				}
				labManaged[e.Dev][s.ports[e.Port].l3] = true
			}
		}
	}
	dhcpRouters := func(dom string, except string) []struct{ dev, iface string } {
		var out []struct{ dev, iface string }
		for _, m := range members[dom] {
			if !strings.HasPrefix(m, "R/") {
				continue
			}
			p := strings.SplitN(m[2:], "/", 2)
			if p[0] == except {
				continue
			}
			if s := snaps[p[0]]; s != nil && s.dhcpSrv[p[1]] != "" {
				out = append(out, struct{ dev, iface string }{p[0], p[1]})
			}
		}
		return out
	}
	hasInternet := func(dom string) string {
		for _, m := range members[dom] {
			if strings.HasPrefix(m, "I/") {
				return m[2:]
			}
		}
		return ""
	}
	want := map[string]map[string]wantClient{} // router dev -> key -> client
	addWant := func(dev string, c wantClient) {
		if want[dev] == nil {
			want[dev] = map[string]wantClient{}
		}
		want[dev][c.key] = c
	}
	views := map[string]*labView{}
	upstreamOf := map[string]map[string][2]string{} // dev -> l3 -> {upstream dev, client key}
	host := hostNet()
	// 3. routers asking for DHCP
	for id, s := range snaps {
		v := &labView{dhcp: map[string]labLease{}}
		views[id] = v
		for _, dc := range s.clients {
			x := dc["interface"]
			l3 := s.l3of[x]
			if l3 == "" {
				l3 = x
			}
			if !labManaged[id][l3] {
				continue // not cabled in the lab: the simulator's own uplink
			}
			dom := ""
			if d := domainOf("R/" + id + "/" + l3); d != nil {
				dom = u.find("R/" + id + "/" + l3)
			}
			lease := labLease{Mode: "none"}
			if dom != "" {
				if inet := hasInternet(dom); inet != "" {
					lease = labLease{Mode: "isp", From: inet}
					lease.Addr = host.String()
					if host.ip != nil && host.net != nil && !s.d.Primary {
						if ip := host.ip.To4(); ip != nil {
							n := int(ip[3]) + s.d.Index
							if n > 253 {
								n = 2 + s.d.Index
							}
							ones, _ := host.net.Mask.Size()
							lease.Addr = fmt.Sprintf("%s/%d", net.IPv4(ip[0], ip[1], ip[2], byte(n)), ones)
						}
					}
					lease.GW = hostGateway(host)
					lease.DNS = lease.GW
				} else if srv := dhcpRouters(dom, id); len(srv) > 0 {
					up := srv[0]
					key := "router:" + id + ":" + l3
					mac := s.ifMAC[x]
					from := physOf(id, l3)
					if p := s.byName[x]; p != nil && p.l3 == l3 {
						from = "P/" + id + "/" + p.id
					}
					addWant(up.dev, wantClient{key: key, name: s.identity, kind: "router", mac: mac, iface: up.iface, port: portInto(up.dev, from)})
					lease = labLease{Mode: "router", From: up.dev}
					if upstreamOf[id] == nil {
						upstreamOf[id] = map[string][2]string{}
					}
					upstreamOf[id][l3] = [2]string{up.dev, key}
					if us := snaps[up.dev]; us != nil {
						if c := us.labCl[key]; c != nil && c["address"] != "" && c["status"] == "connected" {
							for _, n := range us.dhcpNet {
								if ipInPrefix(c["address"], n["address"]) {
									ones := strings.SplitN(n["address"], "/", 2)
									lease.Addr = c["address"] + "/" + ones[len(ones)-1]
									lease.GW = n["gateway"]
									lease.DNS = firstNonEmpty(n["dns-server"], n["gateway"])
								}
							}
						}
					}
				}
			}
			v.dhcp[x] = lease
		}
	}
	// 4. end devices become clients of the router serving their network
	devState := map[string]*labDevState{}
	for _, d := range devs {
		if d.Kind == "router" || d.Kind == "switch" || d.Kind == "internet" {
			continue
		}
		st := &labDevState{Status: "unplugged"}
		devState[d.ID] = st
		if d.Off {
			st.Status = "off"
			continue
		}
		var lk *LabLink
		var mine LabEnd
		for _, x := range links {
			if x.A.Dev == d.ID {
				lk, mine = x, x.A
			} else if x.B.Dev == d.ID {
				lk, mine = x, x.B
			}
		}
		if lk == nil {
			continue
		}
		if !linkUp[lk.ID] {
			st.Status = "no link"
			continue
		}
		_ = mine
		dom := u.find("E/" + d.ID)
		if srv := dhcpRouters(dom, ""); len(srv) > 0 {
			up := srv[0]
			port := portInto(up.dev, "E/"+d.ID)
			key := "dev:" + d.ID
			kind := map[string]string{"pc": "desktop", "server": "desktop", "printer": "iot", "camera": "iot"}[d.Kind]
			if kind == "" {
				kind = d.Kind
			}
			addWant(up.dev, wantClient{key: key, name: d.Name, kind: kind, mac: d.MAC, iface: up.iface, port: port})
			st.Status, st.Via = "getting an address", up.dev
			if us := snaps[up.dev]; us != nil {
				if c := us.labCl[key]; c != nil {
					if c["address"] != "" {
						st.Status, st.Addr = "connected", c["address"]
					}
					st.User = c["hotspot-user"]
					if c["status"] == "blocked" {
						st.Status = "blocked"
					}
				}
			}
		} else if inet := hasInternet(dom); inet != "" {
			st.Status, st.Via, st.Online = "connected", inet, true
			st.Addr = "public address"
		} else {
			st.Status = "no DHCP server on this network"
		}
	}
	// 5. internet reachability, router by router, following gateways
	online := map[string]bool{}
	viaOf := map[string]string{}
	for iter := 0; iter < len(snaps)+2; iter++ {
		changed := false
		for id, s := range snaps {
			on, via := false, ""
			if s.running {
				for _, rt := range s.routes {
					gw := strings.SplitN(rt["gateway"], "%", 2)[0]
					egress := ""
					for ifn, as := range s.addrs {
						for _, a := range as {
							if ipInPrefix(gw, a) {
								egress = ifn
							}
						}
					}
					if egress == "" {
						continue
					}
					l3 := s.l3of[egress]
					if l3 == "" {
						l3 = egress
					}
					if !labManaged[id][l3] {
						// the simulator's own uplink (a cable without a lab device)
						p := s.byName[egress]
						if s.wanOnline && (p == nil || p.cable) {
							on, via = true, "simulated internet"
						}
						continue
					}
					nd := "R/" + id + "/" + l3
					if domainOf(nd) == nil {
						continue
					}
					dom := u.find(nd)
					if hasInternet(dom) != "" {
						if s.wanOnline {
							on, via = true, "internet"
						} else {
							via = "internet switched off in the simulator"
						}
						continue
					}
					for _, m := range members[dom] {
						if !strings.HasPrefix(m, "R/") {
							continue
						}
						p := strings.SplitN(m[2:], "/", 2)
						us := snaps[p[0]]
						if us == nil || p[0] == id {
							continue
						}
						for _, a := range us.addrs[p[1]] {
							if addrOnly(a) == gw && online[p[0]] {
								mac := strings.ToUpper(s.ifMAC[egress])
								if us.hotspot[p[1]] && !us.authMACs[mac] {
									via = "held by the hotspot of " + us.identity
									continue
								}
								on, via = true, "via "+us.identity
							}
						}
					}
				}
			}
			if on != online[id] {
				changed = true
			}
			online[id] = on
			viaOf[id] = via
		}
		if !changed && iter > 0 {
			break
		}
	}
	// end devices: online when the router they hang off is
	for id, st := range devState {
		if st.Via != "" && snaps[st.Via] != nil && st.Status == "connected" {
			us := snaps[st.Via]
			mac := strings.ToUpper(byID[id].MAC)
			cl := us.labCl["dev:"+id]
			held := cl != nil && us.hotspot[cl["interface"]] && !us.authMACs[mac]
			st.Online = online[st.Via] && !held
			if held {
				st.Status = "login page"
			}
		}
	}
	// 6. neighbours: MNDP from a router reaches the ports it has an L2 path to,
	// through switches and through other routers' bridges (never through our own)
	type nb struct{ iface, addr, mac, identity, board, version, uptime string }
	neigh := map[string][]nb{}
	for id, s := range snaps {
		if !s.running {
			continue
		}
		u2 := uf{}
		for _, lk := range links {
			if linkUp[lk.ID] {
				a, b := pnode(lk.A), pnode(lk.B)
				if a != "" && b != "" {
					u2.union(a, b)
				}
			}
		}
		for oid, o := range snaps {
			if oid == id {
				continue
			}
			for pid, p := range o.ports {
				if p.l3 != p.name {
					u2.union("P/"+oid+"/"+pid, "B/"+oid+"/"+p.l3)
				}
			}
		}
		ids := make([]string, 0, len(s.ports))
		for pid := range s.ports {
			ids = append(ids, pid)
		}
		sort.Strings(ids)
		for _, pid := range ids {
			p := s.ports[pid]
			me := "P/" + id + "/" + pid
			if _, ok := u2[me]; !ok {
				continue
			}
			set := u2.find(me)
			seen := map[string]bool{}
			for oid, o := range snaps {
				if oid == id || !o.running || seen[oid] {
					continue
				}
				for qid, q := range o.ports {
					n := "P/" + oid + "/" + qid
					if _, ok := u2[n]; !ok || u2.find(n) != set {
						continue
					}
					seen[oid] = true
					addr := ""
					if as := o.addrs[q.l3]; len(as) > 0 {
						addr = addrOnly(as[0])
					}
					iface := p.name
					if p.l3 != p.name {
						iface = p.name + "," + p.l3
					}
					neigh[id] = append(neigh[id], nb{iface, addr, o.ifMAC[q.l3], o.identity, o.board, o.version, o.uptime})
					break
				}
			}
		}
	}
	// 7. apply to every router
	for id, s := range snaps {
		r := s.r
		v := views[id]
		v.online, v.via = online[id], viaOf[id]
		r.mu.Lock()
		r.lab = v
		// cables follow the lab
		for _, p := range r.list(MenuMap["/sim/port"]) {
			pid := ""
			if it := r.byName("/interface", p["interface"]); it != nil {
				pid = firstNonEmpty(it["default-name"], it["name"])
			}
			if wc, ok := wantCable[id][pid]; ok {
				p["_labcable"] = "1"
				p["cable"] = strconv.FormatBool(wc)
			} else if p["_labcable"] == "1" {
				delete(p, "_labcable")
				p["cable"] = "false"
			}
		}
		// imaginary devices leave ports that now have a real lab cable
		cm := MenuMap["/sim/client"]
		for _, c := range append([]Item(nil), r.list(cm)...) {
			if a := c["_auto"]; (a == "lan" || a == "hotspot" || a == "pppoe") && r.sim.labCabled(c["port"]) {
				r.sim.clientDisconnect(c, "port taken by the lab")
				r.removeItem(cm, c, true)
			}
		}
		// lab clients: routers and devices plugged into this router's networks
		have := map[string]Item{}
		for _, c := range r.list(cm) {
			if k := c["_lab"]; k != "" {
				have[k] = c
			}
		}
		for k, c := range have {
			w, ok := want[id][k]
			if !ok || w.port != c["port"] || w.iface != c["interface"] || !strings.EqualFold(w.mac, c["mac-address"]) {
				r.sim.clientDisconnect(c, "cable unplugged")
				r.removeItem(cm, c, true)
				delete(have, k)
			}
		}
		for k, w := range want[id] {
			c := have[k]
			if c == nil {
				if w.mac == "" {
					continue
				}
				var err error
				c, err = r.addItem(cm, map[string]string{"name": uniqueClientName(r, w.name), "kind": w.kind, "mac-address": w.mac, "interface": w.iface, "port": w.port, "dynamic": "true", "usage": "auto", "_auto": "lab", "_lab": k}, true)
				if err != nil {
					continue
				}
			}
			if c["status"] != "connected" && c["status"] != "blocked" {
				r.sim.clientConnect(c)
			}
		}
		// neighbours
		nm := MenuMap["/ip/neighbor"]
		seen := map[string]bool{}
		for _, n := range neigh[id] {
			k := n.mac + "|" + n.iface
			seen[k] = true
			vals := map[string]string{"interface": n.iface, "address": n.addr, "address4": n.addr, "mac-address": n.mac, "identity": n.identity, "platform": "MikroTik", "version": n.version, "board": n.board, "uptime": n.uptime, "unpack": "none", "discovered-by": "cdp,lldp,mndp", "interface-name": n.iface, "_lab": "1", "_labk": k}
			var it Item
			for _, x := range r.list(nm) {
				if x["_labk"] == k {
					it = x
				}
			}
			if it == nil {
				vals["age"] = "1s"
				r.addItem(nm, vals, true)
			} else {
				for kk, v := range vals {
					it[kk] = v
				}
				if durSecs(it["age"]) > 58 {
					it["age"] = "1s" // the next announcement
				}
			}
		}
		r.removeWhere("/ip/neighbor", func(it Item) bool { return it["_lab"] == "1" && !seen[it["_labk"]] })
		for _, m := range s.ifMAC {
			if m != "" {
				labMACs.Store(strings.ToUpper(m), true)
			}
		}
		// traffic of routers behind this one = their uplink traffic
		r.labRate = map[string][2]float64{}
		for oid, ups := range upstreamOf {
			o := snaps[oid]
			for l3, up := range ups {
				if up[0] != id || o == nil {
					continue
				}
				var rx, tx float64
				for _, p := range o.ports {
					if p.l3 == l3 {
						rx += p.rx
						tx += p.tx
					}
				}
				r.labRate[strings.ToUpper(o.ifMAC[firstNonEmpty(dhcpIfaceOn(o, l3), l3)])] = [2]float64{rx, tx}
			}
		}
		r.mu.Unlock()
	}
	// a router renamed from its own terminal or WinBox keeps that name on the canvas
	for _, s := range snaps {
		if s.identity != "" && s.identity != s.d.Name {
			l.mu.Lock()
			s.d.Name = s.identity
			l.dirty = true
			l.mu.Unlock()
		}
	}
	// 8. the console's picture
	l.buildView(devs, links, snaps, linkUp, online, viaOf, devState, views)
}

func dhcpIfaceOn(s *rSnap, l3 string) string {
	for _, dc := range s.clients {
		if s.l3of[dc["interface"]] == l3 || dc["interface"] == l3 {
			return dc["interface"]
		}
	}
	return ""
}

func (l *Lab) buildView(devs []*LabDevice, links []*LabLink, snaps map[string]*rSnap, linkUp map[string]bool, online map[string]bool, via map[string]string, devState map[string]*labDevState, views map[string]*labView) {
	var outDevs []map[string]any
	portRate := func(e LabEnd) (float64, float64, bool) {
		if s := snaps[e.Dev]; s != nil {
			if p := s.ports[e.Port]; p != nil {
				return p.rx, p.tx, p.running
			}
		}
		return 0, 0, false
	}
	for _, d := range devs {
		m := map[string]any{"id": d.ID, "kind": d.Kind, "name": d.Name, "x": d.X, "y": d.Y, "primary": d.Primary, "model": d.Model, "mac": d.MAC, "off": d.Off}
		var ports []map[string]any
		for _, p := range l.portsOf(d) {
			pm := map[string]any{"id": p.ID, "name": p.Name, "kind": p.Kind, "speed": p.Speed}
			if s := snaps[d.ID]; s != nil {
				if rp := s.ports[p.ID]; rp != nil {
					pm["up"] = rp.running
					pm["disabled"] = rp.disabled
					pm["virtual"] = rp.cable && !rp.labCable && !rp.radio
					pm["rx"], pm["tx"] = rp.rx, rp.tx
					if as := s.addrs[rp.l3]; len(as) > 0 {
						pm["addr"] = as[0]
					}
				}
			}
			ports = append(ports, pm)
		}
		m["ports"] = ports
		if s := snaps[d.ID]; s != nil {
			m["identity"] = s.identity
			m["state"] = map[bool]string{true: "running", false: "off"}[s.running]
			if s.state == "booting" {
				m["state"] = "booting"
			}
			m["online"] = online[d.ID]
			m["via"] = via[d.ID]
			m["board"] = s.board
			if d.Primary {
				m["base"] = ""
			} else {
				m["base"] = "/r/" + d.ID
			}
			if s.svcPorts != nil {
				m["services"] = s.svcPorts
			}
			var leases []map[string]string
			for ifn, ls := range views[d.ID].dhcp {
				leases = append(leases, map[string]string{"iface": ifn, "mode": ls.Mode, "addr": ls.Addr, "from": ls.From})
			}
			m["uplinks"] = leases
			m["tunnel"] = tunnelUp(s.r)
		} else if d.Kind == "router" {
			m["state"] = "failed"
		}
		if st := devState[d.ID]; st != nil {
			m["status"] = st
		}
		outDevs = append(outDevs, m)
	}
	var outLinks []map[string]any
	for _, lk := range links {
		lm := map[string]any{"id": lk.ID, "a": lk.A, "b": lk.B, "kind": lk.Kind, "color": lk.Color, "up": linkUp[lk.ID]}
		// traffic seen from a router end: rx at A means flow B -> A
		ab, ba := 0.0, 0.0
		if rx, tx, ok := portRate(lk.A); ok {
			ab, ba = tx, rx
		} else if rx, tx, ok := portRate(lk.B); ok {
			ab, ba = rx, tx
		} else {
			for _, e := range []LabEnd{lk.A, lk.B} {
				if st := devState[e.Dev]; st != nil && st.Via != "" {
					if s := snaps[st.Via]; s != nil {
						if rt, ok := s.clRate["dev:"+e.Dev]; ok {
							if e == lk.A {
								ab, ba = rt[1], rt[0]
							} else {
								ab, ba = rt[0], rt[1]
							}
						}
					}
				}
			}
		}
		if !linkUp[lk.ID] {
			ab, ba = 0, 0
		}
		lm["ab"], lm["ba"] = math.Round(ab), math.Round(ba)
		outLinks = append(outLinks, lm)
	}
	l.vmu.Lock()
	l.view = map[string]any{"devices": outDevs, "links": outLinks, "at": time.Now().UnixMilli()}
	l.vmu.Unlock()
}

// tunnelUp reports WireGuard peers with a recent handshake, for the canvas.
func tunnelUp(r *Router) []map[string]string {
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []map[string]string
	for _, p := range r.list(MenuMap["/interface/wireguard/peers"]) {
		if d, ok := parseDur(p["last-handshake"]); ok && d < 3*time.Minute && p["last-handshake"] != "" {
			out = append(out, map[string]string{"iface": p["interface"], "endpoint": p["endpoint-address"], "comment": p["comment"]})
		}
	}
	return out
}

// ---------- the console API ----------

// labHandler serves /lab/... and /r/<router>/... on the console port.
func (w *Web) labRoute(rw http.ResponseWriter, req *http.Request) bool {
	l := w.lab
	if l == nil {
		return false
	}
	p := req.URL.Path
	if strings.HasPrefix(p, "/r/") {
		rest := p[3:]
		id, sub, _ := strings.Cut(rest, "/")
		l.mu.Lock()
		d := l.dev(id)
		l.mu.Unlock()
		if d == nil || d.r == nil || d.web == nil {
			http.Error(rw, "no such router in the lab", 404)
			return true
		}
		r2 := req.Clone(req.Context())
		r2.URL.Path = "/" + sub
		r2.URL.RawPath = ""
		d.web.handler("winbox").ServeHTTP(rw, r2)
		return true
	}
	if !strings.HasPrefix(p, "/lab/") {
		return false
	}
	var body map[string]any
	tok := req.URL.Query().Get("t")
	if req.Method == http.MethodPost {
		json.NewDecoder(req.Body).Decode(&body)
		if t, _ := body["t"].(string); t != "" {
			tok = t
		}
	}
	s := w.session(tok)
	if s == nil || !s.local {
		jsonOut(rw, 200, map[string]any{"error": "session expired", "expired": true})
		return true
	}
	str := func(k string) string { v, _ := body[k].(string); return strings.TrimSpace(v) }
	num := func(k string) float64 { v, _ := body[k].(float64); return v }
	op := strings.TrimPrefix(p, "/lab/")
	switch op {
	case "state":
		l.vmu.Lock()
		v := l.view
		l.vmu.Unlock()
		if v == nil {
			v = map[string]any{"devices": []any{}, "links": []any{}}
		}
		jsonOut(rw, 200, v)
	case "add":
		jsonOut(rw, 200, l.add(str("kind"), str("model"), str("name"), num("x"), num("y"), body["ownLan"] != false, int(num("ports"))))
	case "move":
		l.mu.Lock()
		if d := l.dev(str("id")); d != nil {
			d.X, d.Y = num("x"), num("y")
			l.dirty = true
		}
		l.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"ok": true})
	case "rename":
		jsonOut(rw, 200, l.rename(str("id"), str("name")))
	case "remove":
		jsonOut(rw, 200, l.remove(str("id")))
	case "link":
		jsonOut(rw, 200, l.link(LabEnd{str("aDev"), str("aPort")}, LabEnd{str("bDev"), str("bPort")}, str("color")))
	case "unlink":
		l.mu.Lock()
		for i, lk := range l.Links {
			if lk.ID == str("id") {
				l.Links = append(l.Links[:i], l.Links[i+1:]...)
				l.dirty = true
				break
			}
		}
		l.mu.Unlock()
		go l.tick()
		jsonOut(rw, 200, map[string]any{"ok": true})
	case "power":
		jsonOut(rw, 200, l.power(str("id"), str("action")))
	case "virtual":
		// unplug the simulator's imaginary devices from a router port
		l.mu.Lock()
		d := l.dev(str("id"))
		l.mu.Unlock()
		if d != nil && d.r != nil {
			d.r.Exec(&Ctx{User: s.user, Internal: true}, "/sim/port/unplug", map[string]string{"numbers": str("port")}, nil, nil)
		}
		jsonOut(rw, 200, map[string]any{"ok": true})
	case "color":
		l.mu.Lock()
		for _, lk := range l.Links {
			if lk.ID == str("id") {
				lk.Color = str("color")
				l.dirty = true
			}
		}
		l.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"ok": true})
	case "vouchers", "hslogin", "hslogout", "usage", "client":
		jsonOut(rw, 200, l.clientCall(op, str("id"), body))
	case "models":
		var list []map[string]any
		for _, k := range ModelOrder {
			m := Models[k]
			e, sf, wl := m.portNames()
			list = append(list, map[string]any{"key": m.Key, "board": m.Board, "name": m.Name, "family": m.Family, "ether": len(e), "sfp": len(sf), "wireless": len(wl), "summary": m.summary()})
		}
		jsonOut(rw, 200, map[string]any{"models": list})
	default:
		jsonOut(rw, 404, map[string]any{"error": "unknown lab call"})
	}
	return true
}

// labClient finds the virtual client a lab device (or a router's uplink)
// became on the router serving its network.
func (l *Lab) labClient(id string) (*LabDevice, Item) {
	l.mu.Lock()
	rs := l.routers()
	l.mu.Unlock()
	for _, d := range rs {
		d.r.mu.Lock()
		for _, c := range d.r.list(MenuMap["/sim/client"]) {
			k := c["_lab"]
			if k == "dev:"+id || strings.HasPrefix(k, "router:"+id+":") {
				cp := Item{}
				for a, b := range c {
					cp[a] = b
				}
				d.r.mu.Unlock()
				return d, cp
			}
		}
		d.r.mu.Unlock()
	}
	return nil, nil
}

func (l *Lab) clientCall(op, id string, body map[string]any) map[string]any {
	up, c := l.labClient(id)
	if c == nil {
		return map[string]any{"error": "not connected to a router's network yet"}
	}
	str := func(k string) string { v, _ := body[k].(string); return v }
	ctx := &Ctx{User: "admin", Internal: true}
	r := up.r
	switch op {
	case "client":
		return map[string]any{"router": up.ID, "routerName": up.Name, "client": c}
	case "vouchers":
		var out []map[string]string
		r.mu.Lock()
		for _, u := range r.list(MenuMap["/ip/hotspot/user"]) {
			if u.B("disabled") || u["name"] == "default-trial" {
				continue
			}
			out = append(out, map[string]string{"name": u["name"], "password": u["password"], "profile": u["profile"], "limit": u["limit-uptime"], "uptime": u["uptime"], "comment": u["comment"]})
		}
		r.mu.Unlock()
		return map[string]any{"router": up.ID, "routerName": up.Name, "users": out}
	case "hslogin":
		_, err := r.Exec(ctx, "/sim/client/login", map[string]string{"numbers": c[".id"], "user": str("user"), "password": str("password")}, nil, nil)
		if err != nil {
			return map[string]any{"error": err.Error()}
		}
	case "hslogout":
		if _, err := r.Exec(ctx, "/sim/client/logout", map[string]string{"numbers": c[".id"]}, nil, nil); err != nil {
			return map[string]any{"error": err.Error()}
		}
	case "usage":
		if _, err := r.Exec(ctx, "/sim/client/set", map[string]string{"numbers": c[".id"], "usage": str("usage")}, nil, nil); err != nil {
			return map[string]any{"error": err.Error()}
		}
	}
	go l.tick()
	return map[string]any{"ok": true}
}

var endKinds = map[string]string{"pc": "PC", "laptop": "Laptop", "phone": "Phone", "tablet": "Tablet", "tv": "Smart TV", "printer": "Printer", "camera": "Camera", "iot": "Smart plug", "server": "Server"}

var macVendors = map[string][]string{
	"phone": {"3C:28:6D", "A4:50:46", "F0:D7:AA", "C0:EE:FB", "60:AB:67"}, "tablet": {"A4:50:46", "F0:D7:AA"},
	"laptop": {"54:E1:AD", "3C:A9:F4", "F8:59:71"}, "pc": {"00:1E:68", "D4:BE:D9", "B4:2E:99"}, "server": {"00:25:90", "0C:C4:7A"},
	"tv": {"7C:64:56", "A8:23:FE"}, "printer": {"00:1B:A9", "3C:2A:F4"}, "camera": {"BC:32:5F", "E0:50:8B"}, "iot": {"84:F3:EB", "24:0F:9B"},
}

func randMACFor(kind string) string {
	v := macVendors[kind]
	if len(v) == 0 {
		v = []string{"02:00:00"}
	}
	b := make([]byte, 4)
	rand.Read(b)
	return fmt.Sprintf("%s:%02X:%02X:%02X", v[int(b[3])%len(v)], b[0], b[1], b[2])
}

func (l *Lab) add(kind, model, name string, x, y float64, own bool, ports int) map[string]any {
	l.mu.Lock()
	d := &LabDevice{Kind: kind, Name: name, X: x, Y: y}
	switch kind {
	case "router":
		md := lookupModel(model)
		if md == nil {
			l.mu.Unlock()
			return map[string]any{"error": "unknown model " + model}
		}
		d.Model = md.Key
		d.ID = l.nextID("r")
		i := 1
		for l.usedIndex(i) {
			i++
		}
		d.Index = i
		if d.Name == "" {
			d.Name = fmt.Sprintf("MikroTik-%s", strings.ToUpper(d.ID))
		}
	case "switch":
		d.ID = l.nextID("sw")
		d.Ports = ports
		if d.Ports < 4 || d.Ports > 48 {
			d.Ports = 8
		}
		if d.Name == "" {
			d.Name = fmt.Sprintf("Switch %d", l.Seq)
		}
	case "internet":
		d.ID = l.nextID("inet")
		if d.Name == "" {
			d.Name = "Internet"
		}
	default:
		label, ok := endKinds[kind]
		if !ok {
			l.mu.Unlock()
			return map[string]any{"error": "unknown device " + kind}
		}
		d.ID = l.nextID("d")
		d.MAC = randMACFor(kind)
		if d.Name == "" {
			n := 1
			for _, o := range l.Devices {
				if o.Kind == kind {
					n++
				}
			}
			d.Name = fmt.Sprintf("%s %d", label, n)
		}
	}
	l.Devices = append(l.Devices, d)
	l.dirty = true
	l.mu.Unlock()
	if kind == "router" {
		if err := l.bootRouter(d, true); err != nil {
			l.mu.Lock()
			for i, x := range l.Devices {
				if x == d {
					l.Devices = append(l.Devices[:i], l.Devices[i+1:]...)
				}
			}
			l.mu.Unlock()
			return map[string]any{"error": err.Error()}
		}
		if own {
			ownLAN(d.r, d.Index)
		}
		d.r.mu.Lock()
		d.r.log("system,info", "added to the network lab as %s", d.Name)
		d.r.mu.Unlock()
	}
	l.save()
	go l.tick()
	return map[string]any{"ok": true, "id": d.ID}
}

func (l *Lab) rename(id, name string) map[string]any {
	if name == "" {
		return map[string]any{"error": "enter a name"}
	}
	l.mu.Lock()
	d := l.dev(id)
	if d == nil {
		l.mu.Unlock()
		return map[string]any{"error": "no such device"}
	}
	d.Name = name
	l.dirty = true
	r := d.r
	l.mu.Unlock()
	if r != nil {
		r.mu.Lock()
		if it := r.single("/system/identity"); it != nil {
			it["name"] = name
			r.markDirty()
		}
		r.mu.Unlock()
	}
	return map[string]any{"ok": true}
}

func (l *Lab) remove(id string) map[string]any {
	l.mu.Lock()
	d := l.dev(id)
	if d == nil {
		l.mu.Unlock()
		return map[string]any{"error": "no such device"}
	}
	if d.Primary {
		l.mu.Unlock()
		return map[string]any{"error": "the main router stays in the lab"}
	}
	for i, x := range l.Devices {
		if x == d {
			l.Devices = append(l.Devices[:i], l.Devices[i+1:]...)
			break
		}
	}
	var keep []*LabLink
	for _, lk := range l.Links {
		if lk.A.Dev != id && lk.B.Dev != id {
			keep = append(keep, lk)
		}
	}
	l.Links = keep
	l.dirty = true
	l.mu.Unlock()
	if d.Kind == "router" {
		l.stopRouter(d)
		os.RemoveAll(filepath.Join(l.dir, "lab", d.ID))
	}
	l.save()
	go l.tick()
	return map[string]any{"ok": true}
}

func (l *Lab) link(a, b LabEnd, color string) map[string]any {
	l.mu.Lock()
	defer func() {
		l.mu.Unlock()
		go l.tick()
	}()
	da, db := l.dev(a.Dev), l.dev(b.Dev)
	if da == nil || db == nil {
		return map[string]any{"error": "no such device"}
	}
	if a.Dev == b.Dev {
		return map[string]any{"error": "a cable needs two different devices"}
	}
	l.mu.Unlock()
	pa, pb := l.portsOf(da), l.portsOf(db)
	l.mu.Lock()
	find := func(ps []labPort, id string) *labPort {
		for i := range ps {
			if ps[i].ID == id {
				return &ps[i]
			}
		}
		return nil
	}
	ka, kb := find(pa, a.Port), find(pb, b.Port)
	if ka == nil || kb == nil {
		return map[string]any{"error": "no such port"}
	}
	wifiA, wifiB := ka.Kind == "wlan" || ka.Kind == "wifi", kb.Kind == "wlan" || kb.Kind == "wifi"
	if wifiA != wifiB {
		return map[string]any{"error": "Wi-Fi connects to a radio (wlan/wifi), cables to Ethernet ports"}
	}
	kind := "cable"
	if wifiA {
		kind = "wifi"
		if ka.Kind == "wlan" && kb.Kind == "wlan" {
			return map[string]any{"error": "connect a Wi-Fi device (phone, laptop, ...) to the radio"}
		}
	}
	used := func(e LabEnd, multi bool) bool {
		if multi {
			return false
		}
		for _, lk := range l.Links {
			if lk.A == e || lk.B == e {
				return true
			}
		}
		return false
	}
	multi := func(d *LabDevice, p *labPort) bool { return d.Kind == "internet" || p.Kind == "wlan" }
	if used(a, multi(da, ka)) || used(b, multi(db, kb)) {
		return map[string]any{"error": "that port already has a cable: remove it first"}
	}
	// an end device has one connection
	for _, e := range []LabEnd{a, b} {
		if d := l.dev(e.Dev); d != nil && endKinds[d.Kind] != "" {
			for _, lk := range l.Links {
				if lk.A.Dev == e.Dev || lk.B.Dev == e.Dev {
					return map[string]any{"error": d.Name + " is already connected"}
				}
			}
		}
	}
	if color == "" {
		color = "blue"
	}
	lk := &LabLink{ID: l.nextID("l"), A: a, B: b, Kind: kind, Color: color}
	l.Links = append(l.Links, lk)
	l.dirty = true
	return map[string]any{"ok": true, "id": lk.ID}
}

func (l *Lab) power(id, action string) map[string]any {
	l.mu.Lock()
	d := l.dev(id)
	l.mu.Unlock()
	if d == nil {
		return map[string]any{"error": "no such device"}
	}
	if d.Kind != "router" {
		l.mu.Lock()
		d.Off = action == "off"
		l.dirty = true
		l.mu.Unlock()
		go l.tick()
		return map[string]any{"ok": true}
	}
	if d.r == nil {
		return map[string]any{"error": "router is not running"}
	}
	switch action {
	case "on":
		d.r.Exec(&Ctx{User: "admin", Internal: true}, "/sim/power-on", nil, nil, nil)
	case "off":
		go d.r.powerCycle("shutdown")
	case "reboot":
		go d.r.powerCycle("reboot")
	}
	return map[string]any{"ok": true}
}
