package main

import (
	"crypto/md5"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"math"
	"math/rand"
	"net"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Rate holds live per-interface throughput (router perspective).
type Rate struct {
	RxBps, TxBps float64
	RxPps, TxPps float64
}

type clientRT struct {
	phase     string
	phaseLeft int
	down, up  float64 // bps, client perspective
	wait      int     // ticks until next action
	life      int     // ticks remaining for auto clients
	triedAuth bool
	failCount int
}

type returning struct {
	user, pass, mac, name, kind string
}

type Sim struct {
	r         *Router
	rnd       *rand.Rand
	rates     map[string]*Rate
	rt        map[string]*clientRT
	cpu       float64
	tick      int
	pending   []scriptJob
	returning []returning
	chap      map[string][]byte // portal key -> chap challenge (17 bytes: id + 16)
	sessSeq   int
	cpuItems  []Item
}

type scriptJob struct {
	src, user, name string
}

func newSim(r *Router) *Sim {
	return &Sim{r: r, rnd: rand.New(rand.NewSource(time.Now().UnixNano())), rates: map[string]*Rate{}, rt: map[string]*clientRT{}, chap: map[string][]byte{}, sessSeq: 0x81000000}
}

func (s *Sim) renamed(old, nw string) {
	if v, ok := s.rates[old]; ok {
		s.rates[nw] = v
		delete(s.rates, old)
	}
}

func (s *Sim) rate(name string) *Rate {
	rt := s.rates[name]
	if rt == nil {
		rt = &Rate{}
		s.rates[name] = rt
	}
	return rt
}

func (s *Sim) setting(k string) string { return s.r.S("/sim/settings", k) }

// ---------------- interface / link state ----------------

func (s *Sim) portOf(ifname string) Item {
	for _, p := range s.r.list(MenuMap["/sim/port"]) {
		if p["interface"] == ifname {
			return p
		}
	}
	return nil
}

func (s *Sim) cablePlugged(ifname string) bool {
	p := s.portOf(ifname)
	return p == nil || p.B("cable")
}

func (s *Sim) updateLinks() {
	r := s.r
	ifs := r.list(MenuMap["/interface"])
	byName := map[string]Item{}
	for _, it := range ifs {
		byName[it["name"]] = it
	}
	setRun := func(it Item, run bool) {
		was := it.B("running")
		it["running"] = strconv.FormatBool(run)
		if run && !was && (it["type"] == "ether" || it["type"] == "wlan" || it["type"] == "wifi") {
			it["last-link-up-time"] = r.now().Format("2006-01-02 15:04:05")
			if it["type"] == "ether" && s.tick > 1 {
				sp := s.portOf(it["name"])
				speed := "1Gbps"
				if sp != nil {
					speed = sp["speed"] + "bps"
				}
				r.log("interface,info", "%s link up (speed %s, full duplex)", it["name"], speed)
			}
		}
		if !run && was && (it["type"] == "ether" || it["type"] == "wlan" || it["type"] == "wifi") {
			it["last-link-down-time"] = r.now().Format("2006-01-02 15:04:05")
			n, _ := strconv.Atoi(it["link-downs"])
			it["link-downs"] = strconv.Itoa(n + 1)
			if it["type"] == "ether" {
				r.log("interface,info", "%s link down", it["name"])
			}
			s.linkLost(it["name"])
		}
	}
	for _, it := range ifs {
		switch it["type"] {
		case "ether":
			setRun(it, !it.B("disabled") && s.cablePlugged(it["name"]))
		case "wlan", "wifi":
			setRun(it, !it.B("disabled"))
		}
	}
	// bridges: running if any member running
	ports := r.list(MenuMap["/interface/bridge/port"])
	for _, it := range ifs {
		if it["type"] != "bridge" {
			continue
		}
		run := false
		for _, p := range ports {
			if p["bridge"] == it["name"] && !p.B("disabled") {
				if m := byName[p["interface"]]; m != nil && m.B("running") {
					run = true
				}
			}
		}
		if it.B("disabled") {
			run = false
		}
		it["running"] = strconv.FormatBool(run)
	}
	for _, p := range ports {
		m := byName[p["interface"]]
		inactive := m == nil || !m.B("running") || p.B("disabled")
		p["inactive"] = strconv.FormatBool(inactive)
		if inactive {
			p["status"] = "inactive"
			p["role"] = "disabled-port"
		} else {
			p["status"] = "in-bridge"
			p["role"] = "designated-port"
		}
	}
	for _, it := range ifs {
		switch it["type"] {
		case "vlan", "eoip", "pppoe-out":
			parent := byName[it["interface"]]
			run := !it.B("disabled") && (parent == nil || parent.B("running"))
			if it["type"] == "eoip" {
				run = !it.B("disabled") && s.wanUp()
			}
			if it["type"] == "pppoe-out" {
				run = run && it["user"] != "" && s.wanUp()
			}
			it["running"] = strconv.FormatBool(run)
		case "wg":
			it["running"] = strconv.FormatBool(!it.B("disabled"))
		}
	}
}

func (s *Sim) wanUp() bool {
	if s.r.lab != nil {
		return s.r.lab.online
	}
	return s.physWanUp()
}

// physWanUp is the simulator's own uplink: ether1 plugged and the internet switch on.
func (s *Sim) physWanUp() bool {
	if !s.r.single("/sim/settings").B("wan-online") {
		return false
	}
	w := s.r.byName("/interface", "ether1")
	if w == nil {
		for _, it := range s.r.list(MenuMap["/interface/ethernet"]) {
			w = it
			break
		}
	}
	return w != nil && w.B("running")
}

func (s *Sim) linkLost(ifname string) {
	for _, c := range append([]Item(nil), s.r.list(MenuMap["/sim/client"])...) {
		if c["port"] == ifname && c["status"] != "disconnected" {
			s.clientDisconnect(c, "link down")
			c["status"] = "link-down"
		}
	}
}

// logical interface for a port: the bridge it belongs to, or itself
func (s *Sim) logical(port string) string {
	for _, p := range s.r.list(MenuMap["/interface/bridge/port"]) {
		if p["interface"] == port && !p.B("disabled") {
			return p["bridge"]
		}
	}
	return port
}

// pick a plugged, running physical port belonging to logical interface lif
func (s *Sim) pickPort(lif string) string {
	var cands []string
	for _, p := range s.r.list(MenuMap["/interface/bridge/port"]) {
		if p["bridge"] == lif && !p.B("disabled") {
			if i := s.r.byName("/interface", p["interface"]); i != nil && i.B("running") && !s.labCabled(p["interface"]) {
				cands = append(cands, p["interface"])
			}
		}
	}
	if len(cands) == 0 {
		if i := s.r.byName("/interface", lif); i != nil && i.B("running") && i["type"] != "bridge" && !s.labCabled(lif) {
			return lif
		}
		return ""
	}
	return cands[s.rnd.Intn(len(cands))]
}

// labCabled reports a port wired in the network lab: the simulator's
// imaginary devices do not use it.
func (s *Sim) labCabled(ifname string) bool {
	p := s.portOf(ifname)
	return p != nil && p["_labcable"] == "1"
}

// pickWireless returns a running wireless port (wlan/wifi) that is a member of lif
func (s *Sim) pickWireless(lif string) string {
	var cands []string
	for _, p := range s.r.list(MenuMap["/interface/bridge/port"]) {
		if p["bridge"] != lif || p.B("disabled") {
			continue
		}
		if i := s.r.byName("/interface", p["interface"]); i != nil && i.B("running") && (i["type"] == "wlan" || i["type"] == "wifi") {
			cands = append(cands, p["interface"])
		}
	}
	if len(cands) == 0 {
		return ""
	}
	return cands[s.rnd.Intn(len(cands))]
}

// tables carried over when switching router model with "keep users"
var modelKeepPaths = []string{"/ip/hotspot/user", "/ip/hotspot/user/profile", "/ppp/secret", "/ppp/profile", "/user", "/user/group", "/system/identity", "/system/note", "/system/script", "/system/scheduler", "/radius", "/file", "/ip/hotspot/walled-garden", "/ip/hotspot/walled-garden/ip", "/ip/hotspot/ip-binding", "/sim/settings", "/certificate", "/snmp", "/snmp/community"}

// ---------------- pools ----------------

func ip2u(ip net.IP) uint32 { return binary.BigEndian.Uint32(ip.To4()) }
func u2ip(u uint32) net.IP {
	b := make(net.IP, 4)
	binary.BigEndian.PutUint32(b, u)
	return b
}

func poolRanges(spec string) [][2]uint32 {
	var out [][2]uint32
	for _, p := range strings.Split(spec, ",") {
		p = strings.TrimSpace(p)
		if strings.Contains(p, "/") {
			_, n, err := net.ParseCIDR(p)
			if err != nil {
				continue
			}
			ones, bits := n.Mask.Size()
			a := ip2u(n.IP)
			size := uint32(1) << uint(bits-ones)
			out = append(out, [2]uint32{a + 1, a + size - 2})
			continue
		}
		ab := strings.SplitN(p, "-", 2)
		a := net.ParseIP(strings.TrimSpace(ab[0]))
		if a == nil || a.To4() == nil {
			continue
		}
		b := a
		if len(ab) == 2 {
			b = net.ParseIP(strings.TrimSpace(ab[1]))
			if b == nil || b.To4() == nil {
				continue
			}
		}
		out = append(out, [2]uint32{ip2u(a), ip2u(b)})
	}
	return out
}

func (s *Sim) usedIPs() map[string]bool {
	used := map[string]bool{}
	for _, it := range s.r.list(MenuMap["/ip/pool/used"]) {
		used[it["address"]] = true
	}
	for _, it := range s.r.list(MenuMap["/ip/dhcp-server/lease"]) {
		used[it["address"]] = true
	}
	for _, it := range s.r.list(MenuMap["/ip/address"]) {
		used[strings.Split(it["address"], "/")[0]] = true
	}
	return used
}

func (s *Sim) allocIP(pool, owner, info string) string {
	p := s.r.byName("/ip/pool", pool)
	if p == nil {
		if net.ParseIP(pool) != nil {
			return pool
		}
		return ""
	}
	used := s.usedIPs()
	for _, rg := range poolRanges(p["ranges"]) {
		for u := rg[0]; u <= rg[1] && u-rg[0] < 65536; u++ {
			ip := u2ip(u).String()
			if !used[ip] {
				s.r.addItem(MenuMap["/ip/pool/used"], map[string]string{"pool": pool, "address": ip, "owner": owner, "info": info}, true)
				return ip
			}
		}
	}
	if np := p["next-pool"]; np != "" && np != "none" && np != pool {
		return s.allocIP(np, owner, info)
	}
	return ""
}

func (s *Sim) freeIP(addr string) {
	s.r.removeWhere("/ip/pool/used", func(it Item) bool { return it["address"] == addr })
}

// ---------------- clients ----------------

var hostNames = map[string][]string{
	"phone":   {"Galaxy-A14", "iPhone", "Redmi-Note-12", "TECNO-SPARK-10", "Infinix-HOT-30", "itel-A70", "Pixel-7", "OPPO-A57", "HUAWEI-Y9", "Galaxy-S23", "vivo-Y21", "Nokia-G21"},
	"laptop":  {"DESKTOP-7QF2KLM", "LAPTOP-HP-ELITE", "MacBook-Air", "ThinkPad-T480", "DELL-LATITUDE", "LENOVO-IDEAPAD"},
	"desktop": {"OFFICE-PC1", "RECEPTION-PC", "ACCOUNTS-PC", "CASHIER-01"},
	"tablet":  {"Galaxy-Tab-A8", "iPad", "Lenovo-Tab-M10"},
	"tv":      {"Samsung-SmartTV", "LG-webOS-TV", "Android-TV-Box", "Hisense-TV"},
	"iot":     {"HIKVISION-CAM", "ESP32-Sensor", "Tuya-Plug", "Printer-EPSON"},
	"cpe":     {"CPE-Router"},
}

func (s *Sim) randMAC(kind string) string {
	ouis := map[string][]string{
		"phone": {"F4:F5:24", "A4:50:46", "DC:2C:6E", "70:3A:51", "C8:94:02", "B4:CB:57"}, "laptop": {"3C:A0:67", "8C:85:90", "F0:18:98", "54:E1:AD"},
		"desktop": {"00:1E:68", "D4:BE:D9"}, "tablet": {"08:C5:E1", "60:F8:1D"}, "tv": {"64:1C:AE", "B8:BC:5B"}, "iot": {"24:0F:9B", "84:F3:EB"}, "cpe": {"48:A9:8A", "DC:2C:6E", "64:D1:54", "CC:2D:E0"},
	}
	l := ouis[kind]
	if l == nil {
		l = ouis["phone"]
	}
	return fmt.Sprintf("%s:%02X:%02X:%02X", l[s.rnd.Intn(len(l))], s.rnd.Intn(256), s.rnd.Intn(256), s.rnd.Intn(256))
}

func (s *Sim) newClient(kind, lif, auto string) Item {
	names := hostNames[kind]
	if names == nil {
		names = hostNames["phone"]
	}
	name := names[s.rnd.Intn(len(names))]
	if kind == "phone" || kind == "laptop" || kind == "tablet" {
		name = fmt.Sprintf("%s-%02d", name, s.rnd.Intn(100))
	}
	c, err := s.r.addItem(MenuMap["/sim/client"], map[string]string{"name": name, "kind": kind, "mac-address": s.randMAC(kind), "interface": lif, "dynamic": "true", "status": "disconnected", "_auto": auto}, true)
	if err != nil {
		return nil
	}
	return c
}

func (s *Sim) crt(c Item) *clientRT {
	rt := s.rt[c[".id"]]
	if rt == nil {
		rt = &clientRT{phase: "browsing", phaseLeft: 5, life: 600 + s.rnd.Intn(1800)}
		s.rt[c[".id"]] = rt
	}
	return rt
}

func (s *Sim) dhcpServerFor(lif string) Item {
	for _, d := range s.r.list(MenuMap["/ip/dhcp-server"]) {
		if d["interface"] == lif && !d.B("disabled") {
			return d
		}
	}
	return nil
}

func (s *Sim) hotspotFor(lif string) Item {
	for _, h := range s.r.list(MenuMap["/ip/hotspot"]) {
		if h["interface"] == lif && !h.B("disabled") {
			return h
		}
	}
	return nil
}

// clientConnect brings a virtual client online (DHCP lease, ARP, hotspot host…)
func (s *Sim) clientConnect(c Item) error {
	r := s.r
	if c.B("disabled") {
		return trap("client is disabled")
	}
	if c["status"] == "connected" {
		return nil
	}
	lif := s.logical(firstNonEmpty(c["interface"], c["port"]))
	c["interface"] = lif
	if c["port"] == "" || s.logical(c["port"]) != lif {
		c["port"] = s.pickPort(lif)
		if k := c["kind"]; (k == "phone" || k == "tablet" || k == "laptop") && s.rnd.Intn(10) < 7 {
			if w := s.pickWireless(lif); w != "" {
				c["port"] = w
			}
		}
	}
	pi := r.byName("/interface", c["port"])
	if c["port"] == "" || pi == nil || !pi.B("running") {
		c["status"] = "link-down"
		return trap("no running port on %s (plug a cable in first)", lif)
	}
	if c["kind"] == "cpe" {
		c["status"] = "connecting"
		s.crt(c).wait = 1 + s.rnd.Intn(4)
		return nil
	}
	addr := c["_static-ip"]
	if addr == "" {
		srv := s.dhcpServerFor(lif)
		if srv == nil {
			c["status"] = "no-dhcp"
			return trap("no DHCP server on %s", lif)
		}
		// static lease?
		var lease Item
		for _, l := range r.list(MenuMap["/ip/dhcp-server/lease"]) {
			if strings.EqualFold(l["mac-address"], c["mac-address"]) {
				lease = l
			}
		}
		if lease != nil && lease.B("disabled") {
			c["status"] = "blocked"
			return trap("lease disabled")
		}
		if lease == nil {
			addr = s.allocIP(srv["address-pool"], srv["name"], c["mac-address"])
			if addr == "" {
				c["status"] = "no-address"
				r.log("dhcp,warning", "%s failed to give out IP address: pool <%s> is empty", srv["name"], srv["address-pool"])
				return trap("dhcp pool exhausted")
			}
			l, err := r.addItem(MenuMap["/ip/dhcp-server/lease"], map[string]string{"address": addr, "mac-address": c["mac-address"], "server": srv["name"], "dynamic": "true", "status": "bound"}, true)
			if err != nil {
				c["status"] = "no-address"
				return trap("dhcp: %v", err)
			}
			lease = l
		}
		addr = lease["address"]
		lt := durSecs(srv["lease-time"])
		if lt == 0 {
			lt = 600
		}
		lease["status"] = "bound"
		lease["host-name"] = c["name"]
		lease["active-address"] = addr
		lease["active-mac-address"] = c["mac-address"]
		lease["active-client-id"] = "1:" + strings.ToLower(c["mac-address"])
		lease["client-id"] = "1:" + strings.ToLower(c["mac-address"])
		lease["active-server"] = srv["name"]
		lease["last-seen"] = "0s"
		lease["_exp"] = strconv.FormatInt(time.Now().Unix()+lt, 10)
		r.log("dhcp,info", "%s assigned %s for %s %s", srv["name"], addr, c["mac-address"], c["name"])
	}
	c["address"] = addr
	c["status"] = "connected"
	rt := s.crt(c)
	rt.triedAuth = false
	rt.wait = 2 + s.rnd.Intn(6)
	r.addItem(MenuMap["/ip/arp"], map[string]string{"address": addr, "mac-address": c["mac-address"], "interface": lif, "dynamic": "true", "DHCP": "true", "complete": "true", "status": "reachable", "_client": c[".id"]}, true)
	r.addItem(MenuMap["/interface/bridge/host"], map[string]string{"mac-address": c["mac-address"], "on-interface": c["port"], "bridge": lif, "age": "0s", "dynamic": "true", "_client": c[".id"]}, true)
	if pi["type"] == "wifi" {
		sig := -38 - s.rnd.Intn(40)
		ssid, band := "", ""
		if w := r.byName("/interface", c["port"]); w != nil {
			ssid, band = w["configuration.ssid"], w["channel.band"]
		}
		r.addItem(MenuMap["/interface/wifi/registration-table"], map[string]string{"interface": c["port"], "ssid": ssid, "mac-address": c["mac-address"], "uptime": "0s", "last-activity": "10ms", "signal": fmt.Sprint(sig), "auth-type": "wpa2-psk", "band": band, "tx-rate": "573.5Mbps-80MHz/2S/HE-MCS5", "rx-rate": "432.3Mbps-80MHz/2S/HE-MCS4", "packets": "0,0", "bytes": "0,0", "authorized": "true", "_client": c[".id"], "_t0": strconv.FormatInt(time.Now().Unix(), 10)}, true)
	}
	if pi["type"] == "wlan" {
		sig := -38 - s.rnd.Intn(40)
		r.addItem(MenuMap["/interface/wireless/registration-table"], map[string]string{"interface": c["port"], "mac-address": c["mac-address"], "radio-name": c["name"], "ap": "false", "wds": "false", "bridge": "false", "rx-rate": "144.4Mbps-20MHz/2S/SGI", "tx-rate": "130Mbps-20MHz/2S", "uptime": "0s", "last-activity": "10ms", "signal-strength": fmt.Sprintf("%ddBm@HT20-7", sig), "signal-to-noise": fmt.Sprintf("%ddB", 100+sig-5), "tx-ccq": fmt.Sprintf("%d%%", 60+s.rnd.Intn(39)), "p-throughput": fmt.Sprint(60000 + s.rnd.Intn(40000)), "authentication-type": "wpa2-psk", "encryption": "aes-ccm", "packets": "0,0", "bytes": "0,0", "_client": c[".id"], "_t0": strconv.FormatInt(time.Now().Unix(), 10)}, true)
	}
	if hs := s.hotspotFor(lif); hs != nil {
		host, _ := r.addItem(MenuMap["/ip/hotspot/host"], map[string]string{"mac-address": c["mac-address"], "address": addr, "to-address": addr, "server": hs["name"], "uptime": "0s", "idle-time": "0s", "idle-timeout": hs["idle-timeout"], "keepalive-timeout": hs["keepalive-timeout"], "found-by": "DHCP-request", "DHCP": "true", "dynamic": "true", "authorized": "false", "bypassed": "false", "_client": c[".id"]}, true)
		for _, b := range r.list(MenuMap["/ip/hotspot/ip-binding"]) {
			if b.B("disabled") || !strings.EqualFold(b["mac-address"], c["mac-address"]) && b["address"] != addr {
				continue
			}
			if b["type"] == "bypassed" {
				host["bypassed"] = "true"
				host["authorized"] = "true"
			}
			if b["type"] == "blocked" {
				c["status"] = "blocked"
			}
		}
		// mac-cookie auto-login
		for _, ck := range r.list(MenuMap["/ip/hotspot/cookie"]) {
			if strings.EqualFold(ck["mac-address"], c["mac-address"]) {
				if u := r.byName("/ip/hotspot/user", ck["user"]); u != nil {
					s.hotspotLogin(c, u["name"], u["password"], "cookie", true)
				}
			}
		}
	}
	return nil
}

func (s *Sim) clientDisconnect(c Item, reason string) {
	r := s.r
	for _, a := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
		if strings.EqualFold(a["mac-address"], c["mac-address"]) {
			s.hotspotLogout(a, reason)
		}
	}
	for _, a := range append([]Item(nil), r.list(MenuMap["/ppp/active"])...) {
		if a["_client"] == c[".id"] {
			s.pppDisconnect(a, "peer-request")
		}
	}
	cid := c[".id"]
	r.removeWhere("/ip/hotspot/host", func(it Item) bool { return it["_client"] == cid })
	r.removeWhere("/ip/arp", func(it Item) bool { return it["_client"] == cid })
	r.removeWhere("/interface/bridge/host", func(it Item) bool { return it["_client"] == cid })
	r.removeWhere("/interface/wireless/registration-table", func(it Item) bool { return it["_client"] == cid })
	r.removeWhere("/interface/wifi/registration-table", func(it Item) bool { return it["_client"] == cid })
	for _, l := range r.list(MenuMap["/ip/dhcp-server/lease"]) {
		if strings.EqualFold(l["mac-address"], c["mac-address"]) {
			l["status"] = "waiting"
			delete(l, "active-address")
			delete(l, "active-mac-address")
			delete(l, "active-server")
			delete(l, "active-client-id")
			if l.B("dynamic") {
				addr := l["address"]
				r.removeItem(MenuMap["/ip/dhcp-server/lease"], l, true)
				s.freeIP(addr)
			}
			break
		}
	}
	c["status"] = "disconnected"
	delete(c, "address")
	c["hotspot-user"] = ""
	delete(c, "hotspot-user")
}

func (s *Sim) removeClient(c Item) {
	s.clientDisconnect(c, "lost dhcp lease")
	delete(s.rt, c[".id"])
	s.r.removeItem(MenuMap["/sim/client"], c, true)
}

func (s *Sim) clientByMAC(mac string) Item {
	for _, c := range s.r.list(MenuMap["/sim/client"]) {
		if strings.EqualFold(c["mac-address"], mac) {
			return c
		}
	}
	return nil
}

// ---------------- hotspot ----------------

func parsePair(s string) (rx, tx int64) {
	p := strings.SplitN(s, "/", 2)
	rx = parseRate(p[0])
	if len(p) == 2 {
		tx = parseRate(p[1])
	} else {
		tx = rx
	}
	return
}

// hotspotLogin authenticates virtual client c with user/pass.
func (s *Sim) hotspotLogin(c Item, user, pass, by string, trusted bool) (Item, error) {
	r := s.r
	if c["status"] != "connected" {
		return nil, trap("client is not connected")
	}
	hs := s.hotspotFor(c["interface"])
	if hs == nil {
		return nil, trap("no hotspot server on %s", c["interface"])
	}
	for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
		if strings.EqualFold(a["mac-address"], c["mac-address"]) {
			return a, nil
		}
	}
	u := r.byName("/ip/hotspot/user", user)
	if u == nil || u["_default"] == "true" || (!trusted && u["password"] != pass) {
		r.log("hotspot,info,debug", "%s (%s): login failed: invalid username or password", user, c["address"])
		return nil, trap("invalid username or password")
	}
	if u["server"] != "" && u["server"] != "all" && u["server"] != hs["name"] {
		return nil, trap("invalid username or password")
	}
	if u.B("disabled") {
		r.log("hotspot,info,debug", "%s (%s): login failed: user disabled", user, c["address"])
		return nil, trap("user %s is disabled", user)
	}
	if u["mac-address"] != "" && !strings.EqualFold(u["mac-address"], c["mac-address"]) {
		return nil, trap("your MAC address is not allowed for this user")
	}
	if u["address"] != "" && u["address"] != c["address"] {
		return nil, trap("your IP address is not allowed for this user")
	}
	if lu := durSecs(u["limit-uptime"]); lu > 0 && durSecs(u["uptime"]) >= lu {
		r.log("hotspot,info,debug", "%s (%s): login failed: uptime limit reached", user, c["address"])
		return nil, trap("user %s has reached uptime limit", user)
	}
	bi, _ := strconv.ParseInt(u["bytes-in"], 10, 64)
	bo, _ := strconv.ParseInt(u["bytes-out"], 10, 64)
	if lb, _ := strconv.ParseInt(u["limit-bytes-total"], 10, 64); lb > 0 && bi+bo >= lb {
		r.log("hotspot,info,debug", "%s (%s): login failed: traffic limit reached", user, c["address"])
		return nil, trap("user %s has reached traffic limit", user)
	}
	prof := r.byName("/ip/hotspot/user/profile", u["profile"])
	if prof == nil {
		prof = r.byName("/ip/hotspot/user/profile", "default")
	}
	shared := 1
	if prof != nil {
		if prof["shared-users"] == "unlimited" {
			shared = 1 << 30
		} else if n, err := strconv.Atoi(prof["shared-users"]); err == nil {
			shared = n
		}
	}
	cnt := 0
	for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
		if a["user"] == user {
			cnt++
		}
	}
	if cnt >= shared {
		r.log("hotspot,info,debug", "%s (%s): login failed: no more sessions are allowed for user", user, c["address"])
		return nil, trap("no more sessions are allowed for user")
	}
	a := map[string]string{"server": hs["name"], "user": user, "address": c["address"], "mac-address": c["mac-address"], "login-by": by, "uptime": "0s", "idle-time": "0s", "idle-timeout": firstNonEmpty(prof["idle-timeout"], "none"), "keepalive-timeout": firstNonEmpty(prof["keepalive-timeout"], "2m"), "bytes-in": "0", "bytes-out": "0", "packets-in": "0", "packets-out": "0", "radius": "false", "blocked": "false", "_client": c[".id"]}
	if lu := durSecs(u["limit-uptime"]); lu > 0 {
		a["session-time-left"] = fmtDur(time.Duration(lu-durSecs(u["uptime"])) * time.Second)
	}
	if st := durSecs(prof["session-timeout"]); st > 0 {
		if cur, ok := a["session-time-left"]; !ok || durSecs(cur) > st {
			a["session-time-left"] = fmtDur(time.Duration(st) * time.Second)
		}
	}
	if lb, _ := strconv.ParseInt(u["limit-bytes-total"], 10, 64); lb > 0 {
		a["limit-bytes-total"] = strconv.FormatInt(lb-bi-bo, 10)
	}
	act, _ := r.addItem(MenuMap["/ip/hotspot/active"], a, true)
	for _, h := range r.list(MenuMap["/ip/hotspot/host"]) {
		if strings.EqualFold(h["mac-address"], c["mac-address"]) {
			h["authorized"] = "true"
		}
	}
	c["hotspot-user"] = user
	if rl := prof["rate-limit"]; rl != "" {
		r.addItem(MenuMap["/queue/simple"], map[string]string{"name": "<hotspot-" + user + ">", "target": c["address"] + "/32", "max-limit": rl, "dynamic": "true", "_hs": act[".id"]}, true)
	}
	if al := prof["address-list"]; al != "" {
		r.addItem(MenuMap["/ip/firewall/address-list"], map[string]string{"list": al, "address": c["address"], "dynamic": "true", "_hs": act[".id"]}, true)
	}
	hp := r.byName("/ip/hotspot/profile", hs["profile"])
	if hp != nil && strings.Contains(hp["login-by"], "cookie") && by != "cookie" {
		r.removeWhere("/ip/hotspot/cookie", func(it Item) bool { return strings.EqualFold(it["mac-address"], c["mac-address"]) })
		r.addItem(MenuMap["/ip/hotspot/cookie"], map[string]string{"user": user, "mac-address": c["mac-address"], "expires-in": hp["http-cookie-lifetime"], "mac-cookie": strconv.FormatBool(strings.Contains(hp["login-by"], "mac-cookie")), "_exp": strconv.FormatInt(time.Now().Unix()+durSecs(hp["http-cookie-lifetime"]), 10)}, true)
	}
	r.log("hotspot,account,info,debug", "%s (%s): logged in", user, c["address"])
	if prof["on-login"] != "" {
		s.pending = append(s.pending, scriptJob{src: prof["on-login"], user: "admin", name: "hotspot on-login"})
	}
	return act, nil
}

func (s *Sim) hotspotLogout(a Item, reason string) {
	r := s.r
	r.removeItem(MenuMap["/ip/hotspot/active"], a, true)
	for _, h := range r.list(MenuMap["/ip/hotspot/host"]) {
		if strings.EqualFold(h["mac-address"], a["mac-address"]) && !h.B("bypassed") {
			h["authorized"] = "false"
		}
	}
	if c := r.findRef(MenuMap["/sim/client"], a["_client"]); c != nil {
		delete(c, "hotspot-user")
		if reason == "admin reset" || reason == "user request" {
			s.crt(c).triedAuth = true
		}
	}
	id := a[".id"]
	r.removeWhere("/queue/simple", func(q Item) bool { return q["_hs"] == id })
	r.removeWhere("/ip/firewall/address-list", func(q Item) bool { return q["_hs"] == id })
	r.log("hotspot,account,info,debug", "%s (%s): logged out: %s", a["user"], a["address"], reason)
	if u := r.byName("/ip/hotspot/user", a["user"]); u != nil {
		if p := r.byName("/ip/hotspot/user/profile", u["profile"]); p != nil && p["on-logout"] != "" {
			s.pending = append(s.pending, scriptJob{src: p["on-logout"], user: "admin", name: "hotspot on-logout"})
		}
	}
}

// ---------------- PPP ----------------

func (s *Sim) pppServerFor(lif string) Item {
	for _, p := range s.r.list(MenuMap["/interface/pppoe-server/server"]) {
		if p["interface"] == lif && !p.B("disabled") {
			return p
		}
	}
	return nil
}

func (s *Sim) pppConnect(c Item) error {
	r := s.r
	srv := s.pppServerFor(c["interface"])
	if srv == nil {
		return trap("no PPPoE server on %s", c["interface"])
	}
	name := c["pppoe-secret"]
	sec := r.byName("/ppp/secret", name)
	ifn := "<pppoe-" + name + ">"
	if sec == nil || sec.B("disabled") || (sec["service"] != "any" && sec["service"] != "pppoe") {
		r.log("pppoe,ppp,info", "%s: user %s authentication failed", ifn, name)
		return trap("authentication failed")
	}
	if c["_pass"] != "" && c["_pass"] != sec["password"] {
		r.log("pppoe,ppp,info", "%s: user %s authentication failed", ifn, name)
		return trap("authentication failed")
	}
	if sec["caller-id"] != "" && !strings.EqualFold(sec["caller-id"], c["mac-address"]) {
		r.log("pppoe,ppp,info", "%s: user %s authentication failed (caller-id mismatch)", ifn, name)
		return trap("authentication failed")
	}
	for _, a := range r.list(MenuMap["/ppp/active"]) {
		if a["name"] == name {
			return trap("already connected")
		}
	}
	prof := r.byName("/ppp/profile", firstNonEmpty(sec["profile"], srv["default-profile"]))
	if prof == nil {
		prof = Item{}
	}
	local := firstNonEmpty(sec["local-address"], prof["local-address"])
	if p := r.byName("/ip/pool", local); p != nil {
		local = s.allocIP(local, "ppp", name)
	}
	remote := firstNonEmpty(sec["remote-address"], prof["remote-address"])
	remote = s.allocIP(remote, "ppp", name)
	s.sessSeq++
	act, _ := r.addItem(MenuMap["/ppp/active"], map[string]string{"name": name, "service": "pppoe", "caller-id": c["mac-address"], "encoding": "", "address": remote, "uptime": "0s", "session-id": fmt.Sprintf("0x%X", s.sessSeq), "limit-bytes-in": sec["limit-bytes-in"], "limit-bytes-out": sec["limit-bytes-out"], "radius": "false", "_client": c[".id"], "_local": local}, true)
	r.addItem(MenuMap["/interface"], map[string]string{"name": ifn, "type": "pppoe-in", "mtu": "1480", "actual-mtu": "1480", "user": name, "service": "pppoe", "remote-address": remote, "mru": "1480", "encoding": "", "uptime": "0s", "running": "true", "dynamic": "true", "_ppp": act[".id"]}, true)
	if local != "" {
		r.addItem(MenuMap["/ip/address"], map[string]string{"address": local + "/32", "network": remote, "interface": ifn, "dynamic": "true", "_ppp": act[".id"]}, true)
	}
	if rl := prof["rate-limit"]; rl != "" {
		r.addItem(MenuMap["/queue/simple"], map[string]string{"name": ifn, "target": ifn, "max-limit": rl, "dynamic": "true", "_ppp": act[".id"]}, true)
	}
	sec["last-caller-id"] = c["mac-address"]
	r.log("pppoe,ppp,info", "%s: waiting for packets...", ifn)
	r.log("pppoe,ppp,info,account", "%s logged in, %s from %s", name, remote, c["mac-address"])
	r.log("pppoe,ppp,info", "%s: authenticated", ifn)
	r.log("pppoe,ppp,info", "%s: connected", ifn)
	c["status"] = "connected"
	c["address"] = remote
	if prof["on-up"] != "" {
		s.pending = append(s.pending, scriptJob{src: prof["on-up"], user: "admin", name: "ppp on-up"})
	}
	return nil
}

func (s *Sim) pppDisconnect(a Item, reason string) {
	r := s.r
	id := a[".id"]
	ifn := "<pppoe-" + a["name"] + ">"
	r.removeItem(MenuMap["/ppp/active"], a, true)
	r.removeWhere("/interface", func(it Item) bool { return it["_ppp"] == id })
	r.removeWhere("/ip/address", func(it Item) bool { return it["_ppp"] == id })
	r.removeWhere("/queue/simple", func(it Item) bool { return it["_ppp"] == id })
	s.freeIP(a["address"])
	if a["_local"] != "" {
		s.freeIP(a["_local"])
	}
	if sec := r.byName("/ppp/secret", a["name"]); sec != nil {
		sec["last-logged-out"] = r.now().Format("2006-01-02 15:04:05")
		sec["last-disconnect-reason"] = reason
	}
	r.log("pppoe,ppp,info", "%s: terminating... - %s", ifn, reason)
	r.log("pppoe,ppp,info,account", "%s logged out, %s", a["name"], fmtDur(time.Duration(durSecs(a["uptime"]))*time.Second))
	r.log("pppoe,ppp,info", "%s: disconnected", ifn)
	if c := r.findRef(MenuMap["/sim/client"], a["_client"]); c != nil {
		c["status"] = "connecting"
		delete(c, "address")
		s.crt(c).wait = 5 + s.rnd.Intn(10)
	}
}

// ---------------- main tick ----------------

func (s *Sim) level() float64 {
	switch s.setting("traffic-level") {
	case "low":
		return 0.4
	case "high":
		return 1.6
	case "extreme":
		return 3
	}
	return 1
}

func (s *Sim) nextPhase(rt *clientRT, usage string) {
	if usage != "" && usage != "auto" {
		rt.phase = usage
		rt.phaseLeft = 30
		return
	}
	x := s.rnd.Float64() / s.level()
	switch {
	case x < 0.12:
		rt.phase = "heavy"
	case x < 0.35:
		rt.phase = "streaming"
	case x < 0.75:
		rt.phase = "browsing"
	default:
		rt.phase = "idle"
	}
	rt.phaseLeft = 5 + s.rnd.Intn(40)
}

func phaseFrac(p string, rnd *rand.Rand) float64 {
	switch p {
	case "idle":
		return 0.002 + rnd.Float64()*0.02
	case "browsing":
		return 0.03 + rnd.Float64()*0.25
	case "streaming":
		return 0.35 + rnd.Float64()*0.35
	case "heavy":
		return 0.7 + rnd.Float64()*0.3
	}
	return 0.1
}

func addInt(it Item, k string, d int64) {
	n, _ := strconv.ParseInt(it[k], 10, 64)
	it[k] = strconv.FormatInt(n+d, 10)
}

func addPair(it Item, k string, a, b int64) {
	p := strings.SplitN(it[k], "/", 2)
	x, _ := strconv.ParseInt(p[0], 10, 64)
	var y int64
	if len(p) == 2 {
		y, _ = strconv.ParseInt(p[1], 10, 64)
	}
	it[k] = fmt.Sprintf("%d/%d", x+a, y+b)
}

func (s *Sim) step() {
	r := s.r
	s.tick++
	s.updateLinks()
	set := r.single("/sim/settings")
	clients := r.list(MenuMap["/sim/client"])
	wan := s.wanUp()

	// ---- auto population ----
	s.autoClients(set, clients)
	clients = r.list(MenuMap["/sim/client"])

	// ---- per-client traffic ----
	type agg struct{ rx, tx float64 }
	ports := map[string]*agg{}
	lifs := map[string]*agg{}
	addA := func(m map[string]*agg, k string, rx, tx float64) {
		a := m[k]
		if a == nil {
			a = &agg{}
			m[k] = a
		}
		a.rx += rx
		a.tx += tx
	}
	var inetDown, inetUp float64
	byIP := map[string][2]float64{}
	actByMAC := map[string]Item{}
	for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
		actByMAC[strings.ToUpper(a["mac-address"])] = a
	}
	pppByClient := map[string]Item{}
	for _, a := range r.list(MenuMap["/ppp/active"]) {
		pppByClient[a["_client"]] = a
	}
	hostByMAC := map[string]Item{}
	for _, h := range r.list(MenuMap["/ip/hotspot/host"]) {
		hostByMAC[strings.ToUpper(h["mac-address"])] = h
	}
	for _, c := range clients {
		rt := s.crt(c)
		if c["status"] != "connected" {
			rt.down, rt.up = 0, 0
			continue
		}
		rt.phaseLeft--
		if rt.phaseLeft <= 0 {
			s.nextPhase(rt, c["usage"])
		}
		capDown, capUp := 50e6, 20e6
		internet := true
		mac := strings.ToUpper(c["mac-address"])
		act := actByMAC[mac]
		host := hostByMAC[mac]
		pa := pppByClient[c[".id"]]
		switch {
		case pa != nil:
			capDown, capUp = 10e6, 10e6
			if sec := r.byName("/ppp/secret", pa["name"]); sec != nil {
				if p := r.byName("/ppp/profile", sec["profile"]); p != nil && p["rate-limit"] != "" {
					rx, tx := parsePair(p["rate-limit"])
					capUp, capDown = float64(rx), float64(tx)
				}
			}
		case host != nil && !host.B("authorized"):
			capDown, capUp = 25e3, 8e3 // captive portal probes only
			internet = false
		case act != nil:
			capDown, capUp = 10e6, 5e6
			if u := r.byName("/ip/hotspot/user", act["user"]); u != nil {
				if p := r.byName("/ip/hotspot/user/profile", u["profile"]); p != nil && p["rate-limit"] != "" {
					rx, tx := parsePair(p["rate-limit"])
					capUp, capDown = float64(rx), float64(tx)
				}
			}
		case c["kind"] == "tv":
			capDown, capUp = 25e6, 2e6
		case c["kind"] == "iot":
			capDown, capUp = 2e6, 1e6
		}
		if internet && !wan {
			capDown, capUp = 3e3, 2e3
		}
		f := phaseFrac(rt.phase, s.rnd) * s.level()
		if f > 0.98 {
			f = 0.98
		}
		down := capDown * f * (0.85 + s.rnd.Float64()*0.3)
		if down > capDown {
			down = capDown
		}
		up := down * (0.04 + s.rnd.Float64()*0.12)
		if up > capUp {
			up = capUp
		}
		if c["kind"] == "router" {
			if v, ok := r.labRate[mac]; ok {
				down, up = min(v[0], capDown), min(v[1], capUp)
				if internet && !wan {
					down, up = min(down, 3e3), min(up, 2e3)
				}
			}
		}
		if c["status"] == "blocked" {
			down, up = 0, 0
		}
		rt.down, rt.up = down, up
		bd, bu := int64(down/8), int64(up/8)
		addA(ports, c["port"], up, down)
		if pa != nil {
			addA(lifs, "<pppoe-"+pa["name"]+">", up, down)
			addA(lifs, c["interface"], up*0.02+400, down*0.02+400) // PPPoE discovery/LCP overhead seen on bridge
		} else {
			addA(lifs, c["interface"], up, down)
		}
		if internet {
			inetDown += down
			inetUp += up
		}
		byIP[c["address"]] = [2]float64{up, down}
		if act != nil {
			addInt(act, "bytes-out", bd)
			addInt(act, "bytes-in", bu)
			addInt(act, "packets-out", bd/1200+1)
			addInt(act, "packets-in", bu/150+1)
			act["uptime"] = fmtDur(time.Duration(durSecs(act["uptime"])+1) * time.Second)
			if u := r.byName("/ip/hotspot/user", act["user"]); u != nil {
				addInt(u, "bytes-out", bd)
				addInt(u, "bytes-in", bu)
				addInt(u, "packets-out", bd/1200+1)
				addInt(u, "packets-in", bu/150+1)
				u["uptime"] = fmtDur(time.Duration(durSecs(u["uptime"])+1) * time.Second)
				s.checkLimits(act, u)
			}
		}
		if host != nil {
			addInt(host, "bytes-out", bd)
			addInt(host, "bytes-in", bu)
			host["uptime"] = fmtDur(time.Duration(durSecs(host["uptime"])+1) * time.Second)
		}
		if pa != nil {
			pa["uptime"] = fmtDur(time.Duration(durSecs(pa["uptime"])+1) * time.Second)
		}
	}
	// queues
	for _, q := range r.list(MenuMap["/queue/simple"]) {
		if q.B("disabled") {
			q["rate"] = "0/0"
			continue
		}
		var up, down float64
		for _, t := range strings.Split(q["target"], ",") {
			if strings.HasPrefix(t, "<pppoe-") {
				if a := lifs[t]; a != nil {
					up += a.rx
					down += a.tx
				}
				continue
			}
			_, n, err := net.ParseCIDR(t)
			if err != nil {
				continue
			}
			for ip, v := range byIP {
				if x := net.ParseIP(ip); x != nil && n.Contains(x) {
					up += v[0]
					down += v[1]
				}
			}
		}
		mu, md := parsePair(q["max-limit"])
		if mu > 0 && up > float64(mu) {
			up = float64(mu)
		}
		if md > 0 && down > float64(md) {
			down = float64(md)
		}
		q["rate"] = fmt.Sprintf("%d/%d", int64(up), int64(down))
		q["packet-rate"] = fmt.Sprintf("%d/%d", int64(up/1200), int64(down/1200))
		addPair(q, "bytes", int64(up/8), int64(down/8))
		addPair(q, "packets", int64(up/9600), int64(down/9600))
		addInt(q, "total-bytes", int64((up+down)/8))
		addInt(q, "total-packets", int64((up+down)/9600))
	}

	// ---- interfaces ----
	totalMbps := 0.0
	for _, it := range r.list(MenuMap["/interface"]) {
		name := it["name"]
		rt := s.rate(name)
		var rx, tx float64
		if !it.B("running") || it.B("disabled") {
			rt.RxBps, rt.TxBps, rt.RxPps, rt.TxPps = 0, 0, 0, 0
			continue
		}
		switch it["type"] {
		case "ether", "wlan", "wifi":
			if a := ports[name]; a != nil {
				rx, tx = a.rx, a.tx
			}
			if name == "ether1" || (it["type"] == "ether" && s.isWAN(name)) {
				rx += inetDown*1.03 + 8e3 + s.rnd.Float64()*12e3
				tx += inetUp*1.03 + 4e3 + s.rnd.Float64()*6e3
			} else {
				rx += 800 + s.rnd.Float64()*2500
				tx += 1200 + s.rnd.Float64()*3000
			}
		case "bridge", "pppoe-in", "vlan":
			if a := lifs[name]; a != nil {
				rx, tx = a.rx, a.tx
			}
			if it["type"] == "bridge" {
				rx += 600 + s.rnd.Float64()*1500
				tx += 900 + s.rnd.Float64()*1500
			}
		default:
			rx = s.rnd.Float64() * 500
			tx = s.rnd.Float64() * 500
		}
		rt.RxBps, rt.TxBps = rx, tx
		rt.RxPps, rt.TxPps = rx/8/900, tx/8/900
		addInt(it, "rx-byte", int64(rx/8))
		addInt(it, "tx-byte", int64(tx/8))
		addInt(it, "rx-packet", int64(rt.RxPps)+1)
		addInt(it, "tx-packet", int64(rt.TxPps)+1)
		addInt(it, "fp-rx-byte", int64(rx/8*0.9))
		addInt(it, "fp-tx-byte", int64(tx/8*0.9))
		addInt(it, "fp-rx-packet", int64(rt.RxPps*0.9))
		addInt(it, "fp-tx-packet", int64(rt.TxPps*0.9))
		if it["type"] == "pppoe-in" {
			it["uptime"] = fmtDur(time.Duration(durSecs(it["uptime"])+1) * time.Second)
		}
		if it["type"] == "ether" {
			totalMbps += (rx + tx) / 1e6
		}
	}
	// wireless registration counters
	for _, w := range append(append([]Item(nil), r.list(MenuMap["/interface/wireless/registration-table"])...), r.list(MenuMap["/interface/wifi/registration-table"])...) {
		t0, _ := strconv.ParseInt(w["_t0"], 10, 64)
		w["uptime"] = fmtDur(time.Duration(time.Now().Unix()-t0) * time.Second)
		w["last-activity"] = fmt.Sprintf("%dms", 10+s.rnd.Intn(800))
		if c := r.findRef(MenuMap["/sim/client"], w["_client"]); c != nil {
			rt := s.crt(c)
			p := strings.Split(w["bytes"], ",")
			a, _ := strconv.ParseInt(p[0], 10, 64)
			b := int64(0)
			if len(p) > 1 {
				b, _ = strconv.ParseInt(p[1], 10, 64)
			}
			w["bytes"] = fmt.Sprintf("%d,%d", a+int64(rt.up/8), b+int64(rt.down/8))
		}
	}

	// ---- firewall counters ----
	fwd := (inetDown + inetUp) / 8
	for _, path := range []string{"/ip/firewall/filter", "/ip/firewall/nat", "/ip/firewall/mangle", "/ip/firewall/raw"} {
		for _, rule := range r.list(MenuMap[path]) {
			if rule.B("disabled") {
				continue
			}
			w := 0.0005 * s.rnd.Float64()
			cs := rule["connection-state"]
			switch {
			case rule["action"] == "fasttrack-connection":
				w = 0.86
			case rule["chain"] == "forward" && strings.Contains(cs, "established"):
				w = 0.12
			case rule["chain"] == "input" && strings.Contains(cs, "established"):
				w = 0.004
			case rule["chain"] == "srcnat":
				w = 0.002
			case rule["protocol"] == "icmp":
				w = 0.0002
			case rule["action"] == "drop" && s.rnd.Intn(8) != 0:
				w = 0
			}
			b := int64(fwd*w) + int64(s.rnd.Intn(3))*60
			if b > 0 {
				addInt(rule, "bytes", b)
				addInt(rule, "packets", b/700+1)
			}
		}
	}

	// ---- system ----
	capMbps := r.Model.CapMbps
	if capMbps == 0 {
		capMbps = 1000
	}
	sessions := len(r.list(MenuMap["/ip/hotspot/active"])) + len(r.list(MenuMap["/ppp/active"]))
	target := 1.5 + totalMbps/capMbps*70 + float64(sessions)*0.25 + s.rnd.Float64()*3
	if s.tick%37 == 0 {
		target += 15 + s.rnd.Float64()*15
	}
	s.cpu = s.cpu*0.6 + target*0.4
	if s.cpu > 100 {
		s.cpu = 100
	}
	s.updateCPU()
	s.updateHealth()

	// ---- leases / cookies / dhcp client ----
	now := time.Now().Unix()
	for _, l := range r.list(MenuMap["/ip/dhcp-server/lease"]) {
		if e, err := strconv.ParseInt(l["_exp"], 10, 64); err == nil && l["status"] == "bound" {
			if e-now < 60 {
				if srv := r.byName("/ip/dhcp-server", l["server"]); srv != nil {
					e = now + durSecs(srv["lease-time"])
					l["_exp"] = strconv.FormatInt(e, 10)
				}
			}
			l["expires-after"] = fmtDur(time.Duration(e-now) * time.Second)
			l["last-seen"] = fmtDur(time.Duration(s.rnd.Intn(20)) * time.Second)
		} else if l["status"] != "bound" {
			l["last-seen"] = "never"
			delete(l, "expires-after")
		}
	}
	for _, ck := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/cookie"])...) {
		if e, err := strconv.ParseInt(ck["_exp"], 10, 64); err == nil {
			if e < now {
				r.removeItem(MenuMap["/ip/hotspot/cookie"], ck, true)
				continue
			}
			ck["expires-in"] = fmtDur(time.Duration(e-now) * time.Second)
		}
	}
	s.updateDHCPClient(s.physWanUp())
	if s.tick%5 == 1 {
		s.rebuildConnections()
	}
	s.netwatch()
	s.scheduler()
	for _, n := range append([]Item(nil), r.list(MenuMap["/ip/neighbor"])...) {
		age := durSecs(n["age"]) + 1
		if age > 180 {
			r.removeItem(MenuMap["/ip/neighbor"], n, true)
			continue
		}
		n["age"] = fmtDur(time.Duration(age) * time.Second)
	}
}

func (s *Sim) isWAN(name string) bool {
	for _, m := range s.r.list(MenuMap["/interface/list/member"]) {
		if m["list"] == "WAN" && m["interface"] == name {
			return true
		}
	}
	return false
}

func (s *Sim) checkLimits(act, u Item) {
	reason := ""
	if lu := durSecs(u["limit-uptime"]); lu > 0 {
		left := lu - durSecs(u["uptime"])
		act["session-time-left"] = fmtDur(time.Duration(left) * time.Second)
		if left <= 0 {
			reason = "uptime limit reached"
		}
	} else if act["session-time-left"] != "" {
		left := durSecs(act["session-time-left"]) - 1
		act["session-time-left"] = fmtDur(time.Duration(left) * time.Second)
		if left <= 0 {
			reason = "session timeout"
		}
	}
	bi, _ := strconv.ParseInt(u["bytes-in"], 10, 64)
	bo, _ := strconv.ParseInt(u["bytes-out"], 10, 64)
	if lb, _ := strconv.ParseInt(u["limit-bytes-total"], 10, 64); lb > 0 {
		act["limit-bytes-total"] = strconv.FormatInt(max64(lb-bi-bo, 0), 10)
		if bi+bo >= lb {
			reason = "traffic limit reached"
		}
	}
	if lb, _ := strconv.ParseInt(u["limit-bytes-in"], 10, 64); lb > 0 && bi >= lb {
		reason = "traffic limit reached"
	}
	if lb, _ := strconv.ParseInt(u["limit-bytes-out"], 10, 64); lb > 0 && bo >= lb {
		reason = "traffic limit reached"
	}
	if reason != "" {
		s.hotspotLogout(act, reason)
		if c := s.r.findRef(MenuMap["/sim/client"], act["_client"]); c != nil {
			s.crt(c).triedAuth = true
			s.crt(c).life = 20 + s.rnd.Intn(40)
		}
	}
}

func max64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}

func (s *Sim) autoClients(set Item, clients []Item) {
	r := s.r
	count := map[string]int{}
	for _, c := range clients {
		if c.B("dynamic") {
			count[c["_auto"]]++
		}
	}
	// LAN devices
	lanWant, _ := strconv.Atoi(set["lan-devices"])
	lanIf := ""
	if d := r.byName("/ip/dhcp-server", "defconf"); d != nil {
		lanIf = d["interface"]
	} else {
		for _, d := range r.list(MenuMap["/ip/dhcp-server"]) {
			if s.hotspotFor(d["interface"]) == nil {
				lanIf = d["interface"]
				break
			}
		}
	}
	if lanIf != "" && count["lan"] < lanWant && s.rnd.Intn(4) == 0 && s.pickPort(lanIf) != "" {
		kinds := []string{"laptop", "desktop", "tv", "phone", "iot", "laptop"}
		if c := s.newClient(kinds[s.rnd.Intn(len(kinds))], lanIf, "lan"); c != nil {
			s.clientConnect(c)
		}
	}
	if count["lan"] > lanWant {
		for _, c := range clients {
			if c["_auto"] == "lan" {
				s.removeClient(c)
				break
			}
		}
	}
	// hotspot clients
	var hsIf string
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if !h.B("disabled") {
			hsIf = h["interface"]
			break
		}
	}
	maxHS, _ := strconv.Atoi(set["max-hotspot-clients"])
	if set.B("auto-hotspot-clients") && hsIf != "" && count["hotspot"] < maxHS && s.rnd.Intn(12) == 0 {
		kinds := []string{"phone", "phone", "phone", "laptop", "tablet"}
		k := kinds[s.rnd.Intn(len(kinds))]
		if len(s.returning) > 0 && s.rnd.Intn(3) == 0 {
			ret := s.returning[0]
			s.returning = s.returning[1:]
			if c, err := r.addItem(MenuMap["/sim/client"], map[string]string{"name": ret.name, "kind": ret.kind, "mac-address": ret.mac, "interface": hsIf, "dynamic": "true", "_auto": "hotspot", "_voucher": ret.user}, true); err == nil {
				s.clientConnect(c)
			}
		} else if c := s.newClient(k, hsIf, "hotspot"); c != nil {
			s.clientConnect(c)
		}
	}
	if !set.B("auto-hotspot-clients") {
		for _, c := range clients {
			if c["_auto"] == "hotspot" {
				s.removeClient(c)
			}
		}
	}
	// PPPoE CPEs: one per secret
	if set.B("auto-pppoe-clients") {
		have := map[string]bool{}
		for _, c := range clients {
			if c["kind"] == "cpe" {
				have[c["pppoe-secret"]] = true
			}
		}
		for _, sec := range r.list(MenuMap["/ppp/secret"]) {
			if have[sec["name"]] || (sec["service"] != "any" && sec["service"] != "pppoe") {
				continue
			}
			var srv Item
			for _, p := range r.list(MenuMap["/interface/pppoe-server/server"]) {
				if !p.B("disabled") {
					srv = p
					break
				}
			}
			if srv == nil {
				break
			}
			c, err := r.addItem(MenuMap["/sim/client"], map[string]string{"name": "CPE-" + sec["name"], "kind": "cpe", "mac-address": s.randMAC("cpe"), "interface": srv["interface"], "pppoe-secret": sec["name"], "dynamic": "true", "_auto": "pppoe"}, true)
			if err == nil {
				s.clientConnect(c)
				s.crt(c).wait = 2 + s.rnd.Intn(12)
			}
			break // one per tick
		}
	}
	for _, c := range clients {
		if c["_auto"] == "pppoe" && (!set.B("auto-pppoe-clients") || r.byName("/ppp/secret", c["pppoe-secret"]) == nil) {
			s.removeClient(c)
		}
	}
	// state machines
	for _, c := range append([]Item(nil), r.list(MenuMap["/sim/client"])...) {
		rt := s.crt(c)
		if rt.wait > 0 {
			rt.wait--
		}
		switch c["status"] {
		case "link-down", "no-dhcp", "no-address":
			if rt.wait == 0 && !c.B("disabled") {
				rt.wait = 5
				s.clientConnect(c)
			}
		case "connecting":
			if rt.wait == 0 && c["kind"] == "cpe" {
				pi := r.byName("/interface", c["port"])
				if pi == nil || !pi.B("running") {
					c["status"] = "link-down"
					rt.wait = 5
				} else if err := s.pppConnect(c); err != nil {
					rt.wait = 30 + s.rnd.Intn(30)
					rt.failCount++
				}
			}
		case "connected":
			if c["_auto"] == "hotspot" {
				rt.life--
				if !rt.triedAuth && rt.wait == 0 && c["hotspot-user"] == "" && set.B("auto-login-vouchers") {
					rt.triedAuth = true
					user := c["_voucher"]
					if user == "" {
						user = s.freeVoucher()
					}
					if user != "" {
						if u := r.byName("/ip/hotspot/user", user); u != nil {
							s.hotspotLogin(c, u["name"], u["password"], "http-chap", false)
						}
					} else {
						rt.life = 30 + s.rnd.Intn(60)
					}
				}
				if rt.life <= 0 {
					if u := c["hotspot-user"]; u != "" {
						if uu := r.byName("/ip/hotspot/user", u); uu != nil {
							s.returning = append(s.returning, returning{user: u, pass: uu["password"], mac: c["mac-address"], name: c["name"], kind: c["kind"]})
							if len(s.returning) > 20 {
								s.returning = s.returning[1:]
							}
						}
						for _, a := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
							if strings.EqualFold(a["mac-address"], c["mac-address"]) {
								s.hotspotLogout(a, "keepalive timeout")
							}
						}
					}
					s.removeClient(c)
				}
			}
		}
	}
}

// freeVoucher returns an unused, enabled hotspot user (never logged in)
func (s *Sim) freeVoucher() string {
	active := map[string]bool{}
	for _, a := range s.r.list(MenuMap["/ip/hotspot/active"]) {
		active[a["user"]] = true
	}
	var cands []string
	for _, u := range s.r.list(MenuMap["/ip/hotspot/user"]) {
		if u["_default"] == "true" || u.B("disabled") || active[u["name"]] || durSecs(u["uptime"]) > 0 {
			continue
		}
		cands = append(cands, u["name"])
	}
	if len(cands) == 0 {
		return ""
	}
	return cands[s.rnd.Intn(len(cands))]
}

func (s *Sim) updateCPU() {
	r := s.r
	t := r.tbl("/system/resource/cpu")
	if len(t.Items) != r.Model.Cores {
		t.Items = nil
		for i := 0; i < r.Model.Cores; i++ {
			t.Items = append(t.Items, Item{".id": fmt.Sprintf("*%d", i), "cpu": fmt.Sprintf("cpu%d", i), "dynamic": "true"})
		}
	}
	for i, it := range t.Items {
		v := s.cpu * (0.6 + 0.8*s.rnd.Float64())
		if i == 0 {
			v += 2
		}
		v = math.Min(100, math.Max(0, v))
		it["load"] = strconv.Itoa(int(v))
		it["irq"] = strconv.Itoa(int(v * 0.3))
		it["disk"] = "0"
	}
}

func (s *Sim) updateHealth() {
	r := s.r
	t := r.tbl("/system/health")
	temp := 36 + s.cpu*0.18 + s.rnd.Float64()
	vals := [][3]string{{"voltage", fmt.Sprintf("%.1f", 24.0+s.rnd.Float64()*0.3), "V"}, {"temperature", fmt.Sprintf("%.0f", temp), "C"}, {"cpu-temperature", fmt.Sprintf("%.0f", temp+6), "C"}}
	switch r.Model.Family {
	case "ccr":
		vals = append(vals, [3]string{"fan1-speed", fmt.Sprint(4200 + s.rnd.Intn(200)), "RPM"}, [3]string{"fan2-speed", fmt.Sprint(4100 + s.rnd.Intn(200)), "RPM"}, [3]string{"psu1-state", "ok", ""}, [3]string{"psu2-state", "ok", ""})
	case "switch":
		vals = append(vals, [3]string{"poe-out-consumption", fmt.Sprintf("%.1f", 8+s.rnd.Float64()*3), "W"})
	case "virtual":
		vals = nil
	}
	if len(t.Items) != len(vals) {
		t.Items = nil
		for i, v := range vals {
			t.Items = append(t.Items, Item{".id": fmt.Sprintf("*%X", i+1), "name": v[0], "dynamic": "true"})
		}
	}
	for i, v := range vals {
		t.Items[i]["value"] = v[1]
		t.Items[i]["type"] = v[2]
	}
}

func (s *Sim) updateDHCPClient(wan bool) {
	r := s.r
	host := hostNet()
	for _, dc := range r.list(MenuMap["/ip/dhcp-client"]) {
		up := !dc.B("disabled") && wan && r.byName("/interface", dc["interface"]) != nil && r.byName("/interface", dc["interface"]).B("running")
		var lease *labLease
		if r.lab != nil {
			if ls, ok := r.lab.dhcp[dc["interface"]]; ok {
				lease = &ls
				ifc := r.byName("/interface", dc["interface"])
				up = !dc.B("disabled") && ifc != nil && ifc.B("running") && ls.Mode != "none" && ls.Addr != ""
			}
		}
		var addrItem Item
		for _, a := range r.list(MenuMap["/ip/address"]) {
			if a["_dhcpc"] == dc[".id"] {
				addrItem = a
			}
		}
		if !up {
			if dc["status"] == "bound" {
				r.log("dhcp,info", "dhcp-client on %s lost IP address %s", dc["interface"], dc["address"])
			}
			dc["status"] = "searching..."
			delete(dc, "address")
			delete(dc, "gateway")
			if addrItem != nil {
				r.removeItem(MenuMap["/ip/address"], addrItem, true)
			}
			r.removeWhere("/ip/route", func(it Item) bool { return it["_dhcpc"] == dc[".id"] })
			continue
		}
		addr := host.String()
		if dc["_override"] != "" {
			addr = dc["_override"]
		}
		gw := hostGateway(host)
		dns := gw
		if lease != nil {
			addr, gw, dns = lease.Addr, lease.GW, firstNonEmpty(lease.DNS, lease.GW)
		}
		if dc["status"] != "bound" || dc["address"] != addr {
			if addrItem != nil {
				r.removeItem(MenuMap["/ip/address"], addrItem, true)
			}
			r.removeWhere("/ip/route", func(it Item) bool { return it["_dhcpc"] == dc[".id"] })
			dc["status"] = "bound"
			dc["address"] = addr
			dc["gateway"] = gw
			dc["dhcp-server"] = gw
			dc["primary-dns"] = dns
			dc["secondary-dns"] = "8.8.8.8"
			dc["_exp"] = strconv.FormatInt(time.Now().Unix()+86400, 10)
			r.addItem(MenuMap["/ip/address"], map[string]string{"address": addr, "interface": dc["interface"], "dynamic": "true", "_dhcpc": dc[".id"]}, true)
			if dc["add-default-route"] != "no" {
				r.addItem(MenuMap["/ip/route"], map[string]string{"dst-address": "0.0.0.0/0", "gateway": gw, "distance": dc["default-route-distance"], "dynamic": "true", "dhcp": "true", "static": "false", "active": "true", "_dhcpc": dc[".id"]}, true)
			}
			if dc.B("use-peer-dns") {
				r.single("/ip/dns")["dynamic-servers"] = dns
			}
			r.log("dhcp,info", "dhcp-client on %s got IP address %s", dc["interface"], addr)
			r.rebuildRoutes()
		}
		e, _ := strconv.ParseInt(dc["_exp"], 10, 64)
		dc["expires-after"] = fmtDur(time.Duration(e-time.Now().Unix()) * time.Second)
	}
	cloud := r.single("/ip/cloud")
	if wan {
		cloud["status"] = "updated"
		cloud["public-address"] = "41.223.212." + fmt.Sprint(10+int(r.baseMAC[5])%200)
	} else {
		cloud["status"] = "unknown"
		delete(cloud, "public-address")
	}
}

var publicDsts = []string{"142.250.185.78", "157.240.1.35", "31.13.66.4", "104.18.32.7", "172.217.16.142", "52.95.110.1", "13.107.42.14", "185.60.216.35", "151.101.1.140", "23.211.124.65"}

func (s *Sim) rebuildConnections() {
	r := s.r
	t := r.tbl("/ip/firewall/connection")
	t.Items = nil
	for _, c := range r.list(MenuMap["/sim/client"]) {
		if c["status"] != "connected" || c["address"] == "" {
			continue
		}
		rt := s.crt(c)
		n := 1 + s.rnd.Intn(4)
		if rt.phase == "idle" {
			n = 1
		}
		for i := 0; i < n; i++ {
			dst := publicDsts[s.rnd.Intn(len(publicDsts))]
			proto, port := "tcp", "443"
			if s.rnd.Intn(5) == 0 {
				proto, port = "udp", "443"
			}
			sp := 32768 + s.rnd.Intn(28000)
			wan := r.byName("/ip/dhcp-client", "")
			_ = wan
			share := float64(n)
			t.Items = append(t.Items, Item{".id": r.newID("/ip/firewall/connection"), "protocol": proto, "src-address": fmt.Sprintf("%s:%d", c["address"], sp), "dst-address": dst + ":" + port, "reply-src-address": dst + ":" + port, "reply-dst-address": fmt.Sprintf("%s:%d", hostNet().String(), sp),
				"tcp-state": map[bool]string{true: "established", false: ""}[proto == "tcp"], "timeout": fmtDur(time.Duration(86000+s.rnd.Intn(400)) * time.Second), "orig-bytes": fmt.Sprint(s.rnd.Intn(900000)), "repl-bytes": fmt.Sprint(s.rnd.Intn(9000000)),
				"orig-packets": fmt.Sprint(s.rnd.Intn(5000)), "repl-packets": fmt.Sprint(s.rnd.Intn(9000)), "orig-rate": fmt.Sprint(int64(rt.up / share)), "repl-rate": fmt.Sprint(int64(rt.down / share)), "assured": "true", "confirmed": "true", "seen-reply": "true", "srcnat": "true", "fasttrack": "true", "dynamic": "true"})
		}
		if len(t.Items) > 300 {
			break
		}
	}
}

// reachability used by ping / netwatch
func (s *Sim) reach(addr string) (bool, float64, int) {
	r := s.r
	ip := net.ParseIP(addr)
	if ip == nil {
		return false, 0, 0
	}
	if ip.IsLoopback() {
		return true, 0.05, 64
	}
	for _, a := range r.list(MenuMap["/ip/address"]) {
		if strings.Split(a["address"], "/")[0] == addr {
			return true, 0.08, 64
		}
	}
	for _, c := range r.list(MenuMap["/sim/client"]) {
		if c["address"] == addr && c["status"] == "connected" {
			base := 0.6
			if p := r.byName("/interface", c["port"]); p != nil && p["type"] == "wlan" {
				base = 3
			}
			return true, base + s.rnd.Float64()*3, 64
		}
	}
	for _, rt := range r.list(MenuMap["/ip/route"]) {
		if !rt.B("connect") {
			continue
		}
		if _, n, err := net.ParseCIDR(rt["dst-address"]); err == nil && n.Contains(ip) {
			if hostNet().String() != "" && strings.HasPrefix(rt["gateway"], "ether1") {
				return true, 0.5 + s.rnd.Float64(), 64 // host LAN
			}
			return false, 0, 0
		}
	}
	if ip.IsPrivate() {
		return false, 0, 0
	}
	if !s.wanUp() {
		return false, 0, 0
	}
	h := md5.Sum([]byte(addr))
	base := 8 + float64(h[0])/255*90
	return s.rnd.Intn(100) != 0, base + s.rnd.Float64()*6, 117 - int(h[1]%20)
}

func (s *Sim) netwatch() {
	r := s.r
	for _, n := range r.list(MenuMap["/tool/netwatch"]) {
		if n.B("disabled") {
			n["status"] = "unknown"
			continue
		}
		iv := durSecs(n["interval"])
		if iv <= 0 {
			iv = 10
		}
		if s.tick%int(iv) != 0 && n["status"] != "unknown" {
			continue
		}
		host := n["host"]
		if ips, err := net.LookupIP(host); net.ParseIP(host) == nil && err == nil && len(ips) > 0 {
			host = ips[0].String()
		}
		ok, _, _ := s.reach(host)
		st := map[bool]string{true: "up", false: "down"}[ok]
		if n["status"] != st {
			n["status"] = st
			n["since"] = r.now().Format("2006-01-02 15:04:05")
			r.log("netwatch,info", "event %s [ type: %s, host: %s ]", st, n["type"], n["host"])
			if sc := n[st+"-script"]; sc != "" {
				s.pending = append(s.pending, scriptJob{src: sc, user: "admin", name: "netwatch"})
			}
		}
	}
}

func (s *Sim) scheduler() {
	r := s.r
	for _, j := range r.list(MenuMap["/system/scheduler"]) {
		if j.B("disabled") {
			continue
		}
		iv := durSecs(j["interval"])
		run := false
		if j["start-time"] == "startup" && j["_ran"] == "" && s.tick == 3 {
			run = true
			j["_ran"] = "1"
		}
		if iv > 0 && s.tick > 3 && s.tick%int(iv) == 0 {
			run = true
		}
		if iv > 0 {
			j["next-run"] = r.now().Add(time.Duration(iv-int64(s.tick)%iv) * time.Second).Format("2006-01-02 15:04:05")
		}
		if run {
			addInt(j, "run-count", 1)
			src := j["on-event"]
			name := ""
			if sc := r.byName("/system/script", strings.TrimSpace(src)); sc != nil {
				addInt(sc, "run-count", 1)
				sc["last-started"] = r.now().Format("2006-01-02 15:04:05")
				src, name = sc["source"], sc["name"]
			}
			s.pending = append(s.pending, scriptJob{src: src, user: firstNonEmpty(j["owner"], "admin"), name: name})
		}
	}
}

// ---------------- power ----------------

func (r *Router) clearDynamic() {
	for _, p := range []string{"/ip/hotspot/active", "/ip/hotspot/host", "/ppp/active", "/ip/arp", "/interface/bridge/host", "/interface/wireless/registration-table", "/interface/wifi/registration-table", "/ip/pool/used", "/user/active", "/ip/firewall/connection", "/ip/neighbor", "/ip/hotspot/cookie"} {
		keep := []Item{}
		for _, it := range r.tbl(p).Items {
			if p == "/ip/arp" && !it.B("dynamic") || p == "/ip/hotspot/cookie" {
				keep = append(keep, it)
			}
		}
		r.tbl(p).Items = keep
	}
	for _, p := range []string{"/interface", "/ip/address", "/ip/route", "/queue/simple", "/ip/dhcp-server/lease", "/sim/client", "/ip/firewall/address-list"} {
		var keep []Item
		for _, it := range r.tbl(p).Items {
			if it.B("dynamic") {
				continue
			}
			keep = append(keep, it)
		}
		r.tbl(p).Items = keep
	}
	for _, l := range r.tbl("/ip/dhcp-server/lease").Items {
		l["status"] = "waiting"
	}
	for _, c := range r.tbl("/sim/client").Items {
		c["status"] = "disconnected"
		delete(c, "address")
		delete(c, "hotspot-user")
	}
	for _, it := range r.tbl("/ip/dhcp-client").Items {
		it["status"] = "stopped"
	}
	for _, it := range r.tbl("/interface").Items {
		resetCounters(MenuMap["/interface"], it)
		it["running"] = "false"
		it["link-downs"] = "0"
	}
	for _, p := range []string{"/ip/firewall/filter", "/ip/firewall/nat", "/ip/firewall/mangle", "/ip/firewall/raw", "/queue/simple", "/queue/tree"} {
		for _, it := range r.tbl(p).Items {
			resetCounters(MenuMap[p], it)
		}
	}
	r.T["/log"] = &Table{Next: r.tbl("/log").Next}
	if r.sim != nil {
		r.sim.rt = map[string]*clientRT{}
		r.sim.rates = map[string]*Rate{}
		r.sim.tick = 0
	}
	r.rebuildRoutes()
}

// powerCycle: mode reboot | shutdown | reset
func (r *Router) powerCycle(mode string) {
	r.mu.Lock()
	if r.state != "running" && mode != "poweron" {
		r.mu.Unlock()
		return
	}
	if mode != "poweron" {
		r.log("system,info", "%s", map[string]string{"reboot": "system reboot requested", "shutdown": "system shutdown requested", "reset": "configuration reset requested"}[mode])
	}
	r.state = "booting"
	if mode == "shutdown" {
		r.state = "off"
	}
	r.cancelJobs()
	r.gmu.Lock()
	r.globals = nil
	r.gmu.Unlock()
	r.epoch++
	r.markDirty()
	kick := make([]func(), 0, len(r.kickers))
	for _, k := range r.kickers {
		kick = append(kick, k)
	}
	r.mu.Unlock()
	r.save()
	for _, k := range kick {
		k()
	}
	r.mu.Lock()
	if mode == "reset" {
		keep := map[string]*Table{}
		keepPaths := []string{"/ip/service"}
		if r.pendingModel != "" && r.pendingKeep {
			keepPaths = append(keepPaths, modelKeepPaths...)
		}
		for _, p := range keepPaths {
			if t := r.T[p]; t != nil {
				nt := &Table{Next: t.Next}
				for _, it := range t.Items {
					if !it.B("dynamic") {
						nt.Items = append(nt.Items, it)
					}
				}
				keep[p] = nt
			}
		}
		if r.pendingModel != "" {
			if m := lookupModel(r.pendingModel); m != nil {
				mc := *m
				mc.Serial = r.Model.Serial
				r.Model = &mc
			}
			r.log("system,info", "router model changed")
		}
		r.pendingModel = ""
		r.factoryDefaults(r.Opt.Password)
		for p, t := range keep {
			r.T[p] = t
		}
		r.syncSimPorts()
		r.syncServices()
	}
	r.clearDynamic()
	bt := durSecs(r.S("/sim/settings", "boot-time"))
	r.mu.Unlock()
	if mode == "shutdown" {
		return
	}
	if bt < 1 {
		bt = 1
	}
	time.AfterFunc(time.Duration(bt)*time.Second, r.finishBoot)
}

func (r *Router) finishBoot() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.state = "running"
	r.boot = time.Now()
	r.log("system,info", "router rebooted")
	r.log("system,info", "%s", "TikLab "+AppVersion+" simulating RouterOS "+r.Ver+" on "+r.Model.Board)
	r.log("interface,info", "all interfaces initialised")
	if r.sim != nil {
		r.sim.step()
	}
}

func randB64(n int) string {
	b := make([]byte, n)
	for i := range b {
		b[i] = byte(rand.Intn(256))
	}
	return base64.StdEncoding.EncodeToString(b)
}

func timeDate(y, mo, d, h, mi, s int, ref time.Time) time.Time {
	return time.Date(y, time.Month(mo), d, h, mi, s, 0, ref.Location())
}

func parseDate(d string) (time.Time, error) {
	for _, f := range []string{"2006-01-02", "Jan/02/2006", "jan/02/2006", "01/02/2006"} {
		if t, err := time.Parse(f, d); err == nil {
			return t, nil
		}
	}
	if len(d) > 3 {
		if t, err := time.Parse("Jan/02/2006", strings.ToUpper(d[:1])+d[1:]); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("bad date")
}

// ---------------- host network info ----------------

var hostCache struct {
	ip  net.IP
	gw  string
	ts  time.Time
	net *net.IPNet
}

type hostAddr struct {
	ip  net.IP
	net *net.IPNet
}

func (h hostAddr) String() string {
	if h.net == nil {
		return "192.168.1.100/24"
	}
	ones, _ := h.net.Mask.Size()
	return fmt.Sprintf("%s/%d", h.ip, ones)
}

var hostCacheMu sync.Mutex

func hostNet() hostAddr {
	hostCacheMu.Lock()
	defer hostCacheMu.Unlock()
	if time.Since(hostCache.ts) < 30*time.Second && hostCache.ip != nil {
		return hostAddr{hostCache.ip, hostCache.net}
	}
	var ip net.IP
	if c, err := net.Dial("udp", "8.8.8.8:53"); err == nil {
		ip = c.LocalAddr().(*net.UDPAddr).IP
		c.Close()
	}
	var best *net.IPNet
	ifs, _ := net.Interfaces()
	for _, i := range ifs {
		if i.Flags&net.FlagUp == 0 || i.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := i.Addrs()
		for _, a := range addrs {
			if n, ok := a.(*net.IPNet); ok && n.IP.To4() != nil {
				if ip == nil || n.IP.Equal(ip) {
					best = n
					ip = n.IP
				}
			}
		}
	}
	hostCache.ip, hostCache.net, hostCache.ts = ip, best, time.Now()
	return hostAddr{ip, best}
}

func hostGateway(h hostAddr) string {
	if h.net == nil {
		return "192.168.1.1"
	}
	gw := linuxGateway()
	if gw != "" {
		return gw
	}
	n := ip2u(h.net.IP.Mask(h.net.Mask))
	return u2ip(n + 1).String()
}

// sortedNames helper
func sortedKeys(m map[string]bool) []string {
	var out []string
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
