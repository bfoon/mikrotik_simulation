package main

// RouterOS script values: str, num, bool, time, ip, ip6, ip-prefix, id,
// array, code, nil and nothing, with the conversions RouterOS applies.

import (
	"fmt"
	"math/big"
	"net"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type VK uint8

const (
	KNil VK = iota
	KNothing
	KStr
	KNum
	KBool
	KTime
	KIP
	KIP6
	KPrefix
	KID
	KArr
	KCode
)

var kindNames = [...]string{"nil", "nothing", "str", "num", "bool", "time", "ip", "ip6", "ip-prefix", "id", "array", "code"}

func (k VK) String() string { return kindNames[k] }

type Value struct {
	K VK
	S string        // str, ip, ip6, prefix, id
	N int64         // num, bool (1/0)
	D time.Duration // time
	A *Arr
	C *Code
}

// Code is a parsed script body: a do={...} block, a [:parse] result or a function.
type Code struct {
	B   *Block
	Src string
}

var (
	vNil     = Value{K: KNil}
	vNothing = Value{K: KNothing}
	vTrue    = Value{K: KBool, N: 1}
	vFalse   = Value{K: KBool}
)

func vStr(s string) Value         { return Value{K: KStr, S: s} }
func vNum(n int64) Value          { return Value{K: KNum, N: n} }
func vTime(d time.Duration) Value { return Value{K: KTime, D: d} }
func vID(s string) Value          { return Value{K: KID, S: s} }
func vArr(a *Arr) Value           { return Value{K: KArr, A: a} }
func vCode(c *Code) Value         { return Value{K: KCode, C: c} }
func vBool(b bool) Value {
	if b {
		return vTrue
	}
	return vFalse
}

func (v Value) Bool() bool { return v.K == KBool && v.N != 0 }

// Arr is a RouterOS array: positional elements followed by named ones, which
// RouterOS keeps sorted by name.
type Arr struct {
	List []Value
	Map  map[string]Value
}

func newArr(vals ...Value) *Arr { return &Arr{List: append([]Value{}, vals...)} }

func (a *Arr) Len() int {
	if a == nil {
		return 0
	}
	return len(a.List) + len(a.Map)
}

func (a *Arr) keys() []string {
	ks := make([]string, 0, len(a.Map))
	for k := range a.Map {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

// Each visits the elements in RouterOS order: positional first, then named.
func (a *Arr) Each(fn func(key Value, v Value) bool) {
	if a == nil {
		return
	}
	for i, v := range a.List {
		if !fn(vNum(int64(i)), v) {
			return
		}
	}
	for _, k := range a.keys() {
		if !fn(vStr(k), a.Map[k]) {
			return
		}
	}
}

func (a *Arr) Get(key Value) Value {
	if a == nil {
		return vNil
	}
	if key.K == KNum {
		if key.N >= 0 && int(key.N) < len(a.List) {
			return a.List[key.N]
		}
		return vNil
	}
	ks := key.String()
	if n, err := strconv.Atoi(ks); err == nil && key.K != KStr {
		if n >= 0 && n < len(a.List) {
			return a.List[n]
		}
	}
	if v, ok := a.Map[ks]; ok {
		return v
	}
	return vNil
}

func (a *Arr) Set(key Value, v Value) {
	if key.K == KNum {
		n := int(key.N)
		for len(a.List) <= n {
			a.List = append(a.List, vNil)
		}
		a.List[n] = v
		return
	}
	if a.Map == nil {
		a.Map = map[string]Value{}
	}
	a.Map[key.String()] = v
}

func (a *Arr) clone() *Arr {
	b := &Arr{List: append([]Value{}, a.List...)}
	if len(a.Map) > 0 {
		b.Map = map[string]Value{}
		for k, v := range a.Map {
			b.Map[k] = v
		}
	}
	return b
}

// ---------- formatting ----------

// fmtROSTime prints a duration the way RouterOS 7 does: 1w2d03:04:05.
func fmtROSTime(d time.Duration) string {
	neg := d < 0
	if neg {
		d = -d
	}
	ms := int64(d/time.Millisecond) % 1000
	s := int64(d / time.Second)
	w, s := s/604800, s%604800
	dd, s := s/86400, s%86400
	h, s := s/3600, s%3600
	m, s := s/60, s%60
	var b strings.Builder
	if neg {
		b.WriteByte('-')
	}
	if w > 0 {
		fmt.Fprintf(&b, "%dw", w)
	}
	if dd > 0 {
		fmt.Fprintf(&b, "%dd", dd)
	}
	fmt.Fprintf(&b, "%02d:%02d:%02d", h, m, s)
	if ms > 0 {
		fmt.Fprintf(&b, ".%03d", ms)
	}
	return b.String()
}

// String converts a value to text as RouterOS does for concatenation and :tostr.
func (v Value) String() string {
	switch v.K {
	case KNil, KNothing:
		return ""
	case KStr, KIP, KIP6, KPrefix, KID:
		return v.S
	case KNum:
		return strconv.FormatInt(v.N, 10)
	case KBool:
		if v.N != 0 {
			return "true"
		}
		return "false"
	case KTime:
		return fmtROSTime(v.D)
	case KArr:
		var parts []string
		v.A.Each(func(k, x Value) bool {
			if k.K == KStr {
				parts = append(parts, k.S+"="+x.String())
			} else {
				parts = append(parts, x.String())
			}
			return true
		})
		return strings.Join(parts, ";")
	case KCode:
		if v.C != nil {
			return v.C.Src
		}
	}
	return ""
}

// argString converts a value for use as a command argument: arrays become
// comma-separated lists and times use the compact 1h30m form.
func (v Value) argString() string {
	switch v.K {
	case KArr:
		var parts []string
		v.A.Each(func(_, x Value) bool { parts = append(parts, x.argString()); return true })
		return strings.Join(parts, ",")
	case KTime:
		if v.D == 0 {
			return "0s"
		}
		return fmtDur(v.D)
	case KBool:
		if v.N != 0 {
			return "yes"
		}
		return "no"
	}
	return v.String()
}

// ---------- typing of literal words ----------

var (
	reNum     = regexp.MustCompile(`^-?[0-9]+$`)
	reHexNum  = regexp.MustCompile(`^0x[0-9a-fA-F]+$`)
	reTimeU   = regexp.MustCompile(`^(?:[0-9]+w)?(?:[0-9]+d)?(?:[0-9]+h)?(?:[0-9]+m)?(?:[0-9]+(?:\.[0-9]+)?s)?(?:[0-9]+ms)?$`)
	reTimeC   = regexp.MustCompile(`^(?:([0-9]+)w)?(?:([0-9]+)d)?([0-9]{1,2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,3}))?$`)
	reIPv4    = regexp.MustCompile(`^[0-9]{1,3}(?:\.[0-9]{1,3}){3}$`)
	rePrefix4 = regexp.MustCompile(`^[0-9]{1,3}(?:\.[0-9]{1,3}){3}/[0-9]{1,2}$`)
	reID      = regexp.MustCompile(`^\*[0-9A-Fa-f]+$`)
)

// parseROSTime reads 1w2d3h4m5s, 500ms, 01:02:03 or 1d02:03:04.
func parseROSTime(s string) (time.Duration, bool) {
	s = strings.TrimSpace(s)
	neg := strings.HasPrefix(s, "-")
	s = strings.TrimPrefix(s, "-")
	if s == "" {
		return 0, false
	}
	var d time.Duration
	if m := reTimeC.FindStringSubmatch(s); m != nil {
		at := func(i int) int64 { n, _ := strconv.ParseInt(m[i], 10, 64); return n }
		d = time.Duration(at(1))*7*24*time.Hour + time.Duration(at(2))*24*time.Hour + time.Duration(at(3))*time.Hour + time.Duration(at(4))*time.Minute + time.Duration(at(5))*time.Second
		if m[6] != "" {
			ms, _ := strconv.Atoi((m[6] + "00")[:3])
			d += time.Duration(ms) * time.Millisecond
		}
	} else if reTimeU.MatchString(s) && !reNum.MatchString(s) {
		rest := s
		for rest != "" {
			i := 0
			for i < len(rest) && (rest[i] >= '0' && rest[i] <= '9' || rest[i] == '.') {
				i++
			}
			if i == 0 {
				return 0, false
			}
			num, _ := strconv.ParseFloat(rest[:i], 64)
			rest = rest[i:]
			unit := time.Second
			switch {
			case strings.HasPrefix(rest, "ms"):
				unit, rest = time.Millisecond, rest[2:]
			case strings.HasPrefix(rest, "w"):
				unit, rest = 7*24*time.Hour, rest[1:]
			case strings.HasPrefix(rest, "d"):
				unit, rest = 24*time.Hour, rest[1:]
			case strings.HasPrefix(rest, "h"):
				unit, rest = time.Hour, rest[1:]
			case strings.HasPrefix(rest, "m"):
				unit, rest = time.Minute, rest[1:]
			case strings.HasPrefix(rest, "s"):
				rest = rest[1:]
			default:
				return 0, false
			}
			d += time.Duration(num * float64(unit))
		}
	} else {
		return 0, false
	}
	if neg {
		d = -d
	}
	return d, true
}

// typeWord gives an unquoted word its RouterOS type.
func typeWord(s string) Value {
	switch {
	case s == "true":
		return vTrue
	case s == "false":
		return vFalse
	case reNum.MatchString(s):
		if n, err := strconv.ParseInt(s, 10, 64); err == nil {
			return vNum(n)
		}
	case reHexNum.MatchString(s):
		if n, err := strconv.ParseInt(s[2:], 16, 64); err == nil {
			return vNum(n)
		}
	case reIPv4.MatchString(s) && net.ParseIP(s) != nil:
		return Value{K: KIP, S: s}
	case rePrefix4.MatchString(s):
		if _, _, err := net.ParseCIDR(s); err == nil {
			return Value{K: KPrefix, S: s}
		}
	case reID.MatchString(s):
		return vID(strings.ToUpper(s[:1]) + strings.ToUpper(s[1:]))
	}
	if d, ok := parseROSTime(s); ok && (strings.ContainsAny(s, "wdhms:")) {
		return vTime(d)
	}
	if strings.Contains(s, ":") {
		if ip := net.ParseIP(s); ip != nil && ip.To4() == nil {
			return Value{K: KIP6, S: s}
		}
	}
	return vStr(s)
}

// ---------- conversions ----------

func toNum(v Value) (int64, bool) {
	switch v.K {
	case KNum, KBool:
		return v.N, true
	case KTime:
		return int64(v.D / time.Second), true
	case KStr:
		s := strings.TrimSpace(v.S)
		if n, err := strconv.ParseInt(s, 10, 64); err == nil {
			return n, true
		}
		if reHexNum.MatchString(s) {
			n, err := strconv.ParseInt(s[2:], 16, 64)
			return n, err == nil
		}
	case KIP:
		if ip := net.ParseIP(v.S).To4(); ip != nil {
			return int64(ip[0])<<24 | int64(ip[1])<<16 | int64(ip[2])<<8 | int64(ip[3]), true
		}
	}
	return 0, false
}

func toTime(v Value) (time.Duration, bool) {
	switch v.K {
	case KTime:
		return v.D, true
	case KNum:
		return time.Duration(v.N) * time.Second, true
	case KStr:
		if n, err := strconv.ParseInt(strings.TrimSpace(v.S), 10, 64); err == nil {
			return time.Duration(n) * time.Second, true
		}
		return parseROSTime(v.S)
	}
	return 0, false
}

func toBoolV(v Value) (bool, bool) {
	switch v.K {
	case KBool:
		return v.N != 0, true
	case KStr:
		switch strings.ToLower(strings.TrimSpace(v.S)) {
		case "true", "yes":
			return true, true
		case "false", "no":
			return false, true
		}
	case KNum:
		return v.N != 0, true
	}
	return false, false
}

// truthy decides :if conditions. RouterOS wants a bool; other values are
// read leniently.
func truthy(v Value) bool {
	switch v.K {
	case KBool:
		return v.N != 0
	case KNum:
		return v.N != 0
	case KStr:
		b, ok := toBoolV(v)
		if ok {
			return b
		}
		return v.S != ""
	case KArr:
		return v.A.Len() > 0
	case KNil, KNothing:
		return false
	}
	return true
}

func toArray(v Value) *Arr {
	switch v.K {
	case KArr:
		return v.A
	case KNil, KNothing:
		return newArr()
	case KStr:
		if v.S == "" {
			return newArr()
		}
		a := newArr()
		for _, p := range strings.Split(v.S, ",") {
			a.List = append(a.List, typeWord(p))
		}
		return a
	}
	return newArr(v)
}

func ipAdd(ip string, n int64) (Value, bool) {
	p := net.ParseIP(ip).To4()
	if p == nil {
		return vNil, false
	}
	x := new(big.Int).SetBytes(p)
	x.Add(x, big.NewInt(n))
	b := x.Bytes()
	out := make([]byte, 4)
	copy(out[4-min(4, len(b)):], b[max(0, len(b)-4):])
	return Value{K: KIP, S: net.IP(out).String()}, true
}

// cmpValues compares two values for <, >, = with RouterOS's loose typing.
// ok is false when they cannot be ordered.
func cmpValues(a, b Value) (int, bool) {
	if a.K == KTime || b.K == KTime {
		x, ok1 := toTime(a)
		y, ok2 := toTime(b)
		if ok1 && ok2 {
			return cmp3(int64(x), int64(y)), true
		}
	}
	if a.K == KIP && b.K == KIP {
		x, _ := toNum(a)
		y, _ := toNum(b)
		return cmp3(x, y), true
	}
	if x, ok1 := toNum(a); ok1 && (a.K == KNum || b.K == KNum) {
		if y, ok2 := toNum(b); ok2 {
			return cmp3(x, y), true
		}
	}
	if a.K == KStr && b.K == KStr || a.K == KID || b.K == KID {
		return strings.Compare(a.String(), b.String()), true
	}
	return strings.Compare(a.String(), b.String()), a.K != KArr && b.K != KArr
}

func cmp3(a, b int64) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func valEqual(a, b Value) bool {
	if (a.K == KNil || a.K == KNothing) && (b.K == KNil || b.K == KNothing) {
		return true
	}
	if a.K == KBool || b.K == KBool {
		x, ok1 := toBoolV(a)
		y, ok2 := toBoolV(b)
		if ok1 && ok2 {
			return x == y
		}
		return false
	}
	if a.K == KArr || b.K == KArr {
		return a.String() == b.String()
	}
	if a.K == KID || b.K == KID {
		return strings.EqualFold(a.String(), b.String())
	}
	if a.K == KTime || b.K == KTime || a.K == KNum || b.K == KNum {
		if c, ok := cmpValues(a, b); ok && (a.K != KStr || b.K != KStr) {
			return c == 0
		}
	}
	if a.K == KPrefix || b.K == KPrefix {
		return normPrefix(a.String()) == normPrefix(b.String())
	}
	return a.String() == b.String()
}

func normPrefix(s string) string {
	if !strings.Contains(s, "/") && net.ParseIP(s) != nil && net.ParseIP(s).To4() != nil {
		return s + "/32"
	}
	return s
}
