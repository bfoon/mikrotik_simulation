package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"golang.org/x/crypto/ssh"
)

const AppVersion = "1.4.0"

type Options struct {
	Data, Model, Identity, Password, Bind, Version string
	Instance                                       int
	Ports                                          map[string]int
	NoBrowser, Reset, Verbose, NoMNDP              bool
}

// ---------- services (listeners that follow /ip service) ----------

type svcState struct {
	name   string
	ln     net.Listener
	srv    *http.Server
	port   int
	want   int
	status string
}

type Services struct {
	r      *Router
	web    *Web
	mu     sync.Mutex
	s      map[string]*svcState
	tlsCfg *tls.Config
	keys   []ssh.Signer
	bind   string
}

var fallback = map[int]int{80: 8080, 443: 8443, 22: 2222, 23: 2323, 21: 2121}

func (sv *Services) port(name string) int {
	if st := sv.s[name]; st != nil {
		return st.port
	}
	return 0
}

func (sv *Services) listen(want int) (net.Listener, int, error) {
	try := []int{want}
	if fb, ok := fallback[want]; ok {
		try = append(try, fb)
	}
	for i := 1; i <= 20; i++ {
		try = append(try, try[len(try)-1]+1)
	}
	var lastErr error
	for _, p := range try {
		ln, err := net.Listen("tcp", net.JoinHostPort(sv.bind, strconv.Itoa(p)))
		if err == nil {
			return ln, p, nil
		}
		lastErr = err
	}
	return nil, 0, lastErr
}

func (sv *Services) start(name string, want int) {
	sv.mu.Lock()
	defer sv.mu.Unlock()
	if old := sv.s[name]; old != nil {
		if old.srv != nil {
			old.srv.Close()
		}
		if old.ln != nil {
			old.ln.Close()
		}
	}
	st := &svcState{name: name, want: want}
	sv.s[name] = st
	ln, port, err := sv.listen(want)
	if err != nil {
		st.status = "failed: " + err.Error()
		fmt.Printf("  ! %-8s could not listen on %d: %v\n", name, want, err)
		return
	}
	st.ln, st.port, st.status = ln, port, "running"
	r := sv.r
	switch name {
	case "api":
		go serveAPI(r, ln, "api")
	case "api-ssl":
		go serveAPI(r, tls.NewListener(ln, sv.tlsCfg), "api-ssl")
	case "telnet":
		go serveTelnet(r, ln)
	case "ftp":
		go serveFTP(r, ln)
	case "ssh":
		go serveSSH(r, ln, sv.keys)
	case "www", "winbox":
		st.srv = &http.Server{Handler: sv.web.handler(name), ReadHeaderTimeout: 20 * time.Second}
		go st.srv.Serve(ln)
	case "www-ssl":
		st.srv = &http.Server{Handler: sv.web.handler(name), TLSConfig: sv.tlsCfg, ReadHeaderTimeout: 20 * time.Second}
		go st.srv.ServeTLS(ln, "", "")
	}
}

func (sv *Services) stop(name string) {
	sv.mu.Lock()
	defer sv.mu.Unlock()
	if st := sv.s[name]; st != nil {
		if st.srv != nil {
			st.srv.Close()
		}
		if st.ln != nil {
			st.ln.Close()
		}
		st.ln, st.srv, st.port, st.status = nil, nil, 0, "disabled"
	}
}

// apply re-reads /ip service for one service and (re)starts its listener
func (sv *Services) apply(name string) {
	r := sv.r
	r.mu.Lock()
	it := r.byName("/ip/service", name)
	if it == nil {
		r.mu.Unlock()
		return
	}
	want, _ := strconv.Atoi(it["port"])
	disabled := it.B("disabled")
	r.mu.Unlock()
	if disabled {
		if name == "winbox" {
			fmt.Println("  - winbox service disabled - the TikLab GUI stays reachable on the www port")
		}
		sv.stop(name)
	} else {
		sv.mu.Lock()
		cur := sv.s[name]
		same := cur != nil && cur.ln != nil && (cur.want == want || cur.port == want)
		sv.mu.Unlock()
		if !same {
			sv.start(name, want)
		}
	}
	r.mu.Lock()
	r.syncServices()
	r.mu.Unlock()
}

// syncServices writes the actual listening ports back into /ip service (lock held)
func (r *Router) syncServices() {
	if r.svc == nil {
		return
	}
	for _, it := range r.list(MenuMap["/ip/service"]) {
		st := r.svc.s[it["name"]]
		if st == nil {
			continue
		}
		if st.port > 0 {
			it["port"] = strconv.Itoa(st.port)
			it["invalid"] = "false"
		} else if st.status != "disabled" && !it.B("disabled") {
			it["invalid"] = "true"
		}
	}
}

func tlsConfig(dir, cn string) *tls.Config {
	cp, kp := filepath.Join(dir, "tiklab-cert.pem"), filepath.Join(dir, "tiklab-key.pem")
	if c, err := tls.LoadX509KeyPair(cp, kp); err == nil {
		return &tls.Config{Certificates: []tls.Certificate{c}, MinVersion: tls.VersionTLS12}
	}
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	sn, _ := rand.Int(rand.Reader, big.NewInt(1<<62))
	tpl := &x509.Certificate{SerialNumber: sn, Subject: pkix.Name{CommonName: cn, Organization: []string{"TikLab Simulator"}}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().AddDate(10, 0, 0),
		KeyUsage: x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}, DNSNames: []string{"localhost", cn}, IPAddresses: []net.IP{net.IPv4(127, 0, 0, 1)}}
	if h := hostNet(); h.ip != nil {
		tpl.IPAddresses = append(tpl.IPAddresses, h.ip)
	}
	der, _ := x509.CreateCertificate(rand.Reader, tpl, tpl, &key.PublicKey, key)
	kb, _ := x509.MarshalECPrivateKey(key)
	os.WriteFile(cp, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0644)
	os.WriteFile(kp, pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), 0600)
	c, _ := tls.LoadX509KeyPair(cp, kp)
	return &tls.Config{Certificates: []tls.Certificate{c}, MinVersion: tls.VersionTLS12}
}

// ---------- main ----------

func exeDir() string {
	exe, err := os.Executable()
	if err != nil {
		return "."
	}
	if r, err := filepath.EvalSymlinks(exe); err == nil {
		exe = r
	}
	d := filepath.Dir(exe)
	if strings.Contains(d, "go-build") {
		wd, _ := os.Getwd()
		return wd
	}
	return d
}

func openBrowser(url string) {
	var cands [][]string
	switch runtime.GOOS {
	case "windows":
		pf := []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LocalAppData")}
		for _, base := range pf {
			if base == "" {
				continue
			}
			for _, p := range []string{`Microsoft\Edge\Application\msedge.exe`, `Google\Chrome\Application\chrome.exe`} {
				full := filepath.Join(base, p)
				if _, err := os.Stat(full); err == nil {
					cands = append(cands, []string{full, "--app=" + url, "--window-size=1366,820", "--new-window"})
				}
			}
		}
		cands = append(cands, []string{"rundll32", "url.dll,FileProtocolHandler", url})
	case "darwin":
		cands = append(cands, []string{"open", url})
	default:
		for _, b := range []string{"google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "brave-browser"} {
			if p, err := exec.LookPath(b); err == nil {
				cands = append(cands, []string{p, "--app=" + url, "--window-size=1366,820", "--new-window"})
			}
		}
		cands = append(cands, []string{"xdg-open", url})
	}
	for _, c := range cands {
		cmd := exec.Command(c[0], c[1:]...)
		if err := cmd.Start(); err == nil {
			go cmd.Wait()
			return
		}
	}
}

func main() {
	o := &Options{Ports: map[string]int{}}
	flag.StringVar(&o.Data, "data", "", "data directory (default: tiklab-data next to the program)")
	flag.StringVar(&o.Model, "model", "rb4011", "router model key, see -list-models (e.g. hap-ac2, hap-ax2, hex, rb5009, ccr1036, crs326, chr)")
	listModels := flag.Bool("list-models", false, "print the available router models and exit")
	flag.StringVar(&o.Identity, "identity", "", "router identity on first start (default MikroTik)")
	flag.StringVar(&o.Password, "password", "", "admin password used for a fresh configuration (default: empty, like a new router)")
	flag.StringVar(&o.Bind, "bind", "0.0.0.0", "IP address to listen on")
	flag.StringVar(&o.Version, "ros-version", "7.18.2 (stable)", "RouterOS version string to report")
	flag.IntVar(&o.Instance, "instance", 0, "instance number for running several routers on one PC (shifts ports and data dir)")
	flag.BoolVar(&o.NoBrowser, "no-browser", false, "do not open the GUI window automatically")
	flag.BoolVar(&o.Reset, "reset", false, "reset configuration to factory defaults on start")
	flag.BoolVar(&o.Verbose, "verbose", false, "print router log to the console")
	flag.BoolVar(&o.NoMNDP, "no-discovery", false, "disable MNDP neighbor discovery")
	ports := map[string]*int{}
	for _, s := range []struct {
		n string
		d int
	}{{"api", 8728}, {"api-ssl", 8729}, {"www", 80}, {"www-ssl", 443}, {"winbox", 8291}, {"ssh", 22}, {"telnet", 23}, {"ftp", 21}} {
		ports[s.n] = flag.Int(s.n+"-port", 0, fmt.Sprintf("override %s port (default %d)", s.n, s.d))
	}
	flag.Parse()
	if *listModels {
		printModelList()
		return
	}

	md := lookupModel(o.Model)
	if md == nil {
		fmt.Println("unknown model", o.Model)
		printModelList()
		os.Exit(1)
	}
	if o.Data == "" {
		o.Data = filepath.Join(exeDir(), "tiklab-data")
		if o.Instance > 0 {
			o.Data += fmt.Sprintf("-%d", o.Instance)
		}
	}
	if err := os.MkdirAll(o.Data, 0755); err != nil {
		home, _ := os.UserConfigDir()
		o.Data = filepath.Join(home, "TikLab", fmt.Sprintf("instance-%d", o.Instance))
		os.MkdirAll(o.Data, 0755)
	}
	if o.Identity == "" && o.Instance > 0 {
		o.Identity = fmt.Sprintf("MikroTik-%d", o.Instance+1)
	}

	r := &Router{T: map[string]*Table{}, Opt: o, Ver: o.Version, state: "booting", watchers: map[int]*watcher{}, kickers: map[int]func(){}, dataDir: o.Data}
	mdc := *md
	mdc.Serial = ""
	r.Model = &mdc
	r.sim = newSim(r)

	fmt.Printf("\n  TikLab %s - RouterOS-compatible router simulator\n  ---------------------------------------------\n", AppVersion)
	loaded := !o.Reset && r.load()
	if loaded {
		// adopt saved model key if present
		if b, err := os.ReadFile(filepath.Join(o.Data, "config.json")); err == nil {
			var s struct{ Model string }
			json.Unmarshal(b, &s)
			if m := lookupModel(s.Model); m != nil && m.Key != md.Key {
				isFlagSet := false
				flag.Visit(func(f *flag.Flag) {
					if f.Name == "model" {
						isFlagSet = true
					}
				})
				if !isFlagSet {
					mc := *m
					r.Model = &mc
				} else {
					fmt.Println("  - model changed - resetting configuration")
					loaded = false
				}
			}
		}
	}
	if r.baseMAC == nil || !loaded {
		mac := make(net.HardwareAddr, 6)
		rand.Read(mac)
		mac[0], mac[1], mac[2] = 0x48, 0xA9, 0x8A
		mac[5] = mac[5] & 0xC0
		r.baseMAC = mac
	}
	r.Model.Serial = fmt.Sprintf("HD%X", []byte(r.baseMAC[3:6]))
	if !loaded {
		r.factoryDefaults(o.Password)
		fmt.Println("  - fresh configuration created (" + r.Model.Board + ")")
	} else {
		fmt.Println("  - configuration loaded from", filepath.Join(o.Data, "config.json"))
		r.syncSimPorts()
	}
	r.single("/sim/settings")
	r.clearDynamic()
	r.boot = time.Now()
	r.state = "running"
	r.log("system,info", "router rebooted")
	r.log("system,info", "TikLab %s simulating RouterOS %s on %s", AppVersion, r.Ver, r.Model.Board)

	// services
	var mndp *MNDP
	if !o.NoMNDP {
		mndp = startMNDP(r)
		discovery = mndp
	}
	web := newWeb(r, mndp)
	sv := &Services{r: r, web: web, s: map[string]*svcState{}, bind: o.Bind}
	sv.tlsCfg = tlsConfig(o.Data, "tiklab.local")
	sv.keys = sshHostKeys(o.Data)
	r.svc = sv
	r.onSvc = sv.apply
	off := o.Instance * 10
	defaults := map[string]int{"api": 8728, "api-ssl": 8729, "www": 80, "www-ssl": 443, "winbox": 8291, "ssh": 22, "telnet": 23, "ftp": 21}
	if o.Instance > 0 {
		defaults = map[string]int{"api": 8728 + off, "api-ssl": 8729 + off, "www": 8080 + off, "www-ssl": 8443 + off, "winbox": 8291 + off, "ssh": 2222 + off, "telnet": 2323 + off, "ftp": 2121 + off}
	}
	r.mu.Lock()
	for name, def := range defaults {
		want := def
		if p := *ports[name]; p > 0 {
			want = p
		} else if loaded {
			if it := r.byName("/ip/service", name); it != nil {
				if n, _ := strconv.Atoi(it["port"]); n > 0 && o.Instance == 0 {
					want = n
				}
			}
		}
		if it := r.byName("/ip/service", name); it != nil {
			it["port"] = strconv.Itoa(want)
		}
	}
	r.mu.Unlock()
	for _, name := range []string{"winbox", "www", "www-ssl", "api", "api-ssl", "ssh", "telnet", "ftp"} {
		r.mu.Lock()
		it := r.byName("/ip/service", name)
		want, _ := strconv.Atoi(it["port"])
		dis := it.B("disabled")
		r.mu.Unlock()
		if !dis {
			sv.start(name, want)
		} else {
			sv.s[name] = &svcState{name: name, status: "disabled"}
		}
	}
	r.mu.Lock()
	r.syncServices()
	r.markDirty()
	r.mu.Unlock()

	hostIP := "127.0.0.1"
	if h := hostNet(); h.ip != nil {
		hostIP = h.ip.String()
	}
	gui := sv.port("winbox")
	if gui == 0 {
		gui = sv.port("www")
	}
	fmt.Printf("  - model %s (%s): %s, identity %q\n", r.Model.Board, r.Model.Key, r.Model.summary(), r.S("/system/identity", "name"))
	fmt.Printf("  - data directory: %s\n\n", o.Data)
	fmt.Printf("  WinBox-style GUI   http://%s:%d/      (this PC: http://127.0.0.1:%d/)\n", hostIP, gui, gui)
	row := func(label, name, scheme string) {
		st := sv.s[name]
		if st == nil || st.port == 0 {
			status := "disabled"
			if st != nil && st.status != "" {
				status = st.status
			}
			fmt.Printf("  %-18s %s\n", label, status)
			return
		}
		fmt.Printf("  %-18s %s%s:%d\n", label, scheme, hostIP, st.port)
	}
	row("RouterOS API", "api", "")
	row("RouterOS API-SSL", "api-ssl", "")
	row("REST API", "www", "http://")
	if st := sv.s["www"]; st != nil && st.port > 0 {
		fmt.Printf("  %-18s http://%s:%d/login\n", "Hotspot portal", hostIP, st.port)
	}
	row("REST API (HTTPS)", "www-ssl", "https://")
	row("SSH", "ssh", "")
	row("Telnet", "telnet", "")
	row("FTP (files)", "ftp", "")
	pw := "(empty)"
	if o.Password != "" && !loaded {
		pw = "(as set with -password)"
	} else if loaded {
		pw = "(as configured)"
	}
	fmt.Printf("\n  Login: admin %s   -   Discovery (MNDP) on UDP 5678: %v\n", pw, mndp != nil && mndp.conn != nil)
	fmt.Printf("  Press Ctrl+C to stop. Configuration is saved automatically.\n\n")

	// broadcasting the simulated SSID from this PC's Wi-Fi
	r.hw = newHostWifi(r)
	go r.hw.loop()
	r.startLoops()

	// the network lab: more routers, switches and devices on one canvas
	lab := newLab(r, o)
	web.lab = lab
	lab.start()

	if !o.NoBrowser {
		go func() {
			time.Sleep(600 * time.Millisecond)
			openBrowser(fmt.Sprintf("http://127.0.0.1:%d/?auto", gui))
		}()
	}
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	<-sig
	fmt.Println("\n  saving configuration...")
	lab.saveAll()
	fmt.Println("  bye")
}

// startLoops runs a router's simulation, autosave and WireGuard in the background.
func (r *Router) startLoops() {
	r.quit = make(chan struct{})
	go r.wgLoop()
	go func() {
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for {
			select {
			case <-r.quit:
				return
			case <-t.C:
			}
			r.mu.Lock()
			var jobs []scriptJob
			if r.state == "running" {
				func() {
					defer func() {
						if p := recover(); p != nil {
							fmt.Println("  ! simulation error:", p)
						}
					}()
					r.sim.step()
				}()
				jobs = r.sim.pending
				r.sim.pending = nil
			}
			r.mu.Unlock()
			for _, j := range jobs {
				go r.runScript(j.src, j.user, j.name)
			}
		}
	}()
	go func() {
		t := time.NewTicker(3 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-r.quit:
				return
			case <-t.C:
				r.save()
			}
		}
	}()
}
