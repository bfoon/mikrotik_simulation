package main

import (
	"fmt"
	"io"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

const (
	cReset = "\x1b[0m"
	cBold  = "\x1b[1m"
	cDim   = "\x1b[2m"
	cRed   = "\x1b[31m"
	cGreen = "\x1b[32m"
	cYel   = "\x1b[33m"
	cBlue  = "\x1b[34m"
	cMag   = "\x1b[35m"
	cCyan  = "\x1b[36m"
	cGrey  = "\x1b[90m"
)

type CLI struct {
	r           *Router
	user, via   string
	addr        string
	cwd         string
	nums        map[string][]string
	out         io.Writer
	width       int
	interactive bool
	color       bool
	keys        chan byte
	exit        bool
	vars        map[string]string
	errors      int
	ctxPath     string
	script      bool
	lenient     bool
	internal    bool
	warnings    []string
}

func newCLI(r *Router, user, via, addr string, out io.Writer, interactive bool) *CLI {
	return &CLI{r: r, user: user, via: via, addr: addr, out: out, interactive: interactive, color: interactive, width: 100, nums: map[string][]string{}, vars: map[string]string{}, keys: make(chan byte, 64)}
}

func (c *CLI) col(code, s string) string {
	if !c.color {
		return s
	}
	return code + s + cReset
}

func (c *CLI) p(f string, a ...any) { fmt.Fprintf(c.out, f, a...) }

func (c *CLI) Prompt() string {
	c.r.mu.Lock()
	id := c.r.S("/system/identity", "name")
	c.r.mu.Unlock()
	path := strings.ReplaceAll(strings.TrimPrefix(c.cwd, "/"), "/", " ")
	if path != "" {
		path = "/" + path
	}
	who := c.col(cBold, c.user+"@"+id)
	if path == "" {
		return fmt.Sprintf("[%s] > ", who)
	}
	return fmt.Sprintf("[%s] %s> ", who, c.col(cCyan, path))
}

// ---------- tokenizer ----------

type tok struct {
	s     string
	quote bool
	pos   int
	key   string
	val   string
	hasKV bool
	valQ  bool
}

func tokenize(line string) ([]tok, error) {
	var out []tok
	i := 0
	rs := []rune(line)
	for i < len(rs) {
		ch := rs[i]
		if ch == ' ' || ch == '\t' {
			i++
			continue
		}
		start := i
		var b strings.Builder
		quoted := false
		key, hasKV, valStart := "", false, 0
		for i < len(rs) && rs[i] != ' ' && rs[i] != '\t' {
			switch rs[i] {
			case '=':
				if !hasKV && b.Len() > 0 && !strings.HasPrefix(b.String(), "[") && !quoted {
					hasKV = true
					key = b.String()
					valStart = b.Len() + 1
				}
				b.WriteRune('=')
				i++
			case '"':
				quoted = true
				i++
				for i < len(rs) && rs[i] != '"' {
					if rs[i] == '\\' && i+1 < len(rs) {
						i++
						if i+1 < len(rs) && isHex(rs[i]) && isHex(rs[i+1]) {
							v, _ := strconv.ParseUint(string(rs[i:i+2]), 16, 8)
							b.WriteByte(byte(v))
							i += 2
							continue
						}
						switch rs[i] {
						case '$':
							b.WriteRune('\x01') // escaped dollar: not a variable
						case '_':
							b.WriteRune(' ')
						case 'n':
							b.WriteRune('\n')
						case 't':
							b.WriteRune('\t')
						case 'r':
							b.WriteRune('\r')
						default:
							b.WriteRune(rs[i])
						}
					} else {
						b.WriteRune(rs[i])
					}
					i++
				}
				if i >= len(rs) {
					return nil, fmt.Errorf("syntax error (line 1 column %d)", start+1)
				}
				i++
			case '[':
				depth := 0
				b.WriteRune('[')
				i++
				depth = 1
				for i < len(rs) && depth > 0 {
					if rs[i] == '[' {
						depth++
					} else if rs[i] == ']' {
						depth--
					} else if rs[i] == '"' {
						b.WriteRune(rs[i])
						i++
						for i < len(rs) && rs[i] != '"' {
							b.WriteRune(rs[i])
							i++
						}
					}
					if i < len(rs) {
						b.WriteRune(rs[i])
					}
					i++
				}
				if depth > 0 {
					return nil, fmt.Errorf("syntax error (line 1 column %d)", start+1)
				}
			default:
				b.WriteRune(rs[i])
				i++
			}
		}
		t := tok{s: b.String(), quote: quoted, pos: start}
		if hasKV {
			t.hasKV, t.key, t.val = true, key, b.String()[valStart:]
			t.valQ = quoted
			t.quote = false
		}
		out = append(out, t)
	}
	return out, nil
}

// splitTop splits a line on ; outside quotes/brackets/braces
func splitTop(line string) []string {
	var out []string
	depth, inq := 0, false
	start := 0
	for i := 0; i < len(line); i++ {
		switch line[i] {
		case '\\':
			i++
		case '"':
			inq = !inq
		case '[', '{':
			if !inq {
				depth++
			}
		case ']', '}':
			if !inq {
				depth--
			}
		case ';':
			if !inq && depth == 0 {
				out = append(out, line[start:i])
				start = i + 1
			}
		}
	}
	return append(out, line[start:])
}

// ---------- path resolution ----------

func joinPath(base, seg string) string {
	if base == "/" {
		base = ""
	}
	return base + "/" + seg
}

func isDir(p string) bool { return Dirs[p] }

func (c *CLI) commandsAt(p string) []string {
	var out []string
	if m := MenuMap[p]; m != nil {
		if m.Single {
			out = append(out, singleCmds...)
		} else {
			out = append(out, listCmds...)
		}
		out = append(out, m.Cmds...)
		if m.Ordered {
			out = append(out, "move")
		}
	}
	for sp := range SpecialCmds {
		if d, cmd := splitCmd(sp); d == p || (p == "" && d == "") {
			out = append(out, cmd)
		}
	}
	for sp := range specials {
		if d, cmd := splitCmd(sp); d == p {
			out = append(out, cmd)
		}
	}
	return uniqSorted(out)
}

func (c *CLI) subdirs(p string) []string {
	var out []string
	pref := p + "/"
	if p == "" {
		pref = "/"
	}
	for d := range Dirs {
		if d != p && strings.HasPrefix(d, pref) && !strings.Contains(d[len(pref):], "/") && d[len(pref):] != "" {
			out = append(out, d[len(pref):])
		}
	}
	sort.Strings(out)
	return out
}

func uniqSorted(in []string) []string {
	m := map[string]bool{}
	var out []string
	for _, s := range in {
		if s != "" && !m[s] && s != "getall" && s != "listen" {
			m[s] = true
			out = append(out, s)
		}
	}
	sort.Strings(out)
	return out
}

func (c *CLI) isCommand(p, name string) bool {
	for _, x := range c.commandsAt(p) {
		if x == name {
			return true
		}
	}
	return name == "getall" || name == "listen"
}

// ---------- execution ----------

func (c *CLI) RunLine(line string) {
	line = strings.TrimSpace(line)
	if line == "" || strings.HasPrefix(line, "#") {
		return
	}
	for _, part := range splitTop(line) {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.HasPrefix(part, "{") && strings.HasSuffix(part, "}") {
			for _, l := range strings.Split(strings.Trim(part, "{}"), "\n") {
				c.RunLine(l)
			}
			continue
		}
		if _, err := c.runOne(part, true); err != nil {
			c.errors++
			c.p("%s\n", c.col(cRed, err.Error()))
		}
		if c.exit {
			return
		}
	}
}

// runOne executes one command; returns the value (for [subexpressions]).
func (c *CLI) runOne(line string, top bool) (string, error) {
	toks, err := tokenize(line)
	if err != nil {
		return "", err
	}
	if len(toks) == 0 {
		return "", nil
	}
	if strings.HasPrefix(toks[0].s, ":") {
		return c.scripting(toks)
	}
	// resolve path
	cur := c.cwd
	if !top && c.ctxPath != "" {
		cur = c.ctxPath
	}
	i := 0
	cmd := ""
	for ; i < len(toks); i++ {
		t := toks[i].s
		if toks[i].quote || toks[i].hasKV || strings.Contains(t, "=") || strings.HasPrefix(t, "[") {
			break
		}
		segs := []string{t}
		if strings.Contains(t, "/") {
			if strings.HasPrefix(t, "/") {
				cur = ""
			}
			segs = strings.Split(strings.Trim(t, "/"), "/")
			if t == "/" {
				segs = nil
			}
		}
		stop := false
		for si, s := range segs {
			if s == "" {
				continue
			}
			if s == ".." {
				if j := strings.LastIndex(cur, "/"); j >= 0 {
					cur = cur[:j]
				}
				continue
			}
			np := joinPath(cur, s)
			if isDir(np) {
				cur = np
				continue
			}
			if c.isCommand(cur, s) {
				cmd = s
				if si != len(segs)-1 {
					return "", fmt.Errorf("syntax error (line 1 column %d)", toks[i].pos+1)
				}
				stop = true
				break
			}
			// allow unique prefix abbreviations (RouterOS accepts e.g. "/ip addr pr")
			if full := c.abbrev(cur, s); full != "" {
				if isDir(joinPath(cur, full)) {
					cur = joinPath(cur, full)
					continue
				}
				cmd = full
				stop = true
				break
			}
			return "", fmt.Errorf("bad command name %s (line 1 column %d)", s, toks[i].pos+1)
		}
		if stop {
			i++
			break
		}
	}
	if cmd == "" {
		if i < len(toks) {
			return "", fmt.Errorf("expected command name (line 1 column %d)", toks[i].pos+1)
		}
		if top && (c.interactive || c.script) {
			c.cwd = cur
		}
		return "", nil
	}
	rest := toks[i:]
	return c.execCmd(cur, cmd, rest, top)
}

func (c *CLI) abbrev(cur, s string) string {
	var cands []string
	for _, d := range c.subdirs(cur) {
		if strings.HasPrefix(d, s) {
			cands = append(cands, d)
		}
	}
	for _, x := range c.commandsAt(cur) {
		if strings.HasPrefix(x, s) {
			cands = append(cands, x)
		}
	}
	if len(cands) == 1 {
		return cands[0]
	}
	return ""
}

func (c *CLI) expand(v string, quoted bool) (string, error) {
	defer func() {}()
	if !quoted && strings.HasPrefix(v, "[") && strings.HasSuffix(v, "]") {
		return c.runOne(strings.TrimSpace(v[1:len(v)-1]), false)
	}
	if strings.Contains(v, "\x01") {
		out, err := c.expand(strings.ReplaceAll(v, "\x01", "\x02"), quoted)
		return strings.ReplaceAll(out, "\x02", "$"), err
	}
	if strings.Contains(v, "$") {
		re := regexp.MustCompile(`\$([A-Za-z0-9_-]+)`)
		v = re.ReplaceAllStringFunc(v, func(s string) string { return c.vars[s[1:]] })
	}
	if !quoted && strings.Contains(v, "[") {
		re := regexp.MustCompile(`\[[^\[\]]*\]`)
		var err error
		v = re.ReplaceAllStringFunc(v, func(s string) string {
			r, e := c.runOne(strings.TrimSpace(s[1:len(s)-1]), false)
			if e != nil {
				err = e
			}
			return r
		})
		if err != nil {
			return "", err
		}
	}
	return v, nil
}

var positional = map[string][]string{
	"set": {"numbers"}, "remove": {"numbers"}, "enable": {"numbers"}, "disable": {"numbers"}, "comment": {"numbers", "comment"},
	"get": {"numbers", "value-name"}, "unset": {"numbers", "value-name"}, "move": {"numbers", "destination"}, "reset-counters": {"numbers"},
	"monitor-traffic": {"interface"}, "monitor": {"numbers"}, "ping": {"address"}, "traceroute": {"address"}, "run": {"numbers"},
	"make-static": {"numbers"}, "login": {"numbers"}, "logout": {"numbers"}, "connect": {"numbers"}, "disconnect": {"numbers"},
	"plug": {"numbers"}, "unplug": {"numbers"}, "save": {"name"}, "load": {"name"}, "import": {"file-name"}, "sign": {"numbers"},
	"cable-test": {"numbers"}, "edit": {"numbers", "value-name"}, "blink": {"numbers"}, "bandwidth-test": {"address"},
}

var printFlags = map[string]bool{"detail": true, "terse": true, "brief": true, "count-only": true, "stats": true, "without-paging": true, "value-list": true, "as-value": true, "follow": true, "follow-only": true, "where": true, "show-ids": true, "once": true, "stats-detail": true, "oid": true}

func (c *CLI) execCmd(path, cmd string, toks []tok, top bool) (string, error) {
	m := MenuMap[path]
	oldCtx := c.ctxPath
	c.ctxPath = path
	defer func() { c.ctxPath = oldCtx }()
	args := map[string]string{}
	var where []tok
	flags := map[string]bool{}
	pos := positional[cmd]
	if m != nil && m.Single {
		if cmd == "get" {
			pos = []string{"value-name"}
		} else {
			pos = nil
		}
	}
	pi := 0
	for i := 0; i < len(toks); i++ {
		t := toks[i]
		if !t.quote && cmd == "print" || cmd == "find" {
			if t.s == "where" && !t.quote {
				where = toks[i+1:]
				break
			}
		}
		if t.hasKV {
			v, err := c.expand(t.val, t.valQ)
			if err != nil {
				return "", err
			}
			args[t.key] = v
			continue
		}
		if !t.quote && (printFlags[t.s] || t.s == "once" || t.s == "compact" || t.s == "verbose" || t.s == "terse" || t.s == "hide-sensitive" || t.s == "show-sensitive" || t.s == "dry-run") {
			flags[t.s] = true
			args[t.s] = ""
			continue
		}
		v, err := c.expand(t.s, t.quote)
		if err != nil {
			return "", err
		}
		if pi < len(pos) {
			args[pos[pi]] = v
			pi++
			continue
		}
		if cmd == "find" || cmd == "print" {
			where = toks[i:]
			break
		}
		return "", fmt.Errorf("expected end of command (line 1 column %d)", t.pos+1)
	}
	// translate numbers (0,1,2) to ids
	if n, ok := args["numbers"]; ok && m != nil {
		ids, err := c.resolveNums(m, n)
		if err != nil {
			return "", err
		}
		args["numbers"] = ids
	}
	if d, ok := args["destination"]; ok && m != nil {
		if ids, err := c.resolveNums(m, d); err == nil {
			args["destination"] = ids
		}
	}
	full := joinPath(path, cmd)
	ctx := &Ctx{User: c.user, Via: c.via, Addr: c.addr, Interactive: c.interactive, Lenient: c.lenient, Internal: c.internal}
	defer func() { c.warnings = append(c.warnings, ctx.Warnings...) }()
	switch {
	case cmd == "print" && m != nil:
		return "", c.print(m, args, flags, where, top)
	case cmd == "find" && m != nil:
		return c.findIDs(m, args, where)
	case cmd == "export":
		_, sens := args["show-sensitive"]
		c.r.mu.Lock()
		txt := c.r.export(path, sens)
		c.r.mu.Unlock()
		if fn := args["file"]; fn != "" {
			a := map[string]string{"file": fn}
			if sens {
				a["show-sensitive"] = ""
			}
			_, err := c.r.Exec(ctx, "/export", a, nil, nil)
			return "", err
		}
		c.p("%s", txt)
		return "", nil
	case cmd == "edit":
		return "", fmt.Errorf("edit is not supported in this terminal, use set")
	case cmd == "quit" && path == "":
		c.p("interrupted\n")
		c.exit = true
		return "", nil
	case (full == "/system/reboot" || full == "/system/shutdown" || full == "/system/reset-configuration") && c.interactive:
		q := map[string]string{"/system/reboot": "Reboot, yes? [y/N]: ", "/system/shutdown": "Shutdown, yes? [y/N]: ", "/system/reset-configuration": "Dangerous! Reset anyway? [y/N]: "}[full]
		c.p("%s", q)
		k := c.readKey()
		c.p("%c\n", printable(k))
		if k != 'y' && k != 'Y' {
			c.p("action cancelled\n")
			return "", nil
		}
		c.p("system will reboot shortly\n")
	case cmd == "monitor-traffic" || (cmd == "monitor" && path == "/interface/ethernet") || (cmd == "monitor" && path == "/system/resource"):
		return "", c.monitor(full, args)
	case cmd == "ping" || cmd == "traceroute":
		return "", c.pingCmd(full, args)
	}
	if m != nil && !c.isCommand(path, cmd) {
		return "", fmt.Errorf("bad command name %s", cmd)
	}
	if m == nil && specials[full] == nil {
		return "", fmt.Errorf("bad command name %s", cmd)
	}
	var rows []Item
	ret, err := c.r.Exec(ctx, full, args, nil, func(it Item) { rows = append(rows, it) })
	if err != nil {
		return "", err
	}
	if top {
		for _, row := range rows {
			if full == "/import" {
				c.p("%s\n    %s\n", c.col(map[string]string{"error": cRed, "warning": cYel}[row["status"]], "line "+row["line"]+": "+row["message"]), c.col(cGrey, row["command"]))
				continue
			}
			c.printSingle(nil, row)
		}
		if cmd == "get" && ret != "" {
			c.p("%s\n", cliVal(fieldOf(m, args["value-name"]), ret))
		}
		if full == "/export" || full == "/import" {
			c.p("%s\n", ret)
		}
	}
	if cmd == "get" {
		return cliVal(fieldOf(m, args["value-name"]), ret), nil
	}
	return ret, nil
}

func fieldOf(m *Menu, n string) *Field {
	if m == nil {
		return nil
	}
	return m.F(n)
}

func printable(b byte) rune {
	if b < 32 {
		return ' '
	}
	return rune(b)
}

func (c *CLI) readKey() byte {
	select {
	case k := <-c.keys:
		return k
	case <-time.After(60 * time.Second):
		return 'n'
	}
}

func (c *CLI) resolveNums(m *Menu, spec string) (string, error) {
	var out []string
	c.r.mu.Lock()
	defer c.r.mu.Unlock()
	order := c.nums[m.Path]
	if order == nil {
		for _, it := range c.r.list(m) {
			order = append(order, it[".id"])
		}
	}
	for _, p := range strings.FieldsFunc(spec, func(r rune) bool { return r == ',' || r == ';' }) {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		if strings.Contains(p, "-") && !strings.HasPrefix(p, "*") {
			ab := strings.SplitN(p, "-", 2)
			a, e1 := strconv.Atoi(ab[0])
			b, e2 := strconv.Atoi(ab[1])
			if e1 == nil && e2 == nil {
				for n := a; n <= b; n++ {
					if n < len(order) {
						out = append(out, order[n])
					}
				}
				continue
			}
		}
		if n, err := strconv.Atoi(p); err == nil {
			if n < 0 || n >= len(order) {
				return "", fmt.Errorf("no such item")
			}
			out = append(out, order[n])
			continue
		}
		it := c.r.findRef(m, p)
		if it == nil {
			return "", fmt.Errorf("no such item")
		}
		out = append(out, it[".id"])
	}
	return strings.Join(out, ","), nil
}

// ---------- where expressions ----------

type cond struct {
	neg   bool
	field string
	op    string
	val   string
}

func parseWhere(toks []tok) ([][]cond, error) {
	// returns OR-groups of AND-conditions
	var groups [][]cond
	var cur []cond
	neg := false
	for _, t := range toks {
		s := t.s
		if !t.quote {
			switch s {
			case "and", "&&":
				continue
			case "or", "||":
				groups = append(groups, cur)
				cur = nil
				continue
			case "not", "!":
				neg = true
				continue
			}
		}
		cd := cond{neg: neg}
		neg = false
		if strings.HasPrefix(s, "!") && !t.quote {
			cd.neg = !cd.neg
			s = s[1:]
		}
		for _, op := range []string{"!=", "~", ">=", "<=", "=", ">", "<", "in"} {
			if i := strings.Index(s, op); i > 0 && op != "in" {
				cd.field, cd.op, cd.val = s[:i], op, strings.Trim(s[i+len(op):], "\"")
				break
			}
		}
		if cd.op == "" {
			cd.field, cd.op = s, "bool"
		}
		cur = append(cur, cd)
	}
	groups = append(groups, cur)
	return groups, nil
}

func matchWhere(groups [][]cond, it Item) bool {
	if len(groups) == 0 {
		return true
	}
	for _, g := range groups {
		ok := true
		for _, cd := range g {
			v, has := it[cd.field]
			res := false
			val := normQueryVal(cd.val)
			switch cd.op {
			case "bool":
				res = v == "true" || (has && v != "false" && v != "")
			case "=":
				res = v == val || v == cd.val
			case "!=":
				res = v != val && v != cd.val
			case "~":
				if re, err := regexp.Compile(cd.val); err == nil {
					res = re.MatchString(v)
				}
			case ">":
				res = has && cmpVals(v, val) > 0
			case "<":
				res = has && cmpVals(v, val) < 0
			case ">=":
				res = has && cmpVals(v, val) >= 0
			case "<=":
				res = has && cmpVals(v, val) <= 0
			}
			if cd.neg {
				res = !res
			}
			if !res {
				ok = false
				break
			}
		}
		if ok {
			return true
		}
	}
	return false
}

func (c *CLI) collect(m *Menu, args map[string]string, where []tok) ([]Item, error) {
	groups, err := parseWhere(where)
	if err != nil {
		return nil, err
	}
	var rows []Item
	pargs := map[string]string{}
	if f, ok := args["from"]; ok {
		pargs["from"] = f
	}
	var q []string
	for k, v := range args {
		if !printFlags[k] && k != "from" && k != "proplist" && k != "interval" && k != "file" && m.F(k) != nil {
			q = append(q, "?"+k+"="+v)
		}
	}
	_, err = c.r.Exec(&Ctx{User: c.user, Via: c.via, Internal: c.internal}, m.Path+"/print", pargs, q, func(it Item) {
		if matchWhere(groups, it) {
			rows = append(rows, it)
		}
	})
	return rows, err
}

func (c *CLI) findIDs(m *Menu, args map[string]string, where []tok) (string, error) {
	rows, err := c.collect(m, args, where)
	if err != nil {
		return "", err
	}
	var ids []string
	for _, r := range rows {
		ids = append(ids, r[".id"])
	}
	return strings.Join(ids, ","), nil
}

// ---------- printing ----------

func (c *CLI) flagLegend(m *Menu) string {
	if len(m.Flags) == 0 {
		return ""
	}
	var parts []string
	for _, f := range m.Flags {
		parts = append(parts, f.Ch+" - "+f.Name)
	}
	return "Flags: " + strings.Join(parts, "; ")
}

func flagStr(m *Menu, it Item) string {
	var b strings.Builder
	for _, f := range m.Flags {
		if it[f.Field] == f.Val {
			b.WriteString(f.Ch)
		}
	}
	return b.String()
}

func dispWidth(s string) int { return utf8.RuneCountInString(s) }

func (c *CLI) fmtCell(m *Menu, k, v string) string {
	f := m.F(k)
	if f != nil && f.Kind == "bool" {
		return cliVal(f, v)
	}
	if k == "rate" || strings.HasSuffix(k, "-rate") && strings.Contains(v, "/") {
		p := strings.SplitN(v, "/", 2)
		if len(p) == 2 {
			a, _ := strconv.ParseFloat(p[0], 64)
			b, _ := strconv.ParseFloat(p[1], 64)
			return humanBps(a) + "/" + humanBps(b)
		}
	}
	return v
}

func humanBps(v float64) string {
	switch {
	case v >= 1e9:
		return fmt.Sprintf("%.1fGbps", v/1e9)
	case v >= 1e6:
		return fmt.Sprintf("%.1fMbps", v/1e6)
	case v >= 1e3:
		return fmt.Sprintf("%.1fkbps", v/1e3)
	}
	return fmt.Sprintf("%.0fbps", v)
}

func (c *CLI) print(m *Menu, args map[string]string, flags map[string]bool, where []tok, top bool) error {
	if m.Single {
		var row Item
		_, err := c.r.Exec(&Ctx{User: c.user, Via: c.via, Internal: c.internal}, m.Path+"/print", nil, nil, func(it Item) { row = it })
		if err != nil {
			return err
		}
		c.printSingle(m, row)
		return nil
	}
	rows, err := c.collect(m, args, where)
	if err != nil {
		return err
	}
	if flags["count-only"] {
		c.p("%d\n", len(rows))
		return nil
	}
	// numbering for this session
	var ids []string
	c.r.mu.Lock()
	all := c.r.list(m)
	c.r.mu.Unlock()
	_ = all
	for _, r := range rows {
		ids = append(ids, r[".id"])
	}
	c.nums[m.Path] = ids
	if f := c.flagLegend(m); f != "" {
		c.p("%s\n", c.col(cGrey, f))
	}
	detail := flags["detail"] || (m.Detail && !flags["brief"])
	if flags["terse"] {
		for i, r := range rows {
			c.p("%d %s %s\n", i, flagStr(m, r), c.kvLine(m, r, ""))
		}
		return nil
	}
	if detail {
		for i, r := range rows {
			fl := flagStr(m, r)
			if cm := r["comment"]; cm != "" {
				c.p(" %2d %-3s%s\n", i, c.colFlags(fl), c.col(cGrey, ";;; "+cm))
				c.wrap("        "+c.kvLine(m, r, "comment"), "        ")
			} else {
				c.wrap(fmt.Sprintf(" %2d %-3s  %s", i, c.colFlags(fl), c.kvLine(m, r, "comment")), "        ")
			}
			c.p("\n")
		}
		return nil
	}
	cols := m.Cols
	if flags["stats"] && m.Store() == "/interface" {
		cols = []string{"name", "rx-byte", "tx-byte", "rx-packet", "tx-packet", "rx-drop", "tx-drop", "tx-queue-drop", "rx-error", "tx-error"}
	}
	if p := args["proplist"]; p != "" {
		cols = strings.Split(p, ",")
	}
	if len(cols) == 0 {
		for _, f := range m.Fields {
			if !f.Hide && len(cols) < 6 && f.Name != "comment" && f.Name != "disabled" {
				cols = append(cols, f.Name)
			}
		}
	}
	w := make([]int, len(cols))
	for i, cn := range cols {
		w[i] = dispWidth(cn)
	}
	cells := make([][]string, len(rows))
	for ri, r := range rows {
		cells[ri] = make([]string, len(cols))
		for i, cn := range cols {
			v := c.fmtCell(m, cn, r[cn])
			if dispWidth(v) > 40 {
				v = string([]rune(v)[:39]) + "…"
			}
			cells[ri][i] = v
			if dispWidth(v) > w[i] {
				w[i] = dispWidth(v)
			}
		}
	}
	fw := 0
	for _, r := range rows {
		if n := len(flagStr(m, r)); n > fw {
			fw = n
		}
	}
	c.p("%s\n", c.col(cGrey, "Columns: "+strings.ToUpper(strings.Join(cols, ", "))))
	var hdr strings.Builder
	numW := len(strconv.Itoa(len(rows)))
	if numW < 2 {
		numW = 2
	}
	fmt.Fprintf(&hdr, "%*s  %-*s", numW, "#", fw, "")
	for i, cn := range cols {
		fmt.Fprintf(&hdr, " %-*s", w[i], strings.ToUpper(cn))
	}
	c.p("%s\n", c.col(cBold, strings.TrimRight(hdr.String(), " ")))
	for ri, r := range rows {
		if cm := r["comment"]; cm != "" {
			c.p("%s\n", c.col(cGrey, ";;; "+cm))
		}
		var line strings.Builder
		fl := flagStr(m, r)
		fmt.Fprintf(&line, "%*d  %-*s", numW, ri, fw, c.colFlags(fl))
		if c.color {
			// account for escape codes in padding
			pad := fw - len(fl)
			line.Reset()
			fmt.Fprintf(&line, "%*d  %s%s", numW, ri, c.colFlags(fl), strings.Repeat(" ", pad))
		}
		for i, v := range cells[ri] {
			fmt.Fprintf(&line, " %-*s", w[i]+len(v)-dispWidth(v), v)
		}
		txt := strings.TrimRight(line.String(), " ")
		if r["disabled"] == "true" {
			txt = c.col(cGrey, txt)
		}
		c.p("%s\n", txt)
	}
	return nil
}

func (c *CLI) colFlags(fl string) string {
	if !c.color || fl == "" {
		return fl
	}
	var b strings.Builder
	for _, ch := range fl {
		switch ch {
		case 'X', 'I':
			b.WriteString(cRed + string(ch) + cReset)
		case 'R', 'A':
			b.WriteString(cGreen + string(ch) + cReset)
		case 'D':
			b.WriteString(cBlue + string(ch) + cReset)
		default:
			b.WriteString(cYel + string(ch) + cReset)
		}
	}
	return b.String()
}

func (c *CLI) kvLine(m *Menu, r Item, skip string) string {
	var parts []string
	for _, k := range orderedKeys(m, r) {
		if k == ".id" || k == skip {
			continue
		}
		f := m.F(k)
		if f != nil && f.Kind == "bool" && m.Flags != nil {
			isFlag := false
			for _, fd := range m.Flags {
				if fd.Field == k {
					isFlag = true
				}
			}
			if isFlag && (k == "dynamic" || k == "disabled" || k == "invalid" || k == "running" || k == "slave" || k == "default") {
				continue
			}
		}
		v := cliVal(f, r[k])
		if f != nil && (f.Kind == "text" || quotedFields[k]) {
			v = quoteAlways(v)
		} else if strings.ContainsAny(v, " \"") || v == "" {
			v = quoteVal(v)
		}
		parts = append(parts, c.col(cCyan, k)+"="+v)
	}
	return strings.Join(parts, " ")
}

var quotedFields = map[string]bool{"name": true, "comment": true, "ssid": true, "password": true, "radio-name": true, "service-name": true, "user": true, "dns-name": true, "host-name": true, "email": true, "regexp": true, "message": true, "log-prefix": true, "default-name": true, "identity": true, "on-event": true, "contents": true, "source": true, "on-login": true, "on-logout": true, "on-up": true, "on-down": true, "wpa2-pre-shared-key": true, "secret": true}

func quoteAlways(v string) string {
	if strings.ContainsAny(v, " \"\n;") || v == "" {
		return quoteVal(v)
	}
	return `"` + v + `"`
}

func (c *CLI) wrap(s, indent string) {
	words := strings.Split(s, " ")
	lineLen := 0
	first := true
	for _, w := range words {
		vis := len(stripANSI(w))
		if !first && lineLen+vis+1 > c.width {
			c.p("\n%s", indent)
			lineLen = len(indent)
		} else if !first {
			c.p(" ")
			lineLen++
		}
		c.p("%s", w)
		lineLen += vis
		first = false
	}
	c.p("\n")
}

var ansiRe = regexp.MustCompile(`\x1b\[[0-9;]*[a-zA-Z]`)

func stripANSI(s string) string { return ansiRe.ReplaceAllString(s, "") }

func (c *CLI) printSingle(m *Menu, row Item) {
	if row == nil {
		return
	}
	keys := orderedKeys(m, row)
	w := 0
	for _, k := range keys {
		if len(k) > w {
			w = len(k)
		}
	}
	for _, k := range keys {
		if k == ".id" {
			continue
		}
		v := row[k]
		if m != nil {
			if f := m.F(k); f != nil {
				v = cliVal(f, v)
				if strings.HasSuffix(k, "memory") || strings.HasSuffix(k, "hdd-space") {
					n, _ := strconv.ParseFloat(v, 64)
					v = humanBytes(n)
				}
				if k == "cpu-load" {
					v += "%"
				}
				if k == "cpu-frequency" {
					v += "MHz"
				}
			}
		}
		if strings.Contains(v, "\n") {
			v = strings.ReplaceAll(v, "\n", "\n"+strings.Repeat(" ", w+2))
		}
		c.p("%s: %s\n", c.col(cCyan, fmt.Sprintf("%*s", w, k)), v)
	}
}

func humanBytes(n float64) string {
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.1fGiB", n/(1<<30))
	case n >= 1<<20:
		return fmt.Sprintf("%.1fMiB", n/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.1fKiB", n/(1<<10))
	}
	return fmt.Sprintf("%.0fB", n)
}

// ---------- monitor / ping ----------

func (c *CLI) stopper() (chan struct{}, func()) {
	done := make(chan struct{})
	stop := make(chan struct{})
	go func() {
		select {
		case <-c.keys:
			close(done)
		case <-stop:
		}
	}()
	return done, func() { close(stop) }
}

func (c *CLI) monitor(full string, args map[string]string) error {
	_, once := args["once"]
	if !c.interactive {
		args["once"] = ""
		once = true
	}
	done, stop := c.stopper()
	defer stop()
	lines := 0
	var err error
	frame := []Item{}
	flush := func() {
		if lines > 0 {
			c.p("\x1b[%dA\r", lines)
		}
		lines = 0
		for _, it := range frame {
			keys := orderedKeys(nil, it)
			sort.SliceStable(keys, func(i, j int) bool {
				return keys[i] == "name" || (keys[j] != "name" && false)
			})
			w := 0
			for _, k := range keys {
				if len(k) > w {
					w = len(k)
				}
			}
			for _, k := range keys {
				v := it[k]
				if strings.HasSuffix(k, "bits-per-second") {
					f, _ := strconv.ParseFloat(v, 64)
					v = humanBps(f)
				}
				c.p("\x1b[K%s: %s\n", c.col(cCyan, fmt.Sprintf("%*s", w, k)), v)
				lines++
			}
			if len(frame) > 1 {
				c.p("\x1b[K\n")
				lines++
			}
		}
		frame = frame[:0]
	}
	n := len(strings.Split(firstNonEmpty(args["interface"], args["numbers"]), ","))
	_, err = c.r.Exec(&Ctx{User: c.user, Via: c.via, Done: done, Interactive: c.interactive}, full, args, nil, func(it Item) {
		frame = append(frame, it)
		if len(frame) >= n || strings.HasSuffix(full, "resource/monitor") {
			flush()
			if !once && c.interactive {
				c.p("\x1b[K%s", c.col(cGrey, "-- [Q quit|D dump|C-z pause]"))
				c.p("\r")
			}
		}
	})
	if t, ok := err.(*Trap); ok && t.Cat == 2 {
		c.p("\x1b[K\n")
		return nil
	}
	return err
}

func (c *CLI) pingCmd(full string, args map[string]string) error {
	done, stop := c.stopper()
	defer stop()
	trace := strings.HasSuffix(full, "traceroute")
	if trace {
		c.p("%s\n", c.col(cBold, " #  ADDRESS                          LOSS  SENT  LAST       STATUS"))
	} else {
		c.p("%s\n", c.col(cBold, "  SEQ HOST                                     SIZE TTL TIME       STATUS"))
	}
	var last Item
	i := 0
	_, err := c.r.Exec(&Ctx{User: c.user, Via: c.via, Done: done, Interactive: c.interactive}, full, args, nil, func(it Item) {
		last = it
		if trace {
			i++
			c.p("%2d  %-32s %4s %5s  %-10s %s\n", i, it["address"], it["loss"], it["sent"], it["last"], it["status"])
			return
		}
		st := it["status"]
		if st != "" {
			st = c.col(cRed, st)
		}
		c.p("%5s %-40s %4s %3s %-10s %s\n", it["seq"], it["host"], it["size"], it["ttl"], it["time"], st)
	})
	if last != nil && !trace {
		s := fmt.Sprintf("    sent=%s received=%s packet-loss=%s%%", last["sent"], last["received"], last["packet-loss"])
		if last["avg-rtt"] != "" {
			s += fmt.Sprintf(" min-rtt=%s avg-rtt=%s max-rtt=%s", last["min-rtt"], last["avg-rtt"], last["max-rtt"])
		}
		c.p("%s\n\n", s)
	}
	if t, ok := err.(*Trap); ok && t.Cat == 2 {
		return nil
	}
	return err
}

// ---------- scripting (:put, :log, :local ...) ----------

func (c *CLI) scripting(toks []tok) (string, error) {
	cmd := toks[0].s
	argv := func(i int) (string, error) {
		if i >= len(toks) {
			return "", nil
		}
		return c.expand(toks[i].s, toks[i].quote)
	}
	switch cmd {
	case ":put":
		var parts []string
		for i := 1; i < len(toks); i++ {
			v, err := argv(i)
			if err != nil {
				return "", err
			}
			parts = append(parts, v)
		}
		c.p("%s\n", strings.ReplaceAll(strings.Join(parts, " "), ",", ";"))
		return "", nil
	case ":log":
		lvl, _ := argv(1)
		var parts []string
		for i := 2; i < len(toks); i++ {
			v, err := argv(i)
			if err != nil {
				return "", err
			}
			parts = append(parts, v)
		}
		if lvl != "info" && lvl != "warning" && lvl != "error" && lvl != "debug" {
			return "", fmt.Errorf("syntax error: expected info, warning, error or debug")
		}
		c.r.mu.Lock()
		c.r.log("script,"+lvl, "%s", strings.Join(parts, " "))
		c.r.mu.Unlock()
		return "", nil
	case ":local", ":global", ":set":
		if len(toks) < 2 {
			return "", fmt.Errorf("syntax error")
		}
		name := toks[1].s
		v := ""
		if strings.Contains(name, "=") {
			kv := strings.SplitN(name, "=", 2)
			name = kv[0]
			x, err := c.expand(kv[1], toks[1].quote)
			if err != nil {
				return "", err
			}
			v = x
		} else if len(toks) > 2 {
			x, err := argv(2)
			if err != nil {
				return "", err
			}
			v = x
		}
		c.vars[name] = v
		return "", nil
	case ":delay":
		d, _ := argv(1)
		if dd, ok := parseDur(firstNonEmpty(d, "1s")); ok && dd < 30*time.Second {
			time.Sleep(dd)
		}
		return "", nil
	case ":resolve":
		return "142.250.185.78", nil
	case ":len":
		v, _ := argv(1)
		if strings.Contains(v, ",") {
			return strconv.Itoa(len(strings.Split(v, ","))), nil
		}
		return strconv.Itoa(len(v)), nil
	case ":pick":
		v, _ := argv(1)
		a, _ := argv(2)
		b, _ := argv(3)
		ai, _ := strconv.Atoi(a)
		bi, err := strconv.Atoi(b)
		if err != nil {
			bi = ai + 1
		}
		if ai < 0 || ai > len(v) {
			return "", nil
		}
		if bi > len(v) {
			bi = len(v)
		}
		return v[ai:bi], nil
	case ":tostr", ":tonum", ":totime", ":toip", ":typeof":
		v, _ := argv(1)
		return v, nil
	case ":beep", ":nothing", ":error":
		return "", nil
	case ":environment":
		for k, v := range c.vars {
			c.p("%s=%s\n", k, v)
		}
		return "", nil
	case ":execute":
		return "", nil
	}
	return "", fmt.Errorf("'%s' is not supported by the simulator's script engine", cmd)
}

// runScript executes a multi-line script non-interactively; returns error count.
func (r *Router) runScript(src, user, name string) int {
	c := newCLI(r, user, "script", "", io.Discard, false)
	c.color = false
	for _, line := range joinContinuations(src) {
		c.RunLine(line)
	}
	if c.errors > 0 && name != "" {
		r.mu.Lock()
		r.log("script,warning", "script %s finished with %d error(s) (simulator script engine is basic)", name, c.errors)
		r.mu.Unlock()
	}
	return c.errors
}

func joinContinuations(src string) []string {
	var out []string
	var cur strings.Builder
	depth := 0
	for _, l := range strings.Split(strings.ReplaceAll(src, "\r", ""), "\n") {
		t := strings.TrimSpace(l)
		if strings.HasSuffix(t, "\\") {
			cur.WriteString(strings.TrimSuffix(t, "\\") + " ")
			continue
		}
		depth += strings.Count(t, "{") - strings.Count(t, "}")
		cur.WriteString(t)
		if depth > 0 {
			cur.WriteString("\n")
			continue
		}
		out = append(out, cur.String())
		cur.Reset()
		depth = 0
	}
	if cur.Len() > 0 {
		out = append(out, cur.String())
	}
	return out
}

// ---------- help & completion ----------

func (c *CLI) contextAt(line string) (path string, cmd string, last string) {
	toks, _ := tokenize(line)
	path = c.cwd
	if strings.HasSuffix(line, " ") || line == "" {
		toks = append(toks, tok{s: ""})
	}
	for i, t := range toks {
		if i == len(toks)-1 {
			last = t.s
			break
		}
		if cmd != "" {
			continue
		}
		s := t.s
		if strings.HasPrefix(s, "/") {
			path = ""
		}
		for _, seg := range strings.Split(strings.Trim(s, "/"), "/") {
			if seg == "" {
				continue
			}
			if seg == ".." {
				if j := strings.LastIndex(path, "/"); j >= 0 {
					path = path[:j]
				}
				continue
			}
			if isDir(joinPath(path, seg)) {
				path = joinPath(path, seg)
			} else if c.isCommand(path, seg) {
				cmd = seg
			}
		}
	}
	return
}

func (c *CLI) completions(line string) (string, []string) {
	path, cmd, last := c.contextAt(line)
	var cands []string
	prefix := last
	base := ""
	if cmd == "" {
		if i := strings.LastIndex(last, "/"); i >= 0 {
			base = last[:i+1]
			sub := strings.Trim(last[:i], "/")
			if strings.HasPrefix(last, "/") {
				path = ""
			}
			if sub != "" {
				for _, seg := range strings.Split(sub, "/") {
					path = joinPath(path, seg)
				}
			}
			prefix = last[i+1:]
		}
		for _, d := range c.subdirs(path) {
			cands = append(cands, d)
		}
		for _, x := range c.commandsAt(path) {
			cands = append(cands, x)
		}
	} else {
		m := MenuMap[path]
		if strings.Contains(last, "=") {
			kv := strings.SplitN(last, "=", 2)
			base = kv[0] + "="
			prefix = kv[1]
			if m != nil {
				if f := m.F(kv[0]); f != nil {
					switch {
					case f.Kind == "bool":
						cands = []string{"yes", "no"}
					case f.Kind == "enum":
						cands = f.Enum
					case f.Ref != "":
						c.r.mu.Lock()
						for _, it := range c.r.list(MenuMap[f.Ref]) {
							cands = append(cands, it["name"])
						}
						c.r.mu.Unlock()
						cands = append(cands, f.Extra...)
					}
				}
			}
		} else if m != nil {
			for _, f := range m.Fields {
				if !f.RO || cmd == "print" || cmd == "find" {
					cands = append(cands, f.Name+"=")
				}
			}
			if cmd == "print" {
				cands = append(cands, "detail", "terse", "count-only", "where", "stats", "brief")
			}
		} else {
			for _, a := range []string{"address=", "count=", "interval=", "size=", "interface=", "once", "name=", "file=", "duration="} {
				cands = append(cands, a)
			}
		}
	}
	var out []string
	for _, x := range cands {
		if strings.HasPrefix(x, prefix) {
			out = append(out, x)
		}
	}
	sort.Strings(out)
	if len(out) == 0 {
		return line, nil
	}
	common := out[0]
	for _, x := range out[1:] {
		for !strings.HasPrefix(x, common) {
			common = common[:len(common)-1]
		}
	}
	head := line[:len(line)-len(last)]
	nl := head + base + common
	if len(out) == 1 && !strings.HasSuffix(common, "=") && cmd == "" {
		if isDir(joinPath(path, common)) {
			nl += " "
		} else {
			nl += " "
		}
	} else if len(out) == 1 && !strings.HasSuffix(common, "=") {
		nl += " "
	}
	return nl, out
}

func (c *CLI) help(line string) {
	path, cmd, _ := c.contextAt(line)
	if cmd != "" {
		m := MenuMap[path]
		c.p("\n%s\n", c.col(cBold, cmd+" -- "+cmdDesc(cmd)))
		if m != nil && (cmd == "add" || cmd == "set" || cmd == "print" || cmd == "find") {
			var names []string
			for _, f := range m.Fields {
				if !f.RO || cmd == "print" {
					names = append(names, f.Name)
				}
			}
			c.printCols(names)
		}
		return
	}
	title := "/"
	if m := MenuMap[path]; m != nil {
		title = m.Title
	}
	c.p("\n%s\n", c.col(cBold, title))
	if dirs := c.subdirs(path); len(dirs) > 0 {
		c.p("%s\n", c.col(cGrey, ".. -- go up to parent"))
		for _, d := range dirs {
			desc := ""
			if m := MenuMap[joinPath(path, d)]; m != nil {
				desc = m.Title
			}
			c.p("%s %s\n", c.col(cCyan, fmt.Sprintf("%-22s", d)), c.col(cGrey, "-- "+desc))
		}
	}
	for _, x := range c.commandsAt(path) {
		c.p("%s %s\n", c.col(cYel, fmt.Sprintf("%-22s", x)), c.col(cGrey, "-- "+cmdDesc(x)))
	}
}

func (c *CLI) printCols(names []string) {
	w := 0
	for _, n := range names {
		if len(n) > w {
			w = len(n)
		}
	}
	w += 2
	per := c.width / w
	if per < 1 {
		per = 1
	}
	for i, n := range names {
		c.p("%-*s", w, n)
		if (i+1)%per == 0 {
			c.p("\n")
		}
	}
	c.p("\n")
}

func cmdDesc(cmd string) string {
	d := map[string]string{"add": "Create a new item", "comment": "Set comment for items", "disable": "Disable items", "enable": "Enable items", "export": "Print or save an export script", "find": "Find items by value",
		"get": "Gets value of item's property", "print": "Print values of item properties", "remove": "Remove item", "set": "Change item properties", "unset": "Unset item property", "edit": "Edit item property", "move": "Change order of items",
		"reset-counters": "Reset counters", "monitor-traffic": "Monitor traffic through interfaces", "monitor": "Monitor status", "reboot": "Reboot the router", "shutdown": "Shut down the router", "ping": "Send ICMP Echo packets",
		"login": "Log a host in", "logout": "Log a host out", "run": "Run script", "make-static": "Make a dynamic lease static", "quit": "Quit console", "password": "Change password", "import": "Run exported configuration script"}[cmd]
	if d == "" {
		d = cmd
	}
	return d
}

func isHex(r rune) bool { return (r >= '0' && r <= '9') || (r >= 'A' && r <= 'F') }
