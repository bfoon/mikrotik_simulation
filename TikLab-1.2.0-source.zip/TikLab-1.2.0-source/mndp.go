package main

// MNDP – MikroTik Neighbor Discovery Protocol (UDP 5678).
// The simulator announces itself so it appears in WinBox's "Neighbors" tab and
// in /ip neighbor of real routers, and it listens for real routers / other
// TikLab instances so they can be picked from the login window.

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"sync"
	"syscall"
	"time"
)

const (
	tlvMAC      = 1
	tlvIdentity = 5
	tlvVersion  = 7
	tlvPlatform = 8
	tlvUptime   = 10
	tlvSoftID   = 11
	tlvBoard    = 12
	tlvUnpack   = 14
	tlvIPv6     = 15
	tlvIfName   = 16
	tlvIPv4     = 17
)

type Neighbor struct {
	MAC, IP, Identity, Version, Platform, Board, SoftID, IfName string
	Uptime                                                      int
	Seen                                                        time.Time
	TikLab                                                      bool
	GUIPort, APIPort, WebPort                                   int
}

type MNDP struct {
	r       *Router
	conn    *net.UDPConn
	ext     *net.UDPConn
	mu      sync.Mutex
	seen    map[string]*Neighbor
	seq     uint16
	ourMAC  string
	trigger chan struct{}
}

func listenUDPReuse(port int) (*net.UDPConn, error) {
	lc := net.ListenConfig{Control: func(network, address string, c syscall.RawConn) error {
		return c.Control(func(fd uintptr) { setReuse(fd) })
	}}
	pc, err := lc.ListenPacket(context.Background(), "udp4", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return nil, err
	}
	return pc.(*net.UDPConn), nil
}

func startMNDP(r *Router) *MNDP {
	m := &MNDP{r: r, seen: map[string]*Neighbor{}, trigger: make(chan struct{}, 1)}
	c, err := listenUDPReuse(5678)
	if err != nil {
		fmt.Println("  ! MNDP (UDP 5678) unavailable:", err, "- using an ephemeral port for announcements only")
		c, err = listenUDPReuse(0)
		if err != nil {
			return m
		}
	}
	m.conn = c
	if e, err := listenUDPReuse(5679); err == nil {
		m.ext = e
		go m.readExt()
	}
	go m.read()
	go m.announceLoop()
	return m
}

func putTLV(b []byte, t uint16, v []byte) []byte {
	h := make([]byte, 4)
	binary.BigEndian.PutUint16(h[0:2], t)
	binary.BigEndian.PutUint16(h[2:4], uint16(len(v)))
	return append(append(b, h...), v...)
}

func (m *MNDP) packet(ip net.IP) []byte {
	r := m.r
	r.mu.Lock()
	ifname := "ether1"
	wan := r.byName("/interface", "ether1")
	if wan == nil {
		for _, it := range r.list(MenuMap["/interface/ethernet"]) {
			wan = it
			ifname = it["name"]
			break
		}
	}
	macStr := ""
	if wan != nil {
		macStr = wan["mac-address"]
	}
	identity := r.S("/system/identity", "name")
	softID := r.S("/system/license", "software-id")
	uptime := int(time.Since(r.boot).Seconds())
	ver, board := r.Ver, r.Model.Board
	r.mu.Unlock()
	m.mu.Lock()
	m.ourMAC = strings.ToUpper(macStr)
	m.seq++
	seq := m.seq
	m.mu.Unlock()
	mac, _ := net.ParseMAC(macStr)
	b := []byte{0, 0, byte(seq >> 8), byte(seq)}
	b = putTLV(b, tlvMAC, mac)
	b = putTLV(b, tlvIdentity, []byte(identity))
	b = putTLV(b, tlvVersion, []byte(ver))
	b = putTLV(b, tlvPlatform, []byte("MikroTik"))
	up := make([]byte, 4)
	binary.LittleEndian.PutUint32(up, uint32(uptime))
	b = putTLV(b, tlvUptime, up)
	b = putTLV(b, tlvSoftID, []byte(softID))
	b = putTLV(b, tlvBoard, []byte(board))
	b = putTLV(b, tlvUnpack, []byte{1})
	b = putTLV(b, tlvIfName, []byte(ifname))
	if ip4 := ip.To4(); ip4 != nil {
		b = putTLV(b, tlvIPv4, ip4)
	}
	return b
}

type bcastTarget struct {
	ip    net.IP
	bcast net.IP
}

func broadcastTargets() []bcastTarget {
	var out []bcastTarget
	ifs, _ := net.Interfaces()
	for _, i := range ifs {
		if i.Flags&net.FlagUp == 0 || i.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := i.Addrs()
		for _, a := range addrs {
			n, ok := a.(*net.IPNet)
			if !ok || n.IP.To4() == nil {
				continue
			}
			ip := n.IP.To4()
			mask := net.IP(n.Mask).To4()
			if mask == nil {
				continue
			}
			bc := make(net.IP, 4)
			for k := 0; k < 4; k++ {
				bc[k] = ip[k] | ^mask[k]
			}
			out = append(out, bcastTarget{ip: ip, bcast: bc})
		}
	}
	return out
}

func (m *MNDP) announce() {
	if m.conn == nil {
		return
	}
	m.r.mu.Lock()
	running := m.r.state == "running"
	m.r.mu.Unlock()
	if !running {
		return
	}
	targets := broadcastTargets()
	if len(targets) == 0 {
		targets = []bcastTarget{{ip: net.IPv4(127, 0, 0, 1), bcast: net.IPv4(127, 255, 255, 255)}}
	}
	sent := map[string]bool{}
	for _, t := range targets {
		pkt := m.packet(t.ip)
		for _, dst := range []net.IP{t.bcast, net.IPv4bcast} {
			key := dst.String() + t.ip.String()
			if sent[key] {
				continue
			}
			sent[key] = true
			m.conn.WriteToUDP(pkt, &net.UDPAddr{IP: dst, Port: 5678})
		}
	}
	// TikLab extension packet (separate port so WinBox is never confused)
	if m.ext != nil {
		r := m.r
		r.mu.Lock()
		gui, api, web := 0, 0, 0
		if r.svc != nil {
			gui, api, web = r.svc.port("winbox"), r.svc.port("api"), r.svc.port("www")
		}
		r.mu.Unlock()
		m.mu.Lock()
		own := m.ourMAC
		m.mu.Unlock()
		msg := []byte(fmt.Sprintf("TIKLAB1 mac=%s gui=%d api=%d web=%d", own, gui, api, web))
		for _, t := range targets {
			m.ext.WriteToUDP(msg, &net.UDPAddr{IP: t.bcast, Port: 5679})
		}
		m.ext.WriteToUDP(msg, &net.UDPAddr{IP: net.IPv4bcast, Port: 5679})
		m.ext.WriteToUDP(msg, &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 5679})
	}
}

// Discover sends a discovery request (what WinBox does when you press Refresh).
func (m *MNDP) Discover() {
	if m.conn == nil {
		return
	}
	for _, t := range broadcastTargets() {
		m.conn.WriteToUDP([]byte{0, 0, 0, 0}, &net.UDPAddr{IP: t.bcast, Port: 5678})
	}
	m.conn.WriteToUDP([]byte{0, 0, 0, 0}, &net.UDPAddr{IP: net.IPv4bcast, Port: 5678})
	m.announce()
}

func (m *MNDP) announceLoop() {
	time.Sleep(1500 * time.Millisecond)
	m.Discover()
	t := time.NewTicker(15 * time.Second)
	for {
		m.announce()
		select {
		case <-t.C:
		case <-m.trigger:
			time.Sleep(200 * time.Millisecond)
		}
	}
}

func (m *MNDP) read() {
	buf := make([]byte, 2048)
	for {
		n, from, err := m.conn.ReadFromUDP(buf)
		if err != nil {
			return
		}
		pkt := buf[:n]
		if n == 4 {
			select {
			case m.trigger <- struct{}{}:
			default:
			}
			continue
		}
		nb := parseMNDP(pkt)
		m.mu.Lock()
		own := m.ourMAC
		m.mu.Unlock()
		if nb == nil || nb.MAC == "" || strings.EqualFold(nb.MAC, own) {
			continue
		}
		if nb.IP == "" {
			nb.IP = from.IP.String()
		}
		nb.Seen = time.Now()
		m.mu.Lock()
		if old := m.seen[nb.MAC]; old != nil {
			nb.TikLab, nb.GUIPort, nb.APIPort, nb.WebPort = old.TikLab, old.GUIPort, old.APIPort, old.WebPort
		}
		m.seen[nb.MAC] = nb
		m.mu.Unlock()
		m.record(nb)
	}
}

func (m *MNDP) readExt() {
	buf := make([]byte, 512)
	for {
		n, from, err := m.ext.ReadFromUDP(buf)
		if err != nil {
			return
		}
		s := string(buf[:n])
		if !strings.HasPrefix(s, "TIKLAB1 ") {
			continue
		}
		kv := map[string]string{}
		for _, f := range strings.Fields(s)[1:] {
			p := strings.SplitN(f, "=", 2)
			if len(p) == 2 {
				kv[p[0]] = p[1]
			}
		}
		mac := strings.ToUpper(kv["mac"])
		m.mu.Lock()
		if mac == "" || mac == m.ourMAC {
			m.mu.Unlock()
			continue
		}
		nb := m.seen[mac]
		if nb == nil {
			nb = &Neighbor{MAC: mac, IP: from.IP.String(), Seen: time.Now()}
			m.seen[mac] = nb
		}
		nb.TikLab = true
		fmt.Sscan(kv["gui"], &nb.GUIPort)
		fmt.Sscan(kv["api"], &nb.APIPort)
		fmt.Sscan(kv["web"], &nb.WebPort)
		m.mu.Unlock()
	}
}

func parseMNDP(p []byte) *Neighbor {
	if len(p) < 8 {
		return nil
	}
	nb := &Neighbor{}
	i := 4
	for i+4 <= len(p) {
		t := binary.BigEndian.Uint16(p[i : i+2])
		l := int(binary.BigEndian.Uint16(p[i+2 : i+4]))
		i += 4
		if i+l > len(p) {
			break
		}
		v := p[i : i+l]
		i += l
		switch t {
		case tlvMAC:
			if l == 6 {
				nb.MAC = strings.ToUpper(net.HardwareAddr(v).String())
			}
		case tlvIdentity:
			nb.Identity = string(v)
		case tlvVersion:
			nb.Version = string(v)
		case tlvPlatform:
			nb.Platform = string(v)
		case tlvUptime:
			if l == 4 {
				nb.Uptime = int(binary.LittleEndian.Uint32(v))
			}
		case tlvSoftID:
			nb.SoftID = string(v)
		case tlvBoard:
			nb.Board = string(v)
		case tlvIfName:
			nb.IfName = string(v)
		case tlvIPv4:
			if l == 4 {
				nb.IP = net.IP(v).String()
			}
		}
	}
	return nb
}

func (m *MNDP) record(nb *Neighbor) {
	r := m.r
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.state != "running" {
		return
	}
	nm := MenuMap["/ip/neighbor"]
	var it Item
	for _, x := range r.list(nm) {
		if strings.EqualFold(x["mac-address"], nb.MAC) {
			it = x
		}
	}
	vals := map[string]string{"interface": "ether1", "address": nb.IP, "address4": nb.IP, "mac-address": nb.MAC, "identity": nb.Identity, "platform": nb.Platform, "version": nb.Version, "unpack": "none", "age": "0s", "uptime": fmtDur(time.Duration(nb.Uptime) * time.Second), "software-id": nb.SoftID, "board": nb.Board, "ipv6": "false", "interface-name": nb.IfName, "discovered-by": "mndp", "system-caps": "", "system-caps-enabled": ""}
	if it == nil {
		r.addItem(nm, vals, true)
		return
	}
	for k, v := range vals {
		it[k] = v
	}
}

// List returns neighbours seen within the last 3 minutes.
func (m *MNDP) List() []*Neighbor {
	m.mu.Lock()
	defer m.mu.Unlock()
	var out []*Neighbor
	for k, n := range m.seen {
		if time.Since(n.Seen) > 3*time.Minute {
			delete(m.seen, k)
			continue
		}
		out = append(out, n)
	}
	return out
}
