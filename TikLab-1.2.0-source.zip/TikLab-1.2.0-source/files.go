package main

// /file storage (binary safe), uploads, downloads, zip handling,
// hotspot page assets, page previews and the login-page checker.

import (
	"archive/zip"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

const maxUpload = 32 << 20

var textExts = map[string]bool{".html": true, ".htm": true, ".css": true, ".js": true, ".txt": true, ".rsc": true, ".json": true, ".xml": true, ".svg": true, ".csv": true, ".md": true, ".conf": true, ".ini": true, ".log": true, ".auto.rsc": true}

func cleanPath(p string) string {
	p = strings.ReplaceAll(p, "\\", "/")
	p = path.Clean("/" + p)
	p = strings.TrimPrefix(p, "/")
	if p == "." {
		return ""
	}
	return p
}

func fileType(name string, dir bool) string {
	if dir {
		return "directory"
	}
	ext := strings.ToLower(path.Ext(name))
	switch ext {
	case ".rsc":
		return "script"
	case ".backup":
		return "backup"
	case ".npk":
		return "package"
	case "":
		return "file"
	}
	return ext + " file"
}

func isTextData(name string, b []byte) bool {
	if len(b) > 8<<20 || bytes.IndexByte(b, 0) >= 0 || !utf8.Valid(b) {
		return false
	}
	ext := strings.ToLower(path.Ext(name))
	if textExts[ext] {
		return true
	}
	if ext == "" || ext == ".backup" {
		return len(b) < 1<<20
	}
	return false
}

func fileBytes(it Item) []byte {
	if b := it["_b64"]; b != "" {
		d, _ := base64.StdEncoding.DecodeString(b)
		return d
	}
	return []byte(it["contents"])
}

func setFileBytes(it Item, data []byte) {
	if isTextData(it["name"], data) {
		it["contents"] = string(data)
		delete(it, "_b64")
	} else {
		it["_b64"] = base64.StdEncoding.EncodeToString(data)
		delete(it, "contents")
	}
	it["size"] = strconv.Itoa(len(data))
}

// ensureDir creates directory items for name and all its parents (lock held)
func (r *Router) ensureDir(name string) {
	name = cleanPath(name)
	if name == "" {
		return
	}
	parts := strings.Split(name, "/")
	for i := 1; i <= len(parts); i++ {
		p := strings.Join(parts[:i], "/")
		if r.byName("/file", p) == nil {
			r.addItem(MenuMap["/file"], map[string]string{"name": p, "type": "directory"}, true)
		}
	}
}

// putFile creates or replaces a file (lock held)
func (r *Router) putFile(name string, data []byte) Item {
	name = cleanPath(name)
	if d := path.Dir(name); d != "." && d != "" {
		r.ensureDir(d)
	}
	now := r.now().Format("2006-01-02 15:04:05")
	it := r.byName("/file", name)
	if it == nil {
		it, _ = r.addItem(MenuMap["/file"], map[string]string{"name": name, "type": fileType(name, false)}, true)
	}
	it["type"] = fileType(name, false)
	setFileBytes(it, data)
	it["last-modified"] = now
	r.markDirty()
	r.notify("/file", it, false)
	return it
}

func (r *Router) filesUnder(dir string) []Item {
	dir = cleanPath(dir)
	var out []Item
	for _, it := range r.list(MenuMap["/file"]) {
		if dir == "" || it["name"] == dir || strings.HasPrefix(it["name"], dir+"/") {
			out = append(out, it)
		}
	}
	return out
}

func init() {
	delHooks["/file"] = func(r *Router, it Item, internal bool) error {
		if it["type"] == "directory" {
			pre := it["name"] + "/"
			r.removeWhere("/file", func(x Item) bool { return strings.HasPrefix(x["name"], pre) })
		}
		return nil
	}
	setHooks["/file"] = func(r *Router, m *Menu, it Item, nv map[string]string) error {
		if n, ok := nv["name"]; ok {
			nv["name"] = cleanPath(n)
			if nv["name"] == "" {
				return trap("invalid value for argument name")
			}
		}
		return nil
	}
	afterSetHooks["/file"] = func(r *Router, it, old Item) {
		if it["type"] == "directory" && old["name"] != it["name"] {
			for _, x := range r.list(MenuMap["/file"]) {
				if strings.HasPrefix(x["name"], old["name"]+"/") {
					x["name"] = it["name"] + strings.TrimPrefix(x["name"], old["name"])
				}
			}
			return
		}
		if _, ok := it["contents"]; ok {
			delete(it, "_b64")
		}
		if it["_b64"] == "" {
			it["size"] = fmt.Sprint(len(it["contents"]))
		}
		it["last-modified"] = r.now().Format("2006-01-02 15:04:05")
	}
}

// ---------------- zip ----------------

func zipFiles(r *Router, dir string) []byte {
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	r.mu.Lock()
	items := r.filesUnder(dir)
	type f struct {
		name string
		data []byte
	}
	var files []f
	base := path.Dir(cleanPath(dir))
	for _, it := range items {
		if it["type"] == "directory" {
			continue
		}
		rel := it["name"]
		if base != "." && base != "" {
			rel = strings.TrimPrefix(rel, base+"/")
		}
		files = append(files, f{rel, fileBytes(it)})
	}
	r.mu.Unlock()
	for _, x := range files {
		w, err := zw.CreateHeader(&zip.FileHeader{Name: x.name, Method: zip.Deflate, Modified: time.Now()})
		if err == nil {
			w.Write(x.data)
		}
	}
	zw.Close()
	return buf.Bytes()
}

// unzipInto extracts a zip archive into dir, removing a single common top folder.
func unzipInto(r *Router, data []byte, dir string) ([]string, error) {
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, fmt.Errorf("not a valid zip file: %v", err)
	}
	var names []string
	for _, f := range zr.File {
		if !f.FileInfo().IsDir() && !strings.HasPrefix(path.Base(f.Name), ".") && !strings.Contains(f.Name, "__MACOSX") {
			names = append(names, cleanPath(f.Name))
		}
	}
	prefix := ""
	if len(names) > 0 {
		first := strings.SplitN(names[0], "/", 2)
		if len(first) == 2 {
			common := true
			for _, n := range names {
				if !strings.HasPrefix(n, first[0]+"/") {
					common = false
					break
				}
			}
			if common {
				prefix = first[0] + "/"
			}
		}
	}
	var out []string
	total := 0
	for _, f := range zr.File {
		n := cleanPath(f.Name)
		if f.FileInfo().IsDir() || strings.Contains(n, "__MACOSX") || strings.HasPrefix(path.Base(n), ".") {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			continue
		}
		b, _ := io.ReadAll(io.LimitReader(rc, maxUpload))
		rc.Close()
		total += len(b)
		if total > 4*maxUpload {
			return out, fmt.Errorf("archive is too large")
		}
		target := cleanPath(dir + "/" + strings.TrimPrefix(n, prefix))
		r.mu.Lock()
		r.putFile(target, b)
		r.mu.Unlock()
		out = append(out, target)
	}
	return out, nil
}

// ---------------- HTTP handlers ----------------

func (w *Web) fileUpload(rw http.ResponseWriter, req *http.Request, s *guiSession) {
	q := req.URL.Query()
	dir := cleanPath(q.Get("dir"))
	extract := q.Get("extract") != ""
	mr, err := req.MultipartReader()
	if err != nil {
		jsonOut(rw, 400, map[string]any{"error": "expected a multipart upload"})
		return
	}
	var saved, errs []string
	pending := ""
	for {
		part, err := mr.NextPart()
		if err != nil {
			break
		}
		switch part.FormName() {
		case "path":
			b, _ := io.ReadAll(io.LimitReader(part, 4096))
			pending = string(b)
		case "file":
			name := pending
			if name == "" {
				name = part.FileName()
			}
			pending = ""
			data, err := io.ReadAll(io.LimitReader(part, maxUpload+1))
			if err != nil {
				errs = append(errs, name+": "+err.Error())
				continue
			}
			if len(data) > maxUpload {
				errs = append(errs, name+": larger than 32 MB")
				continue
			}
			target := cleanPath(dir + "/" + name)
			if extract && strings.HasSuffix(strings.ToLower(name), ".zip") {
				sub := dir
				if q.Get("zipdir") != "" {
					sub = cleanPath(dir + "/" + strings.TrimSuffix(path.Base(name), path.Ext(name)))
				}
				got, err := unzipInto(w.r, data, sub)
				saved = append(saved, got...)
				if err != nil {
					errs = append(errs, name+": "+err.Error())
				}
				continue
			}
			w.r.mu.Lock()
			w.r.putFile(target, data)
			w.r.log("system,info", "file %s uploaded by %s", target, s.user)
			w.r.mu.Unlock()
			saved = append(saved, target)
		}
	}
	jsonOut(rw, 200, map[string]any{"saved": saved, "errors": errs})
}

func (w *Web) fileDownload(rw http.ResponseWriter, req *http.Request) {
	name := cleanPath(req.URL.Query().Get("name"))
	w.r.mu.Lock()
	it := w.r.byName("/file", name)
	var data []byte
	isDir := it != nil && it["type"] == "directory"
	if it != nil && !isDir {
		data = fileBytes(it)
	}
	w.r.mu.Unlock()
	if it == nil && name != "" {
		http.NotFound(rw, req)
		return
	}
	base := path.Base(name)
	if isDir || name == "" {
		data = zipFiles(w.r, name)
		if name == "" {
			base = "files"
		}
		base += ".zip"
	}
	ct := mime.TypeByExtension(path.Ext(base))
	if ct == "" {
		ct = "application/octet-stream"
	}
	if req.URL.Query().Get("inline") == "" {
		rw.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", base))
	}
	rw.Header().Set("Content-Type", ct)
	rw.Write(data)
}

// ---------------- hotspot assets & previews ----------------

func contentType(name string) string {
	ct := mime.TypeByExtension(strings.ToLower(path.Ext(name)))
	if ct == "" {
		ct = "application/octet-stream"
	}
	return ct
}

// activeHotspotDir returns the html directory of the first enabled hotspot server (lock held)
func (r *Router) activeHotspotDir() string {
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if h.B("disabled") {
			continue
		}
		if p := r.byName("/ip/hotspot/profile", h["profile"]); p != nil {
			return cleanPath(firstNonEmpty(p["html-directory-override"], p["html-directory"], "hotspot"))
		}
	}
	return "hotspot"
}

// serveHotspotAsset serves /<file> from the active hotspot directory (used for page assets)
func (w *Web) serveHotspotAsset(rw http.ResponseWriter, req *http.Request) bool {
	p := cleanPath(req.URL.Path)
	if p == "" {
		return false
	}
	r := w.r
	r.mu.Lock()
	dir := r.activeHotspotDir()
	it := r.byName("/file", dir+"/"+p)
	if it == nil || it["type"] == "directory" {
		r.mu.Unlock()
		return false
	}
	data := fileBytes(it)
	r.mu.Unlock()
	if strings.HasSuffix(strings.ToLower(p), ".html") {
		w.portalHTML(rw, req, path.Base(p))
		return true
	}
	rw.Header().Set("Content-Type", contentType(p))
	rw.Header().Set("Cache-Control", "no-cache")
	rw.Write(data)
	return true
}

// portalHTML renders any .html page of the active directory with live session variables
func (w *Web) portalHTML(rw http.ResponseWriter, req *http.Request, page string) {
	c, key, err := w.portalClient(rw, req)
	if err != nil {
		http.Error(rw, err.Error(), 503)
		return
	}
	req.ParseForm()
	w.r.mu.Lock()
	defer w.r.mu.Unlock()
	vars := w.portalVars(c, key, req)
	w.portalPage(rw, page, vars, c)
}

func previewVars(r *Router, state, dir string) map[string]string {
	v := map[string]string{
		"identity": r.S("/system/identity", "name"), "hostname": "login.wifi", "server-name": "hotspot1", "server-address": "10.5.50.1:80",
		"link-login": "login.html", "link-login-only": "login.html", "link-logout": "logout.html", "link-status": "status.html", "link-orig": "http://www.google.com/", "link-orig-esc": "http%3A%2F%2Fwww.google.com%2F",
		"link-redirect": "status.html", "link-redirect-esc": "status.html", "link-advert": "status.html", "mac": "AA:BB:CC:12:34:56", "mac-esc": "AA%3ABB%3ACC%3A12%3A34%3A56", "ip": "10.5.50.23",
		"username": "", "logged-in": "no", "login-by": "", "trial": "no", "error": "", "error-orig": "", "chap-id": "\\001", "chap-challenge": "\\123\\045\\067\\201\\002\\377\\020\\030\\040\\050\\060\\070\\100\\110\\120\\130",
		"popup": "true", "refresh-timeout": "1m", "refresh-timeout-secs": "60", "interface-name": "bridge-hotspot", "host-ip": "10.5.50.23", "uptime": "", "session-time-left": "", "session-time-left-secs": "",
		"bytes-in": "0", "bytes-out": "0", "bytes-in-nice": "0 B", "bytes-out-nice": "0 B", "packets-in": "0", "packets-out": "0", "remain-bytes-total": "", "blocked": "no", "plain-passwd": "yes", "http-status": "200 OK", "session-id": "", "var": "",
	}
	switch state {
	case "error":
		v["error"] = "invalid username or password"
		v["error-orig"] = v["error"]
		v["username"] = "a7k2mp"
	case "status", "logout", "alogin":
		v["logged-in"] = "yes"
		v["username"] = "a7k2mp"
		v["login-by"] = "http-chap"
		v["uptime"] = "12m34s"
		v["session-time-left"] = "47m26s"
		v["session-time-left-secs"] = "2846"
		v["bytes-in"], v["bytes-out"] = "2483107", "48213558"
		v["bytes-in-nice"], v["bytes-out-nice"] = "2.4 MiB", "46.0 MiB"
		v["remain-bytes-total"] = "953.6 MiB"
		v["session-id"] = "*1A"
	}
	return v
}

// GET /hspreview/<dir...>/<file>?state=login|error|status|logout
func (w *Web) hsPreview(rw http.ResponseWriter, req *http.Request) {
	p := cleanPath(strings.TrimPrefix(req.URL.Path, "/hspreview/"))
	r := w.r
	r.mu.Lock()
	it := r.byName("/file", p)
	var data []byte
	if it != nil {
		data = fileBytes(it)
	}
	dir := path.Dir(p)
	state := req.URL.Query().Get("state")
	vars := previewVars(r, state, dir)
	r.mu.Unlock()
	if it == nil || it["type"] == "directory" {
		http.NotFound(rw, req)
		return
	}
	rw.Header().Set("Cache-Control", "no-cache")
	if strings.HasSuffix(strings.ToLower(p), ".html") {
		rw.Header().Set("Content-Type", "text/html; charset=utf-8")
		out := renderTpl(string(data), vars)
		// keep the preview inside the preview folder
		out = strings.Replace(out, "<head>", "<head><base href=\"/hspreview/"+(&url.URL{Path: dir}).EscapedPath()+"/\">", 1)
		io.WriteString(rw, out)
		return
	}
	rw.Header().Set("Content-Type", contentType(p))
	rw.Write(data)
}

// ---------------- login page checker ----------------

type checkItem struct {
	Level string   `json:"level"` // ok | info | warn | error
	Text  string   `json:"text"`
	Hosts []string `json:"hosts,omitempty"`
}

var knownVars = map[string]bool{}

func init() {
	for _, v := range strings.Fields(`identity hostname server-name server-address link-login link-login-only link-logout link-status link-orig link-orig-esc link-redirect link-redirect-esc link-advert mac mac-esc ip username logged-in login-by trial error error-orig chap-id chap-challenge popup refresh-timeout refresh-timeout-secs interface-name host-ip uptime session-time-left session-time-left-secs bytes-in bytes-out bytes-in-nice bytes-out-nice packets-in packets-out remain-bytes-total remain-bytes-in remain-bytes-out blocked plain-passwd http-status session-id var if elif else endif radius1 radius2 radius3 radius4 radius5 radius6 radius7 radius8 radius9 radius10 radius11 radius12 radius13 radius14 radius15 radius16 radius17 radius18 radius19 radius20 trial-uptime trial-uptime-left limit-bytes-total limit-uptime domain ssl-login http-header var-name`) {
		knownVars[v] = true
	}
}

var (
	reAssets  = regexp.MustCompile(`(?i)(?:src|href)\s*=\s*["']([^"'#]+)["']`)
	reCSSURL  = regexp.MustCompile(`(?i)url\(\s*["']?([^"')]+)["']?\s*\)`)
	reVar     = regexp.MustCompile(`\$\(([^)]*)\)`)
	reFormAct = regexp.MustCompile(`(?is)<form[^>]*action\s*=\s*["']([^"']*)["']`)
)

func (r *Router) checkHotspotDir(dir string) (items []checkItem, total int, files []string) {
	dir = cleanPath(dir)
	add := func(level, f string, a ...any) {
		items = append(items, checkItem{Level: level, Text: fmt.Sprintf(f, a...)})
	}
	byName := map[string]Item{}
	for _, it := range r.filesUnder(dir) {
		if it["type"] == "directory" {
			continue
		}
		rel := strings.TrimPrefix(it["name"], dir+"/")
		byName[rel] = it
		files = append(files, rel)
		total += len(fileBytes(it))
	}
	sort.Strings(files)
	if len(files) == 0 {
		add("error", "The folder %s has no files.", dir)
		return
	}
	login := byName["login.html"]
	if login == nil {
		add("error", "login.html is missing. The router needs it to show the login page.")
	} else {
		add("ok", "login.html found.")
	}
	for _, p := range []string{"alogin.html", "status.html", "logout.html", "error.html", "redirect.html", "rlogin.html"} {
		if byName[p] == nil {
			lvl := "info"
			if p == "status.html" || p == "alogin.html" || p == "logout.html" {
				lvl = "warn"
			}
			add(lvl, "%s is missing. Customers will see a plain page at that step.", p)
		}
	}
	hosts := map[string]bool{}
	var missing []string
	pap := false
	hp := r.byName("/ip/hotspot/profile", "hsprof1")
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if p := r.byName("/ip/hotspot/profile", h["profile"]); p != nil {
			hp = p
		}
	}
	if hp != nil {
		pap = strings.Contains(hp["login-by"], "http-pap")
	}
	for _, rel := range files {
		it := byName[rel]
		if !strings.HasSuffix(rel, ".html") && !strings.HasSuffix(rel, ".css") {
			continue
		}
		src := string(fileBytes(it))
		isHTML := strings.HasSuffix(rel, ".html")
		if isHTML {
			depth := 0
			unknown := map[string]bool{}
			jq := false
			for _, m := range reVar.FindAllStringSubmatch(src, -1) {
				name := strings.Fields(strings.TrimSpace(m[1]) + " ")[0]
				switch name {
				case "if":
					depth++
				case "endif":
					depth--
				}
				if !knownVars[name] {
					if strings.ContainsAny(name, "'\".#") || name == "this" || name == "document" || name == "window" || name == "function" || name == "" {
						jq = true
					} else {
						unknown[name] = true
					}
				}
			}
			if depth != 0 {
				add("error", "%s: $(if …) and $(endif) are not balanced. The router will cut parts of the page.", rel)
			}
			if jq {
				add("warn", "%s uses jQuery-style $(…) inside the HTML. MikroTik replaces $(…) in .html files, so use jQuery(…) or move the code into a .js file.", rel)
			}
			if len(unknown) > 0 {
				add("warn", "%s uses unknown variables: %s. They will be replaced with nothing.", rel, strings.Join(sortedKeys(unknown), ", "))
			}
		}
		refs := reAssets.FindAllStringSubmatch(src, -1)
		refs = append(refs, reCSSURL.FindAllStringSubmatch(src, -1)...)
		for _, m := range refs {
			u := strings.TrimSpace(m[1])
			if u == "" || strings.HasPrefix(u, "$(") || strings.HasPrefix(u, "data:") || strings.HasPrefix(u, "mailto:") || strings.HasPrefix(u, "javascript:") || strings.HasPrefix(u, "tel:") {
				continue
			}
			if strings.HasPrefix(u, "http://") || strings.HasPrefix(u, "https://") || strings.HasPrefix(u, "//") {
				if pu, err := url.Parse(u); err == nil && pu.Host != "" {
					hosts[pu.Host] = true
				}
				continue
			}
			u = strings.SplitN(strings.SplitN(u, "?", 2)[0], "#", 2)[0]
			target := cleanPath(path.Join(path.Dir(rel), u))
			if strings.HasPrefix(u, "/") {
				target = cleanPath(u)
			}
			if target == "" || strings.HasSuffix(target, "login") || strings.HasSuffix(target, "logout") || strings.HasSuffix(target, "status") {
				continue
			}
			if byName[target] == nil {
				missing = append(missing, fmt.Sprintf("%s → %s", rel, u))
			}
		}
	}
	if login != nil {
		src := string(fileBytes(login))
		chap := strings.Contains(src, "chap-id") && strings.Contains(strings.ToLower(src), "md5")
		if m := reFormAct.FindStringSubmatch(src); m != nil {
			if strings.Contains(m[1], "$(link-login") {
				add("ok", "The login form posts to %s.", m[1])
			} else {
				add("warn", "The login form posts to %q. Use $(link-login-only) so it works on any router address.", m[1])
			}
		} else {
			add("error", "login.html has no <form>. Customers have no way to enter a voucher.")
		}
		if strings.Contains(src, `name="username"`) || strings.Contains(src, `name='username'`) || strings.Contains(src, "name=username") {
			add("ok", "The username field is named \"username\".")
		} else {
			add("error", "No input named \"username\". MikroTik expects the voucher code in a field called username.")
		}
		switch {
		case chap:
			add("ok", "CHAP login (hexMD5 with $(chap-id)) is supported, so the password is not sent in clear text.")
			if !strings.Contains(src, "md5.js") || byName["md5.js"] == nil {
				add("warn", "login.html uses hexMD5 but md5.js is not in the folder or not linked.")
			}
		case !pap:
			add("warn", "The page sends the password in plain text but the hotspot profile does not allow http-pap. Enable http-pap in the server profile or use CHAP (md5.js).")
		default:
			add("info", "The page uses plain-text (PAP) login. It works because http-pap is enabled in the server profile.")
		}
	}
	if len(missing) > 0 {
		if len(missing) > 8 {
			missing = append(missing[:8], fmt.Sprintf("…and %d more", len(missing)-8))
		}
		add("error", "Missing files referenced by the pages: %s", strings.Join(missing, "; "))
	} else {
		add("ok", "Every local image, stylesheet and script the pages reference is present.")
	}
	if len(hosts) > 0 {
		hl := sortedKeys(hosts)
		items = append(items, checkItem{Level: "warn", Text: fmt.Sprintf("The pages load %d external host(s) before the customer has logged in. Add them to the walled garden or bundle the files locally: %s", len(hl), strings.Join(hl, ", ")), Hosts: hl})
	}
	free := int(float64(r.Model.HddMB) * 1024 * 1024 * 0.55)
	if r.Model.HddMB <= 16 {
		free = int(float64(r.Model.HddMB) * 1024 * 1024 * 0.25)
	}
	switch {
	case total > free:
		add("error", "The pages take %s but a %s has only about %s free storage.", humanBytes(float64(total)), r.Model.Board, humanBytes(float64(free)))
	case total > free/2:
		add("warn", "The pages take %s, more than half of the %s's free storage (%s).", humanBytes(float64(total)), r.Model.Board, humanBytes(float64(free)))
	default:
		add("ok", "Total size %s fits comfortably on a %s.", humanBytes(float64(total)), r.Model.Board)
	}
	return
}

func (w *Web) hotspotDirs(rw http.ResponseWriter) {
	r := w.r
	r.mu.Lock()
	defer r.mu.Unlock()
	active := r.activeHotspotDir()
	type d struct {
		Dir    string `json:"dir"`
		Active bool   `json:"active"`
		Files  int    `json:"files"`
		Size   int    `json:"size"`
	}
	var out []d
	for _, it := range r.list(MenuMap["/file"]) {
		if strings.HasSuffix(it["name"], "/login.html") || it["name"] == "login.html" {
			dir := path.Dir(it["name"])
			if dir == "." {
				dir = ""
			}
			n, sz := 0, 0
			for _, f := range r.filesUnder(dir) {
				if f["type"] != "directory" {
					n++
					sz += len(fileBytes(f))
				}
			}
			out = append(out, d{Dir: dir, Active: dir == active, Files: n, Size: sz})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Dir < out[j].Dir })
	jsonOut(rw, 200, map[string]any{"dirs": out, "active": active})
}

func (w *Web) hotspotActivate(rw http.ResponseWriter, req *http.Request) {
	var body struct{ Dir string }
	json.NewDecoder(req.Body).Decode(&body)
	r := w.r
	r.mu.Lock()
	defer r.mu.Unlock()
	dir := cleanPath(body.Dir)
	if r.byName("/file", dir+"/login.html") == nil {
		jsonOut(rw, 200, map[string]any{"error": "that folder has no login.html"})
		return
	}
	n := 0
	for _, h := range r.list(MenuMap["/ip/hotspot"]) {
		if p := r.byName("/ip/hotspot/profile", h["profile"]); p != nil {
			p["html-directory"] = dir
			delete(p, "html-directory-override")
			n++
		}
	}
	if n == 0 {
		jsonOut(rw, 200, map[string]any{"error": "no hotspot server is configured"})
		return
	}
	r.markDirty()
	r.log("hotspot,info", "hotspot html-directory set to %s", dir)
	jsonOut(rw, 200, map[string]any{"ok": true})
}
