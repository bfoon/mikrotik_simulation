/* Compact MD5 for hotspot CHAP login (operates on byte strings). */
function hexMD5(s){
  var K=[],S=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21],i,k;
  for(i=0;i<64;i++)K[i]=Math.floor(Math.abs(Math.sin(i+1))*4294967296)|0;
  var n=s.length,words=(((n+8)>>6)+1)<<4,M=new Array(words);
  for(i=0;i<words;i++)M[i]=0;
  for(i=0;i<n;i++)M[i>>2]|=(s.charCodeAt(i)&255)<<((i%4)*8);
  M[n>>2]|=128<<((n%4)*8);M[words-2]=n*8;
  var h0=0x67452301,h1=0xEFCDAB89|0,h2=0x98BADCFE|0,h3=0x10325476;
  for(var j=0;j<words;j+=16){
    var a=h0,b=h1,c=h2,d=h3,f,g,t,x,sh;
    for(i=0;i<64;i++){
      if(i<16){f=(b&c)|(~b&d);g=i;}
      else if(i<32){f=(d&b)|(~d&c);g=(5*i+1)%16;}
      else if(i<48){f=b^c^d;g=(3*i+5)%16;}
      else{f=c^(b|~d);g=(7*i)%16;}
      t=d;d=c;c=b;
      x=(a+f+K[i]+M[j+g])|0;sh=S[(i>>4)*4+i%4];
      b=(b+((x<<sh)|(x>>>(32-sh))))|0;a=t;
    }
    h0=(h0+a)|0;h1=(h1+b)|0;h2=(h2+c)|0;h3=(h3+d)|0;
  }
  var out='',hs=[h0,h1,h2,h3];
  for(i=0;i<4;i++)for(k=0;k<4;k++)out+=('0'+((hs[i]>>>(k*8))&255).toString(16)).slice(-2);
  return out;
}
