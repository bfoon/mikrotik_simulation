package main

import (
	"bufio"
	"crypto/md5"
	"crypto/rand"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"time"
)

// ---------- wire format ----------

func encodeLen(n int) []byte {
	switch {
	case n < 0x80:
		return []byte{byte(n)}
	case n < 0x4000:
		n |= 0x8000
		return []byte{byte(n >> 8), byte(n)}
	case n < 0x200000:
		n |= 0xC00000
		return []byte{byte(n >> 16), byte(n >> 8), byte(n)}
	case n < 0x10000000:
		n |= 0xE0000000
		return []byte{byte(n >> 24), byte(n >> 16), byte(n >> 8), byte(n)}
	}
	return []byte{0xF0, byte(n >> 24), byte(n >> 16), byte(n >> 8), byte(n)}
}

func readLen(r *bufio.Reader) (int, error) {
	b, err := r.ReadByte()
	if err != nil {
		return 0, err
	}
	n := int(b)
	extra := 0
	switch {
	case b&0x80 == 0:
	case b&0xC0 == 0x80:
		n &= 0x3F
		extra = 1
	case b&0xE0 == 0xC0:
		n &= 0x1F
		extra = 2
	case b&0xF0 == 0xE0:
		n &= 0x0F
		extra = 3
	case b == 0xF0:
		n = 0
		extra = 4
	default:
		return 0, errors.New("bad length")
	}
	for i := 0; i < extra; i++ {
		c, err := r.ReadByte()
		if err != nil {
			return 0, err
		}
		n = n<<8 | int(c)
	}
	return n, nil
}

func readSentence(r *bufio.Reader) ([]string, error) {
	var words []string
	for {
		n, err := readLen(r)
		if err != nil {
			return nil, err
		}
		if n == 0 {
			return words, nil
		}
		if n > 16<<20 {
			return nil, errors.New("word too long")
		}
		buf := make([]byte, n)
		if _, err := io.ReadFull(r, buf); err != nil {
			return nil, err
		}
		words = append(words, string(buf))
	}
}

func encodeSentence(words []string) []byte {
	var b []byte
	for _, w := range words {
		b = append(b, encodeLen(len(w))...)
		b = append(b, w...)
	}
	return append(b, 0)
}

// ---------- server ----------

type apiConn struct {
	r       *Router
	c       net.Conn
	wmu     sync.Mutex
	user    string
	session string
	chal    []byte
	via     string
	cancels map[string]chan struct{}
	cmu     sync.Mutex
	closed  chan struct{}
}

func (a *apiConn) send(words ...string) {
	a.wmu.Lock()
	defer a.wmu.Unlock()
	a.c.SetWriteDeadline(time.Now().Add(20 * time.Second))
	a.c.Write(encodeSentence(words))
}

func withTag(tag string, words ...string) []string {
	if tag != "" {
		words = append(words, ".tag="+tag)
	}
	return words
}

func (a *apiConn) reply(m *Menu, tag string, it Item) {
	w := []string{"!re"}
	for _, k := range orderedKeys(m, it) {
		w = append(w, "="+k+"="+it[k])
	}
	a.send(withTag(tag, w...)...)
}

func (a *apiConn) done(tag, ret string) {
	if ret != "" {
		a.send(withTag(tag, "!done", "=ret="+ret)...)
	} else {
		a.send(withTag(tag, "!done")...)
	}
}

func (a *apiConn) trapErr(tag string, err error) {
	msg := err.Error()
	w := []string{"!trap"}
	if t, ok := err.(*Trap); ok && t.Cat != 0 {
		w = append(w, fmt.Sprintf("=category=%d", t.Cat))
	}
	w = append(w, "=message="+msg)
	a.send(withTag(tag, w...)...)
	a.done(tag, "")
}

func serveAPI(r *Router, ln net.Listener, via string) {
	for {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		go handleAPI(r, c, via)
	}
}

func handleAPI(r *Router, c net.Conn, via string) {
	defer c.Close()
	r.mu.Lock()
	running := r.state == "running"
	r.mu.Unlock()
	if !running {
		return
	}
	if tc, ok := c.(*tls.Conn); ok {
		tc.SetDeadline(time.Now().Add(10 * time.Second))
		if err := tc.Handshake(); err != nil {
			return
		}
		tc.SetDeadline(time.Time{})
	}
	a := &apiConn{r: r, c: c, via: via, cancels: map[string]chan struct{}{}, closed: make(chan struct{})}
	kid := r.onKick(func() { c.Close() })
	defer r.offKick(kid)
	defer close(a.closed)
	defer func() {
		a.cmu.Lock()
		for _, ch := range a.cancels {
			close(ch)
		}
		a.cancels = map[string]chan struct{}{}
		a.cmu.Unlock()
		if a.session != "" {
			r.userLogout(a.session)
		}
	}()
	peer := hostOnly(c.RemoteAddr().String())
	rd := bufio.NewReaderSize(c, 64<<10)
	for {
		c.SetReadDeadline(time.Now().Add(30 * time.Minute))
		words, err := readSentence(rd)
		if err != nil {
			return
		}
		if len(words) == 0 {
			continue
		}
		cmd := words[0]
		args := map[string]string{}
		var query []string
		tag := ""
		for _, w := range words[1:] {
			switch {
			case strings.HasPrefix(w, "="):
				kv := strings.SplitN(w[1:], "=", 2)
				if len(kv) == 2 {
					args[kv[0]] = kv[1]
				} else {
					args[kv[0]] = ""
				}
			case strings.HasPrefix(w, ".tag="):
				tag = w[5:]
			case strings.HasPrefix(w, "?"):
				query = append(query, w)
			case strings.HasPrefix(w, ".proplist="):
				args[".proplist"] = w[10:]
			}
		}
		switch cmd {
		case "/login":
			a.login(tag, args, peer)
			continue
		case "/quit":
			a.send("!fatal", "session terminated on request")
			return
		case "/cancel":
			t := args["tag"]
			a.cmu.Lock()
			if t == "" {
				for k, ch := range a.cancels {
					close(ch)
					delete(a.cancels, k)
				}
			} else if ch, ok := a.cancels[t]; ok {
				close(ch)
				delete(a.cancels, t)
			}
			a.cmu.Unlock()
			a.done(tag, "")
			continue
		}
		if a.user == "" {
			a.send(withTag(tag, "!trap", "=message=not logged in")...)
			a.done(tag, "")
			continue
		}
		a.run(cmd, args, query, tag, peer)
	}
}

func hostOnly(addr string) string {
	h, _, err := net.SplitHostPort(addr)
	if err != nil {
		return addr
	}
	return h
}

func (a *apiConn) login(tag string, args map[string]string, peer string) {
	name, pass := args["name"], args["password"]
	if resp, ok := args["response"]; ok {
		// legacy challenge-response (pre 6.43)
		a.r.mu.Lock()
		u := a.r.byName("/user", name)
		a.r.mu.Unlock()
		okAuth := false
		if u != nil && len(a.chal) == 16 && len(resp) == 34 {
			h := md5.New()
			h.Write([]byte{0})
			h.Write([]byte(u["password"]))
			h.Write(a.chal)
			okAuth = "00"+hex.EncodeToString(h.Sum(nil)) == strings.ToLower(resp)
		}
		if !okAuth {
			a.trapErr(tag, trap("invalid user name or password (6)"))
			return
		}
		pass = u["password"]
	} else if _, ok := args["name"]; !ok {
		a.chal = make([]byte, 16)
		rand.Read(a.chal)
		a.done(tag, hex.EncodeToString(a.chal))
		return
	}
	if err := a.r.checkUser(name, pass, a.via, peer); err != nil {
		a.trapErr(tag, err)
		return
	}
	if a.session != "" {
		a.r.userLogout(a.session)
	}
	a.user = name
	a.session = a.r.userLogin(name, a.via, peer)
	a.done(tag, "")
}

func isStreaming(cmd string, args map[string]string) bool {
	_, once := args["once"]
	switch {
	case strings.HasSuffix(cmd, "/listen"):
		return true
	case strings.HasSuffix(cmd, "/monitor-traffic"), strings.HasSuffix(cmd, "/monitor"):
		return !once
	case cmd == "/ping" || cmd == "/tool/ping" || cmd == "/tool/traceroute" || cmd == "/tool/bandwidth-test":
		return true
	}
	return false
}

func (a *apiConn) run(cmd string, args map[string]string, query []string, tag, peer string) {
	done := make(chan struct{})
	ctx := &Ctx{User: a.user, Via: a.via, Addr: peer, Done: done}
	path, _ := splitCmd(cmd)
	m := MenuMap[path]
	exec := func() {
		var res string
		var err error
		func() {
			defer func() {
				if p := recover(); p != nil {
					err = trap("internal error: %v", p)
				}
			}()
			res, err = a.r.Exec(ctx, cmd, args, query, func(it Item) { a.reply(m, tag, it) })
		}()
		if err != nil {
			a.trapErr(tag, err)
		} else {
			a.done(tag, res)
		}
	}
	if isStreaming(cmd, args) {
		if tag != "" {
			a.cmu.Lock()
			a.cancels[tag] = done
			a.cmu.Unlock()
		} else {
			// untagged streaming: cancelled by any /cancel
			a.cmu.Lock()
			a.cancels[fmt.Sprintf("__%p", done)] = done
			a.cmu.Unlock()
		}
		go func() {
			exec()
			a.cmu.Lock()
			for k, ch := range a.cancels {
				if ch == done {
					delete(a.cancels, k)
				}
			}
			a.cmu.Unlock()
		}()
		return
	}
	exec()
}

// ---------- client (used by the GUI to manage real routers) ----------

type APIClient struct {
	mu   sync.Mutex
	c    net.Conn
	rd   *bufio.Reader
	addr string
	user string
	pass string
	tls  bool
}

func dialAPI(addr, user, pass string, useTLS bool) (*APIClient, error) {
	cl := &APIClient{addr: addr, user: user, pass: pass, tls: useTLS}
	if err := cl.connect(); err != nil {
		return nil, err
	}
	return cl, nil
}

func (cl *APIClient) connect() error {
	var c net.Conn
	var err error
	d := &net.Dialer{Timeout: 6 * time.Second}
	if cl.tls {
		c, err = tls.DialWithDialer(d, "tcp", cl.addr, &tls.Config{InsecureSkipVerify: true})
	} else {
		c, err = d.Dial("tcp", cl.addr)
	}
	if err != nil {
		return err
	}
	cl.c = c
	cl.rd = bufio.NewReader(c)
	_, ret, err := cl.talk([]string{"/login", "=name=" + cl.user, "=password=" + cl.pass})
	if err != nil {
		c.Close()
		return err
	}
	if len(ret) == 32 { // legacy challenge
		chal, _ := hex.DecodeString(ret)
		h := md5.New()
		h.Write([]byte{0})
		h.Write([]byte(cl.pass))
		h.Write(chal)
		if _, _, err := cl.talk([]string{"/login", "=name=" + cl.user, "=response=00" + hex.EncodeToString(h.Sum(nil))}); err != nil {
			c.Close()
			return err
		}
	}
	return nil
}

func (cl *APIClient) talk(words []string) ([]Item, string, error) {
	cl.c.SetDeadline(time.Now().Add(15 * time.Second))
	if _, err := cl.c.Write(encodeSentence(words)); err != nil {
		return nil, "", err
	}
	var items []Item
	var trapMsg string
	for {
		s, err := readSentence(cl.rd)
		if err != nil {
			return nil, "", err
		}
		if len(s) == 0 {
			continue
		}
		it := Item{}
		for _, w := range s[1:] {
			if strings.HasPrefix(w, "=") {
				kv := strings.SplitN(w[1:], "=", 2)
				if len(kv) == 2 {
					it[kv[0]] = kv[1]
				}
			}
		}
		switch s[0] {
		case "!re":
			items = append(items, it)
		case "!trap":
			trapMsg = it["message"]
		case "!fatal":
			return nil, "", errors.New(strings.Join(s[1:], " "))
		case "!done":
			if trapMsg != "" {
				return items, "", &Trap{Msg: trapMsg}
			}
			return items, it["ret"], nil
		}
	}
}

func (cl *APIClient) Exec(full string, args map[string]string, query []string) ([]Item, string, error) {
	cl.mu.Lock()
	defer cl.mu.Unlock()
	words := []string{full}
	for k, v := range args {
		words = append(words, "="+k+"="+v)
	}
	words = append(words, query...)
	items, ret, err := cl.talk(words)
	if err != nil {
		if _, ok := err.(*Trap); !ok {
			cl.c.Close()
			if cerr := cl.connect(); cerr != nil {
				return nil, "", cerr
			}
			return cl.talk(words)
		}
	}
	return items, ret, err
}

func (cl *APIClient) Close() {
	cl.mu.Lock()
	defer cl.mu.Unlock()
	if cl.c != nil {
		cl.c.Close()
	}
}
