package main

// Hardware catalog. Port counts, wireless, CPU and memory follow MikroTik's
// published specifications as closely as a simulator needs.

import (
	"fmt"
	"sort"
	"strings"
)

type PanelSpec struct {
	Groups []int  `json:"groups"`         // ethernet ports per group, left to right
	Rows   int    `json:"rows"`           // 1 or 2 rows of jacks
	Look   string `json:"look"`           // metal | black | white | virtual
	Rack   bool   `json:"rack,omitempty"` // 19" rack ears
	PoEIn  []int  `json:"poeIn,omitempty"`
	PoEOut []int  `json:"poeOut,omitempty"`
}

type Model struct {
	Key         string    `json:"key"`
	Board       string    `json:"board"` // /system resource board-name
	Name        string    `json:"name"`  // /system routerboard model
	Family      string    `json:"family"`
	Desc        string    `json:"desc"`
	Arch        string    `json:"arch"`
	CPU         string    `json:"cpu"`
	Cores       int       `json:"cores"`
	MHz         int       `json:"mhz"`
	MemMB       int       `json:"mem"`
	HddMB       int       `json:"hdd"`
	Ether       int       `json:"ether"`              // etherN ports
	FastFrom    int       `json:"fastFrom,omitempty"` // ports >= this index are 10/100 (0 = none)
	Gig25       []int     `json:"gig25,omitempty"`    // 2.5G copper ports
	SFP         int       `json:"sfp"`
	SFPName     string    `json:"sfpName,omitempty"` // sfp | sfp-sfpplus
	Combo       int       `json:"combo,omitempty"`
	WLAN        int       `json:"wlan"`
	WifiAX      bool      `json:"wifiAX,omitempty"` // Wi-Fi 6 (wifi package, wifiN interfaces)
	Level       string    `json:"level"`
	RouterBoard bool      `json:"routerboard"`
	CapMbps     float64   `json:"-"`
	Panel       PanelSpec `json:"panel"`
	Serial      string    `json:"-"`
	Firmware    string    `json:"-"`
	LanSplit    int       `json:"-"`
}

var ModelOrder []string
var Models = map[string]*Model{}
var modelAliases = map[string]string{"hap": "hap-ac2", "hapac2": "hap-ac2", "hexs": "hex-s", "rb4011igs": "rb4011", "rb5009ug": "rb5009"}

func lookupModel(key string) *Model {
	k := strings.ToLower(strings.TrimSpace(key))
	if a, ok := modelAliases[k]; ok {
		k = a
	}
	return Models[k]
}

func addModel(m *Model) {
	if m.Firmware == "" && m.RouterBoard {
		m.Firmware = "7.18.2"
	}
	if m.Panel.Rows == 0 {
		m.Panel.Rows = 1
	}
	if m.LanSplit == 0 {
		m.LanSplit = (m.Ether + 1) / 2
		if m.LanSplit < 1 {
			m.LanSplit = 1
		}
	}
	if m.SFPName == "" {
		m.SFPName = "sfp"
	}
	Models[m.Key] = m
	ModelOrder = append(ModelOrder, m.Key)
}

func init() {
	// ---- home & office (hAP / hEX / classic RB) ----
	addModel(&Model{Key: "hap-lite", Board: "hAP lite", Name: "RB941-2nD", Family: "home", Desc: "Entry-level 2.4 GHz home access point, very common for small hotspots",
		Arch: "smips", CPU: "QCA9533", Cores: 1, MHz: 650, MemMB: 32, HddMB: 16, Ether: 4, FastFrom: 1, WLAN: 1, Level: "4", RouterBoard: true, CapMbps: 80, LanSplit: 2,
		Panel: PanelSpec{Groups: []int{1, 3}, Look: "white", PoEOut: []int{4}}})
	addModel(&Model{Key: "hap-ac-lite", Board: "hAP ac lite", Name: "RB952Ui-5ac2nD", Family: "home", Desc: "Dual-band home router with 10/100 ports and PoE out",
		Arch: "mipsbe", CPU: "QCA9531", Cores: 1, MHz: 650, MemMB: 64, HddMB: 16, Ether: 5, FastFrom: 1, WLAN: 2, Level: "4", RouterBoard: true, CapMbps: 120,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "white", PoEOut: []int{5}}})
	addModel(&Model{Key: "hap-ac2", Board: "hAP ac^2", Name: "RBD52G-5HacD2HnD", Family: "home", Desc: "Dual-band Gigabit home router, a favourite for SOHO hotspots",
		Arch: "arm", CPU: "ARM", Cores: 4, MHz: 716, MemMB: 128, HddMB: 16, Ether: 5, WLAN: 2, Level: "4", RouterBoard: true, CapMbps: 450,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "white", PoEIn: []int{1}}})
	addModel(&Model{Key: "hap-ac3", Board: "hAP ac^3", Name: "RBD53iG-5HacD2HnD", Family: "home", Desc: "Dual-band Gigabit router with high-gain antennas and USB",
		Arch: "arm", CPU: "ARM", Cores: 4, MHz: 716, MemMB: 256, HddMB: 128, Ether: 5, WLAN: 2, Level: "4", RouterBoard: true, CapMbps: 450,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "black", PoEIn: []int{1}, PoEOut: []int{5}}})
	addModel(&Model{Key: "hap-ax2", Board: "hAP ax^2", Name: "C52iG-5HaxD2HaxD", Family: "home", Desc: "Wi-Fi 6 dual-band Gigabit router (RouterOS 7 wifi package)",
		Arch: "arm64", CPU: "ARM64", Cores: 4, MHz: 864, MemMB: 1024, HddMB: 128, Ether: 5, WLAN: 2, WifiAX: true, Level: "4", RouterBoard: true, CapMbps: 1000,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "white", PoEIn: []int{1}, PoEOut: []int{5}}})
	addModel(&Model{Key: "hap-ax3", Board: "hAP ax^3", Name: "C53UiG+5HPaxD2HPaxD", Family: "home", Desc: "Wi-Fi 6 router with a 2.5 Gigabit WAN port",
		Arch: "arm64", CPU: "ARM64", Cores: 4, MHz: 1800, MemMB: 1024, HddMB: 128, Ether: 5, Gig25: []int{1}, WLAN: 2, WifiAX: true, Level: "4", RouterBoard: true, CapMbps: 2000,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "black", PoEIn: []int{1}}})
	addModel(&Model{Key: "hex-lite", Board: "hEX lite", Name: "RB750r2", Family: "home", Desc: "Five-port 10/100 wired router",
		Arch: "smips", CPU: "QCA9533", Cores: 1, MHz: 850, MemMB: 64, HddMB: 16, Ether: 5, FastFrom: 1, Level: "4", RouterBoard: true, CapMbps: 150,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "black", PoEIn: []int{1}}})
	addModel(&Model{Key: "hex", Board: "hEX", Name: "RB750Gr3", Family: "home", Desc: "Five-port Gigabit wired router",
		Arch: "mmips", CPU: "MIPS 1004Kc V2.15", Cores: 4, MHz: 880, MemMB: 256, HddMB: 16, Ether: 5, Level: "4", RouterBoard: true, CapMbps: 400,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "black", PoEIn: []int{1}}})
	addModel(&Model{Key: "hex-s", Board: "hEX S", Name: "RB760iGS", Family: "home", Desc: "Five-port Gigabit router with an SFP cage and PoE out",
		Arch: "mmips", CPU: "MIPS 1004Kc V2.15", Cores: 4, MHz: 880, MemMB: 256, HddMB: 16, Ether: 5, SFP: 1, Level: "4", RouterBoard: true, CapMbps: 450,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "black", PoEIn: []int{1}, PoEOut: []int{5}}})
	addModel(&Model{Key: "rb951", Board: "RB951Ui-2HnD", Name: "RB951Ui-2HnD", Family: "home", Desc: "Classic 2.4 GHz office router still common in the field",
		Arch: "mipsbe", CPU: "MIPS 74Kc V4.12", Cores: 1, MHz: 600, MemMB: 128, HddMB: 128, Ether: 5, FastFrom: 1, WLAN: 1, Level: "4", RouterBoard: true, CapMbps: 150,
		Panel: PanelSpec{Groups: []int{1, 4}, Look: "white", PoEIn: []int{1}, PoEOut: []int{5}}})

	// ---- routers ----
	addModel(&Model{Key: "rb2011", Board: "RB2011UiAS-2HnD", Name: "RB2011UiAS-2HnD-IN", Family: "router", Desc: "Ten ports (5 Gigabit + 5 Fast Ethernet), SFP and 2.4 GHz wireless",
		Arch: "mipsbe", CPU: "MIPS 74Kc V4.12", Cores: 1, MHz: 600, MemMB: 128, HddMB: 128, Ether: 10, FastFrom: 6, SFP: 1, WLAN: 1, Level: "5", RouterBoard: true, CapMbps: 250,
		Panel: PanelSpec{Groups: []int{5, 5}, Look: "white", PoEIn: []int{1}, PoEOut: []int{10}}})
	addModel(&Model{Key: "rb3011", Board: "RB3011UiAS", Name: "RB3011UiAS-RM", Family: "router", Desc: "Rack-mount dual-core router with ten Gigabit ports and SFP",
		Arch: "arm", CPU: "ARMv7", Cores: 2, MHz: 1400, MemMB: 1024, HddMB: 128, Ether: 10, SFP: 1, Level: "5", RouterBoard: true, CapMbps: 800,
		Panel: PanelSpec{Groups: []int{5, 5}, Look: "metal", Rack: true, PoEOut: []int{10}}})
	addModel(&Model{Key: "rb4011", Board: "RB4011iGS+", Name: "RB4011iGS+", Family: "router", Desc: "Quad-core router with ten Gigabit ports and SFP+ (default model)",
		Arch: "arm", CPU: "ARMv7", Cores: 4, MHz: 1400, MemMB: 1024, HddMB: 512, Ether: 10, SFP: 1, SFPName: "sfp-sfpplus", Level: "5", RouterBoard: true, CapMbps: 2000,
		Panel: PanelSpec{Groups: []int{5, 5}, Look: "metal", PoEIn: []int{1}, PoEOut: []int{10}}})
	addModel(&Model{Key: "rb5009", Board: "RB5009UG+S+", Name: "RB5009UG+S+", Family: "router", Desc: "2.5G WAN, seven Gigabit ports and 10G SFP+, a popular ISP edge router",
		Arch: "arm64", CPU: "ARM64", Cores: 4, MHz: 1400, MemMB: 1024, HddMB: 1024, Ether: 8, Gig25: []int{1}, SFP: 1, SFPName: "sfp-sfpplus", Level: "5", RouterBoard: true, CapMbps: 4000,
		Panel: PanelSpec{Groups: []int{1, 7}, Look: "metal", PoEIn: []int{1}, PoEOut: []int{8}}})
	addModel(&Model{Key: "l009", Board: "L009UiGS", Name: "L009UiGS-RM", Family: "router", Desc: "Eight Gigabit ports and a 2.5G SFP in a compact rack case",
		Arch: "arm", CPU: "ARM", Cores: 2, MHz: 800, MemMB: 512, HddMB: 128, Ether: 8, SFP: 1, Level: "5", RouterBoard: true, CapMbps: 900,
		Panel: PanelSpec{Groups: []int{8}, Look: "metal", Rack: true, PoEIn: []int{1}, PoEOut: []int{8}}})

	// ---- cloud core ----
	addModel(&Model{Key: "ccr1009", Board: "CCR1009-7G-1C-1S+", Name: "CCR1009-7G-1C-1S+", Family: "ccr", Desc: "Nine-core Tilera router with a combo port and SFP+",
		Arch: "tile", CPU: "tilegx", Cores: 9, MHz: 1200, MemMB: 2048, HddMB: 128, Ether: 7, Combo: 1, SFP: 1, SFPName: "sfp-sfpplus", Level: "6", RouterBoard: true, CapMbps: 3000,
		Panel: PanelSpec{Groups: []int{7}, Look: "metal", Rack: true}})
	addModel(&Model{Key: "ccr1036", Board: "CCR1036-12G-4S", Name: "CCR1036-12G-4S", Family: "ccr", Desc: "36-core Tilera core router used by many ISPs",
		Arch: "tile", CPU: "tilegx", Cores: 36, MHz: 1200, MemMB: 4096, HddMB: 1024, Ether: 12, SFP: 4, Level: "6", RouterBoard: true, CapMbps: 10000,
		Panel: PanelSpec{Groups: []int{4, 4, 4}, Rows: 2, Look: "metal", Rack: true}})
	addModel(&Model{Key: "ccr2004", Board: "CCR2004-16G-2S+", Name: "CCR2004-16G-2S+", Family: "ccr", Desc: "Sixteen Gigabit ports and two 10G SFP+ on ARM64",
		Arch: "arm64", CPU: "ARM64", Cores: 4, MHz: 1700, MemMB: 4096, HddMB: 128, Ether: 16, SFP: 2, SFPName: "sfp-sfpplus", Level: "6", RouterBoard: true, CapMbps: 8000,
		Panel: PanelSpec{Groups: []int{8, 8}, Rows: 2, Look: "metal", Rack: true}})
	addModel(&Model{Key: "ccr2116", Board: "CCR2116-12G-4S+", Name: "CCR2116-12G-4S+", Family: "ccr", Desc: "Sixteen-core ARM64 core router with four 10G SFP+",
		Arch: "arm64", CPU: "ARM64", Cores: 16, MHz: 2000, MemMB: 16384, HddMB: 128, Ether: 13, SFP: 4, SFPName: "sfp-sfpplus", Level: "6", RouterBoard: true, CapMbps: 20000,
		Panel: PanelSpec{Groups: []int{1, 6, 6}, Rows: 2, Look: "metal", Rack: true}})

	// ---- switches ----
	addModel(&Model{Key: "crs326", Board: "CRS326-24G-2S+", Name: "CRS326-24G-2S+RM", Family: "switch", Desc: "24-port Gigabit switch with two SFP+, running RouterOS",
		Arch: "arm", CPU: "ARMv7", Cores: 1, MHz: 800, MemMB: 512, HddMB: 16, Ether: 24, SFP: 2, SFPName: "sfp-sfpplus", Level: "5", RouterBoard: true, CapMbps: 250,
		Panel: PanelSpec{Groups: []int{8, 8, 8}, Rows: 2, Look: "metal", Rack: true}})
	addModel(&Model{Key: "crs328", Board: "CRS328-24P-4S+", Name: "CRS328-24P-4S+RM", Family: "switch", Desc: "24-port PoE-out Gigabit switch with four SFP+",
		Arch: "arm", CPU: "ARMv7", Cores: 1, MHz: 800, MemMB: 512, HddMB: 16, Ether: 24, SFP: 4, SFPName: "sfp-sfpplus", Level: "5", RouterBoard: true, CapMbps: 250,
		Panel: PanelSpec{Groups: []int{8, 8, 8}, Rows: 2, Look: "metal", Rack: true, PoEOut: []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}}})

	// ---- access points ----
	addModel(&Model{Key: "cap-ac", Board: "cAP ac", Name: "RBcAPGi-5acD2nD", Family: "ap", Desc: "Ceiling-mount dual-band access point for hotspots",
		Arch: "arm", CPU: "ARM", Cores: 4, MHz: 716, MemMB: 128, HddMB: 16, Ether: 2, WLAN: 2, Level: "4", RouterBoard: true, CapMbps: 400, LanSplit: 1,
		Panel: PanelSpec{Groups: []int{1, 1}, Look: "white", PoEIn: []int{1}, PoEOut: []int{2}}})
	addModel(&Model{Key: "wap-ac", Board: "wAP ac", Name: "RBwAPG-5HacD2HnD", Family: "ap", Desc: "Weatherproof dual-band access point for outdoor hotspots",
		Arch: "arm", CPU: "ARM", Cores: 4, MHz: 716, MemMB: 128, HddMB: 16, Ether: 1, WLAN: 2, Level: "4", RouterBoard: true, CapMbps: 350, LanSplit: 1,
		Panel: PanelSpec{Groups: []int{1}, Look: "white", PoEIn: []int{1}}})

	// ---- virtual ----
	addModel(&Model{Key: "chr", Board: "CHR", Name: "CHR QEMU Standard PC", Family: "virtual", Desc: "Cloud Hosted Router, the x86 virtual machine edition",
		Arch: "x86_64", CPU: "QEMU", Cores: 2, MHz: 2400, MemMB: 1024, HddMB: 1024, Ether: 4, Level: "free", CapMbps: 3000, LanSplit: 2,
		Panel: PanelSpec{Groups: []int{4}, Look: "virtual"}})
}

// portSpeed returns the default link speed of ethernet port n (1-based)
func (m *Model) portSpeed(n int) string {
	for _, p := range m.Gig25 {
		if p == n {
			return "2.5G"
		}
	}
	if m.FastFrom > 0 && n >= m.FastFrom {
		return "100M"
	}
	return "1G"
}

func (m *Model) portNames() (ether, sfp, wl []string) {
	ether, sfp, wl = []string{}, []string{}, []string{}
	for i := 1; i <= m.Ether; i++ {
		ether = append(ether, fmt.Sprintf("ether%d", i))
	}
	for i := 1; i <= m.Combo; i++ {
		ether = append(ether, fmt.Sprintf("combo%d", i))
	}
	for i := 1; i <= m.SFP; i++ {
		sfp = append(sfp, fmt.Sprintf("%s%d", m.SFPName, i))
	}
	for i := 1; i <= m.WLAN; i++ {
		if m.WifiAX {
			wl = append(wl, fmt.Sprintf("wifi%d", i))
		} else {
			wl = append(wl, fmt.Sprintf("wlan%d", i))
		}
	}
	return
}

func (m *Model) wirelessKind() string {
	if m.WLAN == 0 {
		return ""
	}
	if m.WifiAX {
		return "wifi"
	}
	return "wlan"
}

func (m *Model) summary() string {
	var p []string
	speeds := map[string]int{}
	for i := 1; i <= m.Ether; i++ {
		speeds[m.portSpeed(i)]++
	}
	for _, s := range []string{"2.5G", "1G", "100M"} {
		if speeds[s] > 0 {
			p = append(p, fmt.Sprintf("%d x %s", speeds[s], s))
		}
	}
	if m.Combo > 0 {
		p = append(p, fmt.Sprintf("%d combo", m.Combo))
	}
	if m.SFP > 0 {
		n := "SFP"
		if m.SFPName == "sfp-sfpplus" {
			n = "SFP+"
		}
		p = append(p, fmt.Sprintf("%d x %s", m.SFP, n))
	}
	if m.WLAN > 0 {
		if m.WifiAX {
			p = append(p, "Wi-Fi 6")
		} else if m.WLAN > 1 {
			p = append(p, "dual-band wireless")
		} else {
			p = append(p, "2.4 GHz wireless")
		}
	}
	return strings.Join(p, ", ")
}

func printModelList() {
	fmt.Println("\n  Available router models (use -model KEY):")
	fams := map[string]string{"home": "Home & office", "router": "Routers", "ccr": "Cloud Core", "switch": "Switches", "ap": "Access points", "virtual": "Virtual"}
	cur := ""
	for _, k := range ModelOrder {
		m := Models[k]
		if fams[m.Family] != cur {
			cur = fams[m.Family]
			fmt.Printf("\n  %s\n", cur)
		}
		fmt.Printf("    %-12s %-20s %s\n", m.Key, m.Board, m.summary())
	}
	fmt.Println()
}

func modelKeys() []string {
	k := append([]string(nil), ModelOrder...)
	sort.Strings(k)
	return k
}
