package main

import (
	"bufio"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"embed"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"io/fs"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

//go:embed web
var webFS embed.FS

type guiSession struct {
	token  string
	user   string
	addr   string
	local  bool
	remote *APIClient
	last   time.Time
	actID  string
	epoch  int
	target string
}

type Web struct {
	r        *Router
	mndp     *MNDP
	mu       sync.Mutex
	sessions map[string]*guiSession
}

func newWeb(r *Router, m *MNDP) *Web {
	w := &Web{r: r, mndp: m, sessions: map[string]*guiSession{}}
	go func() {
		for range time.Tick(time.Minute) {
			w.mu.Lock()
			for k, s := range w.sessions {
				if time.Since(s.last) > 2*time.Hour {
					if s.remote != nil {
						s.remote.Close()
					}
					if s.actID != "" {
						go r.userLogout(s.actID)
					}
					delete(w.sessions, k)
				}
			}
			w.mu.Unlock()
		}
	}()
	return w
}

func (w *Web) handler(kind string) http.Handler {
	mux := http.NewServeMux()
	sub, _ := fs.Sub(webFS, "web")
	static := http.FileServer(http.FS(sub))
	mux.HandleFunc("/rest/", w.rest)
	mux.HandleFunc("/rest", w.rest)
	mux.HandleFunc("/gui/", w.gui)
	mux.HandleFunc("/login", w.portal)
	mux.HandleFunc("/logout", w.portal)
	mux.HandleFunc("/status", w.portal)
	mux.HandleFunc("/hotspot/", w.portal)
	mux.HandleFunc("/md5.js", w.portal)
	mux.HandleFunc("/hspreview/", w.hsPreview)
	mux.HandleFunc("/", func(rw http.ResponseWriter, req *http.Request) {
		if req.URL.Path == "/webfig" || strings.HasPrefix(req.URL.Path, "/webfig/") {
			http.Redirect(rw, req, "/", http.StatusFound)
			return
		}
		if req.URL.Path != "/" {
			if _, err := fs.Stat(sub, strings.TrimPrefix(req.URL.Path, "/")); err != nil {
				// not a console asset: serve files of the active hotspot page set
				if w.serveHotspotAsset(rw, req) {
					return
				}
			}
		}
		rw.Header().Set("Cache-Control", "no-cache")
		static.ServeHTTP(rw, req)
	})
	return withServerHeader(mux)
}

func withServerHeader(h http.Handler) http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, req *http.Request) {
		rw.Header().Set("Server", "TikLab")
		h.ServeHTTP(rw, req)
	})
}

func jsonOut(rw http.ResponseWriter, code int, v any) {
	rw.Header().Set("Content-Type", "application/json")
	rw.WriteHeader(code)
	enc := json.NewEncoder(rw)
	enc.SetEscapeHTML(false)
	enc.Encode(v)
}

func clientIP(req *http.Request) string { return hostOnly(req.RemoteAddr) }

// ------------------------------------------------------------------ REST

func restErr(rw http.ResponseWriter, code int, detail string) {
	msg := map[int]string{400: "Bad Request", 401: "Unauthorized", 404: "Not Found", 500: "Internal Server Error", 503: "Service Unavailable"}[code]
	body := map[string]any{"error": code, "message": msg}
	if detail != "" {
		body["detail"] = detail
	}
	jsonOut(rw, code, body)
}

func anyToStr(v any) string {
	switch x := v.(type) {
	case string:
		return x
	case bool:
		return strconv.FormatBool(x)
	case float64:
		if x == float64(int64(x)) {
			return strconv.FormatInt(int64(x), 10)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	case []any:
		var p []string
		for _, e := range x {
			p = append(p, anyToStr(e))
		}
		return strings.Join(p, ",")
	case nil:
		return ""
	}
	return fmt.Sprint(v)
}

func (w *Web) rest(rw http.ResponseWriter, req *http.Request) {
	r := w.r
	r.mu.Lock()
	svc := r.byName("/ip/service", "www")
	if req.TLS != nil {
		svc = r.byName("/ip/service", "www-ssl")
	}
	disabled := svc != nil && svc.B("disabled")
	state := r.state
	r.mu.Unlock()
	if disabled {
		restErr(rw, 404, "")
		return
	}
	if state != "running" {
		restErr(rw, 503, "router is not running")
		return
	}
	user, pass, ok := req.BasicAuth()
	if !ok {
		rw.Header().Set("WWW-Authenticate", `Basic realm="RouterOS"`)
		restErr(rw, 401, "")
		return
	}
	if err := r.checkUser(user, pass, "rest", clientIP(req)); err != nil {
		rw.Header().Set("WWW-Authenticate", `Basic realm="RouterOS"`)
		restErr(rw, 401, "")
		return
	}
	ctx := &Ctx{User: user, Via: "rest", Addr: clientIP(req)}
	p := "/" + strings.Trim(strings.TrimPrefix(req.URL.Path, "/rest"), "/")
	if up, err := url.PathUnescape(p); err == nil {
		p = up
	}
	body := map[string]string{}
	var proplist string
	var query []string
	if req.Body != nil && (req.Method == "PUT" || req.Method == "PATCH" || req.Method == "POST") {
		raw, _ := io.ReadAll(io.LimitReader(req.Body, 8<<20))
		if len(strings.TrimSpace(string(raw))) > 0 {
			var m map[string]any
			if err := json.Unmarshal(raw, &m); err != nil {
				restErr(rw, 400, "JSON parse error")
				return
			}
			for k, v := range m {
				switch k {
				case ".proplist":
					proplist = anyToStr(v)
				case ".query":
					if arr, ok := v.([]any); ok {
						for _, q := range arr {
							query = append(query, "?"+anyToStr(q))
						}
					}
				default:
					body[k] = anyToStr(v)
				}
			}
		}
	}
	qp := req.URL.Query()
	if pl := qp.Get(".proplist"); pl != "" {
		proplist = pl
	}
	collect := func(full string, args map[string]string, q []string) ([]Item, string, error) {
		var items []Item
		if proplist != "" {
			args[".proplist"] = proplist
		}
		ret, err := r.Exec(ctx, full, args, q, func(it Item) { items = append(items, it) })
		return items, ret, err
	}
	fail := func(err error) {
		msg := err.Error()
		if strings.HasPrefix(msg, "no such command") {
			restErr(rw, 400, "no such command or directory ("+strings.TrimPrefix(p, "/")+")")
			return
		}
		if msg == "no such item" {
			restErr(rw, 404, "")
			return
		}
		restErr(rw, 400, msg)
	}
	m := MenuMap[p]
	parent, last := splitCmd(p)
	pm := MenuMap[parent]
	switch req.Method {
	case "GET":
		if m != nil {
			var q []string
			for k, vs := range qp {
				if strings.HasPrefix(k, ".") {
					continue
				}
				q = append(q, "?"+k+"="+vs[0])
			}
			items, _, err := collect(p+"/print", map[string]string{}, q)
			if err != nil {
				fail(err)
				return
			}
			if m.Single {
				if len(items) > 0 {
					jsonOut(rw, 200, items[0])
				} else {
					jsonOut(rw, 200, map[string]string{})
				}
				return
			}
			if items == nil {
				items = []Item{}
			}
			jsonOut(rw, 200, items)
			return
		}
		if pm != nil && !pm.Single {
			it, err := w.restItem(ctx, pm, last, proplist)
			if err != nil {
				restErr(rw, 404, "")
				return
			}
			jsonOut(rw, 200, it)
			return
		}
		restErr(rw, 400, "no such command or directory ("+strings.TrimPrefix(p, "/")+")")
	case "PUT":
		if m == nil || m.Single {
			restErr(rw, 400, "no such command or directory ("+strings.TrimPrefix(p, "/")+")")
			return
		}
		_, ret, err := collect(p+"/add", body, nil)
		if err != nil {
			fail(err)
			return
		}
		it, err := w.restItem(ctx, m, ret, proplist)
		if err != nil {
			jsonOut(rw, 201, map[string]string{".id": ret})
			return
		}
		jsonOut(rw, 201, it)
	case "PATCH":
		if m != nil && m.Single {
			if _, _, err := collect(p+"/set", body, nil); err != nil {
				fail(err)
				return
			}
			items, _, _ := collect(p+"/print", map[string]string{}, nil)
			if len(items) > 0 {
				jsonOut(rw, 200, items[0])
			} else {
				jsonOut(rw, 200, map[string]string{})
			}
			return
		}
		if pm == nil {
			restErr(rw, 400, "no such command or directory ("+strings.TrimPrefix(p, "/")+")")
			return
		}
		body[".id"] = last
		if _, _, err := collect(parent+"/set", body, nil); err != nil {
			fail(err)
			return
		}
		r.mu.Lock()
		cur := r.findRef(pm, last)
		id := last
		if cur != nil {
			id = cur[".id"]
		}
		r.mu.Unlock()
		it, err := w.restItem(ctx, pm, id, proplist)
		if err != nil {
			restErr(rw, 404, "")
			return
		}
		jsonOut(rw, 200, it)
	case "DELETE":
		if pm == nil {
			restErr(rw, 400, "no such command or directory ("+strings.TrimPrefix(p, "/")+")")
			return
		}
		if _, _, err := collect(parent+"/remove", map[string]string{".id": last}, nil); err != nil {
			fail(err)
			return
		}
		rw.WriteHeader(204)
	case "POST":
		if strings.HasSuffix(p, "/monitor-traffic") || strings.HasSuffix(p, "/monitor") {
			if _, ok := body["duration"]; !ok {
				body["once"] = ""
			}
		}
		if strings.HasSuffix(p, "/listen") {
			restErr(rw, 400, "listen is not supported over REST")
			return
		}
		if (strings.HasSuffix(p, "/ping") || strings.HasSuffix(p, "/traceroute")) && body["count"] == "" {
			body["count"] = "4"
		}
		if v, ok := body["once"]; ok && (v == "true" || v == "yes") {
			body["once"] = ""
		}
		items, ret, err := collect(p, body, query)
		if err != nil {
			fail(err)
			return
		}
		if len(items) == 0 && ret != "" {
			jsonOut(rw, 200, map[string]string{"ret": ret})
			return
		}
		if items == nil {
			items = []Item{}
		}
		jsonOut(rw, 200, items)
	default:
		restErr(rw, 400, "unsupported method")
	}
}

func (w *Web) restItem(ctx *Ctx, m *Menu, ref, proplist string) (Item, error) {
	w.r.mu.Lock()
	it := w.r.findRef(m, ref)
	w.r.mu.Unlock()
	if it == nil {
		return nil, errors.New("not found")
	}
	var found Item
	args := map[string]string{}
	if proplist != "" {
		args[".proplist"] = proplist
	}
	w.r.Exec(ctx, m.Path+"/print", args, []string{"?.id=" + it[".id"]}, func(x Item) { found = x })
	if found == nil {
		return nil, errors.New("not found")
	}
	return found, nil
}

// ------------------------------------------------------------------ GUI backend

func newToken() string {
	b := make([]byte, 18)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func (w *Web) session(tok string) *guiSession {
	w.mu.Lock()
	defer w.mu.Unlock()
	s := w.sessions[tok]
	if s != nil {
		s.last = time.Now()
	}
	return s
}

type execReq struct {
	T     string            `json:"t"`
	Cmd   string            `json:"cmd"`
	Args  map[string]string `json:"args"`
	Query []string          `json:"query"`
}

func (w *Web) isLocalTarget(host string) bool {
	if host == "" || host == "localhost" || host == "127.0.0.1" || host == "::1" || host == "local" || host == "this" {
		return true
	}
	w.r.mu.Lock()
	defer w.r.mu.Unlock()
	for _, a := range w.r.list(MenuMap["/ip/address"]) {
		if strings.Split(a["address"], "/")[0] == host {
			return true
		}
	}
	if hn := hostNet(); hn.ip != nil && hn.ip.String() == host {
		return true
	}
	return false
}

func (w *Web) gui(rw http.ResponseWriter, req *http.Request) {
	r := w.r
	switch strings.TrimPrefix(req.URL.Path, "/gui/") {
	case "schema":
		rw.Header().Set("Cache-Control", "max-age=60")
		jsonOut(rw, 200, map[string]any{"menus": Menus, "version": AppVersion})
	case "models":
		r.mu.Lock()
		cur := r.Model.Key
		r.mu.Unlock()
		var list []map[string]any
		for _, k := range ModelOrder {
			m := Models[k]
			e, sf, wl := m.portNames()
			speeds := map[string]string{}
			for i := 1; i <= m.Ether; i++ {
				speeds[fmt.Sprintf("ether%d", i)] = m.portSpeed(i)
			}
			list = append(list, map[string]any{"key": m.Key, "board": m.Board, "name": m.Name, "family": m.Family, "desc": m.Desc, "arch": m.Arch, "cores": m.Cores, "mhz": m.MHz, "mem": m.MemMB, "hdd": m.HddMB, "summary": m.summary(), "panel": m.Panel, "ether": e, "sfp": sf, "wireless": wl, "wkind": m.wirelessKind(), "speeds": speeds, "sfpName": m.SFPName, "current": k == cur})
		}
		jsonOut(rw, 200, map[string]any{"current": cur, "models": list})
	case "state":
		r.mu.Lock()
		st := map[string]any{"state": r.state, "epoch": r.epoch, "uptime": int(time.Since(r.boot).Seconds()), "identity": r.S("/system/identity", "name")}
		r.mu.Unlock()
		jsonOut(rw, 200, st)
	case "neighbors":
		if req.URL.Query().Get("refresh") != "" && w.mndp != nil {
			w.mndp.Discover()
			time.Sleep(700 * time.Millisecond)
		}
		out := []map[string]any{}
		if w.mndp != nil {
			for _, n := range w.mndp.List() {
				out = append(out, map[string]any{"mac": n.MAC, "ip": n.IP, "identity": n.Identity, "version": n.Version, "board": n.Board, "platform": n.Platform, "uptime": fmtDur(time.Duration(n.Uptime) * time.Second), "tiklab": n.TikLab, "gui": n.GUIPort, "api": n.APIPort, "web": n.WebPort})
			}
		}
		sort.Slice(out, func(i, j int) bool { return fmt.Sprint(out[i]["ip"]) < fmt.Sprint(out[j]["ip"]) })
		r.mu.Lock()
		self := map[string]any{"mac": "", "ip": hostNet().ip.String(), "identity": r.S("/system/identity", "name"), "version": r.Ver, "board": r.Model.Board, "uptime": fmtDur(time.Since(r.boot).Truncate(time.Second)), "self": true, "tiklab": true}
		if w1 := r.byName("/interface", "ether1"); w1 != nil {
			self["mac"] = w1["mac-address"]
		}
		r.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"self": self, "list": out})
	case "login":
		var body struct {
			Host, User, Password string
			Port                 int
			TLS                  bool
		}
		json.NewDecoder(req.Body).Decode(&body)
		host := strings.TrimSpace(body.Host)
		port := body.Port
		if h, p, err := net.SplitHostPort(host); err == nil {
			host = h
			port, _ = strconv.Atoi(p)
		}
		s := &guiSession{token: newToken(), user: body.User, addr: clientIP(req), last: time.Now(), target: host}
		if w.isLocalTarget(host) && (port == 0 || port == r.svc.port("winbox") || port == r.svc.port("www") || port == r.svc.port("api")) {
			r.mu.Lock()
			st := r.state
			r.mu.Unlock()
			if st != "running" {
				jsonOut(rw, 200, map[string]any{"error": "router is " + map[string]string{"booting": "booting, please wait", "off": "powered off"}[st], "state": st})
				return
			}
			if err := r.checkUser(body.User, body.Password, "winbox", s.addr); err != nil {
				jsonOut(rw, 200, map[string]any{"error": "ERROR: wrong username or password"})
				return
			}
			s.local = true
			s.user = strings.SplitN(body.User, "+", 2)[0]
			s.actID = r.userLogin(s.user, "winbox", s.addr)
			r.mu.Lock()
			s.epoch = r.epoch
			r.mu.Unlock()
		} else {
			if port == 0 {
				port = 8728
			}
			cl, err := dialAPI(net.JoinHostPort(host, strconv.Itoa(port)), body.User, body.Password, body.TLS)
			if err != nil {
				msg := err.Error()
				if strings.Contains(msg, "refused") {
					msg = "could not connect to " + net.JoinHostPort(host, strconv.Itoa(port)) + " (is the API service enabled on the router?)"
				}
				jsonOut(rw, 200, map[string]any{"error": "ERROR: " + msg})
				return
			}
			s.remote = cl
		}
		w.mu.Lock()
		w.sessions[s.token] = s
		w.mu.Unlock()
		info := w.info(s)
		info["t"] = s.token
		jsonOut(rw, 200, info)
	case "info":
		s := w.session(req.URL.Query().Get("t"))
		if s == nil {
			jsonOut(rw, 200, map[string]any{"error": "session expired"})
			return
		}
		jsonOut(rw, 200, w.info(s))
	case "logout":
		var body struct{ T string }
		json.NewDecoder(req.Body).Decode(&body)
		w.mu.Lock()
		s := w.sessions[body.T]
		delete(w.sessions, body.T)
		w.mu.Unlock()
		if s != nil {
			if s.remote != nil {
				s.remote.Close()
			}
			if s.actID != "" {
				r.userLogout(s.actID)
			}
		}
		jsonOut(rw, 200, map[string]any{})
	case "exec":
		var er execReq
		if err := json.NewDecoder(req.Body).Decode(&er); err != nil {
			jsonOut(rw, 400, map[string]any{"error": "bad request"})
			return
		}
		s := w.session(er.T)
		if s == nil {
			jsonOut(rw, 200, map[string]any{"error": "session expired", "expired": true})
			return
		}
		if er.Args == nil {
			er.Args = map[string]string{}
		}
		if strings.HasSuffix(er.Cmd, "/monitor-traffic") || strings.HasSuffix(er.Cmd, "/monitor") {
			er.Args["once"] = ""
		}
		if strings.HasSuffix(er.Cmd, "/ping") && er.Args["count"] == "" {
			er.Args["count"] = "4"
		}
		var items []Item
		var ret string
		var err error
		if s.remote != nil {
			items, ret, err = s.remote.Exec(er.Cmd, er.Args, er.Query)
		} else {
			r.mu.Lock()
			st, ep := r.state, r.epoch
			r.mu.Unlock()
			if st != "running" {
				jsonOut(rw, 200, map[string]any{"error": "router is " + st, "state": st})
				return
			}
			if ep != s.epoch {
				s.epoch = ep
				s.actID = r.userLogin(s.user, "winbox", s.addr)
			}
			ret, err = r.Exec(&Ctx{User: s.user, Via: "winbox", Addr: s.addr}, er.Cmd, er.Args, er.Query, func(it Item) { items = append(items, it) })
		}
		if items == nil {
			items = []Item{}
		}
		out := map[string]any{"items": items, "ret": ret}
		if err != nil {
			out["error"] = err.Error()
		}
		jsonOut(rw, 200, out)
	case "files/upload", "files/download", "config/export", "config/analyze", "config/import", "config/sections", "real/probe", "real/clone", "real/send", "hotspot/dirs", "hotspot/check", "hotspot/activate", "hotspot/copy":
		w.transferAPI(rw, req, strings.TrimPrefix(req.URL.Path, "/gui/"))
	case "dash":
		s := w.session(req.URL.Query().Get("t"))
		if s == nil {
			jsonOut(rw, 200, map[string]any{"error": "session expired", "expired": true})
			return
		}
		if s.local {
			r.mu.Lock()
			st := r.state
			r.mu.Unlock()
			if st != "running" {
				jsonOut(rw, 200, map[string]any{"error": "router is " + st, "state": st})
				return
			}
		}
		jsonOut(rw, 200, w.dash(s))
	case "power":
		var body struct{ T, Action string }
		json.NewDecoder(req.Body).Decode(&body)
		s := w.session(body.T)
		if s == nil || !s.local {
			jsonOut(rw, 200, map[string]any{"error": "not allowed"})
			return
		}
		switch body.Action {
		case "on":
			r.Exec(&Ctx{User: s.user, Internal: true}, "/sim/power-on", nil, nil, nil)
		case "off":
			go r.powerCycle("shutdown")
		case "reboot":
			go r.powerCycle("reboot")
		}
		jsonOut(rw, 200, map[string]any{})
	case "term":
		s := w.session(req.URL.Query().Get("t"))
		if s == nil || !s.local {
			http.Error(rw, "terminal is only available for simulated routers", 403)
			return
		}
		w.terminal(rw, req, s)
	default:
		http.NotFound(rw, req)
	}
}

func (w *Web) info(s *guiSession) map[string]any {
	r := w.r
	if s.remote != nil {
		items, _, err := s.remote.Exec("/system/resource/print", nil, nil)
		ids, _, _ := s.remote.Exec("/system/identity/print", nil, nil)
		out := map[string]any{"local": false, "user": s.user, "target": s.target}
		if err == nil && len(items) > 0 {
			out["version"] = items[0]["version"]
			out["board"] = items[0]["board-name"]
			out["arch"] = items[0]["architecture-name"]
		}
		if len(ids) > 0 {
			out["identity"] = ids[0]["name"]
		}
		return out
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	services := map[string]int{}
	if r.svc != nil {
		for _, n := range []string{"api", "api-ssl", "www", "www-ssl", "ssh", "telnet", "winbox"} {
			services[n] = r.svc.port(n)
		}
	}
	hostIP := ""
	if h := hostNet(); h.ip != nil {
		hostIP = h.ip.String()
	}
	return map[string]any{"local": true, "user": s.user, "identity": r.S("/system/identity", "name"), "version": r.Ver, "board": r.Model.Board, "model": r.Model.Key, "modelName": r.Model.Name, "wireless": r.Model.wirelessKind(), "family": r.Model.Family, "arch": r.Model.Arch, "services": services, "hostIP": hostIP, "target": firstNonEmpty(s.target, "127.0.0.1"), "app": AppVersion}
}

// ------------------------------------------------------------------ websocket (minimal RFC 6455)

type wsConn struct {
	c   net.Conn
	rd  *bufio.Reader
	wmu sync.Mutex
}

func wsUpgrade(rw http.ResponseWriter, req *http.Request) (*wsConn, error) {
	if !strings.EqualFold(req.Header.Get("Upgrade"), "websocket") {
		return nil, errors.New("not a websocket request")
	}
	key := req.Header.Get("Sec-WebSocket-Key")
	hj, ok := rw.(http.Hijacker)
	if !ok {
		return nil, errors.New("hijack unsupported")
	}
	conn, brw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	h := sha1.Sum([]byte(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
	brw.WriteString("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + base64.StdEncoding.EncodeToString(h[:]) + "\r\n\r\n")
	brw.Flush()
	return &wsConn{c: conn, rd: brw.Reader}, nil
}

func (ws *wsConn) read() (byte, []byte, error) {
	var msg []byte
	var opcode byte
	for {
		h := make([]byte, 2)
		if _, err := io.ReadFull(ws.rd, h); err != nil {
			return 0, nil, err
		}
		fin := h[0]&0x80 != 0
		op := h[0] & 0x0F
		masked := h[1]&0x80 != 0
		n := uint64(h[1] & 0x7F)
		if n == 126 {
			b := make([]byte, 2)
			io.ReadFull(ws.rd, b)
			n = uint64(binary.BigEndian.Uint16(b))
		} else if n == 127 {
			b := make([]byte, 8)
			io.ReadFull(ws.rd, b)
			n = binary.BigEndian.Uint64(b)
		}
		if n > 1<<20 {
			return 0, nil, errors.New("frame too large")
		}
		var mask [4]byte
		if masked {
			io.ReadFull(ws.rd, mask[:])
		}
		p := make([]byte, n)
		if _, err := io.ReadFull(ws.rd, p); err != nil {
			return 0, nil, err
		}
		if masked {
			for i := range p {
				p[i] ^= mask[i%4]
			}
		}
		switch op {
		case 8:
			ws.write(8, nil)
			return 8, nil, io.EOF
		case 9:
			ws.write(10, p)
			continue
		case 10:
			continue
		}
		if op != 0 {
			opcode = op
		}
		msg = append(msg, p...)
		if fin {
			return opcode, msg, nil
		}
	}
}

func (ws *wsConn) write(op byte, p []byte) error {
	ws.wmu.Lock()
	defer ws.wmu.Unlock()
	h := []byte{0x80 | op}
	switch n := len(p); {
	case n < 126:
		h = append(h, byte(n))
	case n < 65536:
		h = append(h, 126, byte(n>>8), byte(n))
	default:
		b := make([]byte, 8)
		binary.BigEndian.PutUint64(b, uint64(n))
		h = append(append(h, 127), b...)
	}
	ws.c.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if _, err := ws.c.Write(append(h, p...)); err != nil {
		return err
	}
	return nil
}

type wsWriter struct{ ws *wsConn }

func (w wsWriter) Write(p []byte) (int, error) {
	if err := w.ws.write(1, []byte(strings.ToValidUTF8(string(p), "?"))); err != nil {
		return 0, err
	}
	return len(p), nil
}

func (w *Web) terminal(rw http.ResponseWriter, req *http.Request, s *guiSession) {
	ws, err := wsUpgrade(rw, req)
	if err != nil {
		http.Error(rw, err.Error(), 400)
		return
	}
	defer ws.c.Close()
	r := w.r
	kid := r.onKick(func() {
		ws.write(1, []byte("\r\n\x1b[33mConnection closed by router (rebooting).\x1b[0m\r\n"))
		ws.c.Close()
	})
	defer r.offKick(kid)
	cols, _ := strconv.Atoi(req.URL.Query().Get("cols"))
	t := newTerm(r, s.user, "winbox-terminal", s.addr, wsWriter{ws}, cols)
	t.onClose = func() {
		ws.write(1, []byte("\r\n\x1b[2mSession closed. Open a new terminal to reconnect.\x1b[0m\r\n"))
		ws.c.Close()
	}
	t.Start()
	for {
		op, p, err := ws.read()
		if err != nil {
			return
		}
		if op == 1 && len(p) > 0 && p[0] == 1 {
			var ctl struct{ Cols int }
			json.Unmarshal(p[1:], &ctl)
			t.SetWidth(ctl.Cols)
			continue
		}
		t.Input(p)
	}
}

// ------------------------------------------------------------------ Hotspot captive portal

var tplRe = regexp.MustCompile(`\$\(([a-z0-9\-]+)((?:\s[^)]*)?)\)`)

func evalTplCond(arg string, vars map[string]string) bool {
	for _, op := range []string{"==", "!="} {
		if i := strings.Index(arg, op); i > 0 {
			k := strings.TrimSpace(arg[:i])
			v := strings.Trim(strings.TrimSpace(arg[i+2:]), `'"`)
			if op == "==" {
				return vars[k] == v
			}
			return vars[k] != v
		}
	}
	return vars[strings.TrimSpace(arg)] != ""
}

func renderTpl(src string, vars map[string]string) string {
	type frame struct{ parent, taken bool }
	var stack []frame
	active := true
	var b strings.Builder
	last := 0
	for _, loc := range tplRe.FindAllStringSubmatchIndex(src, -1) {
		name := src[loc[2]:loc[3]]
		arg := ""
		if loc[4] >= 0 {
			arg = strings.TrimSpace(src[loc[4]:loc[5]])
		}
		_, known := vars[name]
		ctl := name == "if" || name == "elif" || name == "else" || name == "endif"
		if !ctl && !known {
			continue
		}
		if active {
			b.WriteString(src[last:loc[0]])
		}
		last = loc[1]
		switch name {
		case "if":
			c := evalTplCond(arg, vars)
			stack = append(stack, frame{parent: active, taken: c})
			active = active && c
		case "elif":
			if len(stack) == 0 {
				continue
			}
			f := &stack[len(stack)-1]
			if f.taken {
				active = false
			} else {
				c := evalTplCond(arg, vars)
				f.taken = c
				active = f.parent && c
			}
		case "else":
			if len(stack) == 0 {
				continue
			}
			f := &stack[len(stack)-1]
			active = f.parent && !f.taken
			f.taken = true
		case "endif":
			if len(stack) == 0 {
				continue
			}
			f := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			active = f.parent
		default:
			if active {
				b.WriteString(html.EscapeString(vars[name]))
			}
		}
	}
	if active {
		b.WriteString(src[last:])
	}
	return b.String()
}

func octal(b []byte) string {
	var s strings.Builder
	for _, c := range b {
		fmt.Fprintf(&s, "\\%03o", c)
	}
	return s.String()
}

func niceBytes(s string) string {
	n, _ := strconv.ParseFloat(s, 64)
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.1f GiB", n/(1<<30))
	case n >= 1<<20:
		return fmt.Sprintf("%.1f MiB", n/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.1f KiB", n/(1<<10))
	}
	return fmt.Sprintf("%.0f B", n)
}

func (w *Web) portalClient(rw http.ResponseWriter, req *http.Request) (Item, string, error) {
	r := w.r
	key := ""
	if ck, err := req.Cookie("tiklab_dev"); err == nil {
		key = ck.Value
	}
	if key == "" {
		key = newToken()[:12]
		http.SetCookie(rw, &http.Cookie{Name: "tiklab_dev", Value: key, Path: "/", MaxAge: 86400 * 30})
	}
	q := req.URL.Query()
	mac := strings.ToUpper(q.Get("mac"))
	if mac == "" {
		h := md5.Sum([]byte(clientIP(req) + key))
		mac = fmt.Sprintf("02:%02X:%02X:%02X:%02X:%02X", h[0], h[1], h[2], h[3], h[4])
	}
	if _, err := net.ParseMAC(mac); err != nil {
		return nil, key, errors.New("invalid mac address")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.state != "running" {
		return nil, key, errors.New("router is not running")
	}
	c := r.sim.clientByMAC(mac)
	if c == nil {
		hsIf := ""
		for _, h := range r.list(MenuMap["/ip/hotspot"]) {
			if !h.B("disabled") {
				hsIf = h["interface"]
				break
			}
		}
		if hsIf == "" {
			return nil, key, errors.New("no hotspot server is enabled on this router")
		}
		kind := "laptop"
		ua := strings.ToLower(req.UserAgent())
		if strings.Contains(ua, "mobile") || strings.Contains(ua, "android") || strings.Contains(ua, "iphone") {
			kind = "phone"
		}
		name := "web-" + strings.ReplaceAll(clientIP(req), ":", "")
		var err error
		c, err = r.addItem(MenuMap["/sim/client"], map[string]string{"name": name, "kind": kind, "mac-address": mac, "interface": hsIf, "dynamic": "true", "_auto": "portal"}, true)
		if err != nil {
			return nil, key, err
		}
	}
	if c["status"] != "connected" {
		if err := r.sim.clientConnect(c); err != nil {
			return nil, key, err
		}
	}
	return c, key, nil
}

func (w *Web) portalVars(c Item, key string, req *http.Request) map[string]string {
	r := w.r
	hs := r.sim.hotspotFor(c["interface"])
	prof := Item{}
	if hs != nil {
		if p := r.byName("/ip/hotspot/profile", hs["profile"]); p != nil {
			prof = p
		}
	}
	dst := req.FormValue("dst")
	if dst == "" {
		dst = "http://www.google.com/"
	}
	chal := w.r.sim.chap[key]
	if chal == nil {
		chal = make([]byte, 17)
		rand.Read(chal)
		w.r.sim.chap[key] = chal
	}
	v := map[string]string{
		"identity": r.S("/system/identity", "name"), "hostname": firstNonEmpty(prof["dns-name"], "login.wifi"), "server-name": "", "server-address": req.Host,
		"link-login": "/login?dst=" + url.QueryEscape(dst), "link-login-only": "/login", "link-logout": "/logout", "link-status": "/status", "link-orig": dst, "link-orig-esc": url.QueryEscape(dst), "link-redirect": dst, "link-redirect-esc": url.QueryEscape(dst), "link-advert": "/status",
		"mac": c["mac-address"], "mac-esc": url.QueryEscape(c["mac-address"]), "ip": c["address"], "username": "", "logged-in": "no", "login-by": "", "trial": "no", "error": "", "error-orig": "",
		"chap-id": octal(chal[:1]), "chap-challenge": octal(chal[1:]), "popup": "true", "refresh-timeout": "1m", "refresh-timeout-secs": "60", "interface-name": c["interface"], "host-ip": c["address"],
		"uptime": "", "session-time-left": "", "session-time-left-secs": "", "bytes-in": "0", "bytes-out": "0", "bytes-in-nice": "0 B", "bytes-out-nice": "0 B", "packets-in": "0", "packets-out": "0", "remain-bytes-total": "", "blocked": "no", "radius19": "",
		"plain-passwd": map[bool]string{true: "yes", false: ""}[strings.Contains(prof["login-by"], "http-pap")], "http-status": "200 OK", "session-id": "", "var": req.FormValue("var"),
	}
	if hs != nil {
		v["server-name"] = hs["name"]
	}
	for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
		if strings.EqualFold(a["mac-address"], c["mac-address"]) {
			v["logged-in"] = "yes"
			v["username"] = a["user"]
			v["login-by"] = a["login-by"]
			v["uptime"] = a["uptime"]
			v["session-time-left"] = a["session-time-left"]
			v["session-time-left-secs"] = strconv.FormatInt(durSecs(a["session-time-left"]), 10)
			v["bytes-in"], v["bytes-out"] = a["bytes-in"], a["bytes-out"]
			v["bytes-in-nice"], v["bytes-out-nice"] = niceBytes(a["bytes-in"]), niceBytes(a["bytes-out"])
			v["packets-in"], v["packets-out"] = a["packets-in"], a["packets-out"]
			if a["limit-bytes-total"] != "" {
				v["remain-bytes-total"] = niceBytes(a["limit-bytes-total"])
			}
			v["session-id"] = a[".id"]
		}
	}
	return v
}

func (w *Web) portalPage(rw http.ResponseWriter, name string, vars map[string]string, c Item) {
	r := w.r
	dir := "hotspot"
	if hs := r.sim.hotspotFor(c["interface"]); hs != nil {
		if p := r.byName("/ip/hotspot/profile", hs["profile"]); p != nil {
			dir = firstNonEmpty(p["html-directory-override"], p["html-directory"], "hotspot")
		}
	}
	f := r.byName("/file", dir+"/"+name)
	if f == nil {
		f = r.byName("/file", "hotspot/"+name)
	}
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.Header().Set("Cache-Control", "no-cache")
	if f == nil {
		fmt.Fprintf(rw, "<html><body><h3>%s</h3><p>%s is missing from /file %s</p></body></html>", html.EscapeString(vars["error"]), name, dir)
		return
	}
	io.WriteString(rw, renderTpl(string(fileBytes(f)), vars))
}

func (w *Web) portal(rw http.ResponseWriter, req *http.Request) {
	r := w.r
	path := req.URL.Path
	// static files from the hotspot directory
	if path == "/md5.js" || strings.HasPrefix(path, "/hotspot/") {
		name := strings.TrimPrefix(strings.TrimPrefix(path, "/hotspot/"), "/")
		r.mu.Lock()
		f := r.byName("/file", r.activeHotspotDir()+"/"+name)
		if f == nil {
			f = r.byName("/file", "hotspot/"+name)
		}
		var fdata []byte
		if f != nil {
			fdata = fileBytes(f)
		}
		r.mu.Unlock()
		if f == nil {
			http.NotFound(rw, req)
			return
		}
		ct := "text/plain"
		switch {
		case strings.HasSuffix(name, ".js"):
			ct = "application/javascript"
		case strings.HasSuffix(name, ".css"):
			ct = "text/css"
		case strings.HasSuffix(name, ".html"):
			ct = "text/html"
		case strings.HasSuffix(name, ".svg"):
			ct = "image/svg+xml"
		}
		if ct == "text/plain" {
			ct = contentType(name)
		}
		rw.Header().Set("Content-Type", ct)
		rw.Write(fdata)
		return
	}
	c, key, err := w.portalClient(rw, req)
	if err != nil {
		rw.Header().Set("Content-Type", "text/html; charset=utf-8")
		rw.WriteHeader(503)
		fmt.Fprintf(rw, `<!doctype html><meta name=viewport content="width=device-width"><body style="font-family:sans-serif;padding:40px;background:#0f172a;color:#e2e8f0"><h2>Hotspot unavailable</h2><p>%s</p><p style="opacity:.6">TikLab simulator: check that a hotspot server is enabled and a cable is plugged into a hotspot port.</p></body>`, html.EscapeString(err.Error()))
		return
	}
	req.ParseForm()
	r.mu.Lock()
	defer r.mu.Unlock()
	vars := w.portalVars(c, key, req)
	switch path {
	case "/login":
		user := req.FormValue("username")
		if user == "" {
			if vars["logged-in"] == "yes" {
				w.portalPage(rw, "status.html", vars, c)
				return
			}
			w.portalPage(rw, "login.html", vars, c)
			return
		}
		pass := req.FormValue("password")
		trusted := false
		if chal := r.sim.chap[key]; chal != nil && len(pass) == 32 {
			if u := r.byName("/ip/hotspot/user", user); u != nil {
				h := md5.Sum(append(append([]byte{chal[0]}, []byte(u["password"])...), chal[1:]...))
				if hex.EncodeToString(h[:]) == strings.ToLower(pass) {
					trusted = true
					pass = u["password"]
				}
			}
		}
		delete(r.sim.chap, key)
		by := "http-pap"
		if trusted {
			by = "http-chap"
		}
		_, err := r.sim.hotspotLogin(c, user, pass, by, trusted)
		vars = w.portalVars(c, key, req)
		if err != nil {
			vars["error"] = err.Error()
			vars["error-orig"] = err.Error()
			vars["username"] = user
			w.portalPage(rw, "login.html", vars, c)
			return
		}
		w.portalPage(rw, "alogin.html", vars, c)
	case "/status":
		if vars["logged-in"] != "yes" {
			http.Redirect(rw, req, "/login", http.StatusFound)
			return
		}
		w.portalPage(rw, "status.html", vars, c)
	case "/logout":
		if vars["logged-in"] != "yes" {
			http.Redirect(rw, req, "/login", http.StatusFound)
			return
		}
		for _, a := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
			if strings.EqualFold(a["mac-address"], c["mac-address"]) {
				r.sim.hotspotLogout(a, "user request")
			}
		}
		w.portalPage(rw, "logout.html", vars, c)
	}
}

// ------------------------------------------------------------------ dashboard aggregate

func (w *Web) dash(s *guiSession) map[string]any {
	r := w.r
	out := map[string]any{}
	if s.remote != nil {
		cl := s.remote
		res, _, _ := cl.Exec("/system/resource/print", nil, nil)
		if len(res) > 0 {
			out["resource"] = res[0]
		}
		health, _, _ := cl.Exec("/system/health/print", nil, nil)
		out["health"] = health
		ifs, _, _ := cl.Exec("/interface/print", map[string]string{".proplist": "name,type,running,disabled,mac-address,default-name,slave,comment"}, nil)
		var names []string
		for _, i := range ifs {
			if i["type"] == "ether" || i["type"] == "wlan" {
				names = append(names, i["name"])
			}
		}
		rates := map[string]Item{}
		if len(names) > 0 {
			mt, _, _ := cl.Exec("/interface/monitor-traffic", map[string]string{"interface": strings.Join(names, ","), "once": ""}, nil)
			for _, m := range mt {
				rates[m["name"]] = m
			}
		}
		var list []map[string]any
		for _, i := range ifs {
			e := map[string]any{"name": i["name"], "type": i["type"], "running": i["running"] == "true", "disabled": i["disabled"] == "true", "mac": i["mac-address"], "default": i["default-name"], "cable": i["running"] == "true", "color": "blue", "speed": "1G"}
			if m := rates[i["name"]]; m != nil {
				e["rx"], _ = strconv.ParseFloat(m["rx-bits-per-second"], 64)
				e["tx"], _ = strconv.ParseFloat(m["tx-bits-per-second"], 64)
			}
			list = append(list, e)
		}
		out["ifaces"] = list
		hs, _, _ := cl.Exec("/ip/hotspot/active/print", nil, nil)
		ppp, _, _ := cl.Exec("/ppp/active/print", nil, nil)
		leases, _, _ := cl.Exec("/ip/dhcp-server/lease/print", nil, nil)
		out["counts"] = map[string]int{"hotspot": len(hs), "ppp": len(ppp), "leases": len(leases)}
		clients := []map[string]any{}
		for _, l := range leases {
			if l["status"] != "bound" {
				continue
			}
			c := map[string]any{"name": firstNonEmpty(l["host-name"], l["mac-address"]), "kind": "laptop", "address": l["address"], "mac": l["mac-address"], "iface": l["server"], "status": "connected"}
			for _, a := range hs {
				if strings.EqualFold(a["mac-address"], l["mac-address"]) {
					c["user"] = a["user"]
					c["kind"] = "phone"
				}
			}
			clients = append(clients, c)
		}
		for _, p := range ppp {
			clients = append(clients, map[string]any{"name": p["name"], "kind": "cpe", "address": p["address"], "mac": p["caller-id"], "iface": "pppoe", "status": "connected", "pppoe": p["name"]})
		}
		out["clients"] = clients
		out["model"] = ""
		out["panel"] = PanelSpec{Rows: 1, Look: "metal"}
		return out
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	res := r.single("/system/resource")
	refreshHooks["/system/resource"](r, res)
	out["resource"] = r.out(MenuMap["/system/resource"], res)
	var health []Item
	for _, h := range r.list(MenuMap["/system/health"]) {
		health = append(health, h.Clone())
	}
	out["health"] = health
	var list []map[string]any
	for _, i := range r.list(MenuMap["/interface"]) {
		rt := r.sim.rate(i["name"])
		e := map[string]any{"name": i["name"], "type": i["type"], "running": i.B("running"), "disabled": i.B("disabled"), "mac": i["mac-address"], "default": i["default-name"], "slave": i.B("slave"), "rx": rt.RxBps, "tx": rt.TxBps, "dynamic": i.B("dynamic"), "comment": i["comment"], "sfp": i["_sfp"] == "true", "poe": i["poe-out"]}
		if p := r.sim.portOf(i["name"]); p != nil && (i["type"] == "ether") {
			e["cable"] = p.B("cable")
			e["color"] = p["cable-color"]
			e["speed"] = p["speed"]
			e["portId"] = p[".id"]
		}
		list = append(list, e)
	}
	out["ifaces"] = list
	leases := 0
	for _, l := range r.list(MenuMap["/ip/dhcp-server/lease"]) {
		if l["status"] == "bound" {
			leases++
		}
	}
	out["counts"] = map[string]int{"hotspot": len(r.list(MenuMap["/ip/hotspot/active"])), "ppp": len(r.list(MenuMap["/ppp/active"])), "leases": leases, "users": len(r.list(MenuMap["/ip/hotspot/user"])) - 1}
	clients := []map[string]any{}
	for _, c := range r.list(MenuMap["/sim/client"]) {
		rt := r.sim.crt(c)
		clients = append(clients, map[string]any{"id": c[".id"], "name": c["name"], "kind": c["kind"], "address": c["address"], "mac": c["mac-address"], "iface": c["interface"], "port": c["port"], "status": c["status"], "user": c["hotspot-user"], "pppoe": c["pppoe-secret"], "down": rt.down, "up": rt.up, "auto": c["_auto"]})
	}
	out["clients"] = clients
	out["wan"] = r.sim.wanUp()
	out["model"] = r.Model.Key
	out["panel"] = r.Model.Panel
	out["lanSplit"] = r.Model.LanSplit
	out["cpu"] = r.sim.cpu
	return out
}

// ------------------------------------------------------------------ transfer endpoints

func (w *Web) transferAPI(rw http.ResponseWriter, req *http.Request, op string) {
	r := w.r
	tok := req.URL.Query().Get("t")
	if tok == "" {
		tok = req.Header.Get("X-Tiklab-Token")
	}
	s := w.session(tok)
	if s == nil || !s.local {
		jsonOut(rw, 200, map[string]any{"error": "this needs a session on the simulator (log in again)", "expired": s == nil})
		return
	}
	decode := func(v any) bool {
		if err := json.NewDecoder(io.LimitReader(req.Body, 40<<20)).Decode(v); err != nil {
			jsonOut(rw, 200, map[string]any{"error": "bad request: " + err.Error()})
			return false
		}
		return true
	}
	switch op {
	case "files/upload":
		w.fileUpload(rw, req, s)
	case "files/download":
		w.fileDownload(rw, req)
	case "config/sections":
		var models []map[string]string
		for _, k := range ModelOrder {
			m := Models[k]
			models = append(models, map[string]string{"key": m.Key, "board": m.Board, "name": m.Name, "family": m.Family})
		}
		r.mu.Lock()
		cur := r.Model.Key
		id := r.S("/system/identity", "name")
		r.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"sections": ExportSections, "models": models, "current": cur, "identity": id})
	case "config/export":
		var o ExportOpts
		if !decode(&o) {
			return
		}
		r.mu.Lock()
		res := r.exportScript(o)
		r.mu.Unlock()
		jsonOut(rw, 200, res)
	case "config/analyze":
		var body struct{ Text, File string }
		if !decode(&body) {
			return
		}
		r.mu.Lock()
		if body.File != "" {
			if f := r.byName("/file", cleanPath(body.File)); f != nil {
				body.Text = string(fileBytes(f))
			}
		}
		info := r.analyzeScript(body.Text)
		r.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"info": info, "text": body.Text})
	case "config/import":
		var body struct {
			Text    string
			Mapping map[string]string
			Replace bool
			Model   string
		}
		if !decode(&body) {
			return
		}
		rep := r.applyImport(body.Text, ImportOpts{Mapping: body.Mapping, Replace: body.Replace, Model: body.Model, User: s.user})
		jsonOut(rw, 200, rep)
	case "real/probe", "real/clone", "real/send":
		var o RealOpts
		if !decode(&o) {
			return
		}
		if o.Host == "" {
			jsonOut(rw, 200, map[string]any{"error": "enter the router's address"})
			return
		}
		var logs []string
		lg := func(s string) { logs = append(logs, s) }
		switch op {
		case "real/probe":
			info, err := probeRouter(o)
			if err != nil {
				jsonOut(rw, 200, map[string]any{"error": err.Error()})
				return
			}
			jsonOut(rw, 200, info)
		case "real/clone":
			script, files, err := r.cloneRouter(o, lg)
			if err != nil {
				jsonOut(rw, 200, map[string]any{"error": err.Error(), "log": logs})
				return
			}
			r.mu.Lock()
			info := r.analyzeScript(script)
			r.mu.Unlock()
			jsonOut(rw, 200, map[string]any{"script": script, "files": files, "info": info, "log": logs})
		case "real/send":
			err := r.sendToRouter(o, lg)
			out := map[string]any{"log": logs}
			if err != nil {
				out["error"] = err.Error()
			}
			r.mu.Lock()
			r.log("system,info", "configuration sent to %s by %s", o.Host, s.user)
			r.mu.Unlock()
			jsonOut(rw, 200, out)
		}
	case "hotspot/dirs":
		w.hotspotDirs(rw)
	case "hotspot/check":
		dir := req.URL.Query().Get("dir")
		r.mu.Lock()
		items, total, files := r.checkHotspotDir(dir)
		r.mu.Unlock()
		jsonOut(rw, 200, map[string]any{"items": items, "size": total, "files": files})
	case "hotspot/activate":
		w.hotspotActivate(rw, req)
	case "hotspot/copy":
		var body struct{ From, To string }
		if !decode(&body) {
			return
		}
		from, to := cleanPath(body.From), cleanPath(body.To)
		r.mu.Lock()
		defer r.mu.Unlock()
		if to == "" || r.byName("/file", to) != nil {
			jsonOut(rw, 200, map[string]any{"error": "choose a new folder name"})
			return
		}
		n := 0
		for _, it := range append([]Item(nil), r.filesUnder(from)...) {
			if it["type"] == "directory" {
				continue
			}
			r.putFile(to+strings.TrimPrefix(it["name"], from), fileBytes(it))
			n++
		}
		jsonOut(rw, 200, map[string]any{"copied": n})
	}
}
