package main

import (
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

func linuxGateway() string {
	b, err := os.ReadFile("/proc/net/route")
	if err != nil {
		return ""
	}
	for _, l := range strings.Split(string(b), "\n")[1:] {
		f := strings.Fields(l)
		if len(f) > 2 && f[1] == "00000000" {
			v, err := strconv.ParseUint(f[2], 16, 32)
			if err == nil {
				return net.IPv4(byte(v), byte(v>>8), byte(v>>16), byte(v>>24)).String()
			}
		}
	}
	return ""
}

func fmtRTT(ms float64) string {
	us := int64(ms * 1000)
	if us >= 1000 {
		return fmt.Sprintf("%dms%dus", us/1000, us%1000)
	}
	return fmt.Sprintf("%dus", us)
}

func sleepOrDone(c *Ctx, d time.Duration) bool {
	select {
	case <-c.Done:
		return false
	case <-time.After(d):
		return true
	}
}

func init() {
	// ---- power ----
	specials["/system/reboot"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		go func() { time.Sleep(300 * time.Millisecond); r.powerCycle("reboot") }()
		return "", nil
	}
	specials["/system/shutdown"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		go func() { time.Sleep(300 * time.Millisecond); r.powerCycle("shutdown") }()
		return "", nil
	}
	specials["/system/reset-configuration"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		go func() { time.Sleep(300 * time.Millisecond); r.powerCycle("reset") }()
		return "", nil
	}
	specials["/sim/power-on"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		off := r.state == "off"
		if off {
			r.state = "booting"
		}
		bt := durSecs(r.S("/sim/settings", "boot-time"))
		r.mu.Unlock()
		if !off {
			return "", trap("router is already powered on")
		}
		if bt < 1 {
			bt = 1
		}
		time.AfterFunc(time.Duration(bt)*time.Second, r.finishBoot)
		return "", nil
	}
	specials["/sim/factory-defaults"] = specials["/system/reset-configuration"]
	specials["/sim/change-model"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		key := firstNonEmpty(a["model"], a["key"])
		m := lookupModel(key)
		if m == nil {
			return "", trap("unknown model %q - see /sim models print", key)
		}
		keep := true
		if v, ok := a["keep-users"]; ok {
			b, _ := normBool(v)
			keep = b == "true"
		}
		r.mu.Lock()
		if r.state != "running" {
			r.mu.Unlock()
			return "", trap("router is not running")
		}
		r.pendingModel = m.Key
		r.pendingKeep = keep
		r.mu.Unlock()
		go func() { time.Sleep(300 * time.Millisecond); r.powerCycle("reset") }()
		return m.Key, nil
	}
	specials["/system/check-installation"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		emit(Item{"status": "installation is ok"})
		return "", nil
	}

	// ---- backup ----
	specials["/system/backup/save"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		defer r.mu.Unlock()
		name := a["name"]
		if name == "" {
			name = r.S("/system/identity", "name") + "-" + r.now().Format("20060102-1504")
		}
		if !strings.HasSuffix(name, ".backup") {
			name += ".backup"
		}
		r.removeWhere("/file", func(it Item) bool { return it["name"] == name })
		r.dirty = true
		snap := string(r.snapshot())
		r.addItem(MenuMap["/file"], map[string]string{"name": name, "type": "backup", "contents": snap}, true)
		r.log("system,info", "configuration backup saved")
		return "", nil
	}
	specials["/system/backup/load"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		f := r.byName("/file", a["name"])
		if f == nil {
			f = r.byName("/file", a["name"]+".backup")
		}
		if f == nil {
			r.mu.Unlock()
			return "", trap("failure: no such file")
		}
		contents := f["contents"]
		files := r.tbl("/file")
		keep := &Table{Items: append([]Item(nil), files.Items...), Next: files.Next}
		if err := r.loadSnapshot([]byte(contents)); err != nil {
			r.mu.Unlock()
			return "", trap("failure: backup file is corrupted")
		}
		r.T["/file"] = keep
		r.markDirty()
		r.mu.Unlock()
		go func() { time.Sleep(300 * time.Millisecond); r.powerCycle("reboot") }()
		return "", nil
	}

	// ---- export / import ----
	specials["/export"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		_, sens := a["show-sensitive"]
		r.mu.Lock()
		defer r.mu.Unlock()
		txt := r.export("", sens)
		if fn := a["file"]; fn != "" {
			if !strings.HasSuffix(fn, ".rsc") {
				fn += ".rsc"
			}
			r.putFile(fn, []byte(txt))
			return "", nil
		}
		return txt, nil
	}
	specials["/import"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		name := firstNonEmpty(a["file-name"], a["file"])
		f := r.byName("/file", name)
		if f == nil && !strings.HasSuffix(name, ".rsc") {
			f = r.byName("/file", name+".rsc")
		}
		var text string
		if f != nil {
			text = string(fileBytes(f))
		}
		r.mu.Unlock()
		if f == nil {
			return "", trap("failure: no such file")
		}
		rep := r.importScript(text, ImportOpts{User: c.User}, false)
		for _, l := range rep.Lines {
			if l.Status == "error" || (l.Status != "ok" && a["verbose"] != "") {
				emit(Item{"line": strconv.Itoa(l.Line), "status": l.Status, "message": l.Msg, "command": l.Text})
			}
		}
		if rep.Err > 0 {
			return fmt.Sprintf("Script file loaded and executed with %d error(s), %d warning(s) - %d commands", rep.Err, rep.Warn, rep.Commands), nil
		}
		return fmt.Sprintf("Script file loaded and executed successfully (%d commands, %d warnings)", rep.Commands, rep.Warn), nil
	}
	specials["/password"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		defer r.mu.Unlock()
		u := r.byName("/user", c.User)
		if u == nil {
			return "", trap("no such user")
		}
		if u["password"] != a["old-password"] {
			return "", trap("old password is not correct")
		}
		if a["new-password"] != a["confirm-new-password"] {
			return "", trap("new passwords do not match")
		}
		u["password"] = a["new-password"]
		r.markDirty()
		return "", nil
	}
	specials["/quit"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) { return "", nil }
	specials["/beep"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) { return "", nil }
	specials["/tool/fetch"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		return "", trap("failure: fetch is disabled in the simulator")
	}
	specials["/tool/bandwidth-test"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		dur := durSecs(firstNonEmpty(a["duration"], "5s"))
		for i := int64(0); i < dur; i++ {
			if !sleepOrDone(c, time.Second) {
				break
			}
			emit(Item{"status": "running", "duration": fmtDur(time.Duration(i+1) * time.Second), "rx-current": fmt.Sprint(80e6 + rand.Intn(20e6)), "tx-current": fmt.Sprint(60e6 + rand.Intn(20e6)), "lost-packets": "0", "direction": firstNonEmpty(a["direction"], "receive")})
		}
		return "", nil
	}

	// ---- ping / traceroute ----
	ping := func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		addr := firstNonEmpty(a["address"], a["host"])
		if addr == "" {
			return "", trap("missing value(s) of argument(s) address")
		}
		host := addr
		if net.ParseIP(addr) == nil {
			if ips, err := net.LookupIP(addr); err == nil && len(ips) > 0 {
				for _, ip := range ips {
					if ip.To4() != nil {
						host = ip.String()
						break
					}
				}
			} else {
				return "", trap("invalid value for argument address")
			}
		}
		count, _ := strconv.Atoi(a["count"])
		if count <= 0 && !c.Interactive {
			count = 4
			if c.Via == "api" || c.Via == "api-ssl" {
				count = 1 << 30
			}
		}
		if count <= 0 {
			count = 1 << 30
		}
		size := firstNonEmpty(a["size"], "56")
		iv := time.Second
		if d, ok := parseDur(a["interval"]); ok && d >= 10*time.Millisecond {
			iv = d
		}
		var sent, recv int
		var mn, mx, sum float64
		for i := 0; i < count; i++ {
			r.mu.Lock()
			ok, rtt, ttl := r.sim.reach(host)
			r.mu.Unlock()
			if ok && !net.ParseIP(host).IsPrivate() && rtt > 1 {
				if t := realRTT(host); t > 0 {
					rtt = t
				}
			}
			sent++
			it := Item{"seq": strconv.Itoa(i), "host": host, "sent": strconv.Itoa(sent)}
			if ok {
				recv++
				sum += rtt
				if mn == 0 || rtt < mn {
					mn = rtt
				}
				if rtt > mx {
					mx = rtt
				}
				it["size"] = size
				it["ttl"] = strconv.Itoa(ttl)
				it["time"] = fmtRTT(rtt)
			} else {
				it["status"] = "timeout"
			}
			it["received"] = strconv.Itoa(recv)
			it["packet-loss"] = strconv.Itoa((sent - recv) * 100 / sent)
			if recv > 0 {
				it["min-rtt"] = fmtRTT(mn)
				it["avg-rtt"] = fmtRTT(sum / float64(recv))
				it["max-rtt"] = fmtRTT(mx)
			}
			emit(it)
			if i+1 < count && !sleepOrDone(c, iv) {
				return "", &Trap{Msg: "interrupted", Cat: 2}
			}
		}
		return "", nil
	}
	specials["/ping"] = ping
	specials["/tool/ping"] = ping
	specials["/tool/traceroute"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		addr := a["address"]
		if net.ParseIP(addr) == nil {
			if ips, err := net.LookupIP(addr); err == nil && len(ips) > 0 {
				addr = ips[0].String()
			} else {
				return "", trap("invalid value for argument address")
			}
		}
		r.mu.Lock()
		ok, rtt, _ := r.sim.reach(addr)
		gw := hostGateway(hostNet())
		r.mu.Unlock()
		hops := []string{gw}
		if !net.ParseIP(addr).IsPrivate() {
			hops = append(hops, "41.223.208.1", "196.49.12.9", "105.16.0.65", "72.14.215.85")
		}
		hops = append(hops, addr)
		for i, h := range hops {
			if !sleepOrDone(c, 300*time.Millisecond) {
				break
			}
			it := Item{"address": h, "loss": "0%", "sent": "1", "last": fmtRTT(rtt * float64(i+1) / float64(len(hops))), "status": ""}
			if i == len(hops)-1 && !ok {
				it = Item{"address": "", "loss": "100%", "sent": "1", "status": "timeout"}
			}
			emit(it)
		}
		return "", nil
	}

	// ---- monitoring ----
	monitor := func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		names := strings.Split(firstNonEmpty(a["interface"], a[".id"], a["numbers"]), ",")
		once := a["once"] != "" || a["duration"] != ""
		_, isOnce := a["once"]
		dur := durSecs(a["duration"])
		for n := 0; ; n++ {
			r.mu.Lock()
			if r.state != "running" {
				r.mu.Unlock()
				return "", trap("router is not running")
			}
			var items []Item
			for _, nm := range names {
				nm = strings.TrimSpace(nm)
				if nm == "aggregate" {
					var a Rate
					for _, it := range r.list(MenuMap["/interface/ethernet"]) {
						x := r.sim.rate(it["name"])
						a.RxBps += x.RxBps
						a.TxBps += x.TxBps
						a.RxPps += x.RxPps
						a.TxPps += x.TxPps
					}
					items = append(items, rateItem("aggregate", &a))
					continue
				}
				it := r.findRef(MenuMap["/interface"], nm)
				if it == nil {
					r.mu.Unlock()
					return "", trap("no such item")
				}
				items = append(items, rateItem(it["name"], r.sim.rate(it["name"])))
			}
			r.mu.Unlock()
			for _, it := range items {
				emit(it)
			}
			if isOnce || (once && dur > 0 && int64(n+1) >= dur) {
				return "", nil
			}
			if !sleepOrDone(c, time.Second) {
				return "", &Trap{Msg: "interrupted", Cat: 2}
			}
		}
	}
	specials["/interface/monitor-traffic"] = monitor
	specials["/interface/ethernet/monitor"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		_, once := a["once"]
		for {
			r.mu.Lock()
			var items []Item
			for _, nm := range strings.Split(firstNonEmpty(a["numbers"], a[".id"], a["interface"]), ",") {
				it := r.findRef(MenuMap["/interface/ethernet"], strings.TrimSpace(nm))
				if it == nil {
					r.mu.Unlock()
					return "", trap("no such item")
				}
				sp := r.sim.portOf(it["name"])
				st := Item{"name": it["name"], "status": "no-link", "auto-negotiation": "done", "advertising": it["advertise"], "link-partner-advertising": it["advertise"]}
				if it.B("running") {
					st["status"] = "link-ok"
					st["rate"] = "1Gbps"
					if sp != nil {
						st["rate"] = sp["speed"] + "bps"
					}
					st["full-duplex"] = "true"
					st["tx-flow-control"] = "false"
					st["rx-flow-control"] = "false"
				}
				items = append(items, st)
			}
			r.mu.Unlock()
			for _, it := range items {
				emit(it)
			}
			if once || !sleepOrDone(c, time.Second) {
				return "", nil
			}
		}
	}
	specials["/system/resource/monitor"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		_, once := a["once"]
		for {
			r.mu.Lock()
			it := Item{"cpu-used": strconv.Itoa(int(r.sim.cpu)), "cpu-used-per-cpu": "", "free-memory": r.single("/system/resource")["free-memory"]}
			var per []string
			for _, x := range r.tbl("/system/resource/cpu").Items {
				per = append(per, x["load"]+"%")
			}
			it["cpu-used-per-cpu"] = strings.Join(per, ",")
			r.mu.Unlock()
			emit(it)
			if once || !sleepOrDone(c, time.Second) {
				return "", nil
			}
		}
	}
	specials["/interface/wireless/scan"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		ssids := []string{"Neighbour-WiFi", "AfriCell-4G", "QCell_Home", "TP-Link_8F2A", "Gamtel-FTTH", "HUAWEI-B310"}
		for i, s := range ssids {
			emit(Item{".id": fmt.Sprintf("*%d", i), "address": fmt.Sprintf("C4:AD:34:%02X:%02X:%02X", i, rand.Intn(255), rand.Intn(255)), "ssid": s, "channel": fmt.Sprintf("%d/20/gn", 2412+5*rand.Intn(11)), "sig": fmt.Sprint(-50 - rand.Intn(40)), "nf": "-108", "snr": fmt.Sprint(40 + rand.Intn(20)), "radio-name": ""})
		}
		return "", nil
	}

	// ---- menu commands (lock held) ----
	menuCmds["/system/script/run"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, s := range ts {
			addInt(s, "run-count", 1)
			s["last-started"] = r.now().Format("2006-01-02 15:04:05")
			src, name := s["source"], s["name"]
			go r.runScript(src, c.User, name)
		}
		return "", nil
	}
	menuCmds["/ip/dhcp-server/lease/make-static"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, l := range ts {
			l["dynamic"] = "false"
			r.sim.freeIP(l["address"])
			r.markDirty()
		}
		return "", nil
	}
	menuCmds["/ip/dhcp-client/renew"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, d := range ts {
			d["status"] = "renewing..."
		}
		return "", nil
	}
	menuCmds["/ip/dhcp-client/release"] = menuCmds["/ip/dhcp-client/renew"]
	menuCmds["/ip/hotspot/active/login"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		user, pass := a["user"], a["password"]
		mac, ip := strings.ToUpper(a["mac-address"]), a["ip"]
		if user == "" {
			return "", trap("missing value(s) of argument(s) user")
		}
		if mac == "" && ip == "" {
			return "", trap("missing value(s) of argument(s) ip")
		}
		var cl Item
		for _, x := range r.list(MenuMap["/sim/client"]) {
			if (mac != "" && strings.EqualFold(x["mac-address"], mac)) || (ip != "" && x["address"] == ip) {
				cl = x
			}
		}
		if cl == nil {
			hsIf := ""
			for _, h := range r.list(MenuMap["/ip/hotspot"]) {
				if !h.B("disabled") {
					hsIf = h["interface"]
				}
			}
			if hsIf == "" {
				return "", trap("no hotspot server")
			}
			if mac == "" {
				mac = r.sim.randMAC("phone")
			}
			cl, _ = r.addItem(MenuMap["/sim/client"], map[string]string{"name": "api-" + strings.ReplaceAll(mac, ":", "")[6:], "kind": "phone", "mac-address": mac, "interface": hsIf, "dynamic": "true", "_auto": "api", "_static-ip": ip}, true)
			if err := r.sim.clientConnect(cl); err != nil {
				return "", err
			}
		}
		act, err := r.sim.hotspotLogin(cl, user, pass, "api", false)
		if err != nil {
			return "", err
		}
		return act[".id"], nil
	}
	menuCmds["/sim/client/connect"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, cl := range ts {
			if err := r.sim.clientConnect(cl); err != nil {
				return "", err
			}
		}
		return "", nil
	}
	menuCmds["/sim/client/disconnect"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, cl := range ts {
			r.sim.clientDisconnect(cl, "user request")
		}
		return "", nil
	}
	menuCmds["/sim/client/login"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		cl := ts[0]
		if cl["status"] != "connected" {
			if err := r.sim.clientConnect(cl); err != nil {
				return "", err
			}
		}
		act, err := r.sim.hotspotLogin(cl, a["user"], a["password"], "http-chap", false)
		if err != nil {
			return "", err
		}
		return act[".id"], nil
	}
	menuCmds["/sim/client/logout"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, cl := range ts {
			for _, act := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
				if strings.EqualFold(act["mac-address"], cl["mac-address"]) {
					r.sim.hotspotLogout(act, "user request")
				}
			}
		}
		return "", nil
	}
	plug := func(v string) menuCmdFn {
		return func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
			ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
			if err != nil {
				return "", err
			}
			for _, p := range ts {
				p["cable"] = v
			}
			r.sim.updateLinks()
			r.markDirty()
			return "", nil
		}
	}
	menuCmds["/sim/port/plug"] = plug("true")
	menuCmds["/sim/port/unplug"] = plug("false")
	findSimPort := func(r *Router, ref string) Item {
		for _, p := range r.list(MenuMap["/sim/port"]) {
			if p["interface"] == ref || p[".id"] == ref {
				return p
			}
		}
		return nil
	}
	_ = findSimPort
	specials["/sim/generate-vouchers"] = func(r *Router, c *Ctx, a map[string]string, emit func(Item)) (string, error) {
		r.mu.Lock()
		defer r.mu.Unlock()
		n, _ := strconv.Atoi(firstNonEmpty(a["count"], "10"))
		if n < 1 || n > 5000 {
			return "", trap("invalid value for argument count")
		}
		prof := firstNonEmpty(a["profile"], "default")
		if r.byName("/ip/hotspot/user/profile", prof) == nil {
			return "", trap("input does not match any value of profile")
		}
		length, _ := strconv.Atoi(firstNonEmpty(a["length"], "6"))
		if length < 3 || length > 16 {
			length = 6
		}
		chars := "abcdefghjkmnpqrstuvwxyz23456789"
		if a["charset"] == "numbers" {
			chars = "0123456789"
		}
		var names []string
		for i := 0; i < n; i++ {
			var code string
			for {
				b := make([]byte, length)
				for j := range b {
					b[j] = chars[rand.Intn(len(chars))]
				}
				code = a["prefix"] + string(b)
				if r.byName("/ip/hotspot/user", code) == nil {
					break
				}
			}
			pass := code
			if a["password"] == "random" {
				pass = randHex(3)
			}
			args := map[string]string{"name": code, "password": pass, "profile": prof, "server": firstNonEmpty(a["server"], "all"), "comment": firstNonEmpty(a["comment"], "vc-"+r.now().Format("01.02.06"))}
			if a["limit-uptime"] != "" {
				args["limit-uptime"] = a["limit-uptime"]
			}
			if a["limit-bytes-total"] != "" {
				args["limit-bytes-total"] = a["limit-bytes-total"]
			}
			if _, err := r.addItem(MenuMap["/ip/hotspot/user"], args, false); err != nil {
				return "", err
			}
			names = append(names, code)
			emit(Item{"name": code, "password": pass})
		}
		r.log("system,info", "%d hotspot vouchers generated by %s", n, firstNonEmpty(c.User, "simulator"))
		return strconv.Itoa(len(names)), nil
	}
	menuCmds["/certificate/sign"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, ct := range ts {
			ct["private-key"] = "true"
			ct["trusted"] = "true"
			ct["fingerprint"] = strings.ToLower(randHex(32))
			ct["issuer"] = "CN=" + ct["common-name"]
			now := r.now()
			ct["invalid-before"] = now.Format("2006-01-02 15:04:05")
			days, _ := strconv.Atoi(firstNonEmpty(ct["days-valid"], "365"))
			ct["invalid-after"] = now.AddDate(0, 0, days).Format("2006-01-02 15:04:05")
			ct["expires-after"] = fmtDur(time.Duration(days) * 24 * time.Hour)
			if a["ca"] == "" && strings.Contains(ct["key-usage"], "key-cert-sign") {
				ct["authority"] = "true"
			}
		}
		r.markDirty()
		return "", nil
	}
	menuCmds["/system/package/update/check-for-updates"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		u := r.single("/system/package/update")
		u["status"] = "System is already up to date"
		emit(Item{"channel": u["channel"], "installed-version": u["installed-version"], "latest-version": u["latest-version"], "status": u["status"]})
		return "", nil
	}
	menuCmds["/system/package/update/download"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		return "", trap("System is already up to date")
	}
	menuCmds["/system/package/update/install"] = menuCmds["/system/package/update/download"]
	menuCmds["/system/routerboard/upgrade"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		return "", trap("firmware is already up to date")
	}
	noop := func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) { return "", nil }
	for _, p := range []string{"/ip/dns/flush-cache", "/ip/cloud/force-update", "/interface/blink", "/interface/ethernet/blink", "/interface/ethernet/reset-mac-address", "/ip/hotspot/reset-html", "/interface/wireless/reset-configuration", "/ip/dhcp-server/lease/check-status", "/ip/dhcp-server/lease/send-reconfigure", "/system/package/enable", "/system/package/disable", "/system/package/uninstall", "/ip/hotspot/host/make-binding", "/certificate/import", "/certificate/export-certificate"} {
		menuCmds[p] = noop
	}
	menuCmds["/interface/ethernet/cable-test"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		ts, err := r.targets(m, firstNonEmpty(a[".id"], a["numbers"]))
		if err != nil {
			return "", err
		}
		for _, it := range ts {
			st := Item{"name": it["name"], "status": "link-ok"}
			if !it.B("running") {
				st["status"] = "no-link"
				st["cable-pairs"] = "open:4,open:4,open:4,open:4"
			}
			emit(st)
		}
		return "", nil
	}
	menuCmds["/ip/hotspot/setup"] = func(r *Router, c *Ctx, m *Menu, a map[string]string, emit func(Item)) (string, error) {
		return "", trap("interactive setup is not available here; add /ip hotspot entries directly")
	}
	menuCmds["/ip/dhcp-server/setup"] = menuCmds["/ip/hotspot/setup"]

	// refresh hooks for live values
	refreshHooks["/system/resource"] = func(r *Router, it Item) {
		md := r.Model
		it["uptime"] = fmtDur(time.Since(r.boot).Truncate(time.Second))
		it["version"] = r.Ver
		it["build-time"] = "2025-03-11 11:59:04"
		it["factory-software"] = md.Firmware
		if it["factory-software"] == "" {
			it["factory-software"] = strings.Fields(r.Ver)[0]
		}
		tot := int64(md.MemMB) * 1024 * 1024
		sess := int64(len(r.list(MenuMap["/ip/hotspot/active"])) + len(r.list(MenuMap["/ppp/active"])))
		used := tot*28/100 + sess*350*1024 + int64(rand.Intn(2048))*1024
		it["total-memory"] = strconv.FormatInt(tot, 10)
		it["free-memory"] = strconv.FormatInt(tot-used, 10)
		it["cpu"] = md.CPU
		it["cpu-count"] = strconv.Itoa(md.Cores)
		it["cpu-frequency"] = strconv.Itoa(md.MHz)
		it["cpu-load"] = strconv.Itoa(int(r.sim.cpu))
		hdd := int64(md.HddMB) * 1024 * 1024
		it["total-hdd-space"] = strconv.FormatInt(hdd, 10)
		it["free-hdd-space"] = strconv.FormatInt(hdd*62/100, 10)
		it["write-sect-since-reboot"] = strconv.Itoa(int(time.Since(r.boot).Seconds()) / 3)
		it["write-sect-total"] = strconv.Itoa(48211 + int(time.Since(r.boot).Seconds())/3)
		it["bad-blocks"] = "0%"
		it["architecture-name"] = md.Arch
		it["board-name"] = md.Board
		it["platform"] = "MikroTik"
	}
	refreshHooks["/sim/models"] = func(r *Router, it Item) {
		t := r.tbl("/sim/models")
		t.Items = nil
		for i, k := range ModelOrder {
			m := Models[k]
			wl := "none"
			if m.WLAN > 0 {
				wl = m.summary()[strings.LastIndex(m.summary(), ", ")+2:]
			}
			t.Items = append(t.Items, Item{".id": fmt.Sprintf("*%X", i+1), "key": m.Key, "board": m.Board, "model": m.Name, "family": m.Family, "ports": m.summary(), "cpu": fmt.Sprintf("%d x %d MHz %s", m.Cores, m.MHz, m.Arch), "memory": fmt.Sprintf("%d MiB", m.MemMB), "wireless": wl, "description": m.Desc, "current": fmt.Sprint(m.Key == r.Model.Key), "dynamic": "true"})
		}
	}
	refreshHooks["/user/active"] = nil
	delete(refreshHooks, "/user/active")
}

func rateItem(name string, rt *Rate) Item {
	return Item{"name": name, "rx-packets-per-second": strconv.Itoa(int(rt.RxPps)), "rx-bits-per-second": strconv.Itoa(int(rt.RxBps)), "fp-rx-packets-per-second": strconv.Itoa(int(rt.RxPps * 0.9)), "fp-rx-bits-per-second": strconv.Itoa(int(rt.RxBps * 0.9)), "rx-drops-per-second": "0", "rx-errors-per-second": "0", "tx-packets-per-second": strconv.Itoa(int(rt.TxPps)), "tx-bits-per-second": strconv.Itoa(int(rt.TxBps)), "fp-tx-packets-per-second": strconv.Itoa(int(rt.TxPps * 0.9)), "fp-tx-bits-per-second": strconv.Itoa(int(rt.TxBps * 0.9)), "tx-drops-per-second": "0", "tx-queue-drops-per-second": "0", "tx-errors-per-second": "0"}
}

// realRTT measures a TCP handshake to estimate latency to a public host (no privileges needed).
func realRTT(host string) float64 {
	for _, port := range []string{"443", "80"} {
		t0 := time.Now()
		conn, err := net.DialTimeout("tcp", net.JoinHostPort(host, port), 700*time.Millisecond)
		el := time.Since(t0)
		if err == nil {
			conn.Close()
			return float64(el.Microseconds()) / 1000
		}
		if strings.Contains(err.Error(), "refused") {
			return float64(el.Microseconds()) / 1000
		}
	}
	return 0
}
