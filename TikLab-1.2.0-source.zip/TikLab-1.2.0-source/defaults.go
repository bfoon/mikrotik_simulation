package main

import (
	"crypto/rand"
	"embed"
	"fmt"
	"io/fs"
	"net"
	"sort"
	"strings"
)

//go:embed hotspot
var hotspotFS embed.FS

func (r *Router) nextMAC() string {
	r.macSeq++
	m := make(net.HardwareAddr, 6)
	copy(m, r.baseMAC)
	v := int(m[5]) + r.macSeq
	m[5] = byte(v)
	m[4] = byte(int(m[4]) + v/256)
	return strings.ToUpper(m.String())
}

// markBaseline remembers the factory values of a built-in item so exports
// only contain what the user changed.
func markBaseline(it Item) {
	var b strings.Builder
	keys := make([]string, 0, len(it))
	for k := range it {
		if !strings.HasPrefix(k, "_") && k != ".id" {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		b.WriteString(k + "\x1f" + it[k] + "\x1e")
	}
	it["_base"] = b.String()
}

func baseline(it Item) map[string]string {
	if it["_base"] == "" {
		return nil
	}
	m := map[string]string{}
	for _, kv := range strings.Split(it["_base"], "\x1e") {
		p := strings.SplitN(kv, "\x1f", 2)
		if len(p) == 2 {
			m[p[0]] = p[1]
		}
	}
	return m
}

func randHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return fmt.Sprintf("%X", b)
}

func (r *Router) add(path string, kv ...string) Item {
	args := map[string]string{}
	for i := 0; i+1 < len(kv); i += 2 {
		args[kv[i]] = kv[i+1]
	}
	it, err := r.addItem(MenuMap[path], args, true)
	if err != nil {
		fmt.Println("  ! default config:", path, err)
	}
	if it != nil && it["_default"] == "true" {
		markBaseline(it)
	}
	return it
}

func (r *Router) setS(path string, kv ...string) {
	it := r.single(path)
	for i := 0; i+1 < len(kv); i += 2 {
		it[kv[i]] = kv[i+1]
	}
}

// factoryDefaults builds a realistic default configuration tuned for hotspot / ISP testing.
func (r *Router) factoryDefaults(adminPass string) { r.factoryDefaultsMode(adminPass, true) }

// factoryDefaultsMode builds the configuration. defconf=false gives the bare
// "no-defaults" router (interfaces and built-in items only), like
// /system reset-configuration no-defaults=yes.
func (r *Router) factoryDefaultsMode(adminPass string, defconf bool) {
	r.T = map[string]*Table{}
	r.macSeq = 0
	md := r.Model
	host := hostNet()

	r.setS("/system/identity", "name", firstNonEmpty(r.Opt.Identity, "MikroTik"))
	r.setS("/system/license", "software-id", fmt.Sprintf("%s-%s", randHex(2), randHex(2)), "nlevel", md.Level, "level", md.Level, "features", "")
	fwType := map[string]string{"arm": "ipq4000L", "arm64": "an7581", "mmips": "mt7621L", "mipsbe": "ar9344L", "smips": "qca9531L", "tile": "tilegx"}[md.Arch]
	if !md.RouterBoard {
		fwType = "none"
	}
	r.setS("/system/routerboard", "routerboard", fmt.Sprint(md.RouterBoard), "board-name", md.Board, "model", md.Name, "serial-number", md.Serial, "firmware-type", fwType, "factory-firmware", md.Firmware, "current-firmware", md.Firmware, "upgrade-firmware", md.Firmware)
	r.single("/system/clock")
	r.setS("/system/package/update", "installed-version", strings.Fields(r.Ver)[0], "latest-version", strings.Fields(r.Ver)[0], "status", "System is already up to date")
	r.add("/system/package", "name", "routeros", "version", strings.Fields(r.Ver)[0], "build-time", "2025-03-11 11:59:04", "size", "12.4MiB", "_default", "true")
	if md.WLAN > 0 && md.WifiAX {
		r.add("/system/package", "name", "wifi-qcom", "version", strings.Fields(r.Ver)[0], "build-time", "2025-03-11 11:59:04", "size", "5.2MiB", "_default", "true")
	} else if md.WLAN > 0 {
		r.add("/system/package", "name", "wireless", "version", strings.Fields(r.Ver)[0], "build-time", "2025-03-11 11:59:04", "size", "3.1MiB", "_default", "true")
	}

	// users
	r.add("/user/group", "name", "read", "policy", "local,telnet,ssh,reboot,read,test,winbox,password,web,sniff,api,romon,rest-api,!ftp,!write,!policy,!sensitive", "_default", "true")
	r.add("/user/group", "name", "write", "policy", "local,telnet,ssh,reboot,read,write,test,winbox,password,web,sniff,api,romon,rest-api,!ftp,!policy,!sensitive", "_default", "true")
	r.add("/user/group", "name", "full", "policy", "local,telnet,ssh,ftp,reboot,read,write,policy,test,winbox,password,web,sniff,sensitive,api,romon,rest-api", "_default", "true")
	r.add("/user", "name", "admin", "group", "full", "password", adminPass, "comment", "system default user")

	// interfaces
	speedCfg := map[string][2]string{
		"100M": {"100M-baseT-full", "10M-baseT-half,10M-baseT-full,100M-baseT-half,100M-baseT-full"},
		"1G":   {"1G-baseT-full", "10M-baseT-half,10M-baseT-full,100M-baseT-half,100M-baseT-full,1G-baseT-half,1G-baseT-full"},
		"2.5G": {"2.5G-baseT", "10M-baseT-half,10M-baseT-full,100M-baseT-half,100M-baseT-full,1G-baseT-full,2.5G-baseT"},
	}
	for i := 1; i <= md.Ether; i++ {
		n := fmt.Sprintf("ether%d", i)
		mac := r.nextMAC()
		sp := md.portSpeed(i)
		it := r.add("/interface/ethernet", "name", n, "default-name", n, "mac-address", mac, "orig-mac-address", mac, "speed", speedCfg[sp][0], "advertise", speedCfg[sp][1], "_default", "true", "_speed", sp, "_spd0", speedCfg[sp][0])
		for _, p := range md.Panel.PoEOut {
			if p == i {
				it["poe-out"] = "auto-on"
			}
		}
	}
	for i := 1; i <= md.Combo; i++ {
		n := fmt.Sprintf("combo%d", i)
		mac := r.nextMAC()
		r.add("/interface/ethernet", "name", n, "default-name", n, "mac-address", mac, "orig-mac-address", mac, "speed", "1G-baseT-full", "_default", "true", "_speed", "1G", "_spd0", "1G-baseT-full")
	}
	for i := 1; i <= md.SFP; i++ {
		n := fmt.Sprintf("%s%d", md.SFPName, i)
		mac := r.nextMAC()
		sp, sc := "1G", "1G-baseX"
		if md.SFPName == "sfp-sfpplus" {
			sp, sc = "10G", "10G-baseSR-LR"
		}
		r.add("/interface/ethernet", "name", n, "default-name", n, "mac-address", mac, "orig-mac-address", mac, "speed", sc, "advertise", sc, "_default", "true", "_sfp", "true", "_speed", sp, "_spd0", sc)
	}
	r.add("/interface/wireless/security-profiles", "name", "default", "mode", "none", "default", "true", "_default", "true")
	_, _, wlNames := md.portNames()
	for i, wn := range wlNames {
		mac := r.nextMAC()
		if md.WifiAX {
			band := "5ghz-ax"
			if i == 1 {
				band = "2ghz-ax"
			}
			r.add("/interface/wifi", "name", wn, "default-name", wn, "mac-address", mac, "configuration.ssid", "TikLab-Hotspot", "configuration.mode", "ap", "channel.band", band, "security.authentication-types", "wpa2-psk,wpa3-psk", "security.passphrase", "hotspot123", "disabled", "false", "_default", "true")
			continue
		}
		band, freq := "2ghz-b/g/n", "2437"
		if i == 1 {
			band, freq = "5ghz-a/n/ac", "5180"
		}
		r.add("/interface/wireless", "name", wn, "default-name", wn, "mac-address", mac, "ssid", "TikLab-Hotspot", "band", band, "frequency", freq, "interface-type", map[string]string{"arm": "IPQ4019", "mipsbe": "AR9300", "smips": "QCA9533"}[md.Arch], "radio-name", strings.ReplaceAll(mac, ":", ""), "security-profile", "default", "disabled", "false", "_default", "true")
	}
	for _, l := range []string{"all", "none", "dynamic", "static"} {
		r.add("/interface/list", "name", l, "builtin", "true", "_default", "true")
	}
	if defconf {
		r.add("/interface/bridge", "name", "bridge-lan", "comment", "defconf", "mac-address", r.nextMAC(), "admin-mac", "", "auto-mac", "true")
		r.add("/interface/bridge", "name", "bridge-hotspot", "comment", "hotspot", "mac-address", r.nextMAC(), "auto-mac", "true", "protocol-mode", "none")
		etherNames, sfpNames, _ := md.portNames()
		for i, n := range etherNames {
			if i == 0 {
				continue // ether1 = WAN
			}
			br := "bridge-lan"
			if i+1 > md.LanSplit {
				br = "bridge-hotspot"
			}
			r.add("/interface/bridge/port", "interface", n, "bridge", br, "comment", "defconf")
		}
		for _, n := range sfpNames {
			r.add("/interface/bridge/port", "interface", n, "bridge", "bridge-hotspot")
		}
		for _, n := range wlNames {
			r.add("/interface/bridge/port", "interface", n, "bridge", "bridge-hotspot")
		}
		r.add("/interface/list", "name", "WAN", "comment", "defconf")
		r.add("/interface/list", "name", "LAN", "comment", "defconf")
		r.add("/interface/list/member", "list", "LAN", "interface", "bridge-lan", "comment", "defconf")
		r.add("/interface/list/member", "list", "LAN", "interface", "bridge-hotspot")
		r.add("/interface/list/member", "list", "WAN", "interface", "ether1", "comment", "defconf")

		// IP
		r.add("/ip/pool", "name", "dhcp_pool0", "ranges", "192.168.88.10-192.168.88.254")
		r.add("/ip/pool", "name", "hs-pool-1", "ranges", "10.5.50.2-10.5.50.254")
		r.add("/ip/pool", "name", "pppoe-pool", "ranges", "10.10.10.2-10.10.10.254")
		r.add("/ip/address", "address", "192.168.88.1/24", "interface", "bridge-lan", "comment", "defconf")
		r.add("/ip/address", "address", "10.5.50.1/24", "interface", "bridge-hotspot", "comment", "hotspot network")
		r.add("/ip/dhcp-client", "interface", "ether1", "comment", "defconf", "_host", host.String())
		r.add("/ip/dhcp-server", "name", "defconf", "interface", "bridge-lan", "address-pool", "dhcp_pool0", "lease-time", "30m")
		r.add("/ip/dhcp-server", "name", "dhcp-hotspot", "interface", "bridge-hotspot", "address-pool", "hs-pool-1", "lease-time", "1h")
		r.add("/ip/dhcp-server/network", "address", "192.168.88.0/24", "gateway", "192.168.88.1", "dns-server", "192.168.88.1", "comment", "defconf")
		r.add("/ip/dhcp-server/network", "address", "10.5.50.0/24", "gateway", "10.5.50.1", "dns-server", "10.5.50.1", "comment", "hotspot network")
		r.setS("/ip/dns", "servers", "8.8.8.8,1.1.1.1", "allow-remote-requests", "true", "cache-used", "42KiB")
		r.add("/ip/dns/static", "name", "router.lan", "address", "192.168.88.1", "comment", "defconf")

		// firewall (defconf)
		fw := "/ip/firewall/filter"
		r.add(fw, "chain", "input", "action", "accept", "connection-state", "established,related,untracked", "comment", "defconf: accept established,related,untracked")
		r.add(fw, "chain", "input", "action", "drop", "connection-state", "invalid", "comment", "defconf: drop invalid")
		r.add(fw, "chain", "input", "action", "accept", "protocol", "icmp", "comment", "defconf: accept ICMP")
		r.add(fw, "chain", "input", "action", "accept", "dst-address", "127.0.0.1", "comment", "defconf: accept to local loopback (for CAPsMAN)")
		r.add(fw, "chain", "input", "action", "drop", "in-interface-list", "!LAN", "comment", "defconf: drop all not coming from LAN")
		r.add(fw, "chain", "forward", "action", "fasttrack-connection", "connection-state", "established,related", "comment", "defconf: fasttrack")
		r.add(fw, "chain", "forward", "action", "accept", "connection-state", "established,related,untracked", "comment", "defconf: accept established,related, untracked")
		r.add(fw, "chain", "forward", "action", "drop", "connection-state", "invalid", "comment", "defconf: drop invalid")
		r.add(fw, "chain", "forward", "action", "drop", "connection-state", "new", "connection-nat-state", "!dstnat", "in-interface-list", "WAN", "comment", "defconf: drop all from WAN not DSTNATed")
		r.add("/ip/firewall/nat", "chain", "srcnat", "action", "masquerade", "out-interface-list", "WAN", "comment", "defconf: masquerade")
		r.add("/ip/firewall/nat", "chain", "srcnat", "action", "masquerade", "src-address", "10.5.50.0/24", "comment", "masquerade hotspot network")
	}
	r.setS("/ip/cloud", "status", "unknown")

	// services (ports are synced with real listeners at start-up)
	for _, s := range [][3]string{{"telnet", "23", ""}, {"ftp", "21", ""}, {"www", "80", ""}, {"ssh", "22", ""}, {"www-ssl", "443", ""}, {"api", "8728", ""}, {"winbox", "8291", ""}, {"api-ssl", "8729", ""}} {
		r.add("/ip/service", "name", s[0], "port", s[1], "disabled", firstNonEmpty(s[2], "false"), "_default", "true", "certificate", map[bool]string{true: "tiklab-ssl", false: "none"}[s[0] == "www-ssl" || s[0] == "api-ssl"])
	}
	r.add("/ip/firewall/service-port", "name", "ftp", "ports", "21", "_default", "true")
	r.add("/ip/firewall/service-port", "name", "tftp", "ports", "69", "_default", "true")
	r.add("/ip/firewall/service-port", "name", "sip", "ports", "5060,5061", "_default", "true")

	// hotspot
	r.add("/ip/hotspot/profile", "name", "default", "default", "true", "_default", "true")
	r.add("/ip/hotspot/user/profile", "name", "default", "default", "true", "_default", "true")
	r.add("/ip/hotspot/user", "name", "default-trial", "server", "all", "default", "true", "_default", "true", "comment", "counters and limits for trial users")
	r.add("/ip/hotspot/service-port", "name", "ftp", "ports", "21", "_default", "true")
	if defconf {
		r.add("/ip/hotspot/profile", "name", "hsprof1", "hotspot-address", "10.5.50.1", "dns-name", "login.wifi", "html-directory", "hotspot", "login-by", "cookie,http-chap,http-pap,mac-cookie")
		r.add("/ip/hotspot/user/profile", "name", "1-hour", "rate-limit", "2M/2M", "shared-users", "1", "keepalive-timeout", "2m")
		r.add("/ip/hotspot/user/profile", "name", "1-day", "rate-limit", "3M/5M", "shared-users", "1")
		r.add("/ip/hotspot/user/profile", "name", "1-week", "rate-limit", "5M/10M", "shared-users", "2")
		r.add("/ip/hotspot", "name", "hotspot1", "interface", "bridge-hotspot", "address-pool", "hs-pool-1", "profile", "hsprof1", "idle-timeout", "none")
		r.add("/ip/hotspot/user", "server", "hotspot1", "name", "demo", "password", "demo", "profile", "1-hour", "limit-uptime", "1h", "comment", "sample voucher")
		r.add("/ip/hotspot/walled-garden", "dst-host", "*.tiklab.local", "action", "allow", "comment", "example walled garden entry")
	}

	// PPP
	r.add("/ppp/profile", "name", "default", "default", "true", "_default", "true", "only-one", "default", "change-tcp-mss", "yes")
	r.add("/ppp/profile", "name", "default-encryption", "default", "true", "_default", "true", "use-encryption", "yes")
	if defconf {
		r.add("/ppp/profile", "name", "pppoe-10M", "local-address", "10.10.10.1", "remote-address", "pppoe-pool", "rate-limit", "10M/10M", "dns-server", "8.8.8.8,1.1.1.1", "only-one", "yes")
		r.add("/ppp/profile", "name", "pppoe-20M", "local-address", "10.10.10.1", "remote-address", "pppoe-pool", "rate-limit", "20M/20M", "dns-server", "8.8.8.8,1.1.1.1", "only-one", "yes")
		r.add("/interface/pppoe-server/server", "service-name", "service1", "interface", "bridge-lan", "default-profile", "pppoe-10M", "one-session-per-host", "true", "disabled", "false")
		r.add("/ppp/secret", "name", "client1", "password", "1234", "service", "pppoe", "profile", "pppoe-10M", "comment", "sample PPPoE customer")
		r.add("/ppp/secret", "name", "client2", "password", "1234", "service", "pppoe", "profile", "pppoe-20M")
		r.add("/ppp/secret", "name", "client3", "password", "1234", "service", "pppoe", "profile", "pppoe-10M", "disabled", "true", "comment", "suspended - unpaid")
	}

	// queues
	for _, q := range []string{"default", "ethernet-default", "wireless-default", "synchronous-default", "hotspot-default", "pcq-upload-default", "pcq-download-default", "only-hardware-queue", "multi-queue-ethernet-default", "default-small"} {
		kind := "pfifo"
		if strings.HasPrefix(q, "pcq") {
			kind = "pcq"
		} else if q == "only-hardware-queue" {
			kind = "none"
		} else if q == "multi-queue-ethernet-default" {
			kind = "mq-pfifo"
		} else if q == "synchronous-default" || q == "wireless-default" {
			kind = "sfq"
		}
		r.add("/queue/type", "name", q, "kind", kind, "default", "true", "_default", "true")
	}
	if defconf {
		r.add("/queue/simple", "name", "LAN-total", "target", "192.168.88.0/24", "max-limit", "50M/50M", "comment", "limit whole LAN")
	}

	// system
	r.add("/system/logging/action", "name", "memory", "target", "memory", "default", "true", "_default", "true")
	r.add("/system/logging/action", "name", "disk", "target", "disk", "default", "true", "_default", "true")
	r.add("/system/logging/action", "name", "echo", "target", "echo", "default", "true", "_default", "true")
	r.add("/system/logging/action", "name", "remote", "target", "remote", "remote", "0.0.0.0", "default", "true", "_default", "true")
	for _, t := range []string{"info", "error", "warning", "critical"} {
		r.add("/system/logging", "topics", t, "action", "memory", "default", "true", "_default", "true")
	}
	r.add("/snmp/community", "name", "public", "default", "true", "_default", "true")
	if defconf {
		r.add("/tool/netwatch", "host", "8.8.8.8", "type", "simple", "interval", "10s", "comment", "internet check")
		r.add("/system/script", "name", "hello", "source", ":log info \"Hello from TikLab script\"\n:put \"hello world\"", "comment", "example script")
	}

	// files
	r.add("/file", "name", "skins", "type", "directory")
	r.add("/file", "name", "pub", "type", "directory")
	r.add("/file", "name", "hotspot", "type", "directory")
	entries, _ := fs.ReadDir(hotspotFS, "hotspot")
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	sort.Strings(names)
	for _, n := range names {
		b, _ := hotspotFS.ReadFile("hotspot/" + n)
		typ := ".html file"
		if strings.HasSuffix(n, ".js") {
			typ = ".js file"
		} else if strings.HasSuffix(n, ".txt") {
			typ = ".txt file"
		} else if strings.HasSuffix(n, ".css") {
			typ = ".css file"
		}
		r.add("/file", "name", "hotspot/"+n, "type", typ, "contents", string(b))
	}

	// simulator
	r.single("/sim/settings")
	r.syncSimPorts()
	r.markDirty()
}

// syncSimPorts makes sure every physical port has a /sim/port entry
func (r *Router) syncSimPorts() {
	sp := MenuMap["/sim/port"]
	have := map[string]bool{}
	for _, p := range r.list(sp) {
		have[p["interface"]] = true
	}
	colors := []string{"blue", "yellow", "green", "red", "grey", "white", "orange", "purple"}
	for _, it := range r.list(MenuMap["/interface/ethernet"]) {
		n := it["default-name"]
		if have[it["name"]] {
			continue
		}
		cable := "false"
		idx := 0
		fmt.Sscanf(strings.TrimLeft(n, "etherfpsplu-"), "%d", &idx)
		lan := r.Model.LanSplit
		if n == "ether1" || n == "ether2" || (idx == lan+1 && strings.HasPrefix(n, "ether")) || (idx == lan+2 && strings.HasPrefix(n, "ether")) {
			cable = "true"
		}
		speed := firstNonEmpty(it["_speed"], "1G")
		color := colors[idx%len(colors)]
		if n == "ether1" {
			color = "yellow"
		}
		r.addItem(sp, map[string]string{"interface": it["name"], "cable": cable, "speed": speed, "cable-color": color, "_port": n}, true)
	}
}

// ---------- default hooks ----------

func init() {
	addHooks["/ip/address"] = func(r *Router, m *Menu, it Item) error {
		for _, a := range r.list(m) {
			if a["address"] == it["address"] && a["interface"] == it["interface"] {
				return trap("failure: already have such address")
			}
		}
		ipnetFill(it)
		it["actual-interface"] = it["interface"]
		return nil
	}
	afterHooks["/ip/address"] = func(r *Router, it Item) { r.rebuildRoutes() }
	afterSetHooks["/ip/address"] = func(r *Router, it, old Item) {
		if it["address"] != old["address"] {
			delete(it, "network")
			ipnetFill(it)
		}
		it["actual-interface"] = it["interface"]
		r.rebuildRoutes()
	}
	afterDelHooks["/ip/address"] = func(r *Router, it Item) { r.rebuildRoutes() }
	afterHooks["/ip/route"] = func(r *Router, it Item) { r.rebuildRoutes() }
	afterSetHooks["/ip/route"] = func(r *Router, it, old Item) { r.rebuildRoutes() }
	addHooks["/interface"] = func(r *Router, m *Menu, it Item) error {
		if it["mac-address"] == "" && it["type"] != "pppoe-in" && it["type"] != "pppoe-out" && it["type"] != "wg" {
			it["mac-address"] = r.nextMAC()
		}
		if it["type"] == "vlan" {
			it["l2mtu"] = "1576"
		}
		if it["type"] == "bridge" {
			it["l2mtu"] = "65535"
			it["max-l2mtu"] = "65535"
		}
		if it["type"] == "wg" {
			it["public-key"] = randB64(32)
			if it["private-key"] == "" {
				it["private-key"] = randB64(32)
			}
		}
		if it["default-name"] == "" {
			delete(it, "default-name")
		}
		return nil
	}
	afterHooks["/interface"] = func(r *Router, it Item) {
		if it["type"] == "ether" {
			r.syncSimPorts()
		}
	}
	afterSetHooks["/interface"] = func(r *Router, it, old Item) {
		if it["disabled"] != old["disabled"] && r.sim != nil {
			if it.B("disabled") {
				r.log("interface,info", "%s link down", it["name"])
			}
		}
	}
	afterDelHooks["/interface"] = func(r *Router, it Item) {
		r.removeWhere("/interface/bridge/port", func(p Item) bool { return p["interface"] == it["name"] || p["bridge"] == it["name"] })
	}
	addHooks["/interface/bridge/port"] = func(r *Router, m *Menu, it Item) error {
		if i := r.byName("/interface", it["interface"]); i != nil {
			if i["type"] == "bridge" && it["interface"] == it["bridge"] {
				return trap("failure: can not add bridge to itself")
			}
			for _, p := range r.list(m) {
				if p["interface"] == it["interface"] {
					return trap("failure: device already added as bridge port")
				}
			}
			i["slave"] = "true"
		}
		br := r.byName("/interface", it["bridge"])
		if br == nil || br["type"] != "bridge" {
			return trap("input does not match any value of bridge")
		}
		it["status"] = "in-bridge"
		it["role"] = "designated-port"
		return nil
	}
	afterDelHooks["/interface/bridge/port"] = func(r *Router, it Item) {
		if i := r.byName("/interface", it["interface"]); i != nil {
			i["slave"] = "false"
		}
	}
	addHooks["/queue/simple"] = func(r *Router, m *Menu, it Item) error {
		var t []string
		for _, x := range strings.Split(it["target"], ",") {
			x = strings.TrimSpace(x)
			if x == "" {
				continue
			}
			if net.ParseIP(x) != nil {
				x += "/32"
			}
			t = append(t, x)
		}
		it["target"] = strings.Join(t, ",")
		if !strings.Contains(it["max-limit"], "/") {
			it["max-limit"] = it["max-limit"] + "/" + it["max-limit"]
		}
		return nil
	}
	addHooks["/ip/hotspot/user"] = func(r *Router, m *Menu, it Item) error {
		if it["limit-uptime"] == "0s" {
			delete(it, "limit-uptime")
		}
		for _, k := range []string{"limit-bytes-in", "limit-bytes-out", "limit-bytes-total"} {
			if it[k] == "0" {
				delete(it, k)
			}
		}
		return nil
	}
	delHooks["/ip/hotspot/user"] = func(r *Router, it Item, internal bool) error {
		if r.sim != nil {
			for _, a := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
				if a["user"] == it["name"] {
					r.sim.hotspotLogout(a, "user removed")
				}
			}
		}
		return nil
	}
	afterSetHooks["/ip/hotspot/user"] = func(r *Router, it, old Item) {
		if it.B("disabled") && !old.B("disabled") && r.sim != nil {
			for _, a := range append([]Item(nil), r.list(MenuMap["/ip/hotspot/active"])...) {
				if a["user"] == it["name"] {
					r.sim.hotspotLogout(a, "user disabled")
				}
			}
		}
		if it["name"] != old["name"] {
			for _, a := range r.list(MenuMap["/ip/hotspot/active"]) {
				if a["user"] == old["name"] {
					a["user"] = it["name"]
				}
			}
		}
	}
	delHooks["/ip/hotspot/active"] = func(r *Router, it Item, internal bool) error {
		if !internal && r.sim != nil {
			r.sim.hotspotLogout(it, "admin reset")
			return trap("__handled")
		}
		return nil
	}
	delHooks["/ppp/active"] = func(r *Router, it Item, internal bool) error {
		if !internal && r.sim != nil {
			r.sim.pppDisconnect(it, "admin-reset")
			return trap("__handled")
		}
		return nil
	}
	afterSetHooks["/ppp/secret"] = func(r *Router, it, old Item) {
		if it.B("disabled") && !old.B("disabled") && r.sim != nil {
			for _, a := range append([]Item(nil), r.list(MenuMap["/ppp/active"])...) {
				if a["name"] == it["name"] {
					r.sim.pppDisconnect(a, "secret disabled")
				}
			}
		}
	}
	delHooks["/ppp/secret"] = func(r *Router, it Item, internal bool) error {
		if r.sim != nil {
			for _, a := range append([]Item(nil), r.list(MenuMap["/ppp/active"])...) {
				if a["name"] == it["name"] {
					r.sim.pppDisconnect(a, "secret removed")
				}
			}
		}
		return nil
	}
	addHooks["/file"] = func(r *Router, m *Menu, it Item) error {
		now := r.now().Format("2006-01-02 15:04:05")
		it["creation-time"] = now
		it["last-modified"] = now
		it["size"] = fmt.Sprint(len(it["contents"]))
		if it["type"] == "directory" {
			delete(it, "contents")
			it["size"] = "0"
		}
		return nil
	}
	addHooks["/ip/firewall/address-list"] = func(r *Router, m *Menu, it Item) error {
		it["creation-time"] = r.now().Format("2006-01-02 15:04:05")
		return nil
	}
	addHooks["/user"] = func(r *Router, m *Menu, it Item) error {
		if it["group"] == "" {
			it["group"] = "full"
		}
		return nil
	}
	delHooks["/user"] = func(r *Router, it Item, internal bool) error {
		if internal {
			return nil
		}
		full := 0
		for _, u := range r.list(MenuMap["/user"]) {
			if u["group"] == "full" && !u.B("disabled") {
				full++
			}
		}
		if it["group"] == "full" && full <= 1 {
			return trap("failure: can not remove last full user")
		}
		return nil
	}
	addHooks["/certificate"] = func(r *Router, m *Menu, it Item) error {
		if it["common-name"] == "" {
			it["common-name"] = it["name"]
		}
		return nil
	}
	setHooks["/system/clock"] = func(r *Router, m *Menu, it Item, nv map[string]string) error {
		if t, ok := nv["time"]; ok {
			delete(nv, "time")
			cur := r.now()
			var h, mi, s int
			if _, err := fmt.Sscanf(t, "%d:%d:%d", &h, &mi, &s); err != nil {
				return trap("invalid value for argument time")
			}
			target := timeDate(cur.Year(), int(cur.Month()), cur.Day(), h, mi, s, cur)
			r.clockOff += target.Sub(cur)
		}
		if d, ok := nv["date"]; ok {
			delete(nv, "date")
			cur := r.now()
			t, err := parseDate(d)
			if err != nil {
				return trap("invalid value for argument date")
			}
			target := timeDate(t.Year(), int(t.Month()), t.Day(), cur.Hour(), cur.Minute(), cur.Second(), cur)
			r.clockOff += target.Sub(cur)
		}
		return nil
	}
	refreshHooks["/system/clock"] = func(r *Router, it Item) {
		n := r.now()
		it["time"] = n.Format("15:04:05")
		it["date"] = n.Format("2006-01-02")
		_, off := n.Zone()
		sign := "+"
		if off < 0 {
			sign = "-"
			off = -off
		}
		it["gmt-offset"] = fmt.Sprintf("%s%02d:%02d", sign, off/3600, (off%3600)/60)
	}
	setHooks["/ip/service"] = func(r *Router, m *Menu, it Item, nv map[string]string) error {
		if p, ok := nv["port"]; ok {
			var n int
			fmt.Sscanf(p, "%d", &n)
			if n <= 0 || n > 65535 {
				return trap("invalid value for argument port")
			}
		}
		return nil
	}
	afterSetHooks["/ip/service"] = func(r *Router, it, old Item) {
		if (it["port"] != old["port"] || it["disabled"] != old["disabled"]) && r.onSvc != nil {
			name := it["name"]
			go r.onSvc(name)
		}
	}
}

func ipnetFill(it Item) {
	ip, n, err := net.ParseCIDR(it["address"])
	if err != nil {
		return
	}
	_ = ip
	if it["network"] == "" {
		it["network"] = n.IP.String()
	}
}

func (r *Router) rebuildRoutes() {
	if r.inRebuild {
		return
	}
	r.inRebuild = true
	defer func() { r.inRebuild = false }()
	rt := MenuMap["/ip/route"]
	r.removeWhere("/ip/route", func(it Item) bool { return it.B("connect") })
	for _, a := range r.list(MenuMap["/ip/address"]) {
		if a.B("disabled") {
			continue
		}
		_, n, err := net.ParseCIDR(a["address"])
		if err != nil {
			continue
		}
		dst := n.String()
		if a["network"] != "" && a["network"] != n.IP.String() {
			dst = a["network"] + "/32"
		}
		ip := strings.Split(a["address"], "/")[0]
		r.addItem(rt, map[string]string{"dst-address": dst, "gateway": a["interface"], "immediate-gw": a["interface"], "distance": "0", "scope": "10", "pref-src": ip, "local-address": ip + "%" + a["interface"], "dynamic": "true", "active": "true", "connect": "true", "static": "false", "_keep": ""}, true)
	}
	for _, it := range r.list(rt) {
		if it.B("connect") || it.B("disabled") {
			continue
		}
		gw := it["gateway"]
		active := false
		if g := net.ParseIP(strings.Split(gw, "%")[0]); g != nil {
			for _, c := range r.list(rt) {
				if c.B("connect") {
					if _, n, err := net.ParseCIDR(c["dst-address"]); err == nil && n.Contains(g) {
						active = true
						it["immediate-gw"] = gw + "%" + c["gateway"]
					}
				}
			}
		} else if r.byName("/interface", gw) != nil {
			active = true
			it["immediate-gw"] = gw
		}
		it["active"] = fmt.Sprint(active)
		it["inactive"] = fmt.Sprint(!active)
	}
}
