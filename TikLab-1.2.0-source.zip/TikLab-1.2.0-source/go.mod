module tiklab

go 1.24

require golang.org/x/crypto v0.31.0

require golang.org/x/sys v0.28.0 // indirect

replace (
	golang.org/x/crypto => ./third_party/crypto
	golang.org/x/net => ./third_party/stub-net
	golang.org/x/sys => ./third_party/sys
	golang.org/x/term => ./third_party/stub-term
	golang.org/x/text => ./third_party/stub-text
)
