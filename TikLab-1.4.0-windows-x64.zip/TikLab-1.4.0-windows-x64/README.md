# TikLab 1.4 — RouterOS-compatible router simulator

TikLab is a portable program that behaves like a MikroTik router on your network. Use it for
training, and for testing apps such as TapTap that manage MikroTik routers through the
RouterOS API or REST API, without touching a real customer router.

It is one file with no installation and runs on Windows and Linux. Everything (configuration,
keys, certificates) is saved in a `tiklab-data` folder next to the program.

> TikLab is an independent simulator. It is not made by or affiliated with MikroTik, and it does
> not contain RouterOS. It re-implements RouterOS's behaviour and protocols so that apps and
> people can talk to it as if it were a router.

---

## Quick start

**Windows:** unzip, then double-click **`Start TikLab.bat`** (or `tiklab.exe`).
- If Windows SmartScreen warns about an unknown app, choose *More info → Run anyway*.
- When the Windows Firewall asks, allow access on **Private networks** so phones and other PCs
  (and the TapTap app) can reach the simulator.

**Linux:** unpack, then run `./start-tiklab.sh` (or `./tiklab`).
- Ports below 1024 (80, 443, 22, 23) need root. Without root TikLab moves those services to
  8080, 8443, 2222 and 2323 automatically. To keep the standard ports without running as root:
  `sudo setcap 'cap_net_bind_service=+ep' ./tiklab`

A WinBox-style console opens in your browser automatically. Log in as **admin** with an **empty
password**, which is how a brand-new router ships. The console window shows every address and port.

## Connecting the TapTap app (or any MikroTik tool)

Use the IP address of the PC running TikLab (shown in the console window), user `admin`, and the
router password.

| Service | Default port | Notes |
|---|---|---|
| RouterOS API | **8728** | What most MikroTik apps use (hotspot vouchers, PPPoE, monitoring) |
| RouterOS API-SSL | 8729 | TLS with a self-signed certificate |
| REST API | 80 → `http://PC-IP/rest/...` | RouterOS v7 REST (GET/PUT/PATCH/DELETE/POST) |
| REST API over HTTPS | 443 | self-signed certificate |
| WinBox-style console | 8291 → `http://PC-IP:8291/` | TikLab's own WinBox, in any browser |
| Hotspot login page | 80 → `http://PC-IP/login` | captive portal for testing vouchers from a phone |
| SSH | 22 | RouterOS CLI, including `ssh admin@PC-IP "/ip hotspot user print"` |
| Telnet | 23 | RouterOS CLI |
| FTP | 21 | files and hotspot pages (FileZilla, WinSCP, Windows `ftp`), like a real router |

Ports below 1024 move to 8080/8443/2222/2323/2121 when TikLab runs without admin rights on Linux.
Ports can be changed like on a real router (`/ip service set api port=8730`) or with command-line
options. If a port is busy, TikLab picks the next free one and shows it in the console window.

### End-to-end voucher test

1. Create vouchers from your app (or *Simulator → Vouchers → Generate*).
2. On a phone on the same Wi-Fi, open `http://PC-IP/login` and enter a voucher code.
3. The session appears in your app and in *IP → Hotspot → Active*. Uptime, bytes and the time left
   count down live. When the voucher's uptime or data limit runs out, the user is logged out with
   the same messages RouterOS uses.

You can also log a device in from the API (`/ip/hotspot/active/login user=… password=… ip=… mac-address=…`)
or click a device on the dashboard's network map.

## Connecting to TapTap (taptapnetwork.com)

TikLab joins TapTap the same way a real MikroTik does, through TapTap's own install scripts, so
nothing special is needed on the TapTap side:

1. In TapTap, add a router and choose **TapTap Link**. Copy the install block TapTap shows.
2. In TikLab open **TapTap & Tunnels** (or **New Terminal**), paste the block and run it.
3. The simulated router installs the `taptap-link` script and scheduler, and checks in with TapTap
   every few seconds over HTTPS. TapTap's page turns green; vouchers, sessions, inventory syncs,
   backups and the other Link commands run on the simulator like on a router.
4. **TapTap Tunnel** (RouterOS 7 models): when the tunnel is enabled in TapTap, the install block
   (or TapTap's "enable tunnel" block) creates the `taptap-wg` WireGuard interface and an API user.
   TikLab brings the WireGuard tunnel up for real, so TapTap's servers log in to the simulator's
   RouterOS API through it, from the internet, with no port forwarding on your network.

**TapTap & Tunnels** shows whether Link is checking in (and why not, when it fails), the tunnel's
handshake and traffic, TapTap's API logins through the tunnel, and the last HTTPS calls.

TapTap installed on your own network can also manage TikLab directly over the API (Router → IP
address of the PC, port 8728, user admin). Everything TapTap reads and changes over the API has
been checked against TapTap's own code: vouchers, profiles, active sessions, IP bindings,
interfaces, live traffic, WAN analysis and the full configuration snapshot.

## Wi-Fi on this PC

When the simulated router has Wi-Fi (hAP, cAP, wAP models), the PC's own Wi-Fi adapter can
broadcast the router's SSID, so real phones can join and log in to the simulated hotspot with
real vouchers. Open **Wi-Fi on this PC** (or the button on the dashboard) and switch it on.

- The PC broadcasts the SSID and password of the simulated radio (by default the one serving the
  hotspot, 2.4 GHz first). It follows the simulator: change the SSID, disable the radio or switch
  the router off, and the PC's Wi-Fi follows.
- Phones that join appear in the simulator as wireless clients with their **real MAC address**:
  in the registration table, DHCP leases, hotspot hosts and active sessions, so TapTap sees them.
- The window shows two QR codes: one to join the Wi-Fi, one to open the login page. Phones that
  check for a captive portal (Android, iPhone) are sent to the simulator's login page.
- Customers on this Wi-Fi never get the router console, only the login pages.

| | Windows 10/11 | Linux |
|---|---|---|
| How | Mobile Hotspot (needs a network connection to share) | NetworkManager (`nmcli`), adapter must support AP mode |
| Open (no password) SSID | not possible: Windows uses a password, shown in the window | yes |
| Phones held back until they log in | no: they get the login page, but can browse before logging in | yes, when TikLab runs as root (iptables) |
| Afterwards | Mobile Hotspot gets back its previous name and password | the TikLab-Hotspot connection is removed |

On Windows, if phones join but the login page does not open, Windows Firewall is blocking TikLab
on the hotspot network; the window shows the one command to allow it (run as administrator).

## Scripts and WireGuard

The terminal and `/system script` run full RouterOS scripting: variables (`:local`, `:global`),
`:if`, `:while`, `:for`, `:foreach`, `:do … on-error`, `:onerror`, functions (`:local f do={…}`),
arrays and `->`, `[:parse]`, `:execute`, `:return`, `:pick` `:find` `:len` `:typeof` and the
`:to…` conversions, `:convert`, `:serialize`/`:deserialize` (JSON), `:resolve`, `where` clauses,
`print as-value`, `get` without a property, and scheduler jobs with `:jobname`. Pasted blocks run
as one script, as in WinBox. `/tool fetch` makes real HTTP/HTTPS requests (certificates imported
with `/certificate import … trusted=yes` are trusted; the PC's own trust store is used too).

`/interface wireguard` is real WireGuard, in userspace (no driver or administrator rights). A
simulated router can join a WireGuard network (TapTap Tunnel, your own VPN server), and WireGuard
clients can connect to it: give the interface a `listen-port`, add the client as a peer, and the
simulator answers ping and its services (API, SSH, WebFig/console, Telnet) on its tunnel address.

## What is simulated

- **Router OS behaviour:** 115 RouterOS menus with the usual fields, defaults, validation and
  error messages. This includes interfaces, ethernet, bridge, VLAN, wireless, IP addresses, routes,
  DHCP server/client/leases, DNS, pools, firewall filter/NAT/mangle/raw/address lists, IP services,
  neighbors, hotspot (servers, profiles, users, user profiles, active, hosts, IP bindings, walled
  garden, cookies), PPP secrets/profiles/active and the PPPoE server, simple queues and queue trees,
  RADIUS, users and groups, scheduler, scripts, files, log, certificates, SNMP, netwatch and more.
- **Protocols:**
  - RouterOS API: plain login and the legacy challenge login, `.tag`, `.proplist`, query words
    (`?name=x`, `?>`, `?<`, `?#|&!`), `count-only`, `listen`, `/cancel`, streaming
    `monitor-traffic` and `ping`.
  - REST API.
  - SSH and Telnet CLI: path navigation, `print`/`detail`/`where`, `[find …]`, Tab completion, `?`
    help, `:put`/`:log`/`:local`, export, `/system reboot`.
  - MNDP neighbor discovery.
- **Live behaviour:**
  - Traffic counters, CPU load, memory, temperature and voltage.
  - DHCP leases, ARP, hotspot hosts, sessions that count down, and the rate limits from user profiles.
  - Dynamic queues for hotspot and PPPoE users.
  - PPPoE customers that dial in with your secrets.
  - Firewall counters, connection tracking and log messages.
  - Interfaces go down when you unplug a cable.
  - Reboot drops all sessions and clears dynamic entries, like a real router.
- **Captive portal:** pages are served from `/file hotspot/*.html` with MikroTik's template variables
  (`$(if error)`, `$(link-login-only)`, `$(chap-id)` …) and both CHAP and PAP login. Edit or replace
  them in *Files* to test your own login page design.
- **24 router models**, each with its own ports, wireless, CPU, memory and front panel (see below).

## Router models

| Family | Models (key) |
|---|---|
| Home & office | `hap-lite`, `hap-ac-lite`, `hap-ac2`, `hap-ac3`, `hap-ax2`, `hap-ax3` (Wi-Fi 6), `hex-lite`, `hex`, `hex-s`, `rb951` |
| Routers | `rb2011`, `rb3011`, `rb4011` (default), `rb5009`, `l009` |
| Cloud Core | `ccr1009`, `ccr1036`, `ccr2004`, `ccr2116` |
| Switches | `crs326`, `crs328` |
| Access points | `cap-ac`, `wap-ac` |
| Virtual | `chr` |

Each model reports its real board name, CPU, core count and memory to apps (`/system resource`,
`/system routerboard`). Each one has the right ports: 10/100 or Gigabit, 2.5G, SFP, SFP+ and combo,
plus PoE in/out markers. Wireless models get `wlan1`/`wlan2` (wireless package), and the Wi-Fi 6
hAP ax models get `wifi1`/`wifi2` (wifi package). Run `tiklab -list-models` for the full list with port counts.

**Switching models** reboots the router with the new hardware and its default configuration. By
default your vouchers, hotspot and PPP users, profiles, admin users, scripts and files are kept, so
your app's data survives the switch. You can switch in any of these ways:
- **Console:** choose *Router Model* in the menu (or *Change model* on the dashboard). Pick a card and press *Switch router model*.
- **Command line / API:** `/sim change-model model=hap-ax2` (add `keep-users=no` for a clean reset), or `/sim/change-model` over the API.
- **On start:** `tiklab -model hap-ac2`. This applies on a fresh configuration or when it differs from the saved model.

## Moving configurations between TikLab and real routers

Open **Config Transfer** in the console menu (also under *System → Export / Import*).

### Build in TikLab, then run it on a real MikroTik
1. *Export to a real router* tab: tick the parts you want (interfaces, hotspot, vouchers, PPP, firewall …),
   choose the **target router model**, and choose the script type:
   - **Add to a router that is already set up.** Upload the file and run `/import file-name=NAME.rsc verbose=yes`.
   - **Full configuration for a freshly reset router.** Upload the file and run
     `/system reset-configuration no-defaults=yes skip-backup=yes run-after-reset=NAME.rsc`.
     The script waits for the interfaces and contains these instructions at the top.
2. Press **Download .rsc**, then drag the file into WinBox → Files (or use FTP), or use *Send to a real router*.

Notes:
- If the target model has fewer ports than the simulator, entries for the missing ports are left out and listed for you.
  Wi-Fi interfaces are translated between `wlanN` and `wifiN`.
- Voucher, PPP and Wi-Fi passwords are included when *Include passwords and keys* is ticked.
  Router login passwords (`/user`) are never exported.
- IP service ports are not exported by default, because the simulator may use fallback ports such as 8080.
- The output is standard RouterOS script: alphabetical parameters, `\` line breaks, `\$` and `\XX` escapes for non-English text.
  The command line can do the same: `/export file=name show-sensitive`.

### Bring a real router's configuration into TikLab
1. On the real router run `/export show-sensitive file=myrouter` and download `myrouter.rsc` from WinBox → Files.
2. In the *Import a configuration* tab, drop the file. TikLab then:
   - reads the `# model =` line and offers to **switch the simulator to the same model** (recommended);
   - lists interfaces the simulator lacks, so you can map them or skip the lines that use them;
   - lets you **Replace** the configuration (like a no-defaults reset with run-after-reset) or **Merge** it.
3. You get a line-by-line report (ok, warnings, errors, skipped). Menus the simulator doesn't have
   (OSPF, BGP, IPsec, CAPsMAN, containers …) are skipped and listed. Unknown parameters are dropped with a warning.
   The simulator keeps its own service ports and never disables its console.

RouterOS `.backup` files are encrypted binaries and can't be read. Use the `.rsc` export instead.
The command line can also import: `/import file-name=myrouter.rsc verbose=yes`.

### Clone or send directly (Real router tab)
- **Clone into the simulator** reads a real router without changing anything on it, over its API (port 8728),
  or over SSH (port 22) when the API is off or blocked. Vouchers and PPP secrets come with their passwords. The
  hotspot login pages are copied over FTP (port 21), or with SCP over SSH. You then review and import the result
  as above.
- **Send to the real router** uploads the exported script and, optionally, a hotspot page folder into the router's
  Files over FTP, or SCP when only SSH is open. Running `/import` on the router afterwards is optional, off by
  default, and asks for confirmation.
- **Connect using** chooses Automatic (API, then SSH), API only or SSH only.

### When TikLab cannot reach the router
If a connection fails, TikLab checks the router's ports (API, API-SSL, SSH, FTP, WinBox, WebFig, Telnet), looks
the address up in this PC's ARP table and in MikroTik discovery, and explains what is in the way, with RouterOS
commands you can copy into a WinBox terminal. **Check ports** runs the same check without logging in.

The usual causes:

| What you see | What it means |
|---|---|
| *no reply* / `i/o timeout` on every port | The router's firewall drops the traffic. The default MikroTik firewall only allows management from the LAN ports, so this happens when the PC is on the network of the router's ether1 (for example, ether1 gets 192.168.1.x from the main router and so does the PC). Plug the PC into a LAN port and use 192.168.88.1, or let the PC through (below). |
| *no reply* on the API port only | A firewall rule allows only some ports, or the API service is limited to certain addresses (IP > Services > api > Available From). TikLab switches to SSH automatically if SSH answers. |
| *refused* on the API port | The API service is off or on another port: `/ip service enable api`. |
| *invalid user name or password* | The router answered and rejected the login. Names and passwords are case-sensitive; check the user's Allowed Address. |

Your user name and password are only checked after the connection is made, so a timeout says nothing about them.

To let one PC through the firewall (replace the address with your PC's; TikLab fills it in for you):

```
/ip firewall filter add chain=input action=accept protocol=tcp src-address=192.168.1.50 dst-port=8728,8729,21,22 comment="TikLab access" place-before=[:pick [find chain=input dynamic=no] 0]
```

Remove it when you are done: `/ip firewall filter remove [find comment="TikLab access"]`

## Files and hotspot login pages

- **Files**: upload files, whole folders or `.zip` archives (drag them onto the window), create folders, edit text
  files, and download any file or a whole folder as `.zip`. The **FTP server** gives FileZilla, WinSCP and
  `/tool fetch` the same access a real router gives.
- **Hotspot Pages (Page Studio)**: install a login page design from a folder or `.zip`, then:
  - see it in **four phone previews** (login, wrong voucher, logged in, logged out);
  - run a **pre-flight check** that catches missing files, broken `$(if)` blocks, jQuery `$()` code that MikroTik
    would mangle, forms that don't post to `$(link-login-only)`, PAP/CHAP mismatches, and external hosts that need
    the walled garden (one click adds them). It also warns when the pages won't fit the flash of the selected model;
  - **make it active** and test it live from a phone at `http://PC-IP/login`;
  - download it as `.zip` or send it straight to a real router.
- Pages are served exactly as a real router serves them: from the hotspot `html-directory`, with relative links
  (`img/logo.png`, `css/style.css`) and MikroTik variables.

## The console (WinBox-style)

- **Dashboard:** a live front panel of the router. Link LEDs follow the port state and activity LEDs
  blink with real traffic. **Click a port to plug or unplug its cable.** It also shows the network
  map with animated traffic, gauges, WAN graph and top clients.
- **Menus:** the same layout as WinBox. Double-click a row to edit it, and use + / − / ✓ / ✗ for
  add, remove, enable and disable. Lists refresh live.
- **New Terminal:** the RouterOS command line.
- **Config Transfer, Hotspot Pages, Files:** see *Moving configurations* above.
- **Router Model:** a gallery of all models with front-panel previews. Switch hardware in one click.
- **Simulator:**
  - Reboot, shut down or reset the router.
  - Turn the internet (WAN) off and on.
  - Set the traffic level.
  - Let simulated customers arrive and use unused vouchers automatically.
  - Add virtual devices (phones, laptops, PPPoE CPEs) and log them in.
  - Generate voucher batches.
- **Network Lab:** build a network of several routers and devices and switch the console between
  routers. See *Network Lab* above.
- **Connect to other routers:** the login window lists neighbors found on the network, including
  real MikroTik routers and other TikLab instances. TikLab's console can manage a real MikroTik
  router through its API (port 8728), in the same way that it manages the simulator.

### About the real WinBox

The simulator announces itself with MNDP, so it **shows up in real WinBox's Neighbors list** (MAC,
IP, identity, version, board). Real WinBox cannot log into it, because WinBox needs MikroTik's own
encrypted protocol and the GUI files that ship inside RouterOS. Use TikLab's built-in console
instead: open `http://PC-IP:8291/` in any browser.

If you need the genuine RouterOS (for example to practise with the real WinBox), MikroTik offers a
free *Cloud Hosted Router* (CHR) image that runs in VirtualBox, VMware or QEMU.

## Network Lab: build a whole network

Open **Network Lab** in the console menu. It is a workbench where you build a network out of
several MikroTik routers, switches, the internet and end devices, and wire them up with cables.

**Building**
- **Add things:** drag a router, a switch, the Internet or a device (PC, laptop, phone, tablet,
  smart TV, printer, camera, smart plug, server) from the left onto the canvas. Pick the router
  model in the list under the router tile. You can also select a tile and press Enter.
- **Run a cable:** drag from a port to another port. Ports that can take the cable light up, and
  the cable snaps to the nearest one. Drop it on a device instead, and it uses the first free
  port: ether1 for a router's uplink, a LAN port otherwise.
- **Wi-Fi:** phones, tablets and laptops join a router over the air. Drag from their Wi-Fi symbol
  to one of the router's antennas.
- **Move or pull a cable:** drag a plug out of its port. Drop it on another port to move it, or on
  empty canvas to unplug it. Select a cable to change its colour.
- **Arrange:** drag devices around, scroll to zoom, drag the background to pan, **F** fits the
  network in view, **Delete** removes the selection. **Sample networks** builds a home, an
  office, two hotspot towers or a chain of routers around your main router.

**Configuring several routers.** Every router on the canvas is a complete simulated router with its
own configuration, files, users and services. **Double-click a router** (or choose *Configure in
this console*) and the whole console switches to it: menus, Dashboard, Terminal, everything. The
router chip at the top left shows which router you are configuring and switches between them.
Each router keeps its own windows: switch away and back, and its terminal is still there.

**The cables are real for the simulation**
- A port is up only when its cable leads to something that is switched on.
- A router plugged into another router gets its WAN address from that router's DHCP server, and
  shows up in that router's leases and in both routers' `/ip neighbor`.
- A router plugged into the Internet gets an address from your PC's network, like a modem.
- PCs and phones become clients of the router serving their network: they get a lease, appear in
  the Wi-Fi registration table and wait at the hotspot login page if there is a hotspot. Select a
  device to log it in with a voucher, change what it does (browsing, streaming…) or switch it off.
- Internet access follows the path. Pull the uplink, power off the upstream router, or put a router
  behind a hotspot it has not logged into, and everything behind it goes offline, including
  `/tool fetch` and its TapTap Link.
- The coloured dots on the cables are the real simulated traffic: amber flows toward the devices,
  blue toward the internet. Port LEDs blink with it, and a WireGuard tunnel to TapTap shows as a
  violet arc to the internet.
- New routers get their own LAN (192.168.89.0/24, 192.168.90.0/24, …) so they don't clash with the
  router in front of them. Untick *Give it its own LAN subnet* to keep the factory 192.168.88.1.

**Reaching lab routers from other tools.** Each lab router has its own block of ports on this PC
(router *N* adds 10×N: API 8728+10N, Web 8080+10N, SSH 2222+10N, …). The inspector on the right
lists them. Point the TapTap app or any RouterOS tool at them to manage a whole fleet. Lab routers
also announce themselves with MNDP, so they show up in WinBox's neighbours.

The lab is saved in `tiklab-data/lab.json`, and each router's configuration in
`tiklab-data/lab/<id>/`. Removing a router from the canvas deletes its folder.

### Separate instances

You can still run independent copies of TikLab side by side:

```
tiklab -instance 1 -model hap-ac2 -no-browser
tiklab -instance 2 -model hex-s -no-browser
```

Each instance gets its own data folder (`tiklab-data-1`, …), identity, MAC addresses and ports
(instance *N* adds 10×N: API 8738, GUI 8301, …). They find each other in the console's Neighbors
list but are not wired together. Lab routers use the same port blocks, so don't mix the two on one
PC (the lab skips the block of the instance it runs in).

## Command-line options

```
-model KEY              router model (see -list-models), e.g. hap-ac2, hap-ax2, hex-s, rb5009, ccr1036
-list-models            print all models and exit
-password SECRET        admin password for a fresh configuration (default empty)
-identity NAME          identity for a fresh configuration
-instance N             run several routers side by side
-reset                  factory-reset the configuration on start
-no-browser             don't open the console window
-bind IP                listen on one address only (default all)
-api-port, -api-ssl-port, -www-port, -www-ssl-port, -winbox-port, -ssh-port, -telnet-port
-ros-version "7.18.2 (stable)"   version string reported to apps
-no-discovery           disable MNDP
-verbose                print the router log in the console window
```

Reset everything: run with `-reset`, use *System → Reset Configuration*, or delete the `tiklab-data` folder.

## Limitations

- No real packet forwarding. Clients and traffic are simulated and nothing is routed through the
  simulator (WireGuard tunnels reach the simulator itself, not networks behind it).
- In the Network Lab, cables carry DHCP, neighbour discovery, hotspot logins and internet
  reachability. VLANs, PPPoE between lab routers, routing protocols and firewall rules between
  routers are not simulated, and ping between lab routers does not cross the cables.
- One PC has one Wi-Fi hotspot: only one router at a time can broadcast its SSID from this PC.
- Inside WireGuard tunnels: IPv4 only, and FTP's data connections do not pass (use SCP or the API).
- Wi-Fi on this PC was tested with a stand-in network on Linux; the Windows Mobile Hotspot part and
  real adapters still need trying on your PCs. macOS is not supported for it.
- Routing protocols (OSPF/BGP), IPsec, CAPsMAN, containers and the WinBox binary protocol are not
  emulated. Their lines are skipped (and listed) when you import a real router's configuration.
- `.backup` files from real routers can't be read (they are encrypted). Use `.rsc` exports.

## Licences

TikLab is made of original code. It bundles `golang.org/x/crypto` (BSD-3-Clause), xterm.js (MIT,
see `web/xterm-LICENSE.txt` inside the program) and IBM Plex fonts (SIL Open Font License 1.1).
MikroTik, RouterOS and WinBox are trademarks of MikroTik. They are mentioned only to describe
compatibility.

## Building from source (developers)

Requires Go 1.24 or newer. All dependencies are vendored, so no internet is needed:

```
go build -o tiklab .                                        # this computer
GOOS=windows GOARCH=amd64 go build -ldflags "-s -w" -o tiklab.exe .
GOOS=linux   GOARCH=amd64 go build -ldflags "-s -w" -o tiklab .
GOOS=linux   GOARCH=arm64 go build -ldflags "-s -w" -o tiklab .   # Raspberry Pi 4/5
```

Code map:
- `schema.go`: every RouterOS menu and field.
- `engine.go`: tables, validation and commands shared by all protocols.
- `sim.go`: traffic, clients, hotspot/PPPoE sessions and reboot.
- `api.go`: RouterOS API server and client.
- `web.go`: REST, console backend and captive portal.
- `transfer.go`: export, import and script analysis.
- `realrouter.go`: working with real routers (test, clone, send) over the API or SSH, SCP client.
- `diagnose.go`: connection diagnosis (port checks, ARP, discovery) and the fixes it suggests.
- `ros_parse.go`, `ros_interp.go`, `ros_builtins.go`, `ros_value.go`: the RouterOS script language.
- `ros_net.go`: `/tool fetch`, `/certificate import`, `/file read`.
- `wireguard.go`, `netstack.go`: userspace WireGuard and the small TCP/IP stack inside tunnels.
- `hostwifi.go`, `qrcode.go`: Wi-Fi on this PC (Windows Mobile Hotspot, NetworkManager), QR codes.
- `scp.go`: SCP server on the simulator's SSH port.
- `files.go`: files, uploads, page previews and the page checker.
- `ftp.go`: FTP server and client.
- `cli.go`, `term.go`: CLI, SSH and Telnet.
- `mndp.go`: neighbor discovery.
- `lab.go`, `web/lab.js`: the Network Lab (lab routers, cables, DHCP between routers, the canvas).
- `web/`: the console UI.
- `hotspot/`: default login pages.

To support a new menu, add one `M(...)` line in `schema.go`. The API, REST, CLI and console pick it up automatically.
