@echo off
rem Starts three simulated routers for a training lab.
cd /d "%~dp0"
start "TikLab - Router 1 (RB4011)" tiklab.exe
timeout /t 2 /nobreak >nul
start "TikLab - Router 2 (hAP ac2)" tiklab.exe -instance 1 -model hap-ac2 -no-browser
start "TikLab - Router 3 (hEX S)" tiklab.exe -instance 2 -model hex-s -no-browser
echo Three routers are starting. Router 2 console: http://127.0.0.1:8301  Router 3 console: http://127.0.0.1:8311
pause
