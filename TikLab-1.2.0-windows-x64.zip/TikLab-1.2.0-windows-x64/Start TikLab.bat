@echo off
title TikLab router simulator
cd /d "%~dp0"
tiklab.exe %*
if errorlevel 1 pause
