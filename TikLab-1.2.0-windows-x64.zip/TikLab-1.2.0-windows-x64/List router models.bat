@echo off
cd /d "%~dp0"
tiklab.exe -list-models
pause
