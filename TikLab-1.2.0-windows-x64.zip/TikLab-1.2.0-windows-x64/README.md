# TikLab 1.2 — RouterOS-compatible router simulator

TikLab is a portable program that behaves like a MikroTik router on your network. Use it for
training, and for testing apps such as TapTap that manage MikroTik routers through the
RouterOS API or REST API, without touching a real customer router.

It is one file with no installation and runs on Windows and Linux. Everything (configuration,
keys, certificates) is saved in a `tiklab-data` folder next to the program.

> TikLab is an independent simulator. It is not made by or affiliated with MikroTik, and it does
> not contain RouterOS. It re-implements RouterOS's behaviour and protocols so that apps and
> people can talk to it as if it were a router.

---

## Quick start

**Windows:** unzip, then double-click **`Start TikLab.bat`** (or `tiklab.exe`).
- If Windows SmartScreen warns about an unknown app, choose *More info → Run anyway*.
- When the Windows Firewall asks, allow access on **Private networks** so phones and other PCs
  (and the TapTap app) can reach the simulator.

**Linux:** unpack, then run `./start-tiklab.sh` (or `./tiklab`).
- Ports below 1024 (80, 443, 22, 23) need root. Without root TikLab moves those services to
  8080, 8443, 2222 and 2323 automatically. To keep the standard ports without running as root:
  `sudo setcap 'cap_net_bind_service=+ep' ./tiklab`

A WinBox-style console opens in your browser automatically. Log in as **admin** with an **empty
password**, which is how a brand-new router ships. The console window shows every address and port.

## Connecting the TapTap app (or any MikroTik tool)

Use the IP address of the PC running TikLab (shown in the console window), user `admin`, and the
router password.

| Service | Default port | Notes |
|---|---|---|
| RouterOS API | **8728** | What most MikroTik apps use (hotspot vouchers, PPPoE, monitoring) |
| RouterOS API-SSL | 8729 | TLS with a self-signed certificate |
| REST API | 80 → `http://PC-IP/rest/...` | RouterOS v7 REST (GET/PUT/PATCH/DELETE/POST) |
| REST API over HTTPS | 443 | self-signed certificate |
| WinBox-style console | 8291 → `http://PC-IP:8291/` | TikLab's own WinBox, in any browser |
| Hotspot login page | 80 → `http://PC-IP/login` | captive portal for testing vouchers from a phone |
| SSH | 22 | RouterOS CLI, including `ssh admin@PC-IP "/ip hotspot user print"` |
| Telnet | 23 | RouterOS CLI |
| FTP | 21 | files and hotspot pages (FileZilla, WinSCP, Windows `ftp`), like a real router |

Ports below 1024 move to 8080/8443/2222/2323/2121 when TikLab runs without admin rights on Linux.
Ports can be changed like on a real router (`/ip service set api port=8730`) or with command-line
options. If a port is busy, TikLab picks the next free one and shows it in the console window.

### End-to-end voucher test

1. Create vouchers from your app (or *Simulator → Vouchers → Generate*).
2. On a phone on the same Wi-Fi, open `http://PC-IP/login` and enter a voucher code.
3. The session appears in your app and in *IP → Hotspot → Active*. Uptime, bytes and the time left
   count down live. When the voucher's uptime or data limit runs out, the user is logged out with
   the same messages RouterOS uses.

You can also log a device in from the API (`/ip/hotspot/active/login user=… password=… ip=… mac-address=…`)
or click a device on the dashboard's network map.

## What is simulated

- **Router OS behaviour:** 115 RouterOS menus with the usual fields, defaults, validation and
  error messages. This includes interfaces, ethernet, bridge, VLAN, wireless, IP addresses, routes,
  DHCP server/client/leases, DNS, pools, firewall filter/NAT/mangle/raw/address lists, IP services,
  neighbors, hotspot (servers, profiles, users, user profiles, active, hosts, IP bindings, walled
  garden, cookies), PPP secrets/profiles/active and the PPPoE server, simple queues and queue trees,
  RADIUS, users and groups, scheduler, scripts, files, log, certificates, SNMP, netwatch and more.
- **Protocols:**
  - RouterOS API: plain login and the legacy challenge login, `.tag`, `.proplist`, query words
    (`?name=x`, `?>`, `?<`, `?#|&!`), `count-only`, `listen`, `/cancel`, streaming
    `monitor-traffic` and `ping`.
  - REST API.
  - SSH and Telnet CLI: path navigation, `print`/`detail`/`where`, `[find …]`, Tab completion, `?`
    help, `:put`/`:log`/`:local`, export, `/system reboot`.
  - MNDP neighbor discovery.
- **Live behaviour:**
  - Traffic counters, CPU load, memory, temperature and voltage.
  - DHCP leases, ARP, hotspot hosts, sessions that count down, and the rate limits from user profiles.
  - Dynamic queues for hotspot and PPPoE users.
  - PPPoE customers that dial in with your secrets.
  - Firewall counters, connection tracking and log messages.
  - Interfaces go down when you unplug a cable.
  - Reboot drops all sessions and clears dynamic entries, like a real router.
- **Captive portal:** pages are served from `/file hotspot/*.html` with MikroTik's template variables
  (`$(if error)`, `$(link-login-only)`, `$(chap-id)` …) and both CHAP and PAP login. Edit or replace
  them in *Files* to test your own login page design.
- **24 router models**, each with its own ports, wireless, CPU, memory and front panel (see below).

## Router models

| Family | Models (key) |
|---|---|
| Home & office | `hap-lite`, `hap-ac-lite`, `hap-ac2`, `hap-ac3`, `hap-ax2`, `hap-ax3` (Wi-Fi 6), `hex-lite`, `hex`, `hex-s`, `rb951` |
| Routers | `rb2011`, `rb3011`, `rb4011` (default), `rb5009`, `l009` |
| Cloud Core | `ccr1009`, `ccr1036`, `ccr2004`, `ccr2116` |
| Switches | `crs326`, `crs328` |
| Access points | `cap-ac`, `wap-ac` |
| Virtual | `chr` |

Each model reports its real board name, CPU, core count and memory to apps (`/system resource`,
`/system routerboard`). Each one has the right ports: 10/100 or Gigabit, 2.5G, SFP, SFP+ and combo,
plus PoE in/out markers. Wireless models get `wlan1`/`wlan2` (wireless package), and the Wi-Fi 6
hAP ax models get `wifi1`/`wifi2` (wifi package). Run `tiklab -list-models` for the full list with port counts.

**Switching models** reboots the router with the new hardware and its default configuration. By
default your vouchers, hotspot and PPP users, profiles, admin users, scripts and files are kept, so
your app's data survives the switch. You can switch in any of these ways:
- **Console:** choose *Router Model* in the menu (or *Change model* on the dashboard). Pick a card and press *Switch router model*.
- **Command line / API:** `/sim change-model model=hap-ax2` (add `keep-users=no` for a clean reset), or `/sim/change-model` over the API.
- **On start:** `tiklab -model hap-ac2`. This applies on a fresh configuration or when it differs from the saved model.

## Moving configurations between TikLab and real routers

Open **Config Transfer** in the console menu (also under *System → Export / Import*).

### Build in TikLab, then run it on a real MikroTik
1. *Export to a real router* tab: tick the parts you want (interfaces, hotspot, vouchers, PPP, firewall …),
   choose the **target router model**, and choose the script type:
   - **Add to a router that is already set up.** Upload the file and run `/import file-name=NAME.rsc verbose=yes`.
   - **Full configuration for a freshly reset router.** Upload the file and run
     `/system reset-configuration no-defaults=yes skip-backup=yes run-after-reset=NAME.rsc`.
     The script waits for the interfaces and contains these instructions at the top.
2. Press **Download .rsc**, then drag the file into WinBox → Files (or use FTP), or use *Send to a real router*.

Notes:
- If the target model has fewer ports than the simulator, entries for the missing ports are left out and listed for you.
  Wi-Fi interfaces are translated between `wlanN` and `wifiN`.
- Voucher, PPP and Wi-Fi passwords are included when *Include passwords and keys* is ticked.
  Router login passwords (`/user`) are never exported.
- IP service ports are not exported by default, because the simulator may use fallback ports such as 8080.
- The output is standard RouterOS script: alphabetical parameters, `\` line breaks, `\$` and `\XX` escapes for non-English text.
  The command line can do the same: `/export file=name show-sensitive`.

### Bring a real router's configuration into TikLab
1. On the real router run `/export show-sensitive file=myrouter` and download `myrouter.rsc` from WinBox → Files.
2. In the *Import a configuration* tab, drop the file. TikLab then:
   - reads the `# model =` line and offers to **switch the simulator to the same model** (recommended);
   - lists interfaces the simulator lacks, so you can map them or skip the lines that use them;
   - lets you **Replace** the configuration (like a no-defaults reset with run-after-reset) or **Merge** it.
3. You get a line-by-line report (ok, warnings, errors, skipped). Menus the simulator doesn't have
   (OSPF, BGP, IPsec, CAPsMAN, containers …) are skipped and listed. Unknown parameters are dropped with a warning.
   The simulator keeps its own service ports and never disables its console.

RouterOS `.backup` files are encrypted binaries and can't be read. Use the `.rsc` export instead.
The command line can also import: `/import file-name=myrouter.rsc verbose=yes`.

### Clone or send directly (Real router tab)
- **Clone into the simulator** reads a real router over its API (port 8728) without changing anything on it.
  Vouchers and PPP secrets come with their passwords. If FTP (port 21) is enabled, the hotspot login pages are
  copied too. You then review and import the result as above.
- **Send to the real router** uploads the exported script and, optionally, a hotspot page folder into the router's
  Files via FTP. Running `/import` on the router afterwards is optional, off by default, and asks for confirmation.

## Files and hotspot login pages

- **Files**: upload files, whole folders or `.zip` archives (drag them onto the window), create folders, edit text
  files, and download any file or a whole folder as `.zip`. The **FTP server** gives FileZilla, WinSCP and
  `/tool fetch` the same access a real router gives.
- **Hotspot Pages (Page Studio)**: install a login page design from a folder or `.zip`, then:
  - see it in **four phone previews** (login, wrong voucher, logged in, logged out);
  - run a **pre-flight check** that catches missing files, broken `$(if)` blocks, jQuery `$()` code that MikroTik
    would mangle, forms that don't post to `$(link-login-only)`, PAP/CHAP mismatches, and external hosts that need
    the walled garden (one click adds them). It also warns when the pages won't fit the flash of the selected model;
  - **make it active** and test it live from a phone at `http://PC-IP/login`;
  - download it as `.zip` or send it straight to a real router.
- Pages are served exactly as a real router serves them: from the hotspot `html-directory`, with relative links
  (`img/logo.png`, `css/style.css`) and MikroTik variables.

## The console (WinBox-style)

- **Dashboard:** a live front panel of the router. Link LEDs follow the port state and activity LEDs
  blink with real traffic. **Click a port to plug or unplug its cable.** It also shows the network
  map with animated traffic, gauges, WAN graph and top clients.
- **Menus:** the same layout as WinBox. Double-click a row to edit it, and use + / − / ✓ / ✗ for
  add, remove, enable and disable. Lists refresh live.
- **New Terminal:** the RouterOS command line.
- **Config Transfer, Hotspot Pages, Files:** see *Moving configurations* above.
- **Router Model:** a gallery of all models with front-panel previews. Switch hardware in one click.
- **Simulator:**
  - Reboot, shut down or reset the router.
  - Turn the internet (WAN) off and on.
  - Set the traffic level.
  - Let simulated customers arrive and use unused vouchers automatically.
  - Add virtual devices (phones, laptops, PPPoE CPEs) and log them in.
  - Generate voucher batches.
- **Connect to other routers:** the login window lists neighbors found on the network, including
  real MikroTik routers and other TikLab instances. TikLab's console can manage a real MikroTik
  router through its API (port 8728), in the same way that it manages the simulator.

### About the real WinBox

The simulator announces itself with MNDP, so it **shows up in real WinBox's Neighbors list** (MAC,
IP, identity, version, board). Real WinBox cannot log into it, because WinBox needs MikroTik's own
encrypted protocol and the GUI files that ship inside RouterOS. Use TikLab's built-in console
instead: open `http://PC-IP:8291/` in any browser.

If you need the genuine RouterOS (for example to practise with the real WinBox), MikroTik offers a
free *Cloud Hosted Router* (CHR) image that runs in VirtualBox, VMware or QEMU.

## Training labs: several routers on one PC

```
tiklab -instance 1 -model hap-ac2 -no-browser
tiklab -instance 2 -model hex-s -no-browser
```

Each instance gets its own data folder (`tiklab-data-1`, …), identity, MAC addresses and ports
(instance *N* adds 10×N: API 8738, GUI 8301, …). On Windows, `Start 3-router lab.bat` starts three
routers at once. They find each other in the console's Neighbors list.

## Command-line options

```
-model KEY              router model (see -list-models), e.g. hap-ac2, hap-ax2, hex-s, rb5009, ccr1036
-list-models            print all models and exit
-password SECRET        admin password for a fresh configuration (default empty)
-identity NAME          identity for a fresh configuration
-instance N             run several routers side by side
-reset                  factory-reset the configuration on start
-no-browser             don't open the console window
-bind IP                listen on one address only (default all)
-api-port, -api-ssl-port, -www-port, -www-ssl-port, -winbox-port, -ssh-port, -telnet-port
-ros-version "7.18.2 (stable)"   version string reported to apps
-no-discovery           disable MNDP
-verbose                print the router log in the console window
```

Reset everything: run with `-reset`, use *System → Reset Configuration*, or delete the `tiklab-data` folder.

## Limitations

- No real packet forwarding. Clients and traffic are simulated and nothing is routed through the PC.
- The script engine supports simple commands, `:put`, `:log`, `:local`/`:global` and `:delay`.
  Complex scripts (`:foreach`, `:if` …) are logged as unsupported.
- Routing protocols (OSPF/BGP), IPsec, CAPsMAN, containers and the WinBox binary protocol are not
  emulated. Their lines are skipped (and listed) when you import a real router's configuration.
- `.backup` files from real routers can't be read (they are encrypted). Use `.rsc` exports.

## Licences

TikLab is made of original code. It bundles `golang.org/x/crypto` (BSD-3-Clause), xterm.js (MIT,
see `web/xterm-LICENSE.txt` inside the program) and IBM Plex fonts (SIL Open Font License 1.1).
MikroTik, RouterOS and WinBox are trademarks of MikroTik. They are mentioned only to describe
compatibility.

## Building from source (developers)

Requires Go 1.24 or newer. All dependencies are vendored, so no internet is needed:

```
go build -o tiklab .                                        # this computer
GOOS=windows GOARCH=amd64 go build -ldflags "-s -w" -o tiklab.exe .
GOOS=linux   GOARCH=amd64 go build -ldflags "-s -w" -o tiklab .
GOOS=linux   GOARCH=arm64 go build -ldflags "-s -w" -o tiklab .   # Raspberry Pi 4/5
```

Code map:
- `schema.go`: every RouterOS menu and field.
- `engine.go`: tables, validation and commands shared by all protocols.
- `sim.go`: traffic, clients, hotspot/PPPoE sessions and reboot.
- `api.go`: RouterOS API server and client.
- `web.go`: REST, console backend and captive portal.
- `transfer.go`: export, import and real-router clone/send.
- `files.go`: files, uploads, page previews and the page checker.
- `ftp.go`: FTP server and client.
- `cli.go`, `term.go`: CLI, SSH and Telnet.
- `mndp.go`: neighbor discovery.
- `web/`: the console UI.
- `hotspot/`: default login pages.

To support a new menu, add one `M(...)` line in `schema.go`. The API, REST, CLI and console pick it up automatically.
