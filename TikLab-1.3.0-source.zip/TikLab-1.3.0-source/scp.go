package main

// SCP over the simulator's SSH server, as on RouterOS:
//   scp file.rsc admin@router:/        upload
//   scp -r hotspot2 admin@router:/     upload a folder
//   scp admin@router:/file.rsc .       download

import (
	"bufio"
	"fmt"
	"io"
	"path"
	"sort"
	"strconv"
	"strings"

	"golang.org/x/crypto/ssh"
)

func scpServe(r *Router, user, peer string, ch ssh.Channel, cmd string) int {
	sink, source := false, false
	target := ""
	for _, a := range strings.Fields(cmd)[1:] {
		if strings.HasPrefix(a, "-") {
			sink = sink || strings.Contains(a, "t")
			source = source || strings.Contains(a, "f")
			continue
		}
		target = a
	}
	target = cleanPath(target)
	rd := bufio.NewReader(ch)
	if sink {
		return scpSink(r, user, peer, ch, rd, target)
	}
	if source {
		return scpSource(r, ch, rd, target)
	}
	fmt.Fprint(ch.Stderr(), "scp: use -t or -f\n")
	return 1
}

func scpErr(ch ssh.Channel, msg string) int {
	ch.Write([]byte("\x02scp: " + msg + "\n"))
	return 1
}

func scpSink(r *Router, user, peer string, ch ssh.Channel, rd *bufio.Reader, target string) int {
	r.mu.Lock()
	t := r.byName("/file", target)
	isDir := target == "" || (t != nil && t["type"] == "directory")
	r.mu.Unlock()
	base := target
	rename := ""
	if !isDir {
		base, rename = path.Dir(target), path.Base(target)
		if base == "." {
			base = ""
		}
	}
	stack := []string{base}
	ch.Write([]byte{0})
	n := 0
	for {
		line, err := rd.ReadString('\n')
		if err != nil {
			break
		}
		line = strings.TrimRight(line, "\n")
		if line == "" {
			continue
		}
		cur := stack[len(stack)-1]
		join := func(name string) string {
			if rename != "" && len(stack) == 1 {
				name, rename = rename, ""
			}
			return cleanPath(cur + "/" + path.Base(cleanPath(name)))
		}
		switch line[0] {
		case 'T':
			ch.Write([]byte{0})
		case 'D':
			f := strings.SplitN(line, " ", 3)
			if len(f) < 3 {
				return scpErr(ch, "bad directory record")
			}
			p := join(f[2])
			r.mu.Lock()
			r.ensureDir(p)
			r.mu.Unlock()
			stack = append(stack, p)
			ch.Write([]byte{0})
		case 'E':
			if len(stack) > 1 {
				stack = stack[:len(stack)-1]
			}
			ch.Write([]byte{0})
		case 'C':
			f := strings.SplitN(line, " ", 3)
			if len(f) < 3 {
				return scpErr(ch, "bad file record")
			}
			size, err := strconv.Atoi(f[1])
			if err != nil || size < 0 || size > maxUpload {
				return scpErr(ch, "file too large")
			}
			ch.Write([]byte{0})
			data := make([]byte, size)
			if _, err := io.ReadFull(rd, data); err != nil {
				return 1
			}
			rd.ReadByte() // trailing \0
			p := join(f[2])
			r.mu.Lock()
			r.putFile(p, data)
			r.log("system,info", "file %s uploaded by %s via scp from %s", p, user, peer)
			r.mu.Unlock()
			n++
			ch.Write([]byte{0})
		case 1, 2:
			return 1
		default:
			return scpErr(ch, "unexpected record")
		}
	}
	return 0
}

func scpSource(r *Router, ch ssh.Channel, rd *bufio.Reader, target string) int {
	wait := func() bool {
		b, err := rd.ReadByte()
		return err == nil && b == 0
	}
	if !wait() {
		return 1
	}
	r.mu.Lock()
	it := r.byName("/file", target)
	var items []Item
	if it != nil && it["type"] == "directory" {
		items = r.filesUnder(target)
	} else if it != nil {
		items = []Item{it}
	}
	type ent struct {
		name string
		dir  bool
		data []byte
	}
	var list []ent
	for _, x := range items {
		list = append(list, ent{x["name"], x["type"] == "directory", fileBytes(x)})
	}
	r.mu.Unlock()
	if it == nil {
		return scpErr(ch, target+": no such file or directory")
	}
	sort.Slice(list, func(i, j int) bool { return list[i].name < list[j].name })
	parent := path.Dir(target)
	if parent == "." {
		parent = ""
	}
	var stack []string
	rel := func(p string) []string {
		p = strings.TrimPrefix(strings.TrimPrefix(p, parent), "/")
		return strings.Split(p, "/")
	}
	for _, e := range list {
		parts := rel(e.name)
		dir := parts[:len(parts)-1]
		if e.dir {
			dir = parts
		}
		for len(stack) > len(dir) || !hasPrefix(dir, stack) {
			ch.Write([]byte("E\n"))
			if !wait() {
				return 1
			}
			stack = stack[:len(stack)-1]
		}
		for len(stack) < len(dir) {
			fmt.Fprintf(ch, "D0755 0 %s\n", dir[len(stack)])
			if !wait() {
				return 1
			}
			stack = append(stack, dir[len(stack)])
		}
		if e.dir {
			continue
		}
		fmt.Fprintf(ch, "C0644 %d %s\n", len(e.data), parts[len(parts)-1])
		if !wait() {
			return 1
		}
		ch.Write(e.data)
		ch.Write([]byte{0})
		if !wait() {
			return 1
		}
	}
	for range stack {
		ch.Write([]byte("E\n"))
		if !wait() {
			return 1
		}
	}
	return 0
}
