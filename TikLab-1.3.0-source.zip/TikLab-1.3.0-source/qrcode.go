package main

// A small QR code encoder (byte mode, error correction level M, versions
// 1-10), for the Wi-Fi join code and the login page link shown to phones.

import (
	"fmt"
	"strings"
)

type qrBlocks struct{ ec, b1, d1, b2, d2 int }

// level M
var qrTable = []qrBlocks{
	{},
	{10, 1, 16, 0, 0}, {16, 1, 28, 0, 0}, {26, 1, 44, 0, 0}, {18, 2, 32, 0, 0}, {24, 2, 43, 0, 0},
	{16, 4, 27, 0, 0}, {18, 4, 31, 0, 0}, {22, 2, 38, 2, 39}, {22, 3, 36, 2, 37}, {26, 4, 43, 1, 44},
}

var qrAlign = [][]int{{}, {}, {6, 18}, {6, 22}, {6, 26}, {6, 30}, {6, 34}, {6, 22, 38}, {6, 24, 42}, {6, 26, 46}, {6, 28, 50}}

var gfExp, gfLog [512]int

func init() {
	x := 1
	for i := 0; i < 255; i++ {
		gfExp[i] = x
		gfLog[x] = i
		x <<= 1
		if x&0x100 != 0 {
			x ^= 0x11d
		}
	}
	for i := 255; i < 512; i++ {
		gfExp[i] = gfExp[i-255]
	}
}

func gfMul(a, b int) int {
	if a == 0 || b == 0 {
		return 0
	}
	return gfExp[gfLog[a]+gfLog[b]]
}

func rsEncode(data []byte, n int) []byte {
	gen := []int{1}
	for i := 0; i < n; i++ {
		next := make([]int, len(gen)+1)
		for j, g := range gen {
			next[j] ^= g
			next[j+1] ^= gfMul(g, gfExp[i])
		}
		gen = next
	}
	rem := make([]int, n)
	for _, d := range data {
		f := int(d) ^ rem[0]
		copy(rem, rem[1:])
		rem[n-1] = 0
		for j := 0; j < n; j++ {
			rem[j] ^= gfMul(gen[j+1], f)
		}
	}
	out := make([]byte, n)
	for i, v := range rem {
		out[i] = byte(v)
	}
	return out
}

type qrBits struct {
	b []byte
	n int
}

func (q *qrBits) put(v, n int) {
	for i := n - 1; i >= 0; i-- {
		if q.n%8 == 0 {
			q.b = append(q.b, 0)
		}
		if v>>i&1 == 1 {
			q.b[q.n/8] |= 0x80 >> (q.n % 8)
		}
		q.n++
	}
}

// qrEncode returns the module matrix (true = dark).
func qrEncode(text string) ([][]bool, error) {
	data := []byte(text)
	ver := 0
	for v := 1; v <= 10; v++ {
		t := qrTable[v]
		capBytes := t.b1*t.d1 + t.b2*t.d2
		cc := 8
		if v >= 10 {
			cc = 16
		}
		if (4+cc+8*len(data)+7)/8 <= capBytes {
			ver = v
			break
		}
	}
	if ver == 0 {
		return nil, fmt.Errorf("text too long for a QR code")
	}
	t := qrTable[ver]
	total := t.b1*t.d1 + t.b2*t.d2
	var bits qrBits
	bits.put(4, 4)
	if ver >= 10 {
		bits.put(len(data), 16)
	} else {
		bits.put(len(data), 8)
	}
	for _, c := range data {
		bits.put(int(c), 8)
	}
	for i := 0; i < 4 && bits.n < total*8; i++ {
		bits.put(0, 1)
	}
	for bits.n%8 != 0 {
		bits.put(0, 1)
	}
	for pad := 0; len(bits.b) < total; pad++ {
		bits.b = append(bits.b, []byte{0xec, 0x11}[pad%2])
		bits.n += 8
	}
	// blocks
	var dblocks, eblocks [][]byte
	pos := 0
	for i := 0; i < t.b1+t.b2; i++ {
		n := t.d1
		if i >= t.b1 {
			n = t.d2
		}
		blk := bits.b[pos : pos+n]
		pos += n
		dblocks = append(dblocks, blk)
		eblocks = append(eblocks, rsEncode(blk, t.ec))
	}
	var final []byte
	for i := 0; i < max(t.d1, t.d2); i++ {
		for _, b := range dblocks {
			if i < len(b) {
				final = append(final, b[i])
			}
		}
	}
	for i := 0; i < t.ec; i++ {
		for _, b := range eblocks {
			final = append(final, b[i])
		}
	}

	size := 17 + 4*ver
	m := make([][]bool, size)
	fn := make([][]bool, size) // function modules
	for i := range m {
		m[i] = make([]bool, size)
		fn[i] = make([]bool, size)
	}
	set := func(r, c int, v bool) { m[r][c] = v; fn[r][c] = true }
	finder := func(r, c int) {
		for dr := -1; dr <= 7; dr++ {
			for dc := -1; dc <= 7; dc++ {
				rr, cc := r+dr, c+dc
				if rr < 0 || cc < 0 || rr >= size || cc >= size {
					continue
				}
				in := dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6
				dark := in && (dr == 0 || dr == 6 || dc == 0 || dc == 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4))
				set(rr, cc, dark)
			}
		}
	}
	finder(0, 0)
	finder(0, size-7)
	finder(size-7, 0)
	for i := 8; i < size-8; i++ {
		set(6, i, i%2 == 0)
		set(i, 6, i%2 == 0)
	}
	al := qrAlign[ver]
	for ai, r := range al {
		for aj, c := range al {
			last := len(al) - 1
			if ai == 0 && aj == 0 || ai == 0 && aj == last || ai == last && aj == 0 {
				continue
			}
			for dr := -2; dr <= 2; dr++ {
				for dc := -2; dc <= 2; dc++ {
					set(r+dr, c+dc, max(abs(dr), abs(dc)) != 1)
				}
			}
		}
	}
	// reserve format areas and the dark module
	for i := 0; i < 9; i++ {
		if !fn[8][i] {
			set(8, i, false)
		}
		if !fn[i][8] {
			set(i, 8, false)
		}
	}
	for i := 0; i < 8; i++ {
		set(8, size-1-i, false)
		set(size-1-i, 8, false)
	}
	set(size-8, 8, true)
	if ver >= 7 {
		vb := ver << 12
		rem := ver
		for i := 0; i < 12; i++ {
			rem = rem<<1 ^ (rem>>11)*0x1f25
		}
		vb |= rem & 0xfff
		for i := 0; i < 18; i++ {
			bit := vb>>i&1 == 1
			a, b := size-11+i%3, i/3
			set(a, b, bit)
			set(b, a, bit)
		}
	}
	// data
	bitIdx := 0
	nbits := len(final) * 8
	up := true
	for col := size - 1; col > 0; col -= 2 {
		if col == 6 {
			col--
		}
		for k := 0; k < size; k++ {
			r := k
			if up {
				r = size - 1 - k
			}
			for dc := 0; dc < 2; dc++ {
				c := col - dc
				if fn[r][c] {
					continue
				}
				if bitIdx < nbits {
					m[r][c] = final[bitIdx/8]>>(7-bitIdx%8)&1 == 1
				}
				bitIdx++
			}
		}
		up = !up
	}
	// masks
	maskFn := []func(r, c int) bool{
		func(r, c int) bool { return (r+c)%2 == 0 },
		func(r, c int) bool { return r%2 == 0 },
		func(r, c int) bool { return c%3 == 0 },
		func(r, c int) bool { return (r+c)%3 == 0 },
		func(r, c int) bool { return (r/2+c/3)%2 == 0 },
		func(r, c int) bool { return r*c%2+r*c%3 == 0 },
		func(r, c int) bool { return (r*c%2+r*c%3)%2 == 0 },
		func(r, c int) bool { return ((r+c)%2+r*c%3)%2 == 0 },
	}
	format := func(mask int) int {
		d := (0b00 << 3) | mask // level M
		rem := d
		for i := 0; i < 10; i++ {
			rem = rem<<1 ^ (rem>>9)*0x537
		}
		return (d<<10 | rem&0x3ff) ^ 0x5412
	}
	apply := func(mask int) [][]bool {
		out := make([][]bool, size)
		for r := range m {
			out[r] = append([]bool{}, m[r]...)
			for c := range out[r] {
				if !fn[r][c] && maskFn[mask](r, c) {
					out[r][c] = !out[r][c]
				}
			}
		}
		f := format(mask)
		for i := 0; i < 15; i++ {
			bit := f>>i&1 == 1
			// around the top-left finder
			switch {
			case i < 6:
				out[i][8] = bit
			case i < 8:
				out[i+1][8] = bit
			case i == 8:
				out[8][7] = bit
			default:
				out[8][14-i] = bit
			}
			// the copy split between the other two finders
			if i < 8 {
				out[8][size-1-i] = bit
			} else {
				out[size-15+i][8] = bit
			}
		}
		out[size-8][8] = true
		return out
	}
	best, bestScore := 0, 1<<30
	for mask := 0; mask < 8; mask++ {
		if s := qrPenalty(apply(mask)); s < bestScore {
			best, bestScore = mask, s
		}
	}
	return apply(best), nil
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}

func qrPenalty(m [][]bool) int {
	n := len(m)
	score := 0
	for r := 0; r < n; r++ {
		for _, row := range [][]bool{m[r], colOf(m, r)} {
			run := 1
			for c := 1; c < n; c++ {
				if row[c] == row[c-1] {
					run++
				} else {
					if run >= 5 {
						score += 3 + run - 5
					}
					run = 1
				}
			}
			if run >= 5 {
				score += 3 + run - 5
			}
			for c := 0; c+10 < n; c++ {
				p := []bool{true, false, true, true, true, false, true, false, false, false, false}
				q := []bool{false, false, false, false, true, false, true, true, true, false, true}
				a, b := true, true
				for k := 0; k < 11; k++ {
					a = a && row[c+k] == p[k]
					b = b && row[c+k] == q[k]
				}
				if a || b {
					score += 40
				}
			}
		}
	}
	dark := 0
	for r := 0; r < n-1; r++ {
		for c := 0; c < n-1; c++ {
			if m[r][c] == m[r][c+1] && m[r][c] == m[r+1][c] && m[r][c] == m[r+1][c+1] {
				score += 3
			}
		}
	}
	for r := 0; r < n; r++ {
		for c := 0; c < n; c++ {
			if m[r][c] {
				dark++
			}
		}
	}
	pct := dark * 100 / (n * n)
	score += abs(pct-50) / 5 * 10
	return score
}

func colOf(m [][]bool, c int) []bool {
	out := make([]bool, len(m))
	for r := range m {
		out[r] = m[r][c]
	}
	return out
}

// qrSVG draws a QR code as SVG with a 4-module quiet zone.
func qrSVG(text string, px int) (string, error) {
	m, err := qrEncode(text)
	if err != nil {
		return "", err
	}
	n := len(m) + 8
	var b strings.Builder
	fmt.Fprintf(&b, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" shape-rendering="crispEdges"><rect width="%d" height="%d" fill="#fff"/><path fill="#1e252d" d="`, n, n, px, px, n, n)
	for r := range m {
		for c := range m[r] {
			if m[r][c] {
				fmt.Fprintf(&b, "M%d %dh1v1h-1z", c+4, r+4)
			}
		}
	}
	b.WriteString(`"/></svg>`)
	return b.String(), nil
}

// wifiQR is the text phones read to join a network: WIFI:T:WPA;S:name;P:pass;;
func wifiQR(ssid, pass string) string {
	esc := func(s string) string {
		r := strings.NewReplacer(`\`, `\\`, `;`, `\;`, `,`, `\,`, `:`, `\:`, `"`, `\"`)
		return r.Replace(s)
	}
	if pass == "" {
		return "WIFI:T:nopass;S:" + esc(ssid) + ";;"
	}
	return "WIFI:T:WPA;S:" + esc(ssid) + ";P:" + esc(pass) + ";;"
}
