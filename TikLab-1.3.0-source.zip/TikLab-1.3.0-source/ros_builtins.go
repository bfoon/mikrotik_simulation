package main

// The ":" commands of RouterOS scripting.

import (
	"context"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"sort"
	"strconv"
	"strings"
	"time"
)

func (in *Interp) builtin(name string, st *Stmt, sc *scope, show bool) (Value, error) {
	var pos []*Arg
	named := map[string]*Arg{}
	for _, a := range st.Args[1:] {
		if a.Key != "" {
			named[a.Key] = a
		} else {
			pos = append(pos, a)
		}
	}
	ev := func(a *Arg) (Value, error) {
		if a == nil {
			return vNothing, nil
		}
		if a.Val == nil {
			return typeWord(a.Bare), nil
		}
		return in.eval(a.Val, sc)
	}
	evPos := func(i int) (Value, error) {
		if i < len(pos) {
			return ev(pos[i])
		}
		return vNothing, nil
	}
	evNamed := func(k string) (Value, bool, error) {
		a := named[k]
		if a == nil {
			return vNothing, false, nil
		}
		v, err := ev(a)
		return v, true, err
	}
	code := func(k string) (*Code, error) {
		a := named[k]
		if a == nil {
			return nil, nil
		}
		return in.codeOf(a.Val, sc)
	}
	varName := func(a *Arg) string {
		if a == nil {
			return ""
		}
		if a.Val == nil {
			return a.Bare
		}
		if l, ok := a.Val.(ELit); ok {
			return l.V.String()
		}
		if v, ok := a.Val.(EVar); ok {
			return v.Name
		}
		return ""
	}

	switch name {
	case ":local", ":global":
		if len(pos) == 0 {
			return vNil, fmt.Errorf("expected variable name")
		}
		vn := varName(pos[0])
		if vn == "" {
			return vNil, fmt.Errorf("expected variable name")
		}
		var val Value
		has := false
		if named["do"] != nil {
			c, err := code("do")
			if err != nil {
				return vNil, err
			}
			val, has = vCode(c), true
		} else if len(pos) > 1 {
			v, err := evPos(1)
			if err != nil {
				return vNil, err
			}
			val, has = v, true
		}
		if name == ":global" {
			g := in.r.declareGlobal(vn)
			if sc.glob == nil {
				sc.glob = map[string]bool{}
			}
			sc.glob[vn] = true
			delete(sc.vars, vn)
			if has {
				in.r.gmu.Lock()
				*g = val
				in.r.gmu.Unlock()
			}
			return vNothing, nil
		}
		if !has {
			val = vNothing
		}
		sc.vars[vn] = &val
		if sc.glob != nil {
			delete(sc.glob, vn)
		}
		return vNothing, nil

	case ":set":
		if len(pos) == 0 {
			return vNil, fmt.Errorf("expected variable name")
		}
		var val Value
		if named["do"] != nil {
			c, err := code("do")
			if err != nil {
				return vNil, err
			}
			val = vCode(c)
		} else {
			v, err := evPos(1)
			if err != nil {
				return vNil, err
			}
			val = v
		}
		if b, ok := pos[0].Val.(EBin); ok && b.Op == "->" {
			return vNothing, in.setElem(b, val, sc)
		}
		vn := varName(pos[0])
		if vn == "" {
			return vNil, fmt.Errorf("expected variable name")
		}
		in.setVar(sc, vn, val)
		return vNothing, nil

	case ":put":
		var parts []string
		for i := range pos {
			v, err := evPos(i)
			if err != nil {
				return vNil, err
			}
			parts = append(parts, v.String())
		}
		fmt.Fprintf(in.out, "%s\n", strings.ReplaceAll(strings.Join(parts, " "), "\n", "\r\n"))
		return vNothing, nil

	case ":log":
		if len(pos) < 1 {
			return vNil, fmt.Errorf("expected log level")
		}
		lvl := varName(pos[0])
		switch lvl {
		case "info", "warning", "error", "debug":
		default:
			return vNil, fmt.Errorf("bad log level %s", lvl)
		}
		var parts []string
		for i := 1; i < len(pos); i++ {
			v, err := evPos(i)
			if err != nil {
				return vNil, err
			}
			parts = append(parts, v.String())
		}
		in.r.mu.Lock()
		in.r.log("script,"+lvl, "%s", strings.Join(parts, " "))
		in.r.mu.Unlock()
		return vNothing, nil

	case ":if":
		cond, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		branch := "do"
		if !truthy(cond) {
			branch = "else"
		}
		c, err := code(branch)
		if err != nil {
			return vNil, err
		}
		return vNothing, in.runCode(c, sc)

	case ":do":
		var body *Code
		var err error
		if len(pos) > 0 {
			body, err = in.codeOf(pos[0].Val, sc)
		} else {
			body, err = code("command")
		}
		if err != nil {
			return vNil, err
		}
		onErr, err := code("on-error")
		if err != nil {
			return vNil, err
		}
		if w := named["while"]; w != nil {
			for {
				if in.cancelled() {
					return vNil, errCancelled
				}
				if err := in.runCode(body, sc); err != nil {
					return vNil, err
				}
				c, err := in.eval(w.Val, sc)
				if err != nil {
					return vNil, err
				}
				if !truthy(c) {
					return vNothing, nil
				}
			}
		}
		err = in.runCode(body, sc)
		if err != nil && named["on-error"] != nil {
			if _, ok := err.(*retSig); ok || err == errCancelled {
				return vNil, err
			}
			return vNothing, in.runCode(onErr, sc)
		}
		return vNothing, err

	case ":while":
		body, err := code("do")
		if err != nil {
			return vNil, err
		}
		for {
			if in.cancelled() {
				return vNil, errCancelled
			}
			c, err := evPos(0)
			if err != nil {
				return vNil, err
			}
			if !truthy(c) {
				return vNothing, nil
			}
			if err := in.runCode(body, sc); err != nil {
				return vNil, err
			}
		}

	case ":for":
		vn := varName(firstArg(pos))
		fv, _, err := evNamed("from")
		if err != nil {
			return vNil, err
		}
		tv, _, err := evNamed("to")
		if err != nil {
			return vNil, err
		}
		from, _ := toNum(fv)
		to, _ := toNum(tv)
		step := int64(1)
		if from > to {
			step = -1
		}
		if s, ok, _ := evNamed("step"); ok {
			if n, ok := toNum(s); ok && n != 0 {
				step = n
			}
		}
		body, err := code("do")
		if err != nil {
			return vNil, err
		}
		for i := from; (step > 0 && i <= to) || (step < 0 && i >= to); i += step {
			if in.cancelled() {
				return vNil, errCancelled
			}
			s := newScope(sc)
			x := vNum(i)
			s.vars[vn] = &x
			if err := in.execBlock(body.B, s, true); err != nil {
				return vNil, err
			}
		}
		return vNothing, nil

	case ":foreach":
		names := strings.Split(varName(firstArg(pos)), ",")
		coll, _, err := evNamed("in")
		if err != nil {
			return vNil, err
		}
		body, err := code("do")
		if err != nil {
			return vNil, err
		}
		if body == nil {
			return vNothing, nil
		}
		arr := newArr()
		switch coll.K {
		case KArr:
			arr = coll.A.clone()
		case KNil, KNothing:
		default:
			arr.List = append(arr.List, coll)
		}
		var loopErr error
		arr.Each(func(k, v Value) bool {
			if in.cancelled() {
				loopErr = errCancelled
				return false
			}
			s := newScope(sc)
			if len(names) >= 2 {
				kk, vv := k, v
				s.vars[strings.TrimSpace(names[0])] = &kk
				s.vars[strings.TrimSpace(names[1])] = &vv
			} else {
				vv := v
				s.vars[strings.TrimSpace(names[0])] = &vv
			}
			if err := in.execBlock(body.B, s, true); err != nil {
				loopErr = err
				return false
			}
			return true
		})
		return vNothing, loopErr

	case ":onerror":
		vn := varName(firstArg(pos))
		body, err := code("in")
		if err != nil {
			return vNil, err
		}
		handler, err := code("do")
		if err != nil {
			return vNil, err
		}
		err = in.runCode(body, sc)
		if err == nil {
			return vFalse, nil
		}
		if _, ok := err.(*retSig); ok || err == errCancelled {
			return vNil, err
		}
		s := newScope(sc)
		msg := vStr(err.Error())
		if vn != "" {
			s.vars[vn] = &msg
		}
		if handler != nil {
			if err := in.execBlock(handler.B, s, true); err != nil {
				return vNil, err
			}
		}
		return vTrue, nil

	case ":error":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		return vNil, &ScriptError{Msg: v.String(), User: true}

	case ":return":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		return vNil, &retSig{v}

	case ":delay":
		d := time.Second
		if len(pos) > 0 {
			v, err := evPos(0)
			if err != nil {
				return vNil, err
			}
			if t, ok := toTime(v); ok {
				d = t
			}
		}
		deadline := time.Now().Add(d)
		for time.Now().Before(deadline) {
			if in.cancelled() {
				return vNil, errCancelled
			}
			time.Sleep(min(50*time.Millisecond, time.Until(deadline)+time.Millisecond))
		}
		return vNothing, nil

	case ":len":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		switch v.K {
		case KArr:
			return vNum(int64(v.A.Len())), nil
		case KNil, KNothing:
			return vNum(0), nil
		}
		return vNum(int64(len(v.String()))), nil

	case ":pick":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		sv, err := evPos(1)
		if err != nil {
			return vNil, err
		}
		start, _ := toNum(sv)
		if start < 0 {
			start = 0
		}
		var end int64 = -1
		hasEnd := len(pos) > 2
		if hasEnd {
			ev, err := evPos(2)
			if err != nil {
				return vNil, err
			}
			end, _ = toNum(ev)
		}
		if v.K == KArr {
			n := int64(len(v.A.List))
			if !hasEnd {
				if start < n {
					return v.A.List[start], nil
				}
				return vNil, nil
			}
			end = min(end, n)
			if start >= end {
				return vArr(newArr()), nil
			}
			return vArr(newArr(v.A.List[start:end]...)), nil
		}
		s := v.String()
		n := int64(len(s))
		if !hasEnd {
			end = start + 1
		}
		end = min(end, n)
		if start >= n || start >= end {
			return vStr(""), nil
		}
		return vStr(s[start:end]), nil

	case ":find":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		what, err := evPos(1)
		if err != nil {
			return vNil, err
		}
		from := int64(0)
		if len(pos) > 2 {
			sv, err := evPos(2)
			if err != nil {
				return vNil, err
			}
			if n, ok := toNum(sv); ok {
				from = n + 1
			}
		}
		if from < 0 {
			from = 0
		}
		if v.K == KArr {
			for i := from; i < int64(len(v.A.List)); i++ {
				if valEqual(v.A.List[i], what) {
					return vNum(i), nil
				}
			}
			return vNil, nil
		}
		s := v.String()
		if from > int64(len(s)) {
			return vNil, nil
		}
		if i := strings.Index(s[from:], what.String()); i >= 0 {
			return vNum(from + int64(i)), nil
		}
		return vNil, nil

	case ":typeof":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		return vStr(v.K.String()), nil

	case ":tostr":
		v, err := evPos(0)
		return vStr(v.String()), err
	case ":tonum":
		v, err := evPos(0)
		if n, ok := toNum(v); ok {
			return vNum(n), err
		}
		return vNil, err
	case ":tobool":
		v, err := evPos(0)
		if b, ok := toBoolV(v); ok {
			return vBool(b), err
		}
		return vNil, err
	case ":totime":
		v, err := evPos(0)
		if d, ok := toTime(v); ok {
			return vTime(d), err
		}
		return vNil, err
	case ":toip":
		v, err := evPos(0)
		if ip := net.ParseIP(strings.TrimSpace(v.String())); ip != nil && ip.To4() != nil {
			return Value{K: KIP, S: ip.String()}, err
		}
		return vNil, err
	case ":toip6":
		v, err := evPos(0)
		if ip := net.ParseIP(strings.TrimSpace(v.String())); ip != nil {
			return Value{K: KIP6, S: ip.String()}, err
		}
		return vNil, err
	case ":toarray":
		v, err := evPos(0)
		return vArr(toArray(v)), err
	case ":toid":
		v, err := evPos(0)
		s := v.String()
		if strings.HasPrefix(s, "*") {
			return vID(s), err
		}
		return vNil, err
	case ":tocrlf":
		v, err := evPos(0)
		return vStr(strings.ReplaceAll(strings.ReplaceAll(v.String(), "\r\n", "\n"), "\n", "\r\n")), err

	case ":resolve":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		host := v.String()
		if ip := net.ParseIP(host); ip != nil {
			return typeWord(host), nil
		}
		res := net.DefaultResolver
		if srv, ok, _ := evNamed("server"); ok && srv.String() != "" {
			addr := net.JoinHostPort(srv.String(), "53")
			res = &net.Resolver{PreferGo: true, Dial: func(ctx context.Context, network, _ string) (net.Conn, error) {
				var d net.Dialer
				return d.DialContext(ctx, "udp", addr)
			}}
		}
		if ip := in.r.staticDNS(host); ip != "" {
			return typeWord(ip), nil
		}
		ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second)
		defer cancel()
		ips, err := res.LookupIPAddr(ctx, host)
		if err != nil || len(ips) == 0 {
			return vNil, fmt.Errorf("failure: dns name does not exist")
		}
		for _, ip := range ips {
			if ip.IP.To4() != nil {
				return Value{K: KIP, S: ip.IP.String()}, nil
			}
		}
		return Value{K: KIP6, S: ips[0].IP.String()}, nil

	case ":parse":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		b, err := parseScript(v.String())
		if err != nil {
			return vNil, err
		}
		return vCode(&Code{B: b, Src: v.String()}), nil

	case ":execute":
		var src string
		if a := named["script"]; a != nil {
			if br, ok := a.Val.(EBrace); ok {
				src = br.B.Text
			} else {
				v, err := ev(a)
				if err != nil {
					return vNil, err
				}
				src = v.String()
			}
		} else if len(pos) > 0 {
			if br, ok := pos[0].Val.(EBrace); ok {
				src = br.B.Text
			} else {
				v, err := evPos(0)
				if err != nil {
					return vNil, err
				}
				src = v.String()
			}
		}
		file := ""
		if f, ok, _ := evNamed("file"); ok {
			file = f.String()
		}
		asString := named["as-string"] != nil
		for _, a := range pos {
			if a.Val == nil && a.Bare == "as-string" {
				asString = true
			}
		}
		return in.execute(src, file, asString)

	case ":jobname":
		return vStr(in.jobName), nil

	case ":time":
		var body *Code
		var err error
		if len(pos) > 0 {
			body, err = in.codeOf(pos[0].Val, sc)
		}
		if err != nil {
			return vNil, err
		}
		t0 := time.Now()
		if err := in.runCode(body, sc); err != nil {
			return vNil, err
		}
		return vTime(time.Since(t0)), nil

	case ":environment":
		in.r.gmu.Lock()
		for _, k := range sortedVarKeys(in.r.globals) {
			fmt.Fprintf(in.out, "%s=%s\n", k, in.r.globals[k].String())
		}
		in.r.gmu.Unlock()
		for s := sc; s != nil; s = s.parent {
			for _, k := range sortedVarKeys(s.vars) {
				fmt.Fprintf(in.out, "%s=%s (local)\n", k, s.vars[k].String())
			}
		}
		return vNothing, nil

	case ":convert":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		if x, ok, _ := evNamed("value"); ok {
			v = x
		}
		from, _, _ := evNamed("from")
		to, _, _ := evNamed("to")
		tr, _, _ := evNamed("transform")
		return convertValue(v, from.String(), to.String(), tr.String())

	case ":serialize":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		if x, ok, _ := evNamed("value"); ok {
			v = x
		}
		b, err := json.Marshal(toJSON(v))
		if err != nil {
			return vNil, err
		}
		return vStr(string(b)), nil

	case ":deserialize":
		v, err := evPos(0)
		if err != nil {
			return vNil, err
		}
		if x, ok, _ := evNamed("value"); ok {
			v = x
		}
		var x any
		dec := json.NewDecoder(strings.NewReader(v.String()))
		dec.UseNumber()
		if err := dec.Decode(&x); err != nil {
			return vNil, fmt.Errorf("failure: invalid json")
		}
		return fromJSON(x), nil

	case ":rndnum":
		fv, _, _ := evNamed("from")
		tv, _, _ := evNamed("to")
		a, _ := toNum(fv)
		b, _ := toNum(tv)
		if b < a {
			a, b = b, a
		}
		return vNum(a + rand.Int63n(b-a+1)), nil

	case ":rndstr":
		lv, ok, _ := evNamed("length")
		n := int64(16)
		if ok {
			n, _ = toNum(lv)
		}
		chars := "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
		if f, ok, _ := evNamed("from"); ok && f.String() != "" {
			chars = f.String()
		}
		b := make([]byte, max(0, min(n, 4096)))
		for i := range b {
			b[i] = chars[rand.Intn(len(chars))]
		}
		return vStr(string(b)), nil

	case ":timestamp":
		return vTime(time.Duration(in.r.now().UnixNano())), nil

	case ":retry":
		body, err := code("command")
		if err != nil {
			return vNil, err
		}
		onErr, _ := code("on-error")
		tries := int64(3)
		if v, ok, _ := evNamed("max"); ok {
			tries, _ = toNum(v)
		}
		delay := time.Second
		if v, ok, _ := evNamed("delay"); ok {
			if d, ok := toTime(v); ok {
				delay = d
			}
		}
		var last error
		for i := int64(0); i < max(1, tries); i++ {
			if last = in.runCode(body, sc); last == nil {
				return vNothing, nil
			}
			if _, ok := last.(*retSig); ok || last == errCancelled {
				return vNil, last
			}
			time.Sleep(delay)
		}
		if onErr != nil {
			return vNothing, in.runCode(onErr, sc)
		}
		return vNil, last

	case ":nothing":
		return vNothing, nil
	case ":beep", ":terminal", ":blink", ":grep":
		return vNothing, nil
	}
	return vNil, fmt.Errorf("bad command name %s", strings.TrimPrefix(name, ":"))
}

func firstArg(a []*Arg) *Arg {
	if len(a) == 0 {
		return nil
	}
	return a[0]
}

// setElem assigns into an array element: :set ($arr->"key") value.
func (in *Interp) setElem(b EBin, val Value, sc *scope) error {
	var key Value
	if w, ok := b.R.(EWord); ok {
		key = typeWord(w.S)
		if key.K != KNum {
			key = vStr(w.S)
		}
	} else {
		k, err := in.eval(b.R, sc)
		if err != nil {
			return err
		}
		key = k
	}
	switch base := b.L.(type) {
	case EVar:
		p := in.lookup(sc, base.Name)
		if p == nil {
			nv := vArr(newArr())
			sc.vars[base.Name] = &nv
			p = &nv
		}
		in.r.gmu.Lock()
		defer in.r.gmu.Unlock()
		if p.K != KArr {
			*p = vArr(newArr())
		}
		p.A.Set(key, val)
		return nil
	case EBin:
		if base.Op == "->" {
			inner, err := in.eval(base, sc)
			if err != nil {
				return err
			}
			if inner.K == KArr {
				inner.A.Set(key, val)
				return nil
			}
		}
	}
	return fmt.Errorf("syntax error")
}

func convertValue(v Value, from, to, transform string) (Value, error) {
	var data []byte
	switch from {
	case "", "raw":
		data = []byte(v.String())
	case "base64":
		b, err := base64.StdEncoding.DecodeString(strings.TrimSpace(v.String()))
		if err != nil {
			if b2, err2 := base64.RawStdEncoding.DecodeString(strings.TrimSpace(v.String())); err2 == nil {
				b = b2
			} else {
				return vNil, fmt.Errorf("failure: invalid base64")
			}
		}
		data = b
	case "hex":
		b, err := hex.DecodeString(strings.TrimSpace(v.String()))
		if err != nil {
			return vNil, fmt.Errorf("failure: invalid hex")
		}
		data = b
	case "url":
		s, err := urlUnescape(v.String())
		if err != nil {
			return vNil, err
		}
		data = []byte(s)
	case "byte-array":
		for _, x := range toArray(v).List {
			n, _ := toNum(x)
			data = append(data, byte(n))
		}
	default:
		return vNil, fmt.Errorf("unknown format %s", from)
	}
	switch transform {
	case "lc":
		data = []byte(strings.ToLower(string(data)))
	case "uc":
		data = []byte(strings.ToUpper(string(data)))
	case "rot13":
		for i, c := range data {
			switch {
			case c >= 'a' && c <= 'z':
				data[i] = 'a' + (c-'a'+13)%26
			case c >= 'A' && c <= 'Z':
				data[i] = 'A' + (c-'A'+13)%26
			}
		}
	}
	switch to {
	case "", "raw":
		return vStr(string(data)), nil
	case "base64":
		return vStr(base64.StdEncoding.EncodeToString(data)), nil
	case "hex":
		return vStr(hex.EncodeToString(data)), nil
	case "url":
		return vStr(urlEscape(data)), nil
	case "byte-array":
		a := newArr()
		for _, b := range data {
			a.List = append(a.List, vNum(int64(b)))
		}
		return vArr(a), nil
	}
	return vNil, fmt.Errorf("unknown format %s", to)
}

// urlEscape percent-encodes everything except RFC 3986 unreserved characters.
func urlEscape(b []byte) string {
	var s strings.Builder
	for _, c := range b {
		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == '.' || c == '~' {
			s.WriteByte(c)
		} else {
			fmt.Fprintf(&s, "%%%02X", c)
		}
	}
	return s.String()
}

func urlUnescape(s string) (string, error) {
	var b []byte
	for i := 0; i < len(s); i++ {
		switch {
		case s[i] == '%' && i+2 < len(s)+0 && i+2 <= len(s)-1:
			x, err := hex.DecodeString(s[i+1 : i+3])
			if err != nil {
				return "", fmt.Errorf("failure: invalid url encoding")
			}
			b = append(b, x[0])
			i += 2
		case s[i] == '+':
			b = append(b, ' ')
		default:
			b = append(b, s[i])
		}
	}
	return string(b), nil
}

func toJSON(v Value) any {
	switch v.K {
	case KNum:
		return v.N
	case KBool:
		return v.N != 0
	case KNil, KNothing:
		return nil
	case KArr:
		if len(v.A.Map) == 0 {
			out := []any{}
			for _, x := range v.A.List {
				out = append(out, toJSON(x))
			}
			return out
		}
		out := map[string]any{}
		v.A.Each(func(k, x Value) bool { out[k.String()] = toJSON(x); return true })
		return out
	}
	return v.String()
}

func fromJSON(x any) Value {
	switch t := x.(type) {
	case nil:
		return vNil
	case bool:
		return vBool(t)
	case json.Number:
		if n, err := t.Int64(); err == nil {
			return vNum(n)
		}
		return vStr(t.String())
	case string:
		return vStr(t)
	case []any:
		a := newArr()
		for _, e := range t {
			a.List = append(a.List, fromJSON(e))
		}
		return vArr(a)
	case map[string]any:
		a := newArr()
		keys := make([]string, 0, len(t))
		for k := range t {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			a.Set(vStr(k), fromJSON(t[k]))
		}
		return vArr(a)
	}
	return vStr(fmt.Sprint(x))
}

// staticDNS answers from /ip dns static, as the router's own resolver would.
func (r *Router) staticDNS(name string) string {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, it := range r.list(MenuMap["/ip/dns/static"]) {
		if it.B("disabled") || it["address"] == "" {
			continue
		}
		if strings.EqualFold(it["name"], name) {
			return it["address"]
		}
	}
	return ""
}

var _ = strconv.Itoa
