'use strict';
/* TikLab — WinBox-style management console */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(k));
  return el;
}
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem('tiklab.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('tiklab.' + k, JSON.stringify(v)); } catch { } }
};

const S = { t: null, info: null, menus: {}, wins: {}, z: 20, state: 'running', cascade: 0, termN: 0, epoch: 0 };

async function post(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return r.json();
}
async function exec(cmd, args = {}, query = []) {
  let r;
  try { r = await post('/gui/exec', { t: S.t, cmd, args, query }); }
  catch (e) { return { error: 'connection lost', items: [] }; }
  if (r.expired) { backToLogin('Session expired - please log in again.'); }
  if (r.state && r.state !== 'running') setState(r.state);
  return r;
}

// ---------- formatting ----------
function fmtBytes(n) {
  n = +n; if (!isFinite(n)) return '';
  const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i ? n.toFixed(n < 10 ? 2 : 1) : n.toFixed(0)) + ' ' + u[i];
}
function fmtBps(n) {
  n = +n || 0;
  if (n >= 1e9) return (n / 1e9).toFixed(2) + ' Gbps';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + ' Mbps';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + ' kbps';
  return n.toFixed(0) + ' bps';
}
const BYTE_FIELDS = /^(rx-byte|tx-byte|fp-rx-byte|fp-tx-byte|bytes-in|bytes-out|limit-bytes-(in|out|total)|total-bytes|free-memory|total-memory|free-hdd-space|total-hdd-space|size|orig-bytes|repl-bytes)$/;
function cellVal(m, k, v, row) {
  if (v == null) return '';
  const f = m && m.F[k];
  if (f && f.k === 'bool') return v === 'true' ? 'yes' : v === 'false' ? 'no' : v;
  if (BYTE_FIELDS.test(k) && /^\d+$/.test(v)) return fmtBytes(v);
  if ((k === 'rate' || k === 'bytes' || k === 'orig-rate' || k === 'repl-rate') && /^\d+(\/\d+)?$/.test(v)) {
    if (k === 'bytes') return v.split('/').map(fmtBytes).join(' / ');
    return v.split('/').map(fmtBps).join(' / ');
  }
  if (k === 'contents') return v.length > 60 ? v.slice(0, 60) + '…' : v;
  return v;
}
function itemLabel(row) {
  return row.name || row.user || row.address || row['mac-address'] || row.interface || row['dst-address'] || row.chain || row.list || row.host || row['.id'] || '';
}
function singular(t) { return t.replace(/ies$/, 'y').replace(/(Servers|Profiles|Users|Rules|Addresses|Secrets|Leases|Networks|Routes|Pools|Ports|Lists|Members|Scripts|Bindings|Clients|Queues|Communities|Certificates|Files|Groups|Hosts|Entries|Types)$/, s => s.replace(/es$|s$/, '').replace(/Addresse$/, 'Address')); }

// ---------- icons ----------
const ICON = {
  dash: '<path d="M2 11a6 6 0 1 1 12 0"/><path d="M8 11l3-4"/>',
  iface: '<rect x="2" y="4" width="12" height="8" rx="1"/><path d="M5 7v2M8 7v2M11 7v2"/>',
  wifi: '<path d="M2 6a9 9 0 0 1 12 0"/><path d="M4.5 8.5a5.5 5.5 0 0 1 7 0"/><circle cx="8" cy="11.5" r=".8"/>',
  bridge: '<path d="M2 11h12"/><path d="M3 11a5 5 0 0 1 10 0"/><path d="M5 11V8.5M8 11V7M11 11V8.5"/>',
  ppp: '<path d="M6.5 9.5l3-3"/><path d="M7 5l1.5-1.5a2.5 2.5 0 0 1 3.5 3.5L10.5 8.5"/><path d="M9 11l-1.5 1.5A2.5 2.5 0 0 1 4 9l1.5-1.5"/>',
  ip: '<circle cx="8" cy="8" r="6"/><path d="M2 8h12M8 2c2 2 2 10 0 12M8 2c-2 2-2 10 0 12"/>',
  queue: '<path d="M3 13V8M6.5 13V5M10 13V9M13.5 13V3"/>',
  file: '<path d="M4 2h5l3 3v9H4z"/><path d="M9 2v3h3"/>',
  log: '<path d="M3 4h10M3 8h10M3 12h6"/>',
  radius: '<path d="M8 2l5 2v4c0 3-2.5 5-5 6-2.5-1-5-3-5-6V4z"/>',
  sys: '<circle cx="8" cy="8" r="2.2"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4"/>',
  tool: '<path d="M10.5 2.5a3 3 0 0 0-3.8 3.8L2.5 10.5l3 3 4.2-4.2a3 3 0 0 0 3.8-3.8l-2 2-2-2z"/>',
  term: '<rect x="2" y="3" width="12" height="10" rx="1"/><path d="M4.5 6.5L6.5 8l-2 1.5M8 10h3"/>',
  sim: '<path d="M6 2h4M6.5 2v4l-3.5 7h10L9.5 6V2"/><path d="M5 10h6"/>',
  win: '<rect x="2" y="3" width="12" height="10" rx="1"/><path d="M2 6h12"/>',
  exit: '<path d="M6 3H3v10h3"/><path d="M10 5l3 3-3 3M13 8H6"/>',
  hs: '<path d="M2 6a9 9 0 0 1 12 0"/><rect x="5" y="8.5" width="6" height="5" rx="1"/><path d="M6.5 8.5V7.5a1.5 1.5 0 0 1 3 0v1"/>',
  ipv6: '<circle cx="8" cy="8" r="6"/><path d="M5.5 10.5L8 5l2.5 5.5"/>',
  snmp: '<path d="M3 12l3-4 3 2 4-6"/>',
  cert: '<rect x="2.5" y="3" width="11" height="8" rx="1"/><circle cx="10.5" cy="11.5" r="1.8"/><path d="M5 6h5"/>',
  xfer: '<path d="M3 5h9l-2.5-2.5M13 11H4l2.5 2.5"/>',
  model: '<rect x="1.5" y="5" width="13" height="7" rx="1.2"/><path d="M4 8h1.5M7 8h1.5M10 8h1.5"/><path d="M4 3h8"/>',
  pcwifi: '<rect x="1.5" y="8" width="8" height="5.5" rx="1"/><path d="M4 13.5h3"/><path d="M10 4.5a5 5 0 0 1 4.5 0M11 6.8a2.6 2.6 0 0 1 2.6 0"/><circle cx="12.3" cy="9" r=".7"/>',
  cloud: '<path d="M4.5 12.5a3 3 0 0 1-.3-6 4 4 0 0 1 7.7-.8 2.9 2.9 0 0 1 .6 5.7"/><path d="M8 9v5M6 12l2 2 2-2"/>',
};
const chev = '<svg class="chev" viewBox="0 0 10 10"><path d="M3 2l3 3-3 3"/></svg>';
const ico = n => `<svg viewBox="0 0 16 16">${ICON[n] || ICON.win}</svg>`;

// ---------- window definitions ----------
const WINS = {
  interfaces: { title: 'Interface List', tabs: ['/interface', '/interface/ethernet', '/interface/vlan', '/interface/eoip', '/interface/wireguard', '/interface/wireguard/peers', '/interface/list', '/interface/list/member'] },
  wireless: { title: 'Wireless Tables', tabs: ['/interface/wireless', '/interface/wireless/registration-table', '/interface/wireless/security-profiles', '/interface/wireless/access-list'] },
  wifi: { title: 'WiFi', tabs: ['/interface/wifi', '/interface/wifi/registration-table'] },
  bridge: { title: 'Bridge', tabs: ['/interface/bridge', '/interface/bridge/port', '/interface/bridge/vlan', '/interface/bridge/host'] },
  ppp: { title: 'PPP', tabs: ['/interface/pppoe-server', '/interface/pppoe-server/server', '/ppp/secret', '/ppp/profile', '/ppp/active', '/interface/pppoe-client'], extra: [['PPP AAA', '/ppp/aaa'], ['L2TP Server', '/interface/l2tp-server/server'], ['OVPN Server', '/interface/ovpn-server/server'], ['SSTP Server', '/interface/sstp-server/server'], ['PPTP Server', '/interface/pptp-server/server']] },
  arp: { title: 'ARP List', tabs: ['/ip/arp'] },
  addresses: { title: 'Address List', tabs: ['/ip/address'] },
  dhcpc: { title: 'DHCP Client', tabs: ['/ip/dhcp-client'] },
  dhcps: { title: 'DHCP Server', tabs: ['/ip/dhcp-server', '/ip/dhcp-server/network', '/ip/dhcp-server/lease', '/ip/dhcp-server/option'] },
  relay: { title: 'DHCP Relay', tabs: ['/ip/dhcp-relay'] },
  dns: { title: 'DNS', tabs: ['/ip/dns/static', '/ip/dns/cache'], extra: [['Settings', '/ip/dns']] },
  firewall: { title: 'Firewall', tabs: ['/ip/firewall/filter', '/ip/firewall/nat', '/ip/firewall/mangle', '/ip/firewall/raw', '/ip/firewall/service-port', '/ip/firewall/connection', '/ip/firewall/address-list', '/ip/firewall/layer7-protocol'] },
  hotspot: { title: 'Hotspot', tabs: ['/ip/hotspot', '/ip/hotspot/profile', '/ip/hotspot/user', '/ip/hotspot/user/profile', '/ip/hotspot/active', '/ip/hotspot/host', '/ip/hotspot/ip-binding', '/ip/hotspot/service-port', '/ip/hotspot/walled-garden', '/ip/hotspot/walled-garden/ip', '/ip/hotspot/cookie'] },
  neighbors: { title: 'Neighbor List', tabs: ['/ip/neighbor'], extra: [['Discovery Settings', '/ip/neighbor/discovery-settings']] },
  pool: { title: 'IP Pool', tabs: ['/ip/pool', '/ip/pool/used'] },
  routes: { title: 'Route List', tabs: ['/ip/route'] },
  services: { title: 'IP Service List', tabs: ['/ip/service'] },
  v6addr: { title: 'IPv6 Address List', tabs: ['/ipv6/address'] },
  queues: { title: 'Queue List', tabs: ['/queue/simple', '/queue/tree', '/queue/type'] },
  files: { title: 'File List', tabs: ['/file'] },
  log: { title: 'Log', tabs: ['/log'], log: true },
  radius: { title: 'RADIUS', tabs: ['/radius'], extra: [['Incoming', '/radius/incoming']] },
  users: { title: 'User List', tabs: ['/user', '/user/group', '/user/active'], extra: [['Settings', '/user/settings']] },
  scheduler: { title: 'Scheduler', tabs: ['/system/scheduler'] },
  scripts: { title: 'Script List', tabs: ['/system/script', '/system/script/job'] },
  packages: { title: 'Package List', tabs: ['/system/package'], extra: [['Check For Updates', '/system/package/update']] },
  logging: { title: 'Logging', tabs: ['/system/logging', '/system/logging/action'] },
  health: { title: 'Health', tabs: ['/system/health'] },
  history: { title: 'History', tabs: ['/system/history'] },
  certs: { title: 'Certificates', tabs: ['/certificate'] },
  netwatch: { title: 'Netwatch', tabs: ['/tool/netwatch'] },
  snmp: { title: 'SNMP Communities', tabs: ['/snmp/community'], extra: [['Settings', '/snmp']] },
  graphing: { title: 'Graphing', tabs: ['/tool/graphing/interface'] },
};

const MENU = [
  { n: 'Dashboard', i: 'dash', a: () => openDashboard() },
  { n: 'Interfaces', i: 'iface', w: 'interfaces' },
  { n: 'Wireless', i: 'wifi', w: 'wireless', show: () => !S.info.local || S.info.wireless === 'wlan' },
  { n: 'WiFi', i: 'wifi', w: 'wifi', show: () => !S.info.local || S.info.wireless === 'wifi' },
  { n: 'Bridge', i: 'bridge', w: 'bridge' },
  { n: 'PPP', i: 'ppp', w: 'ppp' },
  { n: 'IP', i: 'ip', kids: [['ARP', 'arp'], ['Addresses', 'addresses'], ['Cloud', '/ip/cloud'], ['DHCP Client', 'dhcpc'], ['DHCP Relay', 'relay'], ['DHCP Server', 'dhcps'], ['DNS', 'dns'], ['Firewall', 'firewall'], ['Hotspot', 'hotspot'], ['Neighbors', 'neighbors'], ['Pool', 'pool'], ['Proxy', '/ip/proxy'], ['Routes', 'routes'], ['Services', 'services'], ['Settings', '/ip/settings'], ['SOCKS', '/ip/socks'], ['SSH', '/ip/ssh'], ['Traffic Flow', '/ip/traffic-flow'], ['UPnP', '/ip/upnp']] },
  { n: 'IPv6', i: 'ipv6', kids: [['Addresses', 'v6addr'], ['Settings', '/ipv6/settings']] },
  { n: 'Queues', i: 'queue', w: 'queues' },
  { n: 'Files', i: 'file', a: () => openFiles() },
  { n: 'Config Transfer', i: 'xfer', a: () => openTransfer(), local: true },
  { n: 'Hotspot Pages', i: 'hs', a: () => openPageStudio(), local: true },
  { n: 'Log', i: 'log', w: 'log' },
  { n: 'RADIUS', i: 'radius', w: 'radius' },
  { n: 'SNMP', i: 'snmp', w: 'snmp' },
  { n: 'Certificates', i: 'cert', w: 'certs' },
  { n: 'System', i: 'sys', kids: [['Clock', '/system/clock'], ['Health', 'health'], ['History', 'history'], ['Identity', '/system/identity'], ['License', '/system/license'], ['Logging', 'logging'], ['Note', '/system/note'], ['NTP Client', '/system/ntp/client'], ['NTP Server', '/system/ntp/server'], ['Packages', 'packages'], ['Resources', () => openResources()], ['RouterBOARD', '/system/routerboard'], ['Scheduler', 'scheduler'], ['Scripts', 'scripts'], ['Users', 'users'], ['Backup', () => doBackup()], ['Export / Import', () => openTransfer()], ['Reboot', () => powerAsk('reboot')], ['Shutdown', () => powerAsk('shutdown')], ['Reset Configuration', () => powerAsk('reset')]] },
  { n: 'Tools', i: 'tool', kids: [['Bandwidth Server', '/tool/bandwidth-server'], ['E-mail', '/tool/e-mail'], ['Graphing', 'graphing'], ['MAC Server', '/tool/mac-server'], ['Netwatch', 'netwatch'], ['Ping', () => openPing()], ['RoMON', '/tool/romon'], ['Traceroute', () => openPing(true)], ['Traffic Monitor', () => openTraffic()]] },
  { sep: true },
  { n: 'New Terminal', i: 'term', a: () => openTerminal() },
  { n: 'Simulator', i: 'sim', a: () => openSimulator(), cls: 'sim', local: true },
  { n: 'Router Model', i: 'model', a: () => openSimulator('model'), cls: 'sim', local: true },
  { n: 'Wi-Fi on this PC', i: 'pcwifi', a: () => openPCWifi(), cls: 'sim', local: true, show: () => !!S.info.wireless },
  { n: 'TapTap & Tunnels', i: 'cloud', a: () => openCloud(), cls: 'sim', local: true },
  { n: 'Hotspot Portal', i: 'win', a: () => window.open(portalURL(), '_blank') , local: true },
  { sep: true },
  { n: 'New WinBox', i: 'win', a: () => window.open(location.href, '_blank') },
  { n: 'Exit', i: 'exit', a: () => logout() },
];

const CMD_LABEL = { 'reset-counters': 'Reset Counters', 'reset-counters-all': 'Reset All Counters', run: 'Run Script', 'make-static': 'Make Static', login: 'Login…', logout: 'Logout', connect: 'Connect', disconnect: 'Disconnect', plug: 'Plug in', unplug: 'Unplug', sign: 'Sign', 'check-for-updates': 'Check', 'cable-test': 'Cable Test', 'flush-cache': 'Flush Cache', 'force-update': 'Force Update', renew: 'Renew', release: 'Release' };

// ---------- window manager ----------
function deskRect() { return $('#desk').getBoundingClientRect(); }
function openWin(id, title, opts, build) {
  if (S.wins[id]) { const w = S.wins[id]; w.el.classList.remove('minimized'); focusWin(w); return w; }
  opts = opts || {};
  const dr = deskRect();
  const W = Math.min(opts.w || 640, dr.width - 20), H = Math.min(opts.h || 380, dr.height - 20);
  const off = (S.cascade++ % 8) * 26;
  const x = opts.x ?? Math.max(8, Math.min(30 + off, dr.width - W - 8)), y = opts.y ?? Math.max(8, Math.min(18 + off, dr.height - H - 8));
  const el = h('div', { class: 'win', style: { left: x + 'px', top: y + 'px', width: W + 'px', height: H + 'px' } });
  const tt = h('div', { class: 't' }, title);
  const bMin = h('button', { 'aria-label': 'Minimize', html: '<svg viewBox="0 0 10 10"><path d="M1 8h8"/></svg>' });
  const bMax = h('button', { 'aria-label': 'Maximize', html: '<svg viewBox="0 0 10 10"><rect x="1.5" y="1.5" width="7" height="7"/></svg>' });
  const bX = h('button', { class: 'x', 'aria-label': 'Close', html: '<svg viewBox="0 0 10 10"><path d="M2 2l6 6M8 2L2 8"/></svg>' });
  const bar = h('div', { class: 'win-title' }, tt, bMin, bMax, bX);
  const body = h('div', { class: 'win-body' });
  el.append(bar, body, h('div', { class: 'rz' }));
  $('#desk').append(el);
  const w = { id, el, body, title, timers: [], closers: [], setTitle(t) { tt.textContent = t; w.title = t; renderTasks(); } };
  w.every = (ms, fn, now = true) => {
    const run = () => { if (!el.classList.contains('minimized') && S.state === 'running' && document.visibilityState !== 'hidden') fn(); };
    if (now) run();
    w.timers.push(setInterval(run, ms));
  };
  w.close = () => closeWin(w);
  bX.onclick = () => closeWin(w);
  bMin.onclick = () => { el.classList.add('minimized'); renderTasks(); };
  bMax.onclick = () => { el.classList.toggle('max'); w.onresize && w.onresize(); };
  bar.ondblclick = e => { if (e.target === bar || e.target === tt) bMax.onclick(); };
  el.addEventListener('mousedown', () => focusWin(w), true);
  drag(bar, el, false, () => w.onresize && w.onresize());
  drag($('.rz', el), el, true, () => w.onresize && w.onresize());
  S.wins[id] = w;
  focusWin(w);
  build && build(w);
  renderTasks();
  return w;
}
function drag(handle, el, resize, done) {
  handle.addEventListener('pointerdown', e => {
    if (e.target.closest('button') && !resize) return;
    if (el.classList.contains('max')) return;
    e.preventDefault();
    const sx = e.clientX, sy = e.clientY, r = el.getBoundingClientRect(), d = deskRect();
    const ox = r.left - d.left, oy = r.top - d.top;
    const mv = ev => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (resize) { el.style.width = Math.max(260, r.width + dx) + 'px'; el.style.height = Math.max(120, r.height + dy) + 'px'; }
      else { el.style.left = Math.max(-r.width + 80, Math.min(d.width - 60, ox + dx)) + 'px'; el.style.top = Math.max(0, Math.min(d.height - 28, oy + dy)) + 'px'; }
    };
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); done && done(); };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
  });
}
function focusWin(w) {
  Object.values(S.wins).forEach(x => x.el.classList.remove('active'));
  w.el.classList.add('active'); w.el.style.zIndex = ++S.z;
  renderTasks();
}
function closeWin(w) {
  w.timers.forEach(clearInterval);
  w.closers.forEach(f => { try { f(); } catch { } });
  w.el.remove(); delete S.wins[w.id]; renderTasks();
}
function renderTasks() {
  const t = $('#tasks'); t.innerHTML = '';
  for (const w of Object.values(S.wins)) {
    const b = h('button', { class: (w.el.classList.contains('active') ? 'on ' : '') + (w.el.classList.contains('minimized') ? 'min' : ''), title: w.title }, w.title);
    b.onclick = () => { if (w.el.classList.contains('active') && !w.el.classList.contains('minimized')) { w.el.classList.add('minimized'); renderTasks(); } else { w.el.classList.remove('minimized'); focusWin(w); } };
    t.append(b);
  }
}

// ---------- table view ----------
function menuOf(path) { return S.menus[path]; }
function tableView(path, opts = {}) {
  const m = menuOf(path);
  const el = h('div', { class: 'tv' });
  if (!m) { el.append(h('div', { class: 'note' }, 'Unknown menu ' + path)); return { el, refresh() { } }; }
  const cols = opts.cols || (m.cols && m.cols.length ? m.cols : m.fields.filter(f => !f.hide && f.n !== 'comment' && f.n !== 'disabled').slice(0, 6).map(f => f.n));
  let rows = [], sel = new Set(), sortK = null, sortD = 1, filter = '', lastErr = '', lastClick = null;
  const ro = opts.readonly || (S.info && !S.info.local && path.startsWith('/sim'));
  const tb = h('div', { class: 'tb' });
  const btn = (cls, title, svg, fn) => { const b = h('button', { class: 'ib ' + cls, title, 'aria-label': title, html: `<svg viewBox="0 0 16 16">${svg}</svg>` }); b.onclick = fn; tb.append(b); return b; };
  if (!m.noAdd && !ro) btn('add', 'Add', '<path d="M8 3v10M3 8h10"/>', () => itemDialog(path, null, opts.preset));
  if (!m.noRemove && !ro) btn('del', 'Remove', '<path d="M3 8h10"/>', () => act('remove'));
  if (m.F.disabled && !ro && !m.dyn) {
    btn('en', 'Enable', '<path d="M3 8.5l3 3 7-7"/>', () => act('enable'));
    btn('dis', 'Disable', '<path d="M4 4l8 8M12 4l-8 8"/>', () => act('disable'));
  }
  if (m.F.comment && !ro) btn('cm', 'Comment', '<path d="M3 3h10v7H7l-3 3v-3H3z"/>', commentSel);
  for (const c of (m.cmds || [])) {
    if (!CMD_LABEL[c] || ro) continue;
    tb.append(h('span', { class: 'sep' }));
    const b = h('button', {}, CMD_LABEL[c]);
    b.onclick = () => {
      if (c === 'login' && path === '/sim/client') return loginVoucher(selRows()[0]);
      if (c === 'login' && path === '/ip/hotspot/active') return formDialog('Hotspot login', [['user', 'User'], ['password', 'Password'], ['mac-address', 'MAC address', 'AA:BB:CC:00:00:10'], ['ip', 'IP address', '10.5.50.250']], a => exec('/ip/hotspot/active/login', a), refresh);
      if (c === 'reset-counters-all') return act(c, true);
      act(c);
    };
    tb.append(b);
  }
  (opts.extra || []).forEach(([label, fn]) => { tb.append(h('span', { class: 'sep' })); const b = h('button', {}, label); b.onclick = () => fn(selRows(), refresh); tb.append(b); });
  const find = h('input', { class: 'find', placeholder: 'Find', 'aria-label': 'Find' });
  find.oninput = () => { filter = find.value.toLowerCase(); render(); };
  tb.append(find);
  const table = h('table', { class: 'tbl' });
  const thead = h('thead'), tbody = h('tbody');
  table.append(thead, tbody);
  const wrap = h('div', { class: 'tbl-wrap' }, table);
  const status = h('div', { class: 'status' });
  el.append(tb, wrap, status);
  const hr = h('tr', null, h('th', { style: { width: '1%' } }, ''));
  for (const c of cols) {
    const th = h('th', { 'data-k': c }, colTitle(c));
    th.onclick = () => { if (sortK === c) sortD = -sortD; else { sortK = c; sortD = 1; } render(); };
    hr.append(th);
  }
  thead.append(hr);
  function colTitle(c) { return c.replace(/-/g, ' ').replace(/^./, s => s.toUpperCase()).replace(/\bip\b/i, 'IP').replace(/\bmac\b/i, 'MAC').replace(/\bmtu\b/i, 'MTU'); }
  function flags(r) { return (m.flags || []).filter(f => r[f.f] === f.v).map(f => f.c).join(''); }
  function selRows() { return rows.filter(r => sel.has(r['.id'])); }
  async function act(cmd, all) {
    const ids = selRows().map(r => r['.id']);
    if (!ids.length && !all) return setErr('Select an item first');
    if (cmd === 'remove' && ids.length > 1 && !confirm(`Remove ${ids.length} items?`)) return;
    const args = all ? {} : { numbers: ids.join(',') };
    const r = await exec(path + '/' + cmd, args);
    if (r.error) setErr(`Couldn't ${cmd} ${m.title}: ${r.error}`); else { setErr(''); if (cmd === 'remove') sel.clear(); }
    refresh();
  }
  async function commentSel() {
    const rs = selRows(); if (!rs.length) return setErr('Select an item first');
    const v = prompt('Comment', rs[0].comment || ''); if (v == null) return;
    const r = await exec(path + '/comment', { numbers: rs.map(x => x['.id']).join(','), comment: v });
    if (r.error) setErr(r.error); refresh();
  }
  function setErr(e) { lastErr = e; renderStatus(); }
  function renderStatus() {
    const shown = tbody.querySelectorAll('tr[data-id]').length;
    status.innerHTML = '';
    status.append(h('span', null, `${shown} item${shown === 1 ? '' : 's'}${shown !== rows.length ? ` out of ${rows.length}` : ''}${sel.size ? ` (${sel.size} selected)` : ''}`));
    if (lastErr) status.append(h('span', { class: 'err' }, lastErr));
  }
  function render() {
    let list = rows.slice();
    if (filter) list = list.filter(r => Object.values(r).some(v => String(v).toLowerCase().includes(filter)));
    if (sortK) list.sort((a, b) => {
      const x = a[sortK] ?? '', y = b[sortK] ?? '';
      const nx = parseFloat(x), ny = parseFloat(y);
      if (!isNaN(nx) && !isNaN(ny) && /^[\d.]+/.test(x)) return (nx - ny) * sortD;
      return String(x).localeCompare(String(y), undefined, { numeric: true }) * sortD;
    });
    $$('th', thead).forEach(th => th.classList.toggle('sorted', th.dataset.k === sortK));
    const frag = document.createDocumentFragment();
    for (const r of list) {
      if (r.comment && !opts.log) frag.append(h('tr', { class: 'cmt' }, h('td'), h('td', { colspan: cols.length }, ';;; ' + r.comment)));
      const cls = [sel.has(r['.id']) ? 'sel' : '', r.disabled === 'true' ? 'dis' : '', r.dynamic === 'true' ? 'dyn' : '', r.invalid === 'true' ? 'inv' : ''].join(' ');
      const tr = h('tr', { class: cls, 'data-id': r['.id'] }, h('td', { class: 'fl' }, flags(r)));
      for (const c of cols) {
        const v = cellVal(m, c, r[c], r);
        const td = h('td', { title: r[c] ?? '' }, v);
        if (opts.log && c === 'message') {
          const t = r.topics || '';
          td.style.color = /error|critical/.test(t) ? 'var(--red)' : /warning/.test(t) ? '#9a6b00' : /account/.test(t) ? 'var(--teal-2)' : '';
        }
        tr.append(td);
      }
      frag.append(tr);
    }
    tbody.innerHTML = ''; tbody.append(frag);
    renderStatus();
  }
  tbody.addEventListener('click', e => {
    const tr = e.target.closest('tr[data-id]'); if (!tr) return;
    const id = tr.dataset.id;
    if (e.ctrlKey || e.metaKey) { sel.has(id) ? sel.delete(id) : sel.add(id); }
    else if (e.shiftKey && lastClick) {
      const ids = $$('tr[data-id]', tbody).map(t => t.dataset.id); const a = ids.indexOf(lastClick), b = ids.indexOf(id);
      ids.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => sel.add(x));
    } else { sel = new Set([id]); }
    lastClick = id;
    $$('tr[data-id]', tbody).forEach(t => t.classList.toggle('sel', sel.has(t.dataset.id)));
    renderStatus();
  });
  tbody.addEventListener('dblclick', e => {
    const tr = e.target.closest('tr[data-id]'); if (!tr) return;
    const r = rows.find(x => x['.id'] === tr.dataset.id);
    if (r) (opts.open || itemDialog)(path, r);
  });
  el.tabIndex = 0;
  el.addEventListener('keydown', e => { if (e.key === 'Delete' && sel.size && !m.noRemove && !ro && document.activeElement !== find) act('remove'); });
  let busy = false;
  async function refresh() {
    if (busy) return; busy = true;
    const r = await exec(path + '/print');
    busy = false;
    if (r.error) { setErr(r.error); return; }
    rows = r.items || [];
    if (opts.log) { const atBottom = wrap.scrollTop + wrap.clientHeight >= wrap.scrollHeight - 30; render(); if (atBottom) wrap.scrollTop = wrap.scrollHeight; }
    else render();
    const ids = new Set(rows.map(x => x['.id'])); [...sel].forEach(x => ids.has(x) || sel.delete(x));
  }
  return { el, refresh, rows: () => rows, selected: selRows };
}

function openList(key) {
  const d = WINS[key];
  const id = 'list:' + key;
  return openWin(id, d.title, { w: d.log ? 860 : 820, h: d.log ? 460 : 400 }, w => {
    const panes = {};
    let cur = null;
    if (d.tabs.length > 1) {
      const tabs = h('div', { class: 'tabs', role: 'tablist' });
      d.tabs.forEach((p, i) => {
        const m = menuOf(p); if (!m) return;
        const b = h('button', { role: 'tab' }, m.title);
        b.onclick = () => show(p, b);
        tabs.append(b);
        if (i === 0) setTimeout(() => show(p, b));
      });
      w.body.append(tabs);
    } else setTimeout(() => show(d.tabs[0]));
    const holder = h('div', { class: 'tabpane' });
    w.body.append(holder);
    function show(p, btn) {
      if (btn) $$('.tabs button', w.body).forEach(b => b.classList.toggle('on', b === btn));
      if (!panes[p]) {
        const extra = (d.extra || []).map(([label, sp]) => [label, () => openSingle(sp)]);
        if (p === '/ip/hotspot/user') extra.push(['Generate vouchers…', () => openSimulator('vouchers')]);
        panes[p] = tableView(p, { log: d.log, extra, cols: d.log ? ['time', 'topics', 'message'] : null });
      }
      holder.innerHTML = ''; holder.append(panes[p].el);
      cur = p; panes[p].refresh();
    }
    w.every(d.log ? 1500 : 2000, () => cur && panes[cur].refresh(), false);
  });
}

// ---------- item dialog ----------
async function refOptions(f) {
  const m = menuOf(f.ref); if (!m) return [];
  const key = m.unique || 'name';
  const r = await exec(f.ref + '/print', { '.proplist': key });
  return [...(f.extra || []), ...(r.items || []).map(x => x[key]).filter(Boolean)];
}
function inputFor(f, val, onchange) {
  let el;
  if (f.k === 'bool') { el = h('input', { type: 'checkbox' }); el.checked = val === 'true' || val === 'yes'; el.getVal = () => el.checked ? 'yes' : 'no'; }
  else if (f.k === 'enum') {
    el = h('select'); if (!f.req) el.append(h('option', { value: '' }, ''));
    f.enum.forEach(e => el.append(h('option', { value: e }, e))); el.value = val ?? ''; el.getVal = () => el.value;
  } else if (f.k === 'ref') {
    el = h('select'); el.append(h('option', { value: val ?? '' }, val ?? ''));
    el.getVal = () => el.value;
    refOptions(f).then(opts => { const cur = el.value; el.innerHTML = ''; if (!f.req) el.append(h('option', { value: '' }, '')); [...new Set([cur, ...opts])].filter((x, i) => x || i === 0).forEach(o => o !== '' && el.append(h('option', { value: o }, o))); el.value = cur; });
  } else if (f.k === 'text') { el = h('textarea', { rows: 8, spellcheck: 'false' }); el.value = val ?? ''; el.getVal = () => el.value; }
  else { el = h('input', { type: f.hide || /password|secret|key$/.test(f.n) ? 'password' : 'text', spellcheck: 'false' }); el.value = val ?? ''; el.getVal = () => el.value; if (f.hide || /password/.test(f.n)) { el.addEventListener('focus', () => el.type = 'text'); el.addEventListener('blur', () => el.type = 'password'); } }
  el.addEventListener('input', onchange); el.addEventListener('change', onchange);
  return el;
}
function itemDialog(path, row, preset) {
  const m = menuOf(path); if (!m) return;
  const isNew = !row;
  const id = 'dlg:' + path + ':' + (row ? row['.id'] : 'new' + Date.now());
  const label = row ? itemLabel(row) : '';
  const title = (isNew ? 'New ' : '') + singular(m.title) + (label ? ' <' + label + '>' : '');
  const ro = S.info && !S.info.local && path.startsWith('/sim');
  openWin(id, title, { w: 560, h: Math.min(560, 140 + m.fields.filter(f => !f.ro).length * 30) }, w => {
    let cur = row ? { ...row } : {};
    const inputs = {}, touched = new Set();
    const main = h('div', { class: 'dlg-main' });
    const tabs = h('div', { class: 'tabs' });
    const gen = h('div', { class: 'form' });
    const stat = h('div', { class: 'form' });
    const traffic = h('div', { class: 'tabpane' });
    const isIf = path.startsWith('/interface') && !path.includes('/port') && !path.includes('list') && !path.includes('registration') && !path.includes('peers') && !path.includes('host') && !path.includes('/server/') && !path.endsWith('/server') && !path.includes('security') && !path.includes('access') && !path.includes('vlan') || path === '/interface/vlan';
    const panes = [['General', gen]];
    const roFields = m.fields.filter(f => f.ro);
    if (!isNew && roFields.length) panes.push(['Status', stat]);
    if (!isNew && isIf) panes.push(['Traffic', traffic]);
    if (panes.length > 1) {
      panes.forEach(([n, p], i) => { const b = h('button', { class: i ? '' : 'on' }, n); b.onclick = () => { $$('button', tabs).forEach(x => x.classList.toggle('on', x === b)); main.querySelectorAll('.form,.tabpane').forEach(x => x.hidden = x !== p); }; tabs.append(b); });
      main.append(tabs);
    }
    panes.forEach(([, p], i) => { p.hidden = i > 0; main.append(p); });
    const status = h('div', { class: 'status' });
    main.append(status);
    const editable = m.fields.filter(f => !f.ro && f.n !== 'disabled');
    const initial = isNew ? { ...Object.fromEntries(m.fields.filter(f => f.d).map(f => [f.n, f.d])), ...(preset || {}) } : row;
    for (const f of editable) {
      const lab = h('label', { class: f.req ? 'req' : '', title: f.n }, f.n.replace(/-/g, ' ').replace(/^./, c => c.toUpperCase()));
      const inp = inputFor(f, initial[f.n], () => touched.add(f.n));
      if (ro) inp.disabled = true;
      inputs[f.n] = inp;
      if (f.k === 'text') { gen.append(h('label', { class: 'full', style: { textAlign: 'left' } }, lab.textContent)); inp.classList.add('full'); gen.append(inp); }
      else gen.append(lab, inp);
    }
    if (preset) Object.keys(preset).forEach(k => touched.add(k));
    function renderStat() {
      stat.innerHTML = '';
      for (const f of roFields) { if (cur[f.n] == null) continue; stat.append(h('label', null, f.n), h('div', { class: 'ro' }, cellVal(m, f.n, cur[f.n]))); }
    }
    renderStat();
    const btns = h('div', { class: 'dlg-btns' });
    const mk = (t, fn, cls) => { const b = h('button', { class: cls || '' }, t); b.onclick = fn; btns.append(b); return b; };
    async function apply(close) {
      const args = {};
      for (const f of editable) {
        const v = inputs[f.n].getVal();
        if (isNew) { if (touched.has(f.n) || (f.req && v !== '')) args[f.n] = v; }
        else {
          let o = row[f.n] ?? '';
          if (f.k === 'bool') o = o === 'true' ? 'yes' : o === 'false' ? 'no' : (f.d === 'true' ? 'yes' : 'no');
          if (v !== o && !(v === '' && o === '')) args[f.n] = v;
        }
      }
      if (!isNew && !Object.keys(args).length) { if (close) w.close(); return true; }
      if (!isNew) args.numbers = row['.id'];
      const r = await exec(path + (isNew ? '/add' : '/set'), args);
      if (r.error) { status.innerHTML = ''; status.append(h('span', { class: 'err' }, `Couldn't ${isNew ? 'add new' : 'change'} ${singular(m.title)} - ${r.error}`)); return false; }
      status.textContent = isNew ? 'Added' : 'Saved';
      refreshAll();
      if (close) w.close();
      else if (isNew && r.ret) { w.close(); const rr = await exec(path + '/print', {}, ['?.id=' + r.ret]); if (rr.items && rr.items[0]) itemDialog(path, rr.items[0]); }
      return true;
    }
    if (!ro) mk('OK', () => apply(true), 'primary');
    mk('Cancel', () => w.close());
    if (!ro) mk('Apply', () => apply(false));
    if (!isNew && !ro) {
      if (m.F.disabled && !m.dyn) mk(row.disabled === 'true' ? 'Enable' : 'Disable', async () => { await exec(path + (row.disabled === 'true' ? '/enable' : '/disable'), { numbers: row['.id'] }); refreshAll(); w.close(); });
      if (!m.noAdd) mk('Copy', () => { const p = {}; editable.forEach(f => { const v = inputs[f.n].getVal(); if (v !== '') p[f.n] = v; }); if (p.name) p.name += '-copy'; itemDialog(path, null, p); });
      if (!m.noRemove) mk('Remove', async () => { const r = await exec(path + '/remove', { numbers: row['.id'] }); if (r.error) { status.innerHTML = ''; status.append(h('span', { class: 'err' }, r.error)); return; } refreshAll(); w.close(); }, 'danger');
      if (path === '/sim/client') { mk('Login…', () => loginVoucher(cur)); mk('Disconnect', () => exec('/sim/client/disconnect', { numbers: row['.id'] })); }
      if (path === '/system/script') mk('Run Script', () => exec('/system/script/run', { numbers: row['.id'] }));
      if (path === '/ip/hotspot/user') mk('Reset Counters', () => exec('/ip/hotspot/user/reset-counters', { numbers: row['.id'] }));
    }
    const dlg = h('div', { class: 'dlg' }, main, btns);
    w.body.append(dlg);
    if (!isNew) {
      w.every(2000, async () => {
        const r = await exec(path + '/print', {}, ['?.id=' + row['.id']]);
        if (r.items && r.items[0]) { cur = r.items[0]; renderStat(); }
      }, false);
      if (isIf) {
        const g = graph(traffic, ['Tx', 'Rx']);
        w.every(1000, async () => {
          const r = await exec('/interface/monitor-traffic', { interface: row.name, once: '' });
          const it = r.items && r.items[0]; if (it) g.push([+it['tx-bits-per-second'], +it['rx-bits-per-second']]);
        });
        w.onresize = () => g.resize();
      }
    }
    const first = gen.querySelector('input:not([type=checkbox]),select,textarea'); first && setTimeout(() => first.focus(), 30);
  });
}

function openSingle(path) {
  const m = menuOf(path); if (!m) return;
  openWin('single:' + path, m.title, { w: 520, h: Math.min(560, 120 + m.fields.length * 30) }, w => {
    const form = h('div', { class: 'form' });
    const status = h('div', { class: 'status' });
    const btns = h('div', { class: 'dlg-btns' });
    const main = h('div', { class: 'dlg-main' }, form, status);
    w.body.append(h('div', { class: 'dlg' }, main, btns));
    let row = {}, inputs = {};
    const editable = m.fields.filter(f => !f.ro);
    async function load(first) {
      const r = await exec(path + '/print');
      row = (r.items && r.items[0]) || {};
      if (first) {
        form.innerHTML = '';
        for (const f of editable) {
          const lab = h('label', { title: f.n }, f.n.replace(/-/g, ' ').replace(/^./, c => c.toUpperCase()));
          const inp = inputFor(f, row[f.n], () => { });
          inputs[f.n] = inp;
          if (f.k === 'text') { form.append(h('label', { class: 'full', style: { textAlign: 'left' } }, lab.textContent)); inp.classList.add('full'); form.append(inp); }
          else form.append(lab, inp);
        }
        if (m.fields.some(f => f.ro)) form.append(h('h4', null, 'Status'));
      }
      $$('.rostat', form).forEach(x => x.remove());
      for (const f of m.fields.filter(f => f.ro)) {
        if (row[f.n] == null) continue;
        form.append(h('label', { class: 'rostat' }, f.n), h('div', { class: 'ro rostat' }, cellVal(m, f.n, row[f.n])));
      }
    }
    async function apply(close) {
      const args = {};
      for (const f of editable) {
        let o = row[f.n] ?? ''; if (f.k === 'bool') o = o === 'true' ? 'yes' : 'no';
        const v = inputs[f.n].getVal(); if (v !== o) args[f.n] = v;
      }
      if (Object.keys(args).length) {
        const r = await exec(path + '/set', args);
        if (r.error) { status.innerHTML = ''; status.append(h('span', { class: 'err' }, r.error)); return; }
        status.textContent = 'Saved';
        if (path === '/system/identity') refreshInfo();
      }
      if (close) w.close(); else load(true);
    }
    if (editable.length) { const ok = h('button', { class: 'primary' }, 'OK'); ok.onclick = () => apply(true); btns.append(ok); }
    const c = h('button', {}, editable.length ? 'Cancel' : 'Close'); c.onclick = () => w.close(); btns.append(c);
    if (editable.length) { const a = h('button', {}, 'Apply'); a.onclick = () => apply(false); btns.append(a); }
    for (const cmd of (m.cmds || [])) { if (!CMD_LABEL[cmd]) continue; const b = h('button', {}, CMD_LABEL[cmd]); b.onclick = async () => { const r = await exec(path + '/' + cmd); status.textContent = r.error || 'Done'; load(false); }; btns.append(b); }
    load(true);
    if (m.fields.some(f => f.ro)) w.every(2000, () => load(false), false);
  });
}

function refreshAll() {
  for (const w of Object.values(S.wins)) w.kick && w.kick();
}

// ---------- graph ----------
function graph(container, names, colors = ['#0F7B8A', '#E0951A']) {
  const legend = h('div', { class: 'legend' });
  const vals = names.map(() => h('b'));
  names.forEach((n, i) => legend.append(h('span', null, h('i', { style: { background: colors[i] } }), n + ' ', vals[i])));
  const cv = h('canvas', { height: 160 });
  container.append(legend, cv);
  const data = names.map(() => []);
  const N = 90;
  function resize() { const r = cv.getBoundingClientRect(); const d = devicePixelRatio || 1; cv.width = Math.max(10, r.width * d); cv.height = Math.max(10, (r.height || 160) * d); draw(); }
  function draw() {
    const c = cv.getContext('2d'), W = cv.width, H = cv.height, d = devicePixelRatio || 1;
    c.clearRect(0, 0, W, H);
    let max = 1e3; data.forEach(s => s.forEach(v => { if (v > max) max = v; }));
    const nice = [1e3, 1e4, 5e4, 1e5, 5e5, 1e6, 2e6, 5e6, 1e7, 2e7, 5e7, 1e8, 2e8, 5e8, 1e9, 2e9, 1e10]; max = nice.find(x => x >= max * 1.1) || max * 1.2;
    c.strokeStyle = '#e3e7eb'; c.lineWidth = 1; c.fillStyle = '#7a8591'; c.font = `${11 * d}px Plex, sans-serif`;
    for (let i = 0; i <= 4; i++) { const y = Math.round(8 * d + (H - 16 * d) * i / 4) + .5; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); if (i < 4) c.fillText(fmtBps(max * (1 - i / 4)), 4 * d, y + 12 * d); }
    data.forEach((s, k) => {
      if (s.length < 2) return;
      c.beginPath();
      s.forEach((v, i) => { const x = W - (s.length - 1 - i) * W / (N - 1); const y = 8 * d + (H - 16 * d) * (1 - v / max); i ? c.lineTo(x, y) : c.moveTo(x, y); });
      c.strokeStyle = colors[k]; c.lineWidth = 1.6 * d; c.stroke();
      c.lineTo(W, H - 8 * d); c.lineTo(W - (s.length - 1) * W / (N - 1), H - 8 * d); c.closePath();
      c.globalAlpha = .1; c.fillStyle = colors[k]; c.fill(); c.globalAlpha = 1;
    });
  }
  setTimeout(resize, 30);
  new ResizeObserver(() => resize()).observe(cv);
  return { push(v) { v.forEach((x, i) => { data[i].push(x); if (data[i].length > N) data[i].shift(); vals[i].textContent = fmtBps(x); }); draw(); }, resize };
}

// ---------- dashboard: front panel ----------
const CABLE = { blue: '#2f6fd6', yellow: '#e8c33a', green: '#2ea05a', red: '#d24a3f', grey: '#8d969f', white: '#e9ecef', orange: '#e8892d', purple: '#7d55c7' };
const LOOKS = {
  metal: { body: ['#46525f', '#36414e', '#262e38'], stroke: '#1b2128', hi: '#6b7783', silk: '#aeb9c4', brand: '#e1e6eb', vent: '#1b2128' },
  black: { body: ['#3b3f45', '#25282d', '#141619'], stroke: '#0b0c0e', hi: '#666d75', silk: '#a3abb3', brand: '#f1f3f5', vent: '#08090a' },
  white: { body: ['#ffffff', '#f2f4f6', '#dce1e5'], stroke: '#a9b2ba', hi: '#ffffff', silk: '#5d6873', brand: '#2b3440', vent: null },
  virtual: { body: ['#4b5764', '#3d4855', '#303a45'], stroke: '#8c9aa8', hi: '#6b7783', silk: '#b5c0ca', brand: '#e8ecf0', vent: null, dash: true },
};
function natural(a, b) { return a.localeCompare(b, undefined, { numeric: true }); }
function portKey(i) { return i.default || i.name; }
function etherSort(a, b) { const ea = /^ether/.test(portKey(a)), eb = /^ether/.test(portKey(b)); if (ea !== eb) return ea ? -1 : 1; return natural(portKey(a), portKey(b)); }
function portNum(i) { const m = /^ether(\d+)$/.exec(portKey(i)); return m ? +m[1] : 0; }
function buildPanel(d, opt = {}) {
  const spec = d.panel || {}, look = LOOKS[spec.look] || LOOKS.metal;
  const rows = spec.rows === 2 ? 2 : 1;
  const ifs = d.ifaces || [];
  const isSfp = i => i.sfp || /^sfp/.test(portKey(i));
  const ethers = ifs.filter(i => i.type === 'ether' && !isSfp(i) && !i.dynamic).sort(etherSort);
  const sfps = ifs.filter(i => i.type === 'ether' && isSfp(i)).sort(etherSort);
  const wlans = ifs.filter(i => i.type === 'wlan' || i.type === 'wifi');
  let sizes = (spec.groups || []).slice();
  const total = sizes.reduce((a, b) => a + b, 0);
  if (!sizes.length) for (let i = 0; i < ethers.length; i += 8) sizes.push(Math.min(8, ethers.length - i));
  else if (total < ethers.length) sizes.push(ethers.length - total);
  const groups = []; let k = 0;
  for (const n of sizes) { if (k >= ethers.length) break; groups.push(ethers.slice(k, k + n)); k += n; }
  const poeIn = new Set(spec.poeIn || []), poeOut = new Set(spec.poeOut || []);
  const PW = 46, GAP = 22, RH = 60, ear = spec.rack ? 26 : 0;
  const top = opt.preview ? 6 : 24, CH = rows === 2 ? 172 : 116;
  const left = 170 + ear;
  let x = left, ports = '', cables = '', labels = '';
  const pos = [];
  groups.forEach(g => {
    const gx = x, cols = rows === 2 ? Math.ceil(g.length / 2) : g.length;
    g.forEach((p, j) => pos.push([p, gx + (rows === 2 ? Math.floor(j / 2) : j) * PW, top + 26 + (rows === 2 ? j % 2 : 0) * RH]));
    const gw = cols * PW - 6, names = g.map(portKey);
    const lab = names.length > 1 && names.every(n => /^ether/.test(n)) ? 'ether' + names[0].slice(5) + '–' + names[names.length - 1].slice(5) : names.join(' ');
    labels += `<path d="M${gx + 2} ${top + CH - 30}h${gw - 4}" stroke="${look.silk}" stroke-opacity=".5"/><text class="silk" fill="${look.silk}" x="${gx + gw / 2}" y="${top + CH - 17}" text-anchor="middle">${esc(lab)}</text>`;
    x = gx + cols * PW + GAP;
  });
  const sfpPos = [], sfpCols = rows === 2 ? Math.ceil(sfps.length / 2) : sfps.length;
  sfps.forEach((p, j) => sfpPos.push([p, x + (rows === 2 ? Math.floor(j / 2) : j) * 62, top + 26 + (rows === 2 ? j % 2 : 0) * RH]));
  if (sfps.length) { labels += `<text class="silk" fill="${look.silk}" x="${x + sfpCols * 31 - 5}" y="${top + CH - 17}" text-anchor="middle">${/plus/.test(portKey(sfps[0])) ? 'SFP+' : 'SFP'}</text>`; x += sfpCols * 62; }
  const W = Math.max(x + 70 + ear, 330), H = top + CH + (opt.preview ? 6 : 92);
  pos.forEach(([p, px, y], i) => {
    const n = portNum(p), lbl = n ? String(n) : portKey(p);
    ports += `<g class="port${p.disabled ? ' disabled-port' : ''}" data-if="${esc(p.name)}" tabindex="${opt.preview ? -1 : 0}">
      <rect class="house" x="${px}" y="${y}" width="40" height="36" rx="3"/>
      <path class="hole" d="M${px + 5} ${y + 6}h30v20h-8v5h-14v-5h-8z"/>
      <path d="M${px + 9} ${y + 8}v5M${px + 12} ${y + 8}v5M${px + 15} ${y + 8}v5M${px + 18} ${y + 8}v5M${px + 21} ${y + 8}v5M${px + 24} ${y + 8}v5M${px + 27} ${y + 8}v5M${px + 30} ${y + 8}v5" stroke="#b8963a" stroke-width="1"/>
      <rect class="led ${p.running ? 'link' : 'off'}" data-led="link" x="${px + 3}" y="${y - 7}" width="7" height="4" rx="1"/>
      <rect class="led off" data-led="act" x="${px + 30}" y="${y - 7}" width="7" height="4" rx="1"/>
      <text class="silk" fill="${look.silk}" x="${px + 20}" y="${y + 48}" text-anchor="middle">${esc(lbl)}</text>`;
    if (poeIn.has(n) || poeOut.has(n)) ports += `<path d="M${px + 34} ${y + 40}l-3.2 5h2.6l-1.2 4 4.4-5.6h-2.6z" fill="${poeOut.has(n) ? '#F0B429' : 'none'}" stroke="#F0B429" stroke-width=".8"/>`;
    if (p.cable && !opt.preview) {
      const col = CABLE[p.color] || CABLE.blue, dark = shade(col, -35);
      const cx = px + 20, dx = (i - (pos.length - 1) / 2) * 7;
      const path = `M${cx} ${y + 30} C${cx} ${y + 80}, ${cx + dx} ${top + CH + 20}, ${cx + dx * 1.5} ${H + 4}`;
      cables += `<path d="${path}" stroke="${dark}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="${path}" stroke="${col}" stroke-width="8" fill="none" stroke-linecap="round"/>`;
      ports += `<g class="plug" data-plug="${esc(p.name)}"><rect x="${px + 7}" y="${y + 9}" width="26" height="22" rx="2" fill="${col}" fill-opacity=".55" stroke="${dark}"/><rect x="${px + 10}" y="${y + 10}" width="20" height="4" fill="#d9c27a" opacity=".85"/><rect x="${px + 12}" y="${y + 30}" width="16" height="14" rx="3" fill="${col}" stroke="${dark}"/></g>`;
    }
    ports += '</g>';
  });
  sfpPos.forEach(([p, px, y]) => {
    ports += `<g class="port${p.disabled ? ' disabled-port' : ''}" data-if="${esc(p.name)}" tabindex="${opt.preview ? -1 : 0}">
      <rect class="house" x="${px}" y="${y + 4}" width="52" height="26" rx="2" style="fill:#8e9aa6;stroke:#5d6874"/>
      <rect x="${px + 5}" y="${y + 9}" width="42" height="14" rx="1" fill="#0a0d10"/>
      <rect class="led ${p.running ? 'link' : 'off'}" data-led="link" x="${px + 4}" y="${y - 6}" width="7" height="4" rx="1"/>
      <rect class="led off" data-led="act" x="${px + 41}" y="${y - 6}" width="7" height="4" rx="1"/>
      <text class="silk" fill="${look.silk}" x="${px + 26}" y="${y + 48}" text-anchor="middle">${esc(portKey(p).replace('sfp-sfpplus', 'sfp+').replace(/^sfp(\d)/, 'sfp$1'))}</text>`;
    if (p.cable && !opt.preview) {
      const col = CABLE[p.color] || CABLE.yellow;
      ports += `<g class="plug"><rect x="${px + 8}" y="${y + 11}" width="36" height="10" fill="#c9ced3" stroke="#6b747d"/></g>`;
      cables += `<path d="M${px + 26} ${y + 30} C${px + 26} ${y + 90}, ${px + 30} ${top + CH + 20}, ${px + 40} ${H + 4}" stroke="${col}" stroke-width="5" fill="none"/>`;
    }
    ports += '</g>';
  });
  const board = opt.board || (S.info && S.info.board) || 'Router';
  const mname = opt.board ? opt.modelName : (S.info && S.info.modelName);
  const bx = 22 + ear;
  const wl = wlans.map((w, i) => `<rect class="led ${w.running ? 'link' : 'off'}" data-wlan="${esc(w.name)}" x="${bx + 2 + (i % 2) * 64}" y="${top + 86 + Math.floor(i / 2) * 14}" width="8" height="5" rx="1"/><text class="silk" fill="${look.silk}" x="${bx + 14 + (i % 2) * 64}" y="${top + 91 + Math.floor(i / 2) * 14}">${esc(w.name)}</text>`).join('');
  const earsSvg = ear ? [4, W - ear - 4].map(ex => `<rect x="${ex}" y="${top + 2}" width="${ear + 2}" height="${CH - 4}" rx="3" fill="${look.body[1]}" stroke="${look.stroke}"/><rect x="${ex + ear / 2 - 3}" y="${top + 16}" width="8" height="16" rx="4" fill="#cfd6dc" stroke="${look.stroke}"/><rect x="${ex + ear / 2 - 3}" y="${top + CH - 34}" width="8" height="16" rx="4" fill="#cfd6dc" stroke="${look.stroke}"/>`).join('') : '';
  const gid = 'ch' + (opt.preview ? Math.random().toString(36).slice(2, 7) : '');
  const isCHR = spec.look === 'virtual';
  const size = opt.preview ? `width="100%" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet"` : `width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"`;
  return `<svg xmlns="http://www.w3.org/2000/svg" ${size} role="img" aria-label="Front panel of ${esc(board)}">
    <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${look.body[0]}"/><stop offset=".08" stop-color="${look.body[1]}"/><stop offset="1" stop-color="${look.body[2]}"/></linearGradient>
    <pattern id="vent${gid}" width="7" height="7" patternUnits="userSpaceOnUse"><circle cx="3.5" cy="3.5" r="1.4" fill="${look.vent || 'none'}"/></pattern></defs>
    ${cables}${earsSvg}
    <rect x="${4 + ear}" y="${top}" width="${W - 8 - 2 * ear}" height="${CH}" rx="${spec.look === 'white' ? 14 : 9}" fill="url(#${gid})" stroke="${look.stroke}" ${look.dash ? 'stroke-dasharray="6 4" stroke-width="1.5"' : ''}/>
    <rect x="${10 + ear}" y="${top + 3}" width="${W - 20 - 2 * ear}" height="1" fill="${look.hi}" opacity=".6"/>
    <text class="silk-b" fill="${look.brand}" x="${bx}" y="${top + 30}">${esc(board)}</text>
    <text class="silk" fill="${look.silk}" x="${bx}" y="${top + 46}">${isCHR ? 'virtual router' : (mname && mname !== board ? esc(mname) : '')}</text>
    <circle class="led ${opt.preview ? 'off' : 'pwr'}" data-sys="pwr" cx="${bx + 5}" cy="${top + 64}" r="3.2"/><text class="silk" fill="${look.silk}" x="${bx + 13}" y="${top + 67}">PWR</text>
    <circle class="led off" data-sys="usr" cx="${bx + 55}" cy="${top + 64}" r="3.2"/><text class="silk" fill="${look.silk}" x="${bx + 63}" y="${top + 67}">USR</text>
    ${isCHR ? '' : `<circle cx="${bx + 106}" cy="${top + 64}" r="3" fill="#111" stroke="${look.hi}"/><text class="silk" fill="${look.silk}" x="${bx + 100}" y="${top + 80}">RST</text>`}
    ${wl}
    ${look.vent ? `<rect x="${W - ear - 58}" y="${top + 14}" width="40" height="${CH - 28}" rx="4" fill="url(#vent${gid})" opacity=".9"/>` : ''}
    ${labels}${ports}
  </svg>`;
}
function shade(hex, amt) { const n = parseInt(hex.slice(1), 16); const c = v => Math.max(0, Math.min(255, v + amt)); return '#' + ((c(n >> 16) << 16) | (c((n >> 8) & 255) << 8) | c(n & 255)).toString(16).padStart(6, '0'); }

function showTip(e, html) { const t = $('#tip'); t.innerHTML = html; t.hidden = false; const x = Math.min(innerWidth - 290, e.clientX + 14), y = Math.min(innerHeight - t.offsetHeight - 8, e.clientY + 14); t.style.left = x + 'px'; t.style.top = y + 'px'; }
function hideTip() { $('#tip').hidden = true; }
function showPop(x, y, head, sub, actions) {
  const p = $('#pop'); p.innerHTML = '';
  p.append(h('div', { class: 'ph' }, head, sub ? h('small', null, sub) : null));
  actions.forEach(([label, fn]) => { const b = h('button', null, label); b.onclick = () => { p.hidden = true; fn(); }; p.append(b); });
  p.hidden = false; p.style.left = Math.min(innerWidth - 200, x) + 'px'; p.style.top = Math.min(innerHeight - p.offsetHeight - 8, y) + 'px';
}
addEventListener('pointerdown', e => { if (!e.target.closest('#pop')) $('#pop').hidden = true; });

function openDashboard() {
  const dr = deskRect();
  openWin('dash', 'Dashboard', { w: Math.min(1180, dr.width - 24), h: Math.min(780, dr.height - 20), x: 12, y: 10 }, w => {
    const root = h('div', { class: 'dash' });
    const panelWrap = h('div', { class: 'panel-wrap' });
    const panelSvg = h('div');
    panelWrap.append(panelSvg);
    if (S.info.local) {
      const cm = h('button', { class: 'panel-model' }, 'Change model'); cm.onclick = () => openSimulator('model');
      const pw = h('button', { class: 'panel-model pc' }, 'Wi-Fi on this PC'); pw.onclick = () => openPCWifi();
      panelWrap.append(h('div', { class: 'panel-btns' }, S.info.wireless ? pw : '', cm));
    }
    const gauges = h('div', { class: 'gauges' });
    const topo = h('div', { class: 'card' }, h('h3', null, 'Network map', h('span', { class: 'grow' }), h('span', { id: 'topoNote' }, 'click a device for actions')));
    const topoCv = h('canvas');
    topo.append(topoCv);
    const trafCard = h('div', { class: 'card' }, h('h3', null, 'WAN traffic'));
    const talkers = h('div', { class: 'talkers' });
    const grid = h('div', { class: 'dash-grid' }, topo, trafCard);
    root.append(panelWrap, gauges, grid);
    w.body.append(root);
    const g = graph(trafCard, ['Download', 'Upload']);
    trafCard.append(h('h3', { style: { borderTop: '1px solid var(--line-2)' } }, 'Top clients'), talkers);
    let data = null, panelKey = '', ledTimer;
    const topoState = new Topology(topoCv);
    w.closers.push(() => { clearInterval(ledTimer); topoState.stop(); });
    w.onresize = () => { g.resize(); topoState.resize(); };
    panelWrap.addEventListener('click', async e => {
      const p = e.target.closest('.port'); if (!p || !data) return;
      const it = data.ifaces.find(i => i.name === p.dataset.if);
      if (!it) return;
      if (!S.info.local) return itemDialogByName('/interface', it.name);
      if (!it.portId) return;
      await exec('/sim/port/' + (it.cable ? 'unplug' : 'plug'), { numbers: it.portId });
      load();
    });
    panelWrap.addEventListener('dblclick', e => { const p = e.target.closest('.port'); if (p) itemDialogByName('/interface', p.dataset.if); });
    panelWrap.addEventListener('pointermove', e => {
      const p = e.target.closest('.port'); if (!p || !data) return hideTip();
      const it = data.ifaces.find(i => i.name === p.dataset.if); if (!it) return;
      const poe = it.poe ? ' · PoE out' : ((data.panel && data.panel.poeIn || []).includes(+String(it.default || '').replace(/\D/g, '')) && /^ether/.test(it.default || '') ? ' · PoE in' : '');
      showTip(e, `<b>${esc(it.name)}</b>${it.comment ? ' <span class="dim">' + esc(it.comment) + '</span>' : ''}<br>${it.disabled ? 'disabled' : it.running ? 'link up · ' + esc(it.speed || '1G') + 'bps full duplex' : (it.cable === false ? 'no cable' : 'no link')}${poe}<br><span class="dim">rx</span> ${fmtBps(it.rx)} &nbsp;<span class="dim">tx</span> ${fmtBps(it.tx)}<br><span class="dim">${esc(it.mac || '')}</span><br><span class="dim">${S.info.local ? 'click to ' + (it.cable ? 'unplug' : 'plug in') + ' the cable · double-click for settings' : 'double-click for settings'}</span>`);
    });
    panelWrap.addEventListener('pointerleave', hideTip);
    ledTimer = setInterval(() => {
      if (!data || S.state !== 'running') return;
      for (const it of data.ifaces) {
        const el = panelWrap.querySelector(`.port[data-if="${CSS.escape(it.name)}"] [data-led=act]`); if (!el) continue;
        const rate = (it.rx || 0) + (it.tx || 0);
        const p = it.running ? Math.min(.95, .04 + Math.log10(1 + rate / 1000) * .2) : 0;
        el.setAttribute('class', 'led ' + (Math.random() < p ? 'act' : 'off'));
      }
      const usr = panelWrap.querySelector('[data-sys=usr]'); if (usr) usr.setAttribute('class', 'led ' + (data.cpu > 40 && Math.random() < .5 ? 'act' : 'off'));
    }, 85);
    function gauge(k, v, unit, pct, cls) {
      return `<div class="gauge ${cls || ''}"><div class="k">${k}</div><div class="v">${v}${unit ? '<small>' + unit + '</small>' : ''}</div>${pct != null ? `<div class="bar"><i style="width:${Math.max(2, Math.min(100, pct))}%"></i></div>` : ''}</div>`;
    }
    async function load() {
      let r;
      try { r = await (await fetch('/gui/dash?t=' + S.t)).json(); } catch { return; }
      if (r.expired) return backToLogin('Session expired');
      if (r.error) { if (r.state) setState(r.state); return; }
      data = r;
      const key = JSON.stringify(r.ifaces.map(i => [i.name, i.cable, i.running, i.disabled, i.color, i.type])) + (S.info && S.info.board);
      if (key !== panelKey) { panelKey = key; panelSvg.innerHTML = buildPanel(r); }
      const res = r.resource || {};
      const cpu = +res['cpu-load'] || 0, tot = +res['total-memory'] || 1, free = +res['free-memory'] || 0;
      const temp = (r.health || []).find(x => x.name === 'temperature'), volt = (r.health || []).find(x => x.name === 'voltage');
      const memPct = (1 - free / tot) * 100;
      gauges.innerHTML = gauge('CPU', cpu, '%', cpu, cpu > 80 ? 'hot' : cpu > 50 ? 'warn' : '') + gauge('Memory', Math.round(memPct), '% of ' + fmtBytes(tot).replace('.00', ''), memPct)
        + (temp ? gauge('Temperature', temp.value, '°C', (+temp.value - 20) * 1.4, +temp.value > 65 ? 'hot' : '') : '') + (volt ? gauge('Voltage', volt.value, 'V') : '')
        + gauge('Uptime', esc(res.uptime || ''), '') + gauge('Hotspot online', r.counts.hotspot, '') + gauge('PPPoE online', r.counts.ppp, '') + gauge('DHCP leases', r.counts.leases, '')
        + (r.wan !== undefined ? gauge('Internet', r.wan ? 'online' : 'offline', '') : '');
      const wan = r.ifaces.find(i => i.name === 'ether1') || r.ifaces.find(i => i.type === 'ether');
      if (wan) g.push([wan.rx, wan.tx]);
      const top = (r.clients || []).filter(c => c.status === 'connected').sort((a, b) => (b.down + b.up) - (a.down + a.up)).slice(0, 8);
      talkers.innerHTML = top.length ? top.map(c => `<div><span>${esc(c.user || c.pppoe || c.name)} <span style="color:var(--muted)">${esc(c.address || '')}</span></span><span>${fmtBps(c.down || 0)}</span></div>`).join('') : '<div><span style="color:var(--muted)">No active clients yet</span></div>';
      topoState.update(r);
    }
    w.every(1000, load);
    w.kick = load;
  });
}
async function itemDialogByName(path, name) {
  const r = await exec(path + '/print', {}, ['?name=' + name]);
  if (r.items && r.items[0]) {
    const t = r.items[0].type;
    const p = { ether: '/interface/ethernet', bridge: '/interface/bridge', vlan: '/interface/vlan', wlan: '/interface/wireless' }[t] || path;
    const rr = p === path ? r : await exec(p + '/print', {}, ['?name=' + name]);
    itemDialog(p, (rr.items && rr.items[0]) || r.items[0]);
  }
}

// ---------- dashboard: network map ----------
class Topology {
  constructor(cv) {
    this.cv = cv; this.parts = []; this.nodes = []; this.links = []; this.d = null; this.run = true; this.last = performance.now();
    this.resize(); new ResizeObserver(() => this.resize()).observe(cv);
    cv.addEventListener('click', e => this.click(e));
    cv.addEventListener('pointermove', e => this.hover(e));
    cv.addEventListener('pointerleave', hideTip);
    const loop = t => { if (!this.run) return; this.frame(t); requestAnimationFrame(loop); };
    requestAnimationFrame(loop);
  }
  stop() { this.run = false; }
  resize() { const r = this.cv.getBoundingClientRect(); this.dpr = devicePixelRatio || 1; this.W = Math.max(200, r.width); this.H = Math.max(260, r.height); this.cv.width = this.W * this.dpr; this.cv.height = this.H * this.dpr; this.layout(); }
  update(d) { this.d = d; this.layout(); }
  layout() {
    const d = this.d; if (!d) return;
    const W = this.W, H = this.H;
    const groups = {};
    for (const c of d.clients || []) { if (c.status === 'disconnected') continue; const k = c.pppoe ? 'PPPoE' : c.iface || '?'; (groups[k] = groups[k] || []).push(c); }
    const keys = Object.keys(groups).sort();
    this.inet = { x: 56, y: H / 2, kind: 'inet' };
    this.router = { x: Math.max(160, W * .24), y: H / 2, kind: 'router' };
    const nodes = [];
    const colX0 = this.router.x + 120, colW = Math.max(130, (W - colX0 - 10) / Math.max(1, keys.length));
    keys.forEach((k, gi) => {
      const list = groups[k].sort((a, b) => natural(a.name, b.name));
      const per = Math.max(1, Math.floor((H - 50) / 34));
      const cols = Math.ceil(list.length / per);
      list.forEach((c, i) => {
        const col = Math.floor(i / per), row = i % per, rows = Math.min(per, list.length - col * per);
        nodes.push({ c, group: k, x: colX0 + gi * colW + col * Math.min(70, colW / cols) + 10, y: H / 2 + (row - (rows - 1) / 2) * 34, kind: c.kind });
      });
      nodes.groupHeads = nodes.groupHeads || [];
      nodes.groupHeads.push({ k, x: colX0 + gi * colW, n: list.length });
    });
    this.nodes = nodes;
    this.heads = nodes.groupHeads || [];
  }
  spawn(dt) {
    const d = this.d; if (!d) return;
    const rate = (bps, max) => Math.min(max, Math.log10(1 + bps / 2000) * 1.6);
    const wanUp = d.wan !== false;
    let tot = 0; (d.clients || []).forEach(c => tot += (c.down || 0) + (c.up || 0));
    if (wanUp && Math.random() < rate(tot, 6) * dt) this.parts.push({ a: this.inet, b: this.router, t: 0, col: '#0F7B8A', sp: .9 });
    if (wanUp && Math.random() < rate(tot * .1, 3) * dt) this.parts.push({ a: this.router, b: this.inet, t: 0, col: '#E0951A', sp: .9 });
    for (const n of this.nodes) {
      if (Math.random() < rate(n.c.down || 0, 5) * dt) this.parts.push({ a: this.router, b: n, t: 0, col: '#0F7B8A', sp: .7 + Math.random() * .4 });
      if (Math.random() < rate(n.c.up || 0, 3) * dt) this.parts.push({ a: n, b: this.router, t: 0, col: '#E0951A', sp: .7 + Math.random() * .4 });
    }
    if (this.parts.length > 600) this.parts.splice(0, this.parts.length - 600);
  }
  curve(a, b, t) { const mx = (a.x + b.x) / 2; const x = (1 - t) ** 3 * a.x + 3 * (1 - t) ** 2 * t * mx + 3 * (1 - t) * t * t * mx + t ** 3 * b.x; const y = (1 - t) ** 3 * a.y + 3 * (1 - t) ** 2 * t * a.y + 3 * (1 - t) * t * t * b.y + t ** 3 * b.y; return [x, y]; }
  frame(now) {
    const dt = Math.min(.1, (now - this.last) / 1000); this.last = now;
    const c = this.cv.getContext('2d'), d = this.d; if (!c) return;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.clearRect(0, 0, this.W, this.H);
    if (!d) return;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!reduce && S.state === 'running') this.spawn(dt);
    const wanUp = d.wan !== false;
    // links
    const line = (a, b, col, w, dash) => { c.beginPath(); const mx = (a.x + b.x) / 2; c.moveTo(a.x, a.y); c.bezierCurveTo(mx, a.y, mx, b.y, b.x, b.y); c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.stroke(); c.setLineDash([]); };
    line(this.inet, this.router, wanUp ? '#9fb3c2' : '#d64545', 3, wanUp ? null : [6, 5]);
    for (const n of this.nodes) line(this.router, n, n.c.status === 'connected' ? '#c3ccd5' : '#e3b4b4', 1.2, n.c.status === 'connected' ? null : [3, 3]);
    // packets
    c.globalAlpha = .9;
    this.parts = this.parts.filter(p => { p.t += dt * p.sp; if (p.t >= 1) return false; const [x, y] = this.curve(p.a, p.b, p.t); c.beginPath(); c.arc(x, y, 2.2, 0, 7); c.fillStyle = p.col; c.fill(); return true; });
    c.globalAlpha = 1;
    // group heads
    c.font = '600 12px PlexCond, sans-serif'; c.fillStyle = '#4f5965'; c.textAlign = 'left';
    for (const g of this.heads) c.fillText(`${g.k} (${g.n})`, g.x, 18);
    // internet
    this.drawCloud(c, this.inet.x, this.inet.y, wanUp);
    // router
    const R = this.router;
    c.fillStyle = '#2B3440'; roundRect(c, R.x - 44, R.y - 20, 88, 40, 7); c.fill();
    c.fillStyle = '#34D058'; for (let i = 0; i < 5; i++) { c.fillRect(R.x - 34 + i * 14, R.y + 6, 8, 3); }
    c.fillStyle = '#fff'; c.font = '600 12px PlexCond, sans-serif'; c.textAlign = 'center';
    c.fillText(((S.info && S.info.identity) || 'router').slice(0, 13), R.x, R.y - 3);
    // clients
    for (const n of this.nodes) this.drawNode(c, n);
    if (!this.nodes.length) { c.fillStyle = '#76808c'; c.font = '12.5px Plex, sans-serif'; c.textAlign = 'left'; c.fillText(S.info && S.info.local ? 'No clients connected yet. Add one in Simulator, or open the hotspot login page.' : 'No DHCP or PPP clients found.', R.x + 70, 40); }
  }
  drawCloud(c, x, y, up) {
    c.beginPath(); c.arc(x - 14, y + 4, 13, 0, 7); c.arc(x + 2, y - 6, 17, 0, 7); c.arc(x + 18, y + 5, 12, 0, 7);
    c.fillStyle = up ? '#dbe7ee' : '#f3dcdc'; c.fill();
    c.fillStyle = up ? '#2b3440' : '#a33'; c.font = '500 11px PlexCond, sans-serif'; c.textAlign = 'center'; c.fillText(up ? 'Internet' : 'offline', x + 2, y + 34);
  }
  drawNode(c, n) {
    const cl = n.c, ok = cl.status === 'connected';
    const auth = cl.user || cl.pppoe || cl.auto === 'lan' || (!cl.user && cl.iface && !/hotspot/.test(cl.iface));
    const ring = !ok ? '#d64545' : cl.pppoe ? '#0F7B8A' : cl.user ? '#1f8a3b' : auth ? '#6d7c8a' : '#b8860b';
    c.beginPath(); c.arc(n.x, n.y, 11, 0, 7); c.fillStyle = '#fff'; c.fill(); c.lineWidth = 2; c.strokeStyle = ring; c.stroke();
    c.strokeStyle = '#2b3440'; c.lineWidth = 1.3; c.fillStyle = '#2b3440';
    const k = n.kind;
    if (k === 'phone' || k === 'tablet') { roundRect(c, n.x - 3.5, n.y - 6, 7, 12, 1.5); c.stroke(); }
    else if (k === 'laptop' || k === 'desktop') { c.strokeRect(n.x - 5, n.y - 5, 10, 7); c.beginPath(); c.moveTo(n.x - 7, n.y + 4); c.lineTo(n.x + 7, n.y + 4); c.stroke(); }
    else if (k === 'tv') { c.strokeRect(n.x - 6, n.y - 5, 12, 8); c.beginPath(); c.moveTo(n.x - 2, n.y + 6); c.lineTo(n.x + 2, n.y + 6); c.stroke(); }
    else if (k === 'cpe') { c.strokeRect(n.x - 6, n.y - 2, 12, 6); c.beginPath(); c.moveTo(n.x - 3, n.y - 2); c.lineTo(n.x - 5, n.y - 7); c.moveTo(n.x + 3, n.y - 2); c.lineTo(n.x + 5, n.y - 7); c.stroke(); }
    else { c.beginPath(); c.arc(n.x, n.y, 3, 0, 7); c.fill(); }
    if (cl.iface && /hotspot/.test(cl.iface) && !cl.user && ok) { c.fillStyle = '#b8860b'; c.fillRect(n.x + 6, n.y - 11, 6, 5); }
    c.fillStyle = '#1e252d'; c.font = '11.5px Plex, sans-serif'; c.textAlign = 'left';
    c.fillText((cl.user || cl.pppoe || cl.name || '').slice(0, 16), n.x + 16, n.y - 1);
    c.fillStyle = '#76808c'; c.font = '10.5px Plex, sans-serif';
    c.fillText(ok ? (cl.address || '') : cl.status, n.x + 16, n.y + 11);
  }
  pick(e) { const r = this.cv.getBoundingClientRect(); const x = e.clientX - r.left, y = e.clientY - r.top; return this.nodes.find(n => Math.hypot(n.x - x, n.y - y) < 14 || (x > n.x && x < n.x + 110 && Math.abs(y - n.y) < 12)); }
  hover(e) { const n = this.pick(e); this.cv.style.cursor = n ? 'pointer' : ''; if (!n) return hideTip(); const c = n.c; showTip(e, `<b>${esc(c.name)}</b> <span class="dim">${esc(c.kind)}</span><br>${esc(c.address || c.status)}<br><span class="dim">${esc(c.mac || '')}</span>${c.user ? '<br>hotspot user <b>' + esc(c.user) + '</b>' : ''}${c.pppoe ? '<br>PPPoE <b>' + esc(c.pppoe) + '</b>' : ''}<br><span class="dim">down</span> ${fmtBps(c.down)} <span class="dim">up</span> ${fmtBps(c.up)}`); }
  click(e) {
    const n = this.pick(e); if (!n || !S.info.local || !n.c.id) return;
    const c = n.c, acts = [];
    if (/hotspot/.test(c.iface || '') && !c.user && c.status === 'connected') acts.push(['Log in with a voucher…', () => loginVoucher({ '.id': c.id, name: c.name })]);
    if (c.user) acts.push(['Log out of hotspot', () => exec('/sim/client/logout', { numbers: c.id })]);
    acts.push(c.status === 'connected' ? ['Disconnect device', () => exec('/sim/client/disconnect', { numbers: c.id })] : ['Connect device', () => exec('/sim/client/connect', { numbers: c.id })]);
    acts.push(['Device settings…', async () => { const r = await exec('/sim/client/print', {}, ['?.id=' + c.id]); r.items && r.items[0] && itemDialog('/sim/client', r.items[0]); }]);
    showPop(e.clientX, e.clientY, c.name, `${c.address || ''} ${c.mac || ''}`, acts);
  }
}
function roundRect(c, x, y, w, hh, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + hh, r); c.arcTo(x + w, y + hh, x, y + hh, r); c.arcTo(x, y + hh, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }

// ---------- small command form ----------
function formDialog(title, fields, run, after) {
  openWin('form:' + title + Date.now(), title, { w: 420, h: 110 + fields.length * 32 }, w => {
    const form = h('div', { class: 'form' }), st = h('div', { class: 'status' }), inputs = {};
    for (const [k, label, ph] of fields) { inputs[k] = h('input', { placeholder: ph || '', spellcheck: 'false' }); form.append(h('label', null, label), inputs[k]); }
    const ok = h('button', { class: 'primary' }, 'Run'), cancel = h('button', {}, 'Cancel');
    ok.onclick = async () => {
      const a = {}; for (const [k] of fields) if (inputs[k].value !== '') a[k] = inputs[k].value;
      const r = await run(a);
      if (r && r.error) { st.innerHTML = ''; st.append(h('span', { class: 'err' }, r.error)); return; }
      w.close(); after && after();
    };
    cancel.onclick = () => w.close();
    w.body.append(h('div', { class: 'dlg' }, h('div', { class: 'dlg-main' }, form, st), h('div', { class: 'dlg-btns' }, ok, cancel)));
    setTimeout(() => form.querySelector('input').focus(), 30);
  });
}

// ---------- voucher login (simulator) ----------
async function loginVoucher(client) {
  if (!client) return alert('Select a virtual client first');
  const r = await exec('/ip/hotspot/user/print', {}, []);
  const users = (r.items || []).filter(u => u.default !== 'true');
  openWin('vlogin:' + client['.id'], 'Log in ' + client.name, { w: 400, h: 220 }, w => {
    const sel = h('select'); users.forEach(u => sel.append(h('option', { value: u.name }, `${u.name}  (${u.profile}${u['limit-uptime'] ? ', ' + u['limit-uptime'] : ''}, used ${u.uptime})`)));
    const pass = h('input', { type: 'text', placeholder: 'password (filled from the user)' });
    const fill = () => { const u = users.find(x => x.name === sel.value); pass.value = u ? (u.password || '') : ''; };
    sel.onchange = fill; fill();
    const st = h('div', { class: 'status' });
    const form = h('div', { class: 'form' }, h('label', null, 'Voucher'), sel, h('label', null, 'Password'), pass);
    const ok = h('button', { class: 'primary' }, 'Log in'); const cancel = h('button', {}, 'Cancel');
    ok.onclick = async () => { const res = await exec('/sim/client/login', { numbers: client['.id'], user: sel.value, password: pass.value }); if (res.error) { st.innerHTML = ''; st.append(h('span', { class: 'err' }, res.error)); } else { w.close(); refreshAll(); } };
    cancel.onclick = () => w.close();
    w.body.append(h('div', { class: 'dlg' }, h('div', { class: 'dlg-main' }, form, st), h('div', { class: 'dlg-btns' }, ok, cancel)));
  });
}

// ---------- terminal ----------
function openTerminal() {
  if (!S.info.local) {
    return openWin('term-remote', 'Terminal', { w: 520, h: 200 }, w => w.body.append(h('div', { class: 'note' }, 'The built-in terminal is available for simulated routers. For a real MikroTik router use SSH (port 22) or its own WinBox.')));
  }
  const n = ++S.termN;
  openWin('term' + n, 'Terminal <' + n + '>', { w: 820, h: 460 }, w => {
    const host = h('div', { class: 'term-host' });
    w.body.append(host);
    const term = new Terminal({ fontFamily: 'PlexMono, Consolas, monospace', fontSize: 13.5, cursorBlink: true, theme: { background: '#1b2129', foreground: '#d8dee6', cursor: '#F0B429', selectionBackground: '#3d4a58', cyan: '#5fc6d3', brightBlack: '#7d8996', blue: '#6aa3e8', green: '#6cd88a', yellow: '#f0c25a', red: '#ff7a7a' }, scrollback: 3000 });
    const fit = new FitAddon.FitAddon(); term.loadAddon(fit);
    term.open(host);
    setTimeout(() => { try { fit.fit(); } catch { } }, 20);
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/gui/term?t=${S.t}&cols=${term.cols}`);
    ws.onmessage = e => term.write(e.data);
    ws.onclose = () => term.write('\r\n\x1b[2m[disconnected]\x1b[0m\r\n');
    term.onData(d => ws.readyState === 1 && ws.send(d));
    const sendSize = () => { try { fit.fit(); } catch { } if (ws.readyState === 1) ws.send('\x01' + JSON.stringify({ cols: term.cols })); };
    ws.onopen = () => { sendSize(); term.focus(); };
    w.onresize = sendSize;
    new ResizeObserver(sendSize).observe(host);
    w.el.addEventListener('mousedown', () => setTimeout(() => term.focus()));
    w.closers.push(() => { ws.close(); term.dispose(); });
  });
}

// ---------- tools ----------
function openTraffic() {
  openWin('traffic', 'Traffic Monitor', { w: 640, h: 360 }, async w => {
    const sel = h('select');
    const r = await exec('/interface/print', { '.proplist': 'name' });
    (r.items || []).forEach(i => sel.append(h('option', { value: i.name }, i.name)));
    const tb = h('div', { class: 'tb' }, h('span', null, 'Interface '), sel);
    const pane = h('div', { class: 'tabpane' });
    w.body.append(tb, pane);
    const g = graph(pane, ['Tx', 'Rx']);
    sel.onchange = () => { g.resize(); };
    w.every(1000, async () => { const r = await exec('/interface/monitor-traffic', { interface: sel.value || 'ether1', once: '' }); const it = r.items && r.items[0]; if (it) g.push([+it['tx-bits-per-second'], +it['rx-bits-per-second']]); });
    w.onresize = () => g.resize();
  });
}
function openPing(trace) {
  openWin(trace ? 'trace' : 'ping', trace ? 'Traceroute' : 'Ping', { w: 620, h: 380 }, w => {
    const addr = h('input', { value: '8.8.8.8', style: { width: '200px' } });
    const count = h('input', { value: '4', style: { width: '60px' } });
    const start = h('button', { class: 'primary' }, 'Start'), stop = h('button', {}, 'Stop');
    const tb = h('div', { class: 'tb' }, h('span', null, 'Address '), addr, trace ? '' : h('span', null, ' Count '), trace ? '' : count, start, stop);
    const tbl = h('table', { class: 'tbl' }); const tbody = h('tbody');
    tbl.append(h('thead', null, h('tr', null, ...(trace ? ['#', 'Address', 'Loss', 'Last', 'Status'] : ['Seq', 'Host', 'Time', 'TTL', 'Size', 'Status']).map(x => h('th', null, x)))), tbody);
    const st = h('div', { class: 'status' });
    w.body.append(tb, h('div', { class: 'tbl-wrap' }, tbl), st);
    let running = false;
    stop.onclick = () => running = false;
    start.onclick = async () => {
      tbody.innerHTML = ''; running = true; st.textContent = '';
      if (trace) {
        const r = await exec('/tool/traceroute', { address: addr.value });
        if (r.error) { st.textContent = r.error; return; }
        (r.items || []).forEach((it, i) => tbody.append(h('tr', null, h('td', null, i + 1), h('td', null, it.address), h('td', null, it.loss), h('td', null, it.last || ''), h('td', null, it.status || ''))));
        return;
      }
      const n = +count.value || 4; let sent = 0, recv = 0;
      for (let i = 0; i < n && running; i++) {
        const r = await exec('/ping', { address: addr.value, count: '1' });
        if (r.error) { st.textContent = r.error; break; }
        const it = r.items[0] || {}; sent++; if (!it.status) recv++;
        tbody.append(h('tr', null, h('td', null, i), h('td', null, it.host), h('td', null, it.time || ''), h('td', null, it.ttl || ''), h('td', null, it.size || ''), h('td', { style: { color: it.status ? 'var(--red)' : '' } }, it.status || '')));
        st.textContent = `sent ${sent}, received ${recv}, packet loss ${Math.round((sent - recv) * 100 / sent)}%`;
        if (i + 1 < n) await new Promise(r => setTimeout(r, 800));
      }
      running = false;
    };
  });
}
function openResources() {
  openWin('resources', 'Resources', { w: 560, h: 480 }, w => {
    const form = h('div', { class: 'form', style: { flex: 'none' } });
    const pane = h('div', { class: 'tabpane', style: { minHeight: '150px' } });
    w.body.append(form, pane);
    const g = graph(pane, ['CPU load'], ['#0F7B8A']);
    const m = menuOf('/system/resource');
    w.every(1000, async () => {
      const r = await exec('/system/resource/print'); const it = r.items && r.items[0]; if (!it) return;
      form.innerHTML = '';
      for (const f of m.fields) if (it[f.n] != null) form.append(h('label', null, f.n), h('div', { class: 'ro' }, cellVal(m, f.n, it[f.n]) + (f.n === 'cpu-load' ? ' %' : f.n === 'cpu-frequency' ? ' MHz' : '')));
      g.push([+it['cpu-load'] * 1e4]);
    });
    w.onresize = () => g.resize();
    pane.querySelector('.legend b').style.display = 'none';
  });
}
async function doBackup() {
  const name = prompt('Backup name', ((S.info && S.info.identity) || 'router') + '-backup'); if (!name) return;
  const r = await exec('/system/backup/save', { name });
  alert(r.error ? r.error : `Backup ${name}.backup saved. You can see it in Files and restore it with /system backup load.`);
}
function powerAsk(kind) {
  if (!S.info.local) { if (kind === 'reboot' && confirm('Reboot the router?')) exec('/system/reboot'); return; }
  const q = { reboot: 'Reboot the router?', shutdown: 'Shut down the router? You can power it on again from this window.', reset: 'Reset the configuration to factory defaults? All settings, vouchers and secrets will be lost.' }[kind];
  if (!confirm(q)) return;
  if (kind === 'reset') exec('/system/reset-configuration'); else post('/gui/power', { t: S.t, action: kind === 'reboot' ? 'reboot' : 'off' });
}
function portalURL() { const s = S.info && S.info.services || {}; const host = location.hostname; return `http://${host}:${s.www || location.port}/login`; }

// ---------- simulator window ----------
function openSimulator(tab) {
  if (!S.info.local) return;
  const w0 = S.wins.sim; if (w0) { focusWin(w0); w0.el.classList.remove('minimized'); w0.show && tab && w0.show(tab); return; }
  openWin('sim', 'Simulator', { w: 900, h: 600 }, w => {
    const tabs = h('div', { class: 'tabs' });
    const holder = h('div', { class: 'tabpane' });
    w.body.append(tabs, holder);
    const panes = {};
    const defs = [['overview', 'Power & behaviour'], ['model', 'Router model'], ['vouchers', 'Vouchers'], ['clients', 'Virtual clients'], ['ports', 'Ports & cables']];
    defs.forEach(([k, n]) => { const b = h('button', { 'data-k': k }, n); b.onclick = () => show(k); tabs.append(b); });
    function show(k) {
      $$('button', tabs).forEach(b => b.classList.toggle('on', b.dataset.k === k));
      if (!panes[k]) panes[k] = build(k);
      holder.innerHTML = ''; holder.append(panes[k].el); panes[k].refresh && panes[k].refresh();
      w.cur = k;
    }
    w.show = show;
    function build(k) {
      if (k === 'clients') return tableView('/sim/client', { preset: { kind: 'phone', interface: 'bridge-hotspot' } });
      if (k === 'ports') return tableView('/sim/port');
      if (k === 'overview') {
        const el = h('div', { style: { overflow: 'auto', flex: 1 } });
        const st = h('span', { class: 'pill' }, h('i'), 'running');
        const p1 = h('div', { class: 'sim-sec' }, h('h4', null, 'Power'), h('p', null, 'Reboot drops every API, SSH and Telnet session and clears dynamic entries, the same way a real router does. Use it to check that your app reconnects.'),
          h('div', { class: 'row-btns' }, st, btn('Reboot', () => powerAsk('reboot')), btn('Shut down', () => powerAsk('shutdown')), btn('Reset configuration', () => powerAsk('reset'))));
        const formHost = h('div', { class: 'form', style: { padding: 0, overflow: 'visible', gridTemplateColumns: '170px minmax(0,240px)' } });
        const applyBtn = btn('Apply settings', apply, 'primary');
        const p2 = h('div', { class: 'sim-sec' }, h('h4', null, 'Simulated network behaviour'), h('p', null, 'Auto hotspot clients arrive on the hotspot bridge and log in with unused vouchers, like real customers. Auto PPPoE clients dial in with every enabled secret.'), formHost, h('div', { class: 'row-btns', style: { marginTop: '8px' } }, applyBtn));
        const s = S.info.services || {};
        const p3 = h('div', { class: 'sim-sec' }, h('h4', null, 'Connect your app'),
          h('p', null, `Point the TapTap app (or any RouterOS tool) at ${S.info.hostIP || location.hostname}. Log in as admin with the router password.`),
          h('div', { class: 'chips' }, ...[['RouterOS API', s.api], ['API-SSL', s['api-ssl']], ['REST', s.www ? `http://${S.info.hostIP}:${s.www}/rest` : ''], ['SSH', s.ssh], ['Telnet', s.telnet], ['Hotspot page', portalURL()]].filter(x => x[1]).map(([a, b]) => h('span', null, a + ' ', h('code', null, String(b))))));
        el.append(p1, p2, p3);
        const m = menuOf('/sim/settings'); const inputs = {}; let row = {};
        async function refresh() {
          const r = await exec('/sim/settings/print'); row = (r.items && r.items[0]) || {};
          if (!formHost.childElementCount) for (const f of m.fields) { const inp = inputFor(f, row[f.n], () => { }); inputs[f.n] = inp; formHost.append(h('label', null, f.n.replace(/-/g, ' ').replace(/^./, c => c.toUpperCase()).replace('pppoe', 'PPPoE').replace('wan', 'WAN').replace('lan', 'LAN')), inp); }
          const sr = await (await fetch('/gui/state')).json();
          st.className = 'pill ' + (sr.state === 'running' ? '' : sr.state === 'off' ? 'off' : 'boot'); st.lastChild.textContent = sr.state + ' · up ' + fmtUp(sr.uptime);
        }
        async function apply() {
          const args = {}; for (const f of m.fields) { let o = row[f.n] ?? ''; if (f.k === 'bool') o = o === 'true' ? 'yes' : 'no'; const v = inputs[f.n].getVal(); if (v !== o) args[f.n] = v; }
          if (Object.keys(args).length) { const r = await exec('/sim/settings/set', args); if (r.error) alert(r.error); }
          refresh();
        }
        return { el, refresh };
      }
      if (k === 'model') return modelPicker(w);
      if (k === 'vouchers') {
        const el = h('div', { style: { display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 } });
        const count = h('input', { value: '10', style: { width: '64px' } });
        const prof = h('select'); const len = h('input', { value: '6', style: { width: '50px' } });
        const prefix = h('input', { placeholder: 'optional', style: { width: '90px' } });
        const lu = h('input', { placeholder: 'e.g. 1h', style: { width: '80px' } });
        const lb = h('input', { placeholder: 'e.g. 500M', style: { width: '90px' } });
        const charset = h('select', null, h('option', { value: 'mixed' }, 'letters + digits'), h('option', { value: 'numbers' }, 'digits only'));
        const out = h('textarea', { class: 'vout', readonly: true, placeholder: 'Generated codes appear here, one per line.' });
        const gen = btn('Generate', async () => {
          const r = await exec('/sim/generate-vouchers', { count: count.value, profile: prof.value, length: len.value, prefix: prefix.value, 'limit-uptime': lu.value, 'limit-bytes-total': lb.value, charset: charset.value });
          if (r.error) return alert(r.error);
          out.value = (r.items || []).map(i => i.name).join('\n'); users.refresh();
        }, 'primary');
        const sec = h('div', { class: 'sim-sec' }, h('h4', null, 'Generate hotspot vouchers'), h('p', null, 'Creates hotspot users with the code as both name and password, exactly as a voucher app would through the API.'),
          h('div', { class: 'row-btns' }, 'Count', count, 'Profile', prof, 'Length', len, 'Prefix', prefix, 'Uptime limit', lu, 'Data limit', lb, charset, gen), out);
        const users = tableView('/ip/hotspot/user');
        el.append(sec, users.el);
        exec('/ip/hotspot/user/profile/print').then(r => (r.items || []).forEach(p => prof.append(h('option', { value: p.name }, p.name))));
        return { el, refresh: users.refresh };
      }
    }
    function btn(t, fn, cls) { const b = h('button', { class: cls || '' }, t); b.onclick = fn; return b; }
    show(tab || 'overview');
    w.every(2000, () => panes[w.cur] && panes[w.cur].refresh && panes[w.cur].refresh(), false);
  });
}
function fmtMem(mb) { return mb >= 1024 ? (mb / 1024) + ' GB' : mb + ' MB'; }
function modelPicker(w) {
  const el = h('div', { class: 'mp' });
  const filters = h('div', { class: 'mp-filters', role: 'group', 'aria-label': 'Filter models' });
  const grid = h('div', { class: 'mp-grid' });
  const keep = h('input', { type: 'checkbox' }); keep.checked = true;
  const selName = h('span', { class: 'mp-sel' }, 'Choose a model');
  const go = h('button', { class: 'primary', disabled: true }, 'Switch router model');
  const bar = h('div', { class: 'mp-bar' }, selName, h('label', { class: 'chk' }, keep, ' Keep vouchers, hotspot and PPP users, profiles, admin users and files'), h('span', { class: 'grow' }), go);
  el.append(filters, grid, bar);
  let models = [], fam = 'all', chosen = null, current = null;
  const FAMS = [['all', 'All'], ['home', 'Home & office'], ['router', 'Routers'], ['ccr', 'Cloud Core'], ['switch', 'Switches'], ['ap', 'Access points'], ['virtual', 'Virtual']];
  FAMS.forEach(([k, n]) => { const b = h('button', { class: k === fam ? 'on' : '', 'data-f': k }, n); b.onclick = () => { fam = k; $$('button', filters).forEach(x => x.classList.toggle('on', x.dataset.f === k)); render(); }; filters.append(b); });
  function previewData(m) {
    return { panel: m.panel, ifaces: [...(m.ether || []).map(n => ({ name: n, default: n, type: 'ether' })), ...(m.sfp || []).map(n => ({ name: n, default: n, type: 'ether', sfp: true })), ...(m.wireless || []).map(n => ({ name: n, type: m.wkind }))] };
  }
  function select(m) {
    chosen = m.key;
    $$('.mp-card', grid).forEach(c => c.classList.toggle('on', c.dataset.k === chosen));
    selName.textContent = m.key === current ? `${m.board} is the current model` : `Switch to ${m.board}`;
    go.disabled = m.key === current;
  }
  function render() {
    grid.innerHTML = '';
    for (const m of models.filter(x => fam === 'all' || x.family === fam)) {
      const pv = h('div', { class: 'pv look-' + m.panel.look, html: buildPanel(previewData(m), { preview: true, board: m.board, modelName: m.name }) });
      const card = h('div', { class: 'mp-card' + (m.key === chosen ? ' on' : ''), 'data-k': m.key, role: 'button', tabindex: 0, 'aria-label': m.board }, pv,
        h('div', { class: 'mp-name' }, m.board, m.current ? h('span', { class: 'cur-tag' }, 'current') : ''),
        h('div', { class: 'mp-code' }, m.name),
        h('dl', null, h('dt', null, 'Ports'), h('dd', null, m.summary || '—'), h('dt', null, 'CPU'), h('dd', null, `${m.cores} × ${m.mhz} MHz, ${m.arch}`), h('dt', null, 'Memory'), h('dd', null, `${fmtMem(m.mem)} RAM, ${fmtMem(m.hdd)} storage`)),
        h('p', null, m.desc));
      card.onclick = () => select(m);
      card.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(m); } };
      card.ondblclick = () => { select(m); go.click(); };
      grid.append(card);
    }
  }
  go.onclick = async () => {
    const m = models.find(x => x.key === chosen); if (!m || m.key === current) return;
    const msg = `Switch this router to ${m.board} (${m.name})?\n\nThe router reboots with ${m.board} hardware and the default configuration for it (interfaces, bridges, DHCP, hotspot and PPPoE server).` + (keep.checked ? '\n\nVouchers, hotspot and PPP users, profiles, admin users, scripts and files are kept.' : '\n\nEverything else is reset to defaults, including vouchers and PPP secrets.');
    if (!confirm(msg)) return;
    const r = await exec('/sim/change-model', { model: m.key, 'keep-users': keep.checked ? 'yes' : 'no' });
    if (r.error) return alert(r.error);
    setState('booting');
  };
  async function refresh() {
    if (models.length && current === (S.info && S.info.model)) return;
    const r = await (await fetch('/gui/models')).json();
    models = r.models; current = r.current;
    if (!chosen) chosen = current;
    render(); const m = models.find(x => x.key === chosen); if (m) select(m);
  }
  return { el, refresh };
}
function fmtUp(s) { s = +s || 0; const d = Math.floor(s / 86400), hh = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + 'd' : '') + (hh ? hh + 'h' : '') + m + 'm' + (s % 60) + 's'; }

// ---------- menu ----------
function renderMenu() {
  const nav = $('#menu'); nav.innerHTML = '';
  for (const it of MENU) {
    if (it.sep) { nav.append(h('div', { class: 'menu-sep' })); continue; }
    if (it.local && !S.info.local) continue;
    if (it.show && !it.show()) continue;
    const row = h('div', { class: 'mi ' + (it.cls || ''), tabindex: 0, role: 'button', html: ico(it.i) + `<span>${esc(it.n)}</span>` + (it.kids ? chev : '') });
    nav.append(row);
    const go = fn => () => { fn(); if (matchMedia('(max-width:860px)').matches) $('#app').classList.remove('showmenu'); };
    if (it.kids) {
      const sub = h('div', { class: 'sub' });
      for (const [n, target] of it.kids) {
        const k = h('div', { class: 'mi', tabindex: 0, role: 'button' }, n);
        k.onclick = go(() => open(target));
        k.onkeydown = e => e.key === 'Enter' && k.onclick();
        sub.append(k);
      }
      row.onclick = () => { row.classList.toggle('open'); sub.classList.toggle('open'); };
      nav.append(sub);
    } else row.onclick = go(() => it.a ? it.a() : open(it.w));
    row.onkeydown = e => e.key === 'Enter' && row.onclick();
  }
  function open(t) { if (typeof t === 'function') return t(); if (t.startsWith('/')) return openSingle(t); openList(t); }
}

// ---------- state / overlay ----------
function setState(st) {
  if (st === S.state) return;
  S.state = st;
  const ov = $('#overlay');
  if (st === 'running') { ov.hidden = true; refreshInfo(); return; }
  ov.hidden = false; ov.innerHTML = '';
  if (st === 'booting') ov.append(h('div', { class: 'ov-box' }, h('h2', null, 'Rebooting'), h('p', null, 'Sessions were dropped. Reconnecting when the router is back…'), h('div', { class: 'ov-prog' }, h('i', { style: { animationDuration: '6s' } }))));
  else if (st === 'off') {
    const b = h('button', null, 'Power on'); b.onclick = () => post('/gui/power', { t: S.t, action: 'on' });
    ov.append(h('div', { class: 'ov-box' }, h('h2', null, 'Router is powered off'), h('p', null, 'All services are down, like an unplugged router.'), S.info && S.info.local ? b : ''));
  }
}
async function pollState() {
  if (!S.t || !S.info || !S.info.local) return;
  try { const r = await (await fetch('/gui/state')).json(); setState(r.state); } catch { setState('booting'); }
}
async function refreshInfo() {
  if (!S.t) return;
  try {
    const r = await (await fetch('/gui/info?t=' + S.t)).json();
    if (r.error) return;
    const before = S.info && S.info.model;
    S.info = { ...S.info, ...r }; renderTop();
    if (before !== S.info.model) { renderMenu(); Object.values(S.wins).forEach(w => w.kick && w.kick()); }
  } catch { }
}
function renderTop() {
  const i = S.info;
  $('#sessTitle').innerHTML = `<b>${esc(i.user)}@${esc(i.target || '127.0.0.1')}</b> (${esc(i.identity || '')}) - ${i.local ? 'TikLab simulating ' : ''}RouterOS ${esc(i.version || '')} on ${esc(i.board || '')}${i.arch ? ' (' + esc(i.arch) + ')' : ''}`;
  document.title = `${i.user}@${i.target || '127.0.0.1'} (${i.identity || ''}) - TikLab`;
  $('#portalLink').hidden = !i.local; $('#portalLink').href = portalURL();
  const s = i.services || {};
  $('#svcInfo').innerHTML = i.local ? [['API', s.api], ['API-SSL', s['api-ssl']], ['REST', s.www], ['SSH', s.ssh], ['Telnet', s.telnet]].filter(x => x[1]).map(([a, b]) => `<span>${a} <b>${b}</b></span>`).join('') : '<span>managed over the RouterOS API</span>';
}
async function topStats() {
  if (!S.t || S.state !== 'running') return;
  const r = await exec('/system/resource/print', { '.proplist': 'cpu-load,uptime,free-memory,total-memory' });
  const it = r.items && r.items[0]; if (!it) return;
  $('#topStats').innerHTML = `<span>CPU <b>${it['cpu-load']}%</b></span><span>Uptime <b>${esc(it.uptime)}</b></span><span>Free memory <b>${fmtBytes(it['free-memory'])}</b></span>`;
}

// ---------- login ----------
function showLogin(msg) {
  $('#app').hidden = true; $('#login').hidden = false;
  if (msg) { $('#lgMsg').textContent = msg; $('#lgMsg').className = 'lg-msg'; }
  loadNeighbors(); renderSaved();
}
function backToLogin(msg) {
  if (!S.t) return;
  S.t = null;
  Object.values(S.wins).forEach(closeWin);
  showLogin(msg);
}
async function logout() {
  if (S.t) post('/gui/logout', { t: S.t });
  S.t = null; Object.values(S.wins).forEach(closeWin); showLogin('Disconnected.');
}
async function loadNeighbors(refresh) {
  if (!$('#app').hidden) return;
  let r; try { r = await (await fetch('/gui/neighbors' + (refresh ? '?refresh=1' : ''))).json(); } catch { return; }
  const tb = $('#nbTable tbody'); tb.innerHTML = '';
  const rows = [{ ...r.self }, ...(r.list || [])];
  for (const n of rows) {
    const tr = h('tr', { 'data-ip': n.self ? '127.0.0.1' : n.ip + (n.tiklab && n.api && n.api !== 8728 ? ':' + n.api : '') },
      h('td', null, n.mac || ''), h('td', null, n.self ? (n.ip || '127.0.0.1') : n.ip, n.self ? h('span', { class: 'self-tag' }, 'this simulator') : n.tiklab ? h('span', { class: 'lab-tag' }, 'TikLab') : ''),
      h('td', null, n.identity || ''), h('td', null, n.version || ''), h('td', null, n.board || ''), h('td', null, n.uptime || ''));
    tr.ondblclick = () => { $('#lgHost').value = tr.dataset.ip; $('#lgPass').focus(); };
    tr.onclick = () => { $$('#nbTable tr').forEach(x => x.classList.remove('sel')); tr.classList.add('sel'); $('#lgHost').value = tr.dataset.ip; };
    tb.append(tr);
  }
}
function renderSaved() {
  const tb = $('#svTable tbody'); tb.innerHTML = '';
  const list = store.get('saved', []);
  if (!list.length) tb.append(h('tr', null, h('td', { colspan: 4, style: { color: 'var(--muted)' } }, 'No saved routers yet. Fill in the form and choose "Add to saved".')));
  list.forEach((s, i) => {
    const del = h('button', { class: 'ghost' }, 'Remove'); del.onclick = e => { e.stopPropagation(); list.splice(i, 1); store.set('saved', list); renderSaved(); };
    const tr = h('tr', null, h('td', null, s.host), h('td', null, s.user), h('td', null, s.pass ? 'password kept' : ''), h('td', null, del));
    tr.ondblclick = tr.onclick = () => { $('#lgHost').value = s.host; $('#lgUser').value = s.user; $('#lgPass').value = s.pass || ''; };
    tb.append(tr);
  });
}
async function doLogin(e) {
  e && e.preventDefault();
  const host = $('#lgHost').value.trim(), user = $('#lgUser').value.trim(), pass = $('#lgPass').value;
  const msg = $('#lgMsg'); msg.className = 'lg-msg ok'; msg.textContent = 'Connecting to ' + host + '…';
  $('#lgBtn').disabled = true;
  let r;
  try { r = await post('/gui/login', { host, user, password: pass }); } catch { r = { error: 'ERROR: simulator not reachable' }; }
  $('#lgBtn').disabled = false;
  if (r.error) { msg.className = 'lg-msg'; msg.textContent = r.error; return; }
  msg.textContent = 'Logging in… loading menus…';
  store.set('last', { host, user, pass: $('#lgKeep').checked ? pass : '' , keep: $('#lgKeep').checked });
  S.t = r.t; S.info = r; S.state = 'running';
  $('#login').hidden = true; $('#app').hidden = false; $('#overlay').hidden = true;
  renderTop(); renderMenu();
  openDashboard();
  topStats();
}

async function boot() {
  const sc = await (await fetch('/gui/schema')).json();
  for (const m of sc.menus) { m.F = {}; for (const f of m.fields) m.F[f.n] = f; S.menus[m.path] = m; }
  const last = store.get('last', null);
  if (last) { $('#lgHost').value = last.host || '127.0.0.1'; $('#lgUser').value = last.user || 'admin'; $('#lgPass').value = last.pass || ''; $('#lgKeep').checked = !!last.keep; }
  $('#loginForm').onsubmit = doLogin;
  $('#lgSave').onclick = () => { const list = store.get('saved', []); list.push({ host: $('#lgHost').value, user: $('#lgUser').value, pass: $('#lgKeep').checked ? $('#lgPass').value : '' }); store.set('saved', list); renderSaved(); $$('.neigh-tabs [data-tab]')[1].click(); };
  $$('.neigh-tabs [data-tab]').forEach(b => b.onclick = () => { $$('.neigh-tabs [data-tab]').forEach(x => x.classList.toggle('on', x === b)); $('#nbTable').hidden = b.dataset.tab !== 'nb'; $('#svTable').hidden = b.dataset.tab !== 'saved'; });
  $('#nbRefresh').onclick = () => loadNeighbors(true);
  $('#logoutBtn').onclick = logout;
  $('#menuToggle').onclick = () => { const a = $('#app'); matchMedia('(max-width:860px)').matches ? a.classList.toggle('showmenu') : a.classList.toggle('nomenu'); };
  showLogin();
  setInterval(() => loadNeighbors(), 5000);
  setInterval(pollState, 1500);
  setInterval(topStats, 3000);
  if (new URLSearchParams(location.search).has('auto')) doLogin();
}
boot();

// ================= files, config transfer, page studio =================
function tokenQS(extra) { return new URLSearchParams({ t: S.t, ...(extra || {}) }).toString(); }
async function gpost(op, body) {
  try { return await (await fetch('/gui/' + op + '?' + tokenQS(), { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) })).json(); }
  catch (e) { return { error: 'connection lost' }; }
}
async function gget(op, q) { try { return await (await fetch('/gui/' + op + '?' + tokenQS(q))).json(); } catch { return { error: 'connection lost' }; } }
function downloadURL(url, name) { const a = h('a', { href: url, download: name || '' }); document.body.append(a); a.click(); a.remove(); }
function downloadText(text, name) { const u = URL.createObjectURL(new Blob([text], { type: 'text/plain' })); downloadURL(u, name); setTimeout(() => URL.revokeObjectURL(u), 4000); }
async function uploadFiles(files, dir, opts = {}) {
  const fd = new FormData();
  for (const f of files) { fd.append('path', f.relPath || f.webkitRelativePath || f.name); fd.append('file', f, f.name); }
  const r = await fetch('/gui/files/upload?' + tokenQS({ dir: dir || '', extract: opts.extract ? '1' : '', zipdir: opts.zipdir ? '1' : '' }), { method: 'POST', body: fd });
  return r.json();
}
// collect files (with folders) from a drop event
async function filesFromDrop(dt) {
  const out = [];
  const walk = (entry, prefix) => new Promise(res => {
    if (entry.isFile) entry.file(f => { f.relPath = prefix + f.name; out.push(f); res(); }, () => res());
    else if (entry.isDirectory) {
      const rd = entry.createReader(); const all = [];
      const next = () => rd.readEntries(async ents => { if (!ents.length) { for (const e of all) await walk(e, prefix + entry.name + '/'); res(); } else { all.push(...ents); next(); } }, () => res());
      next();
    } else res();
  });
  const items = [...(dt.items || [])].map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  if (items.length) { for (const e of items) await walk(e, ''); return out; }
  return [...dt.files];
}
function dropZone(el, onFiles, label) {
  const ov = h('div', { class: 'drop-ov', hidden: true }, label || 'Drop files to upload');
  el.style.position = 'relative'; el.append(ov);
  let n = 0;
  el.addEventListener('dragenter', e => { if (![...e.dataTransfer.types].includes('Files')) return; e.preventDefault(); n++; ov.hidden = false; });
  el.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('Files')) e.preventDefault(); });
  el.addEventListener('dragleave', () => { if (--n <= 0) { n = 0; ov.hidden = true; } });
  el.addEventListener('drop', async e => { e.preventDefault(); n = 0; ov.hidden = true; const files = await filesFromDrop(e.dataTransfer); if (files.length) onFiles(files); });
}
function pickFiles(opts, cb) {
  const inp = h('input', { type: 'file', multiple: true, accept: opts.accept || '' });
  if (opts.folder) inp.webkitdirectory = true;
  inp.onchange = () => cb([...inp.files]); inp.click();
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const ta = h('textarea', { style: { position: 'fixed', left: '-9999px' } }); ta.value = text; document.body.append(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove();
    if (!ok) { toast('Copy failed: select the text and press Ctrl+C', true); return false; }
  }
  toast('Copied. Paste it into a WinBox terminal on the router.'); return true;
}
const PORT_WORD = { open: 'answers', refused: 'refused', silent: 'no reply', unreachable: 'no route', error: 'error' };
// renderDiag draws a connection diagnosis: what answered, what it means, how to fix it.
function renderDiag(d, recheck) {
  const ok = d.api === 'open' && !d.fix.length;
  const box = h('div', { class: 'dg' + (ok ? ' ok' : '') });
  box.append(h('div', { class: 'dg-head' }, d.headline));
  const who = [d.host];
  if (d.seen) who.push(d.seen); else if (d.mac) who.push((d.vendor ? 'MikroTik MAC ' : 'MAC ') + d.mac);
  box.append(h('div', { class: 'dg-path' },
    h('div', { class: 'dg-end' }, h('small', null, 'This PC'), h('b', null, d.localIp || 'unknown'), d.localNet ? h('small', null, d.localNet) : ''),
    h('div', { class: 'dg-wire' + (d.sameNet ? '' : ' routed') }, h('small', null, d.self ? 'same address' : d.sameNet ? 'same network' : 'through a gateway')),
    h('div', { class: 'dg-end' }, h('small', null, 'Router'), h('b', null, who[0]), who[1] ? h('small', null, who[1]) : '')));
  box.append(h('div', { class: 'dg-ports' }, ...d.ports.map(p =>
    h('div', { class: 'dg-port st-' + p.state, title: [p.need ? 'Used for: ' + p.need : '', p.detail || '', p.state !== 'silent' ? p.ms + ' ms' : 'waited ' + (p.ms / 1000).toFixed(1) + ' s'].filter(Boolean).join('\n') },
      h('i'), h('b', null, p.name), h('small', null, p.port), h('span', null, PORT_WORD[p.state] || p.state)))));
  if (d.explain.length) box.append(h('h5', null, 'What this means'), ...d.explain.map(t => h('p', null, t)));
  if (d.fix.length) {
    box.append(h('h5', null, d.fix.length > 1 ? 'Ways to fix it' : 'How to fix it'));
    d.fix.forEach(f => {
      const step = h('div', { class: 'dg-fix' }, h('b', null, f.title), f.text ? h('p', null, f.text) : '');
      const code = (cmd, label) => { const b = h('button', { class: 'dg-copy' }, 'Copy'); b.onclick = () => copyText(cmd); return h('div', { class: 'dg-cmd' }, label ? h('small', null, label) : '', h('pre', null, cmd), b); };
      if (f.cmd) step.append(code(f.cmd));
      if (f.undo) step.append(code(f.undo, 'To remove it afterwards'));
      box.append(step);
    });
  }
  if (recheck) { const b = h('button', {}, 'Check again'); b.onclick = recheck; box.append(h('div', { class: 'row-btns' }, b)); }
  return box;
}
function toast(msg, bad) {
  const t = h('div', { class: 'toast' + (bad ? ' bad' : '') }, msg); document.body.append(t);
  setTimeout(() => t.classList.add('out'), 3800); setTimeout(() => t.remove(), 4400);
}

// ---------- Files ----------
function openFiles() {
  if (!S.info.local) return openList('files');
  openWin('files', 'File List', { w: 860, h: 460 }, w => {
    let tv;
    const target = h('select', { title: 'Upload into this folder' });
    async function refreshDirs() {
      const r = await exec('/file/print', { '.proplist': 'name,type' });
      const cur = target.value;
      target.innerHTML = '';
      target.append(h('option', { value: '' }, '/ (top level)'));
      (r.items || []).filter(f => f.type === 'directory').forEach(f => target.append(h('option', { value: f.name }, '/' + f.name)));
      target.value = cur;
    }
    const doUpload = async (files, extract) => {
      const zips = files.some(f => /\.zip$/i.test(f.name));
      const ex = extract ?? (zips && confirm('Extract the .zip file(s) into the folder? (Cancel keeps the .zip as one file)'));
      const r = await uploadFiles(files, target.value, { extract: ex });
      toast((r.saved || []).length + ' file(s) uploaded' + ((r.errors || []).length ? ' · ' + r.errors.join('; ') : ''), (r.errors || []).length);
      tv.refresh(); refreshDirs();
    };
    tv = tableView('/file', {
      extra: [
        ['Upload files…', () => pickFiles({}, f => doUpload(f))],
        ['Upload folder…', () => pickFiles({ folder: true }, f => doUpload(f, false))],
        ['New folder', async () => { const n = prompt('Folder name (use / for sub-folders)', target.value ? target.value + '/new-folder' : 'new-folder'); if (!n) return; const r = await exec('/file/add', { name: n, type: 'directory' }); if (r.error) toast(r.error, true); tv.refresh(); refreshDirs(); }],
        ['Download', rows => { if (!rows.length) return toast('Select a file or folder first', true); rows.forEach(f => downloadURL('/gui/files/download?' + tokenQS({ name: f.name }), '')); }],
        ['Import .rsc…', rows => { const f = rows.find(x => /\.rsc$/i.test(x.name)); if (!f) return toast('Select a .rsc file first', true); openTransfer('import', { file: f.name }); }],
        ['Page Studio', rows => openPageStudio(rows[0] && rows[0].type === 'directory' ? rows[0].name : null)],
      ]
    });
    const bar = h('div', { class: 'tb' }, h('span', null, 'Upload into '), target, h('span', { class: 'muted' }, 'Drag files, folders or .zip archives anywhere on this window.'));
    w.body.append(bar, tv.el);
    dropZone(w.body, files => doUpload(files), 'Drop to upload into /' + (target.value || ''));
    refreshDirs(); tv.refresh();
    w.every(3000, () => tv.refresh(), false);
    w.kick = () => { tv.refresh(); refreshDirs(); };
  });
}

// ---------- syntax highlighting for RouterOS scripts ----------
function hlRSC(text) {
  return text.split('\n').map(l => {
    const e = esc(l);
    if (/^\s*#/.test(l)) return `<span class="c-cm">${e}</span>`;
    if (/^\//.test(l)) return `<span class="c-path">${e}</span>`;
    if (/^:/.test(l)) return `<span class="c-kw">${e}</span>`;
    return e.replace(/(&quot;(?:\\.|[^&]|&(?!quot;))*?&quot;)/g, '<span class="c-str">$1</span>').replace(/(^|\s)([a-z0-9.\-]+)=/g, '$1<span class="c-key">$2</span>=').replace(/^(\s*)(add|set|remove)\b/, '$1<span class="c-kw">$2</span>');
  }).join('\n');
}

// ---------- Config transfer ----------
function openTransfer(tab, init) {
  if (!S.info.local) return toast('Config transfer works on the simulator session', true);
  const ex = S.wins.xfer;
  if (ex) { focusWin(ex); ex.el.classList.remove('minimized'); ex.show(tab || 'export', init); return; }
  const dr = deskRect();
  openWin('xfer', 'Configuration Transfer', { w: Math.min(1060, dr.width - 30), h: Math.min(660, dr.height - 24) }, w => {
    const tabs = h('div', { class: 'tabs' }), holder = h('div', { class: 'tabpane' });
    w.body.append(tabs, holder);
    const panes = {};
    const defs = [['export', 'Export to a real router'], ['import', 'Import a configuration'], ['real', 'Real router (clone or send)']];
    defs.forEach(([k, n]) => { const b = h('button', { 'data-k': k }, n); b.onclick = () => show(k); tabs.append(b); });
    let meta = null, lastExport = '';
    async function show(k, init) {
      $$('button', tabs).forEach(b => b.classList.toggle('on', b.dataset.k === k));
      if (!meta) meta = await gget('config/sections');
      if (!panes[k]) panes[k] = ({ export: buildExport, import: buildImport, real: buildReal })[k]();
      holder.innerHTML = ''; holder.append(panes[k].el);
      panes[k].shown && panes[k].shown(init);
    }
    w.show = show;
    const radio = (name, val, label, checked) => { const r = h('input', { type: 'radio', name, value: val }); r.checked = !!checked; return [r, h('label', { class: 'rad' }, r, ' ', label)]; };

    function buildExport() {
      const el = h('div', { class: 'xf' });
      const left = h('div', { class: 'xf-opts' }), right = h('div', { class: 'xf-out' });
      el.append(left, right);
      const secs = {};
      const secBox = h('div', { class: 'xf-secs' });
      meta.sections.forEach(s => { const c = h('input', { type: 'checkbox' }); c.checked = s.key !== 'services'; secs[s.key] = c; c.onchange = regen; secBox.append(h('label', { class: 'chk' }, c, ' ' + s.title)); });
      const sens = h('input', { type: 'checkbox' }); sens.checked = true; sens.onchange = regen;
      const tgt = h('select'); meta.models.forEach(m => tgt.append(h('option', { value: m.key }, m.board + (m.key === meta.current ? '  (this simulator)' : '')))); tgt.value = meta.current; tgt.onchange = regen;
      const [rMerge, lMerge] = radio('xmode', 'merge', 'Add to a router that is already set up', true);
      const [rFull, lFull] = radio('xmode', 'full', 'Full configuration for a freshly reset router');
      rMerge.onchange = rFull.onchange = regen;
      const fname = h('input', { value: ((meta.identity || 'tiklab').replace(/[^\w.-]+/g, '-') + '.rsc') }); fname.onchange = regen;
      left.append(h('h4', null, 'What to include'), secBox,
        h('label', { class: 'chk' }, sens, ' Include passwords and keys (vouchers, PPP secrets, Wi-Fi keys)'),
        h('h4', null, 'Target router'), tgt, h('p', { class: 'muted' }, 'Pick the real router model. Ports it does not have are left out and listed below.'),
        h('h4', null, 'Script type'), lMerge, lFull,
        h('h4', null, 'File name'), fname);
      const stat = h('div', { class: 'xf-stat' });
      const warns = h('ul', { class: 'xf-warn' });
      const pre = h('pre', { class: 'code' });
      const bDl = h('button', { class: 'primary' }, 'Download .rsc');
      const bCopy = h('button', {}, 'Copy');
      const bSave = h('button', {}, 'Save to router files');
      const bSend = h('button', {}, 'Send to a real router…');
      right.append(h('div', { class: 'row-btns' }, stat, h('span', { class: 'grow' }), bCopy, bSave, bSend, bDl), warns, pre);
      let timer;
      function regen() { clearTimeout(timer); timer = setTimeout(gen, 150); }
      async function gen() {
        const sel = Object.entries(secs).filter(([, c]) => c.checked).map(([k]) => k);
        const r = await gpost('config/export', { sections: sel, sensitive: sens.checked, target: tgt.value, full: rFull.checked, wrap: true, fileName: fname.value });
        if (r.error) { stat.textContent = r.error; return; }
        lastExport = r.script;
        pre.innerHTML = hlRSC(r.script);
        stat.textContent = `${r.lines} commands, ${r.script.split('\n').length} lines` + (r.warnings && r.warnings.length ? `, ${r.warnings.length} note(s)` : '');
        warns.innerHTML = ''; (r.warnings || []).forEach(x => warns.append(h('li', null, x)));
      }
      bDl.onclick = () => downloadText(lastExport, fname.value || 'tiklab-config.rsc');
      bCopy.onclick = async () => { try { await navigator.clipboard.writeText(lastExport); toast('Copied to the clipboard'); } catch { toast('Copy failed: select the text and press Ctrl+C', true); } };
      bSave.onclick = async () => { const r = await exec('/file/add', { name: fname.value, contents: lastExport }); if (r.error && /already/.test(r.error)) { await exec('/file/set', { numbers: fname.value, contents: lastExport }); } toast('Saved as ' + fname.value + ' in Files'); };
      bSend.onclick = () => show('real', { script: lastExport, fileName: fname.value });
      return { el, shown: gen };
    }

    function buildImport() {
      const el = h('div', { class: 'xi' });
      let text = '', info = null, fileName = '';
      const drop = h('div', { class: 'xi-drop' }, h('b', null, 'Drop a .rsc export here'), h('span', null, 'Make one on the real router with  /export show-sensitive file=myrouter  then download it from WinBox > Files.'));
      const bPick = h('button', {}, 'Choose file…');
      const fromFiles = h('select', null, h('option', { value: '' }, 'Or pick from router files…'));
      const bPaste = h('button', {}, 'Paste text…');
      const src = h('div', { class: 'row-btns' }, bPick, fromFiles, bPaste);
      const ana = h('div', { class: 'xi-ana', hidden: true });
      const report = h('div', { class: 'xi-rep', hidden: true });
      el.append(h('div', { class: 'xi-top' }, drop, src), ana, report);
      dropZone(el, files => loadFile(files[0]), 'Drop the .rsc file');
      bPick.onclick = () => pickFiles({ accept: '.rsc,.txt,.backup,.auto.rsc' }, f => f[0] && loadFile(f[0]));
      bPaste.onclick = () => formText('Paste a RouterOS script', '', t => { fileName = 'pasted script'; analyze(t); });
      fromFiles.onchange = async () => { if (!fromFiles.value) return; fileName = fromFiles.value; const r = await gpost('config/analyze', { file: fromFiles.value }); text = r.text; setInfo(r.info); };
      async function refreshFiles() {
        const r = await exec('/file/print', { '.proplist': 'name,type' });
        fromFiles.innerHTML = ''; fromFiles.append(h('option', { value: '' }, 'Or pick from router files…'));
        (r.items || []).filter(f => /\.(rsc|txt)$/i.test(f.name)).forEach(f => fromFiles.append(h('option', { value: f.name }, f.name)));
      }
      async function loadFile(f) {
        fileName = f.name;
        if (/\.backup$/i.test(f.name)) { ana.hidden = false; report.hidden = true; ana.innerHTML = ''; ana.append(h('div', { class: 'note bad' }, h('b', null, f.name + ' is a binary RouterOS backup. '), 'Backups are encrypted and only restore on the same kind of router, so they cannot be read here. On the router run ', h('code', null, '/export show-sensitive file=myrouter'), ' and import myrouter.rsc instead.')); return; }
        analyze(await f.text());
      }
      async function analyze(t) { text = t; const r = await gpost('config/analyze', { text: t }); setInfo(r.info); }
      function setInfo(i) {
        info = i; report.hidden = true; ana.hidden = false; ana.innerHTML = '';
        if (!i || !i.commands) { ana.append(h('div', { class: 'note bad' }, 'No RouterOS commands found in this file.')); return; }
        const head = h('div', { class: 'xi-head' }, h('b', null, fileName || 'Script'), ' — ', `${i.commands} commands`, i.version ? `, exported by RouterOS ${i.version}` : '', i.modelLine ? ` on ${i.modelLine}` : '');
        ana.append(head);
        // model choice
        const modelRow = h('div', { class: 'xi-sec' });
        let rSwitch = null;
        if (i.matchKey && i.matchKey !== i.current) {
          const [a, la] = radio('xm', 'switch', `Switch the simulator to ${i.matchBoard} first (recommended: same ports as the real router)`, true);
          const [b, lb] = radio('xm', 'keep', `Keep ${i.currentBoard} and map the interfaces below`);
          rSwitch = a; a.onchange = b.onchange = renderMap;
          modelRow.append(h('h4', null, 'Router model'), la, lb);
        } else if (i.matchKey) modelRow.append(h('h4', null, 'Router model'), h('p', null, `This file comes from the same model as the simulator (${i.currentBoard}).`));
        else modelRow.append(h('h4', null, 'Router model'), h('p', { class: 'muted' }, `The file does not name a known model. It will be imported into the ${i.currentBoard}.`));
        ana.append(modelRow);
        const mapBox = h('div', { class: 'xi-sec' });
        ana.append(mapBox);
        const sels = {};
        function renderMap() {
          mapBox.innerHTML = '';
          const missing = (rSwitch && rSwitch.checked) ? (i.missingIfSwitched || []) : (i.missing || []);
          if (!missing.length) return;
          mapBox.append(h('h4', null, 'Interfaces this router does not have'), h('p', { class: 'muted' }, 'Choose where each one should go, or skip the lines that use it.'));
          const grid = h('div', { class: 'xi-map' });
          for (const n of missing) {
            const s = h('select', null, h('option', { value: '' }, 'skip lines using it'));
            (i.available || []).forEach(a => s.append(h('option', { value: a }, a)));
            sels[n] = s; grid.append(h('span', null, n), h('span', null, '→'), s);
          }
          mapBox.append(grid);
        }
        renderMap();
        const [rRep, lRep] = radio('xr', 'replace', 'Replace the configuration (like reset no-defaults and run-after-reset). Keeps your admin login and files.', i.fullConfig);
        const [rMer, lMer] = radio('xr', 'merge', 'Merge into the current configuration (add or update items)', !i.fullConfig);
        ana.append(h('div', { class: 'xi-sec' }, h('h4', null, 'How to import'), lRep, lMer));
        const notes = h('div', { class: 'xi-sec' });
        if (i.unsupported && i.unsupported.length) notes.append(h('p', { class: 'muted' }, 'Not simulated, these menus will be skipped: ' + i.unsupported.join(', ')));
        if (i.sensitiveHidden) notes.append(h('p', { class: 'warnline' }, 'This export has no passwords. Vouchers and PPP secrets will be created with empty passwords. Export with show-sensitive to include them.'));
        ana.append(notes);
        const go = h('button', { class: 'primary' }, 'Import');
        ana.append(h('div', { class: 'row-btns' }, go, h('span', { class: 'muted' }, rRep.checked ? 'The simulator restarts while the file is applied.' : '')));
        rRep.onchange = rMer.onchange = () => { go.nextSibling.textContent = rRep.checked ? 'The simulator restarts while the file is applied.' : ''; };
        go.onclick = async () => {
          const mapping = {}; Object.entries(sels).forEach(([k, s]) => mapping[k] = s.value);
          if (rRep.checked && !confirm('Replace the simulator configuration with this file?')) return;
          go.disabled = true; go.textContent = 'Importing…';
          const res = await gpost('config/import', { text, mapping, replace: rRep.checked, model: rSwitch && rSwitch.checked ? i.matchKey : '' });
          go.disabled = false; go.textContent = 'Import';
          showReport(res);
          setTimeout(() => { refreshInfo(); refreshAll(); }, 1500);
        };
      }
      function showReport(r) {
        report.hidden = false; report.innerHTML = '';
        if (r.error) { report.append(h('div', { class: 'note bad' }, r.error)); return; }
        const onlyBad = h('input', { type: 'checkbox' }); onlyBad.checked = r.err + r.warn + r.skipped > 0;
        const pills = h('div', { class: 'row-btns' }, h('b', null, `Imported ${r.commands} commands in ${r.duration}`), h('span', { class: 'pill' }, h('i'), `${r.ok} ok`), h('span', { class: 'pill boot' }, h('i'), `${r.warn} warnings`), h('span', { class: 'pill off' }, h('i'), `${r.err} errors`), h('span', { class: 'pill gray' }, h('i'), `${r.skipped} skipped`), h('span', { class: 'grow' }), h('label', { class: 'chk' }, onlyBad, ' Only show problems'));
        const tbody = h('tbody');
        const tbl = h('table', { class: 'tbl' }, h('thead', null, h('tr', null, h('th', null, 'Line'), h('th', null, 'Result'), h('th', null, 'Command'), h('th', null, 'Details'))), tbody);
        const render = () => { tbody.innerHTML = ''; r.lines.filter(l => !onlyBad.checked || l.status !== 'ok').forEach(l => tbody.append(h('tr', { class: 'st-' + l.status }, h('td', { class: 'num' }, l.line), h('td', null, l.status), h('td', { class: 'mono', title: l.text }, l.text), h('td', { title: l.msg || '' }, l.msg || '')))); };
        onlyBad.onchange = render; render();
        report.append(pills, h('div', { class: 'tbl-wrap' }, tbl));
        report.scrollIntoView({ block: 'nearest' });
      }
      return { el, shown: async init => { refreshFiles(); if (init && init.script) { fileName = init.name || 'cloned router'; text = init.script; setInfo(init.info); } else if (init && init.file) { fileName = init.file; const r = await gpost('config/analyze', { file: init.file }); text = r.text; setInfo(r.info); } } };
    }

    function buildReal() {
      const el = h('div', { class: 'xr' });
      const saved = store.get('realrouter', { host: '192.168.88.1', user: 'admin', apiPort: 8728, ftpPort: 21, sshPort: 22, method: 'auto' });
      const host = h('input', { value: saved.host }), user = h('input', { value: saved.user }), pass = h('input', { type: 'password', placeholder: 'router password' });
      const num = v => h('input', { value: v, inputmode: 'numeric', style: { width: '64px' } });
      const api = num(saved.apiPort), ftp = num(saved.ftpPort), sshp = num(saved.sshPort || 22);
      const method = h('select', null, h('option', { value: 'auto' }, 'Automatic: API, then SSH'), h('option', { value: 'api' }, 'API only'), h('option', { value: 'ssh' }, 'SSH only'));
      method.value = saved.method || 'auto';
      const bTest = h('button', {}, 'Test connection'), bCheck = h('button', { title: 'Check which MikroTik ports answer, without logging in' }, 'Check ports');
      const ports = h('div', { class: 'xr-ports' }, h('span', null, 'API'), api, h('span', null, 'SSH'), sshp, h('span', null, 'FTP'), ftp);
      const form = h('div', { class: 'form', style: { flex: 'none', gridTemplateColumns: '120px minmax(0,320px)' } }, h('label', null, 'Router address'), host, h('label', null, 'User'), user, h('label', null, 'Password'), pass, h('label', null, 'Connect using'), method, h('label', null, 'Ports'), ports, h('span'), h('div', { class: 'row-btns' }, bTest, bCheck));
      const probeHint = () => h('div', { class: 'xr-probe muted' }, 'TikLab logs in with the RouterOS API (port 8728). If that port is off or blocked it tries SSH (port 22). FTP (port 21) copies files and hotspot pages.');
      const probe = h('div', { class: 'xr-probe-wrap' });
      const opts = () => { const o = { host: host.value.trim(), user: user.value.trim(), password: pass.value, apiPort: +api.value || 8728, ftpPort: +ftp.value || 21, sshPort: +sshp.value || 22, method: method.value }; store.set('realrouter', { host: o.host, user: o.user, apiPort: o.apiPort, ftpPort: o.ftpPort, sshPort: o.sshPort, method: o.method }); return o; };
      const log = h('pre', { class: 'xr-log', hidden: true });
      const showLog = (lines, err) => { log.hidden = false; log.textContent = (lines || []).join('\n') + (err ? '\n\n' + err : ''); log.classList.toggle('bad', !!err); };
      const busy = (b, on, label) => { b.disabled = on; if (label) b.textContent = label; };
      const showDiag = (d, err) => {
        probe.innerHTML = '';
        const box = renderDiag(d, runCheck);
        if (err) box.append(h('details', { class: 'dg-raw' }, h('summary', null, 'Technical details'), h('p', null, err)));
        probe.append(box);
        el.scrollTop = 0;
      };
      const runCheck = async () => {
        busy(bCheck, true, 'Checking…'); probe.innerHTML = ''; probe.append(h('div', { class: 'xr-probe muted' }, `Checking the MikroTik ports on ${host.value.trim()}. This takes up to 5 seconds…`));
        const r = await gpost('real/diagnose', opts());
        busy(bCheck, false, 'Check ports');
        if (r.error) { probe.innerHTML = ''; probe.append(h('div', { class: 'xr-probe bad' }, r.error)); return; }
        showDiag(r.diag);
      };
      bCheck.onclick = runCheck;
      bTest.onclick = async () => {
        busy(bTest, true, 'Connecting…'); probe.innerHTML = ''; probe.append(h('div', { class: 'xr-probe muted' }, 'Connecting…'));
        const r = await gpost('real/probe', opts());
        busy(bTest, false, 'Test connection');
        if (r.error) { if (r.diag) showDiag(r.diag, r.error); else { probe.innerHTML = ''; probe.append(h('div', { class: 'xr-probe bad' }, r.error)); } return; }
        const p = h('div', { class: 'xr-probe' });
        p.append(h('b', null, r.identity || 'Router'), ` — ${r.model || r.board}, RouterOS ${r.version}, up ${r.uptime}. Connected over ${r.via}. `, r.matchBoard ? `Matches the simulator model ${r.matchBoard}. ` : 'No matching simulator model. ', r.ftp ? 'FTP is available.' : 'FTP is not available, so hotspot pages cannot be copied. ', (r.hotspotDirs || []).length ? ` Hotspot pages: ${r.hotspotDirs.join(', ')}.` : '');
        probe.innerHTML = ''; probe.append(p);
        if (r.via === 'SSH' && method.value !== 'ssh') probe.append(h('p', { class: 'warnline' }, 'The API port did not answer, so TikLab used SSH. Clone, send and /import work over SSH. Click Check ports to see why the API is blocked.'));
        if (!r.ftp && r.ftpError) probe.append(h('p', { class: 'muted', style: { margin: '2px 0', fontSize: '12px' } }, r.ftpError));
      };
      // clone
      const cFiles = h('input', { type: 'checkbox' }); cFiles.checked = true;
      const bClone = h('button', { class: 'primary' }, 'Clone into the simulator');
      bClone.onclick = async () => {
        bClone.disabled = true; bClone.textContent = 'Reading the router…';
        const r = await gpost('real/clone', { ...opts(), files: cFiles.checked });
        bClone.disabled = false; bClone.textContent = 'Clone into the simulator';
        showLog(r.log, r.error);
        if (r.diag) showDiag(r.diag, r.error);
        if (!r.error) { toast('Router read. Review and import it.'); show('import', { script: r.script, info: r.info, name: 'clone of ' + host.value }); }
      };
      // send
      const sRun = h('input', { type: 'checkbox' });
      const runWarn = h('p', { class: 'warnline', hidden: true }, 'This changes the live router. Test the file on a spare router first. With a full-configuration script the router resets itself.');
      sRun.onchange = () => runWarn.hidden = !sRun.checked;
      const pages = h('select', null, h('option', { value: '' }, 'No hotspot pages'));
      const sName = h('input', { value: 'tiklab-config.rsc' });
      const bSend = h('button', { class: 'primary' }, 'Send to the router');
      let pendingScript = '';
      const scriptInfo = h('span', { class: 'muted' }, 'Uses the script from the Export tab.');
      bSend.onclick = async () => {
        let script = pendingScript || lastExport;
        if (!script) { const r = await gpost('config/export', { sensitive: true, wrap: true }); script = r.script; }
        const what = [`upload ${sName.value}`, pages.value ? `upload the ${pages.value} page folder` : '', sRun.checked ? 'RUN /import on the router' : ''].filter(Boolean).join(', ');
        if (!confirm(`Connect to ${host.value} and ${what}?`)) return;
        bSend.disabled = true;
        const r = await gpost('real/send', { ...opts(), script, fileName: sName.value, run: sRun.checked, pagesDir: pages.value });
        bSend.disabled = false;
        showLog(r.log, r.error);
        if (r.diag) showDiag(r.diag, r.error);
        toast(r.error ? 'Send failed' : 'Sent to ' + host.value, !!r.error);
      };
      el.append(h('div', { class: 'xr-col' }, h('h4', null, 'Router connection'), form, probeHint()),
        h('div', { class: 'xr-col' }, probe,
          h('div', { class: 'xr-card' }, h('h4', null, 'Clone a real router into the simulator'), h('p', null, 'Reads the configuration over the API (or SSH) without changing anything on the router, then lets you review and import it. Hotspot vouchers and PPP secrets come with their passwords.'), h('label', { class: 'chk' }, cFiles, ' Also copy the hotspot login pages (FTP, or SCP over SSH)'), h('div', { class: 'row-btns' }, bClone)),
          h('div', { class: 'xr-card' }, h('h4', null, 'Send to the real router'), h('p', null, 'Uploads the exported script, and optionally a hotspot page folder, into the router\'s Files.'), scriptInfo, h('div', { class: 'form', style: { padding: '6px 0', gridTemplateColumns: '120px minmax(0,1fr)' } }, h('label', null, 'File name'), sName, h('label', null, 'Hotspot pages'), pages), h('label', { class: 'chk' }, sRun, ' Run /import on the router after uploading'), runWarn, h('div', { class: 'row-btns' }, bSend)),
          log));
      return {
        el, shown: async init => {
          if (init && init.script) { pendingScript = init.script; sName.value = init.fileName || sName.value; scriptInfo.textContent = `Ready to send ${init.fileName} (${init.script.split('\n').length} lines) from the Export tab.`; }
          const r = await gget('hotspot/dirs'); pages.innerHTML = ''; pages.append(h('option', { value: '' }, 'No hotspot pages'));
          (r.dirs || []).forEach(d => pages.append(h('option', { value: d.dir }, d.dir + (d.active ? ' (active)' : ''))));
        }
      };
    }
    show(tab || 'export', init);
  });
}
function formText(title, val, cb) {
  openWin('ftext' + Date.now(), title, { w: 640, h: 420 }, w => {
    const ta = h('textarea', { spellcheck: 'false', style: { flex: 1, margin: '8px', minHeight: '200px' } }); ta.value = val || '';
    const ok = h('button', { class: 'primary' }, 'Use this text'); ok.onclick = () => { w.close(); cb(ta.value); };
    w.body.append(ta, h('div', { class: 'row-btns', style: { padding: '0 8px 8px' } }, ok));
    setTimeout(() => ta.focus(), 30);
  });
}

// ---------- Hotspot page studio ----------
function openPageStudio(dirHint) {
  if (!S.info.local) return;
  const ex = S.wins.studio; if (ex) { focusWin(ex); ex.el.classList.remove('minimized'); dirHint && ex.select(dirHint); return; }
  const dr = deskRect();
  openWin('studio', 'Hotspot Page Studio', { w: Math.min(1180, dr.width - 24), h: Math.min(700, dr.height - 20), x: 12, y: 10 }, w => {
    const left = h('div', { class: 'ps-left' }), main = h('div', { class: 'ps-main' });
    w.body.append(h('div', { class: 'ps' }, left, main));
    let sel = dirHint || null, dirs = [];
    const list = h('div', { class: 'ps-list' });
    const bUp = h('button', { class: 'primary' }, 'Upload folder or .zip…');
    const bNew = h('button', {}, 'New copy of the default pages');
    left.append(h('h4', null, 'Login page sets'), h('p', { class: 'muted' }, 'Each folder with a login.html is a page set. The active set is what customers see.'), list, h('div', { class: 'ps-actions' }, bUp, bNew), h('p', { class: 'muted' }, 'Tip: drag a folder or a .zip of your design onto this window.'));
    const head = h('div', { class: 'ps-head' });
    const previews = h('div', { class: 'ps-prev' });
    const checks = h('div', { class: 'ps-check' });
    main.append(head, previews, checks);
    async function install(files) {
      const zip = files.length === 1 && /\.zip$/i.test(files[0].name);
      let name = zip ? files[0].name.replace(/\.zip$/i, '') : ((files[0].relPath || files[0].webkitRelativePath || '').split('/')[0] || 'hotspot-new');
      name = prompt('Name of the new page set folder', name.replace(/[^\w.-]+/g, '-'));
      if (!name) return;
      let r;
      if (zip) r = await uploadFiles(files, name, { extract: true });
      else {
        files.forEach(f => { const p = (f.relPath || f.webkitRelativePath || f.name).split('/'); if (p.length > 1) p.shift(); f.relPath = p.join('/'); });
        r = await uploadFiles(files, name, {});
      }
      toast(`${(r.saved || []).length} files installed in ${name}` + ((r.errors || []).length ? ' · ' + r.errors.join('; ') : ''), (r.errors || []).length);
      sel = name; await load();
    }
    bUp.onclick = () => { const zip = confirm('Upload a .zip archive? (Cancel to choose a folder instead)'); pickFiles(zip ? { accept: '.zip' } : { folder: true }, f => f.length && install(f)); };
    bNew.onclick = async () => { const n = prompt('New folder name', 'hotspot-custom'); if (!n) return; const r = await gpost('hotspot/copy', { from: 'hotspot', to: n }); if (r.error) return toast(r.error, true); sel = n; load(); toast('Copied the default pages to ' + n + '. Edit them in Files or download, edit and upload again.'); };
    dropZone(w.body, files => install(files), 'Drop a page folder or .zip to install it');
    async function load() {
      const r = await gget('hotspot/dirs'); dirs = r.dirs || [];
      if (!sel || !dirs.find(d => d.dir === sel)) sel = (dirs.find(d => d.active) || dirs[0] || {}).dir;
      list.innerHTML = '';
      dirs.forEach(d => { const b = h('div', { class: 'ps-item' + (d.dir === sel ? ' on' : ''), role: 'button', tabindex: 0 }, h('b', null, d.dir || '/'), d.active ? h('span', { class: 'cur-tag' }, 'active') : '', h('small', null, `${d.files} files, ${fmtBytes(d.size)}`)); b.onclick = () => { sel = d.dir; load(); }; list.append(b); });
      if (sel != null) showDir(sel);
    }
    w.select = d => { sel = d; load(); };
    async function showDir(dir) {
      const d = dirs.find(x => x.dir === dir) || {};
      const bAct = h('button', { class: 'primary', disabled: !!d.active }, d.active ? 'Active on the hotspot' : 'Make active');
      bAct.onclick = async () => { const r = await gpost('hotspot/activate', { dir }); if (r.error) return toast(r.error, true); toast(dir + ' is now the hotspot login page'); load(); };
      const bLive = h('a', { class: 'top-link', href: portalURL(), target: '_blank' }, 'Open live login page');
      const bDl = h('button', {}, 'Download .zip'); bDl.onclick = () => downloadURL('/gui/files/download?' + tokenQS({ name: dir }), dir + '.zip');
      const bSend = h('button', {}, 'Send to a real router…'); bSend.onclick = () => openTransfer('real');
      const bEdit = h('button', {}, 'Edit files'); bEdit.onclick = () => openFiles();
      const bDel = h('button', { class: 'danger' }, 'Delete'); bDel.onclick = async () => { if (d.active) return toast('Make another set active first', true); if (!confirm('Delete the folder ' + dir + ' and all its files?')) return; await exec('/file/remove', { numbers: dir }); sel = null; load(); };
      head.innerHTML = ''; head.append(h('h3', null, dir || '/'), h('span', { class: 'grow' }), bAct, bLive, bEdit, bDl, bSend, bDel);
      previews.innerHTML = '';
      const states = [['login.html', 'login', 'Login'], ['login.html', 'error', 'Wrong voucher'], ['status.html', 'status', 'Logged in'], ['logout.html', 'logout', 'Logged out']];
      const stamp = Date.now();
      states.forEach(([page, st, label]) => {
        const src = `/hspreview/${dir.split('/').map(encodeURIComponent).join('/')}/${page}?state=${st}&_=${stamp}`;
        previews.append(h('figure', { class: 'phone' }, h('div', { class: 'phone-frame' }, h('iframe', { src, title: label + ' preview', loading: 'lazy', sandbox: 'allow-same-origin allow-scripts allow-forms' })), h('figcaption', null, label)));
      });
      checks.innerHTML = ''; checks.append(h('h4', null, 'Pre-flight check'), h('p', { class: 'muted' }, 'Checking…'));
      const c = await gget('hotspot/check', { dir });
      checks.innerHTML = ''; checks.append(h('h4', null, 'Pre-flight check'));
      const ul = h('ul', { class: 'chk-list' });
      (c.items || []).forEach(it => {
        const li = h('li', { class: 'lv-' + it.level }, h('span', { class: 'lv' }, { ok: 'OK', info: 'Info', warn: 'Check', error: 'Fix' }[it.level]), h('span', null, it.text));
        if (it.hosts) { const b = h('button', {}, 'Add to walled garden'); b.onclick = async () => { for (const host of it.hosts) await exec('/ip/hotspot/walled-garden/add', { 'dst-host': host, comment: 'added by Page Studio for ' + dir }); toast(it.hosts.length + ' host(s) allowed before login'); b.disabled = true; }; li.append(b); }
        ul.append(li);
      });
      checks.append(ul);
    }
    load();
    w.kick = load;
  });
}


// ---------- Wi-Fi on this PC ----------
function qrImg(text, label) {
  return h('img', { class: 'qr', alt: label, src: '/gui/qr?' + tokenQS({ text }) });
}
function openPCWifi() {
  if (!S.info.local) return;
  const ex = S.wins.pcwifi; if (ex) { focusWin(ex); ex.el.classList.remove('minimized'); return; }
  openWin('pcwifi', 'Wi-Fi on this PC', { w: 980, h: 620 }, w => {
    const root = h('div', { class: 'pw' });
    w.body.append(root);
    let last = null, busy = false, lastQR = '';
    const band = h('div', { class: 'pw-band' });
    const left = h('div', { class: 'pw-col' }), right = h('div', { class: 'pw-col pw-phone' });
    root.append(band, h('div', { class: 'pw-cols' }, left, right));
    const sw = h('input', { type: 'checkbox', class: 'switch' });
    const radio = h('select');
    const captive = h('input', { type: 'checkbox' });
    const send = async body => { busy = true; const r = await gpost('pcwifi', body); busy = false; if (r.error) return toast(r.error, true); render(r); };
    sw.onchange = () => send({ on: sw.checked });
    radio.onchange = () => send({ radio: radio.value });
    captive.onchange = () => send({ captive: captive.checked });
    const qrJoin = h('div', { class: 'pw-qr' }), qrLogin = h('div', { class: 'pw-qr' });
    const devBody = h('tbody');
    const devices = h('div', { class: 'pw-devs' }, h('h4', null, 'Devices on this Wi-Fi'), h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, ...['Device', 'MAC address', 'Address on the PC', 'Address in the router', 'Logged in as', 'Joined'].map(x => h('th', null, x)))), devBody)));
    const opts = h('div', { class: 'form pw-form' });
    const notes = h('div', { class: 'pw-notes' });
    left.append(h('label', { class: 'pw-switch' }, sw, h('span', null, h('b', null, 'Broadcast the router’s Wi-Fi from this PC'), h('small', null, 'Phones that join get the simulator’s hotspot login page and log in with real vouchers.'))), opts, notes);
    right.append(h('div', { class: 'pw-qrs' }, qrJoin, qrLogin), devices);
    function render(d) {
      last = d;
      const want = d.want || {}, caps = d.caps || {};
      sw.checked = !!want.on;
      // band: status
      const st = d.state || 'off';
      const led = { on: 'on', starting: 'boot', stopping: 'boot', failed: 'off', off: 'gray' }[st] || 'gray';
      const head = st === 'on' ? `Broadcasting “${d.ssid}”` : st === 'starting' ? `Starting “${d.ssid || '…'}”…` : st === 'failed' ? 'Could not broadcast' : st === 'stopping' ? 'Switching off…' : 'Not broadcasting';
      band.className = 'pw-band st-' + st;
      band.innerHTML = '';
      band.append(h('i', { class: 'pw-led ' + led }), h('div', null, h('b', null, head), h('small', null,
        st === 'on' ? `from this PC (${caps.method || ''}) for ${d.radio}${d.pcIp ? ' · this PC is ' + d.pcIp + ' on that network' : ''}` :
        st === 'failed' ? (d.detail || caps.reason || '') :
        (d.detail && want.on ? d.detail : caps.supported ? `This PC can broadcast with ${caps.method}.` : (caps.reason || 'Checking this PC’s Wi-Fi…')))));
      // options
      radio.innerHTML = '';
      radio.append(h('option', { value: 'auto' }, 'Automatic (the hotspot radio, 2.4 GHz first)'));
      (d.radios || []).forEach(x => radio.append(h('option', { value: x.name, disabled: x.disabled }, `${x.name} — ${x.ssid || '(no SSID)'} (${/^5/.test(x.band || '') ? '5 GHz' : '2.4 GHz'}, ${x.open ? 'open' : 'password'})${x.disabled ? ' · disabled' : ''}`)));
      radio.value = want.radio || 'auto';
      captive.checked = want.captive !== false;
      opts.innerHTML = '';
      opts.append(h('label', null, 'Simulated radio'), radio);
      if (caps.os === 'linux') opts.append(h('label', null, 'Before login'), h('label', { class: 'chk' }, captive, caps.captive ? ' Hold back devices until they log in' : ' Hold back devices until they log in (needs root)'));
      notes.innerHTML = '';
      const note = (t, cls) => notes.append(h('p', { class: 'pw-note ' + (cls || '') }, t));
      if (d.pcPass) note(`The simulated SSID is open, but Windows Mobile Hotspot always needs a password. Phones join with “${d.pass}”. The login page still works as on the router.`, 'warn');
      if (st === 'on' && caps.os === 'linux' && !d.captive) note(caps.captiveWhy || 'Phones can browse before they log in.', 'muted');
      if (st === 'on' && caps.os === 'windows') note(caps.captiveWhy, 'muted');
      if (caps.os === 'windows' && d.restore) note(d.restore, 'muted');
      if (d.firewallCmd && st === 'on') {
        const pre = h('pre', null, d.firewallCmd); const b = h('button', { class: 'dg-copy' }, 'Copy'); b.onclick = () => copyText(d.firewallCmd);
        notes.append(h('div', { class: 'pw-fw' }, h('p', null, 'If phones join but the login page does not open, Windows Firewall is blocking TikLab. Run this once in an administrator Command Prompt:'), h('div', { class: 'dg-cmd' }, pre, b)));
      }
      if (!caps.supported && !want.on && caps.reason) note(caps.reason, 'warn');
      // phone side
      const qk = (d.wifiQR || '') + '|' + (d.portal || '');
      if (qk !== lastQR) {
        lastQR = qk;
        qrJoin.innerHTML = ''; qrLogin.innerHTML = '';
        if (st === 'on' && d.wifiQR) {
          qrJoin.append(h('div', { class: 'pw-step' }, h('span', null, '1'), 'Join the Wi-Fi'), qrImg(d.wifiQR, 'Wi-Fi QR code'), h('div', { class: 'pw-net' }, h('b', null, d.ssid), h('small', null, d.pass ? 'Password ' + d.pass : 'Open network')));
          qrLogin.append(h('div', { class: 'pw-step' }, h('span', null, '2'), 'Open the login page'), qrImg(d.portal, 'Login page QR code'), h('div', { class: 'pw-net' }, h('b', { class: 'mono' }, d.portal.replace('http://', '')), h('small', null, d.captive ? 'Phones usually open it by themselves' : 'Or wait for the phone’s “sign in” prompt')));
        } else {
          qrJoin.append(h('div', { class: 'pw-empty' }, h('b', null, 'Phones join here'), h('p', null, 'Switch on broadcasting to get a QR code for the Wi-Fi and one for the login page.')));
        }
      }
      devBody.innerHTML = '';
      const cl = d.clients || [];
      if (!cl.length) devBody.append(h('tr', null, h('td', { colspan: 6, class: 'muted' }, st === 'on' ? 'No devices yet. Scan code 1 with a phone.' : '—')));
      cl.forEach(c => devBody.append(h('tr', { class: c.loggedIn ? '' : 'st-warning' }, h('td', null, c.name), h('td', { class: 'mono' }, c.mac), h('td', { class: 'mono' }, c.ip || ''), h('td', { class: 'mono' }, c.simAddress || ''), h('td', null, c.user || (c.loggedIn ? 'bypassed' : 'not logged in')), h('td', null, c.since || ''))));
    }
    const poll = async () => { if (busy) return; const r = await gget('pcwifi'); if (!r.error) render(r); };
    poll();
    const iv = setInterval(poll, 2500);
    w.closers.push(() => clearInterval(iv));
  });
}

// ---------- TapTap & tunnels ----------
function ago(sec) { if (sec == null) return ''; if (sec < 60) return sec + ' s ago'; if (sec < 3600) return Math.round(sec / 60) + ' min ago'; return Math.round(sec / 3600) + ' h ago'; }
function openCloud() {
  if (!S.info.local) return;
  const ex = S.wins.cloud; if (ex) { focusWin(ex); ex.el.classList.remove('minimized'); return; }
  openWin('cloud', 'TapTap & Tunnels', { w: 1000, h: 640 }, w => {
    const root = h('div', { class: 'cl' });
    w.body.append(root);
    const ta = h('textarea', { spellcheck: 'false', placeholder: 'Paste the install block from TapTap here (TapTap > Routers > TapTap Link > copy), or any RouterOS script.' });
    const run = h('button', { class: 'primary' }, 'Run on the simulated router');
    const out = h('pre', { class: 'xr-log', hidden: true });
    run.onclick = async () => {
      if (!ta.value.trim()) return toast('Paste the script first', true);
      run.disabled = true; run.textContent = 'Running…'; out.hidden = false; out.className = 'xr-log'; out.textContent = 'Running…';
      const r = await gpost('script/run', { text: ta.value });
      run.disabled = false; run.textContent = 'Run on the simulated router';
      out.textContent = (r.output || '') + (r.error ? '\n' + r.error : '') + `\n(${((r.ms || 0) / 1000).toFixed(1)} s)`;
      out.classList.toggle('bad', !!r.error);
      refresh();
    };
    const linkCard = h('div', { class: 'cl-card' }), tunCard = h('div', { class: 'cl-card' });
    const callsBody = h('tbody');
    root.append(
      h('div', { class: 'cl-col' }, h('h4', null, 'Connect to TapTap'),
        h('p', { class: 'muted' }, 'In TapTap, add a router and choose TapTap Link. Copy the install block and paste it below. The simulated router then checks in with TapTap like a real MikroTik, and on RouterOS 7 it also opens the TapTap Tunnel (WireGuard), so TapTap reaches its API from the internet.'),
        ta, h('div', { class: 'row-btns' }, run, h('span', { class: 'muted', style: { fontSize: '12px' } }, 'You can also paste it into New Terminal.')), out),
      h('div', { class: 'cl-col' }, linkCard, tunCard, h('div', { class: 'cl-card' }, h('h4', null, 'Recent HTTPS calls by scripts'), h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, ...['When', 'Call', 'Result'].map(x => h('th', null, x)))), callsBody)))));
    async function refresh() {
      const d = await gget('cloud');
      if (d.error) return;
      const L = d.link || {};
      linkCard.innerHTML = '';
      const ledL = !L.installed ? 'gray' : L.lastOK ? 'on' : L.lastPoll == null ? 'boot' : 'off';
      linkCard.append(h('h4', null, h('i', { class: 'pw-led ' + ledL }), 'TapTap Link'),
        h('p', null, !L.installed ? 'Not installed. Paste TapTap’s install block on the left.' :
          `Checks in with ${(L.server || '').replace(/^https?:\/\//, '')} every ${L.interval || '?'}${L.enabled === false ? ' (scheduler disabled)' : ''}. ` +
          (L.lastPoll == null ? 'No check-in yet.' : L.lastOK ? `Last check-in ${ago(L.lastPoll)}: OK.` : `Last check-in ${ago(L.lastPoll)} failed: ${L.lastMsg}`)));
      tunCard.innerHTML = '';
      tunCard.append(h('h4', null, 'WireGuard tunnels'));
      if (!(d.tunnels || []).length) tunCard.append(h('p', { class: 'muted' }, 'None. TapTap adds taptap-wg on RouterOS 7 when the tunnel is switched on in TapTap. Any /interface wireguard you add here connects for real.'));
      (d.tunnels || []).forEach(t => {
        const peers = t.peers || [];
        const up = peers.some(p => p.lastHandshake && !/^([3-9]m|\d+h|\d+d)/.test(p.lastHandshake));
        tunCard.append(h('div', { class: 'cl-tun' }, h('div', null, h('i', { class: 'pw-led ' + (t.disabled ? 'gray' : up ? 'on' : 'boot') }), h('b', null, t.name), ' ', h('span', { class: 'mono muted' }, (t.addresses || []).join(', '))),
          ...peers.map(p => h('div', { class: 'cl-peer' }, h('span', { class: 'mono' }, p.endpoint || 'no endpoint'), h('span', null, p.lastHandshake ? 'handshake ' + p.lastHandshake + ' ago' : 'no handshake yet'), h('span', { class: 'muted' }, `rx ${fmtBytes(+p.rx || 0)} · tx ${fmtBytes(+p.tx || 0)}`)))));
      });
      if ((d.logins || []).length) tunCard.append(h('p', { class: 'muted', style: { marginTop: '6px' } }, 'Logins through the tunnel:'), h('pre', { class: 'cl-logins' }, d.logins.join('\n')));
      callsBody.innerHTML = '';
      const calls = d.calls || [];
      if (!calls.length) callsBody.append(h('tr', null, h('td', { colspan: 3, class: 'muted' }, 'No /tool fetch calls yet.')));
      calls.forEach(c => callsBody.append(h('tr', { class: c.ok ? '' : 'st-error' }, h('td', null, new Date(c.at).toLocaleTimeString()), h('td', { class: 'mono', title: c.url }, c.method + ' ' + c.url.replace(/^https?:\/\/[^/]+/, '')), h('td', { title: c.msg }, c.ok ? `OK (${c.ms} ms)` : c.msg))));
    }
    refresh();
    const iv = setInterval(refresh, 3000);
    w.closers.push(() => clearInterval(iv));
  });
}
