package main

// FTP server (files in /file, like a real router) and a small FTP client
// used to copy files to and from real MikroTik routers.

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"net"
	"net/textproto"
	"path"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// ---------------- server ----------------

func serveFTP(r *Router, ln net.Listener) {
	for {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		go handleFTP(r, c)
	}
}

type ftpSess struct {
	r      *Router
	c      net.Conn
	w      *bufio.Writer
	user   string
	authed bool
	cwd    string
	pasv   net.Listener
	active string
	rnfr   string
	sid    string
	peer   string
}

func (s *ftpSess) reply(code int, msg string) {
	s.w.WriteString(fmt.Sprintf("%d %s\r\n", code, msg))
	s.w.Flush()
}

func (s *ftpSess) abs(p string) string {
	if p == "" {
		return s.cwd
	}
	if strings.HasPrefix(p, "/") {
		return cleanPath(p)
	}
	return cleanPath(s.cwd + "/" + p)
}

func (s *ftpSess) dataConn() (net.Conn, error) {
	if s.pasv != nil {
		s.pasv.(*net.TCPListener).SetDeadline(time.Now().Add(15 * time.Second))
		c, err := s.pasv.Accept()
		s.pasv.Close()
		s.pasv = nil
		return c, err
	}
	if s.active != "" {
		a := s.active
		s.active = ""
		return net.DialTimeout("tcp", a, 10*time.Second)
	}
	return nil, errors.New("use PASV or PORT first")
}

func handleFTP(r *Router, c net.Conn) {
	defer func() {
		if p := recover(); p != nil {
			fmt.Println("  ! ftp session error:", p)
		}
	}()
	defer c.Close()
	r.mu.Lock()
	running := r.state == "running"
	r.mu.Unlock()
	if !running {
		return
	}
	kid := r.onKick(func() { c.Close() })
	defer r.offKick(kid)
	s := &ftpSess{r: r, c: c, w: bufio.NewWriter(c), peer: hostOnly(c.RemoteAddr().String())}
	defer func() {
		if s.pasv != nil {
			s.pasv.Close()
		}
		if s.sid != "" {
			r.userLogout(s.sid)
		}
	}()
	r.mu.Lock()
	id := r.S("/system/identity", "name")
	r.mu.Unlock()
	s.reply(220, id+" FTP server (MikroTik "+strings.Fields(r.Ver)[0]+") ready")
	rd := bufio.NewReader(c)
	for {
		c.SetReadDeadline(time.Now().Add(10 * time.Minute))
		line, err := rd.ReadString('\n')
		if err != nil {
			return
		}
		line = strings.TrimRight(line, "\r\n")
		cmd, arg := line, ""
		if i := strings.IndexByte(line, ' '); i >= 0 {
			cmd, arg = line[:i], line[i+1:]
		}
		cmd = strings.ToUpper(cmd)
		if !s.authed && cmd != "USER" && cmd != "PASS" && cmd != "QUIT" && cmd != "SYST" && cmd != "FEAT" && cmd != "AUTH" && cmd != "OPTS" {
			s.reply(530, "Please login with USER and PASS.")
			continue
		}
		switch cmd {
		case "USER":
			s.user = arg
			s.reply(331, "Password required for "+arg)
		case "PASS":
			if err := r.checkUser(s.user, arg, "ftp", s.peer); err != nil {
				time.Sleep(500 * time.Millisecond)
				s.reply(530, "Login incorrect")
				continue
			}
			s.authed = true
			s.sid = r.userLogin(s.user, "ftp", s.peer)
			s.reply(230, "User "+s.user+" logged in")
		case "AUTH":
			s.reply(502, "TLS is not supported")
		case "SYST":
			s.reply(215, "UNIX Type: L8")
		case "FEAT":
			s.w.WriteString("211-Features:\r\n PASV\r\n EPSV\r\n SIZE\r\n MDTM\r\n UTF8\r\n211 End\r\n")
			s.w.Flush()
		case "OPTS", "TYPE", "MODE", "STRU", "ALLO":
			s.reply(200, "OK")
		case "NOOP":
			s.reply(200, "NOOP ok")
		case "PWD", "XPWD":
			s.reply(257, `"/`+s.cwd+`" is current directory`)
		case "CWD", "XCWD":
			p := s.abs(arg)
			r.mu.Lock()
			it := r.byName("/file", p)
			r.mu.Unlock()
			if p != "" && (it == nil || it["type"] != "directory") {
				s.reply(550, "No such directory")
				continue
			}
			s.cwd = p
			s.reply(250, "CWD command successful")
		case "CDUP", "XCUP":
			s.cwd = cleanPath(path.Dir("/" + s.cwd))
			s.reply(250, "CDUP command successful")
		case "PASV", "EPSV":
			if s.pasv != nil {
				s.pasv.Close()
			}
			lip := hostOnly(c.LocalAddr().String())
			ln, err := net.Listen("tcp", net.JoinHostPort(lip, "0"))
			if err != nil {
				s.reply(425, "Can't open data connection")
				continue
			}
			s.pasv = ln
			port := ln.Addr().(*net.TCPAddr).Port
			if cmd == "EPSV" {
				s.reply(229, fmt.Sprintf("Entering Extended Passive Mode (|||%d|)", port))
			} else {
				ip := net.ParseIP(lip).To4()
				if ip == nil {
					ip = net.IPv4(127, 0, 0, 1).To4()
				}
				s.reply(227, fmt.Sprintf("Entering Passive Mode (%d,%d,%d,%d,%d,%d)", ip[0], ip[1], ip[2], ip[3], port>>8, port&255))
			}
		case "PORT":
			p := strings.Split(arg, ",")
			if len(p) != 6 {
				s.reply(501, "Bad PORT")
				continue
			}
			hi, _ := strconv.Atoi(p[4])
			lo, _ := strconv.Atoi(p[5])
			s.active = fmt.Sprintf("%s.%s.%s.%s:%d", p[0], p[1], p[2], p[3], hi*256+lo)
			s.reply(200, "PORT command successful")
		case "LIST", "NLST", "MLSD":
			target := arg
			if strings.HasPrefix(target, "-") {
				target = ""
			}
			dir := s.abs(target)
			r.mu.Lock()
			var lines []string
			for _, it := range r.list(MenuMap["/file"]) {
				n := it["name"]
				if path.Dir("/"+n) != "/"+dir && !(dir == "" && !strings.Contains(n, "/")) {
					continue
				}
				base := path.Base(n)
				size := it["size"]
				if it["type"] != "directory" {
					size = strconv.Itoa(len(fileBytes(it)))
				}
				t, _ := time.Parse("2006-01-02 15:04:05", it["last-modified"])
				if t.IsZero() {
					t = time.Now()
				}
				switch cmd {
				case "NLST":
					lines = append(lines, base)
				case "MLSD":
					typ := "file"
					if it["type"] == "directory" {
						typ = "dir"
					}
					lines = append(lines, fmt.Sprintf("type=%s;size=%s;modify=%s; %s", typ, size, t.Format("20060102150405"), base))
				default:
					perm := "-rw-rw-rw-"
					if it["type"] == "directory" {
						perm = "drwxrwxrwx"
					}
					lines = append(lines, fmt.Sprintf("%s 1 owner group %12s %s %s", perm, size, t.Format("Jan _2 15:04"), base))
				}
			}
			r.mu.Unlock()
			dc, err := s.dataConn()
			if err != nil {
				s.reply(425, err.Error())
				continue
			}
			s.reply(150, "Opening data connection")
			io.WriteString(dc, strings.Join(lines, "\r\n")+map[bool]string{true: "\r\n", false: ""}[len(lines) > 0])
			dc.Close()
			s.reply(226, "Transfer complete")
		case "RETR":
			p := s.abs(arg)
			r.mu.Lock()
			it := r.byName("/file", p)
			var data []byte
			if it != nil && it["type"] != "directory" {
				data = fileBytes(it)
			}
			r.mu.Unlock()
			if data == nil && (it == nil || it["type"] == "directory") {
				s.reply(550, "No such file")
				continue
			}
			dc, err := s.dataConn()
			if err != nil {
				s.reply(425, err.Error())
				continue
			}
			s.reply(150, fmt.Sprintf("Opening BINARY mode data connection for %s (%d bytes)", path.Base(p), len(data)))
			dc.Write(data)
			dc.Close()
			s.reply(226, "Transfer complete")
		case "STOR", "APPE":
			p := s.abs(arg)
			if p == "" {
				s.reply(553, "Bad file name")
				continue
			}
			dc, err := s.dataConn()
			if err != nil {
				s.reply(425, err.Error())
				continue
			}
			s.reply(150, "Opening data connection")
			dc.SetReadDeadline(time.Now().Add(5 * time.Minute))
			data, err := io.ReadAll(io.LimitReader(dc, maxUpload+1))
			dc.Close()
			if err != nil || len(data) > maxUpload {
				s.reply(552, "Transfer failed or file too large (32 MB limit)")
				continue
			}
			r.mu.Lock()
			if cmd == "APPE" {
				if it := r.byName("/file", p); it != nil {
					data = append(fileBytes(it), data...)
				}
			}
			r.putFile(p, data)
			r.log("system,info", "file %s uploaded via ftp by %s", p, s.user)
			r.mu.Unlock()
			s.reply(226, "Transfer complete")
		case "DELE", "RMD", "XRMD":
			p := s.abs(arg)
			r.mu.Lock()
			it := r.byName("/file", p)
			if it != nil {
				r.removeItem(MenuMap["/file"], it, true)
			}
			r.mu.Unlock()
			if it == nil {
				s.reply(550, "No such file or directory")
			} else {
				s.reply(250, "Deleted")
			}
		case "MKD", "XMKD":
			p := s.abs(arg)
			r.mu.Lock()
			r.ensureDir(p)
			r.mu.Unlock()
			s.reply(257, `"/`+p+`" created`)
		case "RNFR":
			s.rnfr = s.abs(arg)
			s.reply(350, "Ready for RNTO")
		case "RNTO":
			r.mu.Lock()
			it := r.byName("/file", s.rnfr)
			var err error
			if it != nil {
				err = r.setItem(MenuMap["/file"], it, map[string]string{"name": s.abs(arg)}, true)
			}
			r.mu.Unlock()
			if it == nil || err != nil {
				s.reply(550, "Rename failed")
			} else {
				s.reply(250, "Renamed")
			}
		case "SIZE":
			r.mu.Lock()
			it := r.byName("/file", s.abs(arg))
			n := -1
			if it != nil && it["type"] != "directory" {
				n = len(fileBytes(it))
			}
			r.mu.Unlock()
			if n < 0 {
				s.reply(550, "No such file")
			} else {
				s.reply(213, strconv.Itoa(n))
			}
		case "MDTM":
			r.mu.Lock()
			it := r.byName("/file", s.abs(arg))
			r.mu.Unlock()
			if it == nil {
				s.reply(550, "No such file")
				continue
			}
			t, _ := time.Parse("2006-01-02 15:04:05", it["last-modified"])
			s.reply(213, t.Format("20060102150405"))
		case "QUIT":
			s.reply(221, "Goodbye")
			return
		default:
			s.reply(502, "Command not implemented")
		}
	}
}

// ---------------- client ----------------

type FTPClient struct {
	tc   *textproto.Conn
	host string
}

type ftpEntry struct {
	Name string
	Dir  bool
	Size int64
}

func ftpDial(addr, user, pass string) (*FTPClient, error) {
	c, err := net.DialTimeout("tcp", addr, 8*time.Second)
	if err != nil {
		return nil, err
	}
	c.SetDeadline(time.Now().Add(5 * time.Minute))
	f := &FTPClient{tc: textproto.NewConn(c), host: hostOnly(addr)}
	if _, _, err := f.tc.ReadResponse(220); err != nil {
		c.Close()
		return nil, err
	}
	code, msg, err := f.cmd("USER " + user)
	if err != nil {
		return nil, err
	}
	if code == 331 {
		if code, msg, err = f.cmd("PASS " + pass); err != nil {
			return nil, err
		}
	}
	if code != 230 {
		f.Close()
		return nil, fmt.Errorf("ftp login failed: %s", msg)
	}
	f.cmd("TYPE I")
	return f, nil
}

func (f *FTPClient) cmd(line string) (int, string, error) {
	id, err := f.tc.Cmd("%s", line)
	if err != nil {
		return 0, "", err
	}
	f.tc.StartResponse(id)
	defer f.tc.EndResponse(id)
	return f.tc.ReadResponse(0)
}

var rePasv = regexp.MustCompile(`(\d+),(\d+),(\d+),(\d+),(\d+),(\d+)`)

func (f *FTPClient) data() (net.Conn, error) {
	code, msg, err := f.cmd("EPSV")
	port := 0
	if err == nil && code == 229 {
		if i := strings.Index(msg, "|||"); i >= 0 {
			fmt.Sscanf(msg[i+3:], "%d", &port)
		}
	}
	if port == 0 {
		code, msg, err = f.cmd("PASV")
		if err != nil || code != 227 {
			return nil, fmt.Errorf("passive mode refused: %s", msg)
		}
		m := rePasv.FindStringSubmatch(msg)
		if m == nil {
			return nil, fmt.Errorf("bad PASV reply")
		}
		hi, _ := strconv.Atoi(m[5])
		lo, _ := strconv.Atoi(m[6])
		port = hi*256 + lo
	}
	return net.DialTimeout("tcp", net.JoinHostPort(f.host, strconv.Itoa(port)), 8*time.Second)
}

func (f *FTPClient) transfer(cmd string, upload []byte) ([]byte, error) {
	dc, err := f.data()
	if err != nil {
		return nil, err
	}
	code, msg, err := f.cmd(cmd)
	if err != nil {
		dc.Close()
		return nil, err
	}
	if code != 150 && code != 125 {
		dc.Close()
		return nil, fmt.Errorf("%s", msg)
	}
	var out []byte
	dc.SetDeadline(time.Now().Add(5 * time.Minute))
	if upload != nil {
		_, err = io.Copy(dc, bytes.NewReader(upload))
	} else {
		out, err = io.ReadAll(io.LimitReader(dc, 64<<20))
	}
	dc.Close()
	if err != nil {
		return nil, err
	}
	if code, msg, err = f.tc.ReadResponse(0); err != nil || code >= 400 {
		return nil, fmt.Errorf("transfer failed: %s %v", msg, err)
	}
	return out, nil
}

func (f *FTPClient) List(dir string) ([]ftpEntry, error) {
	b, err := f.transfer("LIST "+dir, nil)
	if err != nil {
		return nil, err
	}
	var out []ftpEntry
	for _, l := range strings.Split(strings.ReplaceAll(string(b), "\r", ""), "\n") {
		fs := strings.Fields(l)
		if len(fs) < 9 {
			continue
		}
		name := strings.Join(fs[8:], " ")
		if name == "." || name == ".." {
			continue
		}
		size, _ := strconv.ParseInt(fs[4], 10, 64)
		out = append(out, ftpEntry{Name: name, Dir: strings.HasPrefix(fs[0], "d"), Size: size})
	}
	return out, nil
}

func (f *FTPClient) Retr(p string) ([]byte, error) { return f.transfer("RETR "+p, nil) }
func (f *FTPClient) Stor(p string, data []byte) error {
	if data == nil {
		data = []byte{}
	}
	_, err := f.transfer("STOR "+p, data)
	return err
}
func (f *FTPClient) Mkd(p string)  { f.cmd("MKD " + p) }
func (f *FTPClient) Dele(p string) { f.cmd("DELE " + p) }
func (f *FTPClient) Close() {
	f.cmd("QUIT")
	f.tc.Close()
}

// fetchTree downloads dir recursively (max total bytes)
func (f *FTPClient) fetchTree(dir string, max int, got func(name string, data []byte)) error {
	total := 0
	var walk func(d string, depth int) error
	walk = func(d string, depth int) error {
		if depth > 6 {
			return nil
		}
		ents, err := f.List(d)
		if err != nil {
			return err
		}
		for _, e := range ents {
			p := d + "/" + e.Name
			if e.Dir {
				walk(p, depth+1)
				continue
			}
			b, err := f.Retr(p)
			if err != nil {
				continue
			}
			total += len(b)
			if total > max {
				return fmt.Errorf("stopped after %s", humanBytes(float64(max)))
			}
			got(p, b)
		}
		return nil
	}
	return walk(dir, 0)
}
