package main

import (
	"unicode/utf8"
	"bufio"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/binary"
	"encoding/pem"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

const banner = "\r\n" +
	"\x1b[36m  _____ _ _    _           _     \x1b[0m\r\n" +
	"\x1b[36m |_   _(_) | _| |    __ _ | |__  \x1b[0m\r\n" +
	"\x1b[36m   | | | | |/ / |   / _` || '_ \\ \x1b[0m\r\n" +
	"\x1b[36m   | | | |   <| |__| (_| || |_) |\x1b[0m\r\n" +
	"\x1b[36m   |_| |_|_|\\_\\_____\\__,_||_.__/ \x1b[0m\r\n\r\n" +
	"  \x1b[1mTikLab %s\x1b[0m  -  RouterOS-compatible network simulator\r\n" +
	"  Simulating RouterOS %s on %s\r\n" +
	"  For training and app testing. Not affiliated with MikroTik.\r\n\r\n" +
	"  Press F1 or type ? for help, Tab completes.\r\n\r\n"

// Term is an interactive line-editing terminal on top of the CLI.
type Term struct {
	cli     *CLI
	w       io.Writer
	wmu     sync.Mutex
	buf     []rune
	pos     int
	hist    []string
	hidx    int
	busy    bool
	bmu     sync.Mutex
	esc     []byte
	lastCR  bool
	closed  bool
	onClose func()
	lastTab bool
	pending string // lines of a block still open ({, [, ( or a quote)
	kmu     sync.Mutex
	ahead   []byte // typed or pasted while a command runs
	u8      []byte
}

type crlfWriter struct{ t *Term }

func (c crlfWriter) Write(p []byte) (int, error) {
	c.t.write(strings.ReplaceAll(strings.ReplaceAll(string(p), "\r\n", "\n"), "\n", "\r\n"))
	return len(p), nil
}

func newTerm(r *Router, user, via, addr string, w io.Writer, width int) *Term {
	t := &Term{w: w}
	t.cli = newCLI(r, user, via, addr, crlfWriter{t}, true)
	if width > 20 {
		t.cli.width = width
	}
	return t
}

func (t *Term) write(s string) {
	t.wmu.Lock()
	defer t.wmu.Unlock()
	if !t.closed {
		t.w.Write([]byte(s))
	}
}

func (t *Term) Start() {
	r := t.cli.r
	r.mu.Lock()
	note := r.single("/system/note")
	ver, board := r.Ver, r.Model.Board
	r.mu.Unlock()
	t.write(fmt.Sprintf(banner, AppVersion, ver, board))
	if note.B("show-at-cli-login") && note["note"] != "" {
		t.write(strings.ReplaceAll(note["note"], "\n", "\r\n") + "\r\n\r\n")
	}
	t.prompt()
}

func (t *Term) SetWidth(w int) {
	if w > 20 {
		t.cli.width = w
	}
}

func (t *Term) prompt() {
	t.write(t.promptStr())
}

func (t *Term) promptStr() string {
	if t.pending != "" {
		return "{... "
	}
	return t.cli.Prompt()
}

func (t *Term) redraw() {
	line := string(t.buf)
	s := "\r\x1b[K" + t.promptStr() + line
	if back := len(t.buf) - t.pos; back > 0 {
		s += fmt.Sprintf("\x1b[%dD", back)
	}
	t.write(s)
}

func (t *Term) isBusy() bool {
	t.bmu.Lock()
	defer t.bmu.Unlock()
	return t.busy
}

func (t *Term) Input(data []byte) {
	t.kmu.Lock()
	defer t.kmu.Unlock()
	t.feed(data)
}

// feed handles input bytes. While a command runs, they go to a waiting
// prompt or monitor, or are kept and replayed when the command ends, so a
// pasted list of commands runs line by line.
func (t *Term) feed(data []byte) {
	for _, b := range data {
		if t.isBusy() {
			if b == 3 {
				t.cli.interrupt.Store(true)
				if t.cli.interp != nil {
					t.cli.interp.cancel.Store(true)
				}
				t.bmu.Lock()
				t.ahead = nil
				t.bmu.Unlock()
			}
			if t.cli.wantKey.Load() > 0 || b == 3 {
				select {
				case t.cli.keys <- b:
				default:
				}
				continue
			}
			t.bmu.Lock()
			if len(t.ahead) < 4<<20 {
				t.ahead = append(t.ahead, b)
			}
			t.bmu.Unlock()
			continue
		}
		t.key(b)
		if t.closed {
			return
		}
	}
}

func (t *Term) key(b byte) {
	if len(t.esc) > 0 {
		t.esc = append(t.esc, b)
		s := string(t.esc)
		if len(t.esc) == 2 && b != '[' && b != 'O' {
			t.esc = nil
			return
		}
		if len(t.esc) >= 3 && (b >= 'A' && b <= 'Z' || b == '~' || b >= 'a' && b <= 'z') {
			t.esc = nil
			switch s {
			case "\x1b[A", "\x1bOA":
				t.histMove(-1)
			case "\x1b[B", "\x1bOB":
				t.histMove(1)
			case "\x1b[C", "\x1bOC":
				if t.pos < len(t.buf) {
					t.pos++
					t.write("\x1b[C")
				}
			case "\x1b[D", "\x1bOD":
				if t.pos > 0 {
					t.pos--
					t.write("\x1b[D")
				}
			case "\x1b[H", "\x1bOH", "\x1b[1~":
				t.pos = 0
				t.redraw()
			case "\x1b[F", "\x1bOF", "\x1b[4~":
				t.pos = len(t.buf)
				t.redraw()
			case "\x1b[3~":
				if t.pos < len(t.buf) {
					t.buf = append(t.buf[:t.pos], t.buf[t.pos+1:]...)
					t.redraw()
				}
			case "\x1bOP", "\x1b[11~":
				t.showHelp()
			}
			return
		}
		if len(t.esc) > 8 {
			t.esc = nil
		}
		return
	}
	if b != '\t' {
		t.lastTab = false
	}
	switch b {
	case 0x1b:
		t.esc = []byte{b}
	case '\r', '\n':
		if b == '\n' && t.lastCR {
			t.lastCR = false
			return
		}
		t.lastCR = b == '\r'
		line := string(t.buf)
		t.buf, t.pos = nil, 0
		t.write("\r\n")
		if strings.TrimSpace(line) != "" {
			if len(t.hist) == 0 || t.hist[len(t.hist)-1] != line {
				t.hist = append(t.hist, line)
			}
		}
		t.hidx = len(t.hist)
		full := line
		if t.pending != "" {
			full = t.pending + "\n" + line
		}
		if !scriptComplete(full) {
			t.pending = full
			t.prompt()
			return
		}
		t.pending = ""
		trim := strings.TrimSpace(full)
		if trim == "" || (strings.HasPrefix(trim, "#") && !strings.Contains(trim, "\n")) {
			t.prompt()
			return
		}
		t.exec(full)
		return
	case 0x7f, 0x08:
		if t.pos > 0 {
			t.buf = append(t.buf[:t.pos-1], t.buf[t.pos:]...)
			t.pos--
			t.redraw()
		}
	case 0x01:
		t.pos = 0
		t.redraw()
	case 0x05:
		t.pos = len(t.buf)
		t.redraw()
	case 0x02:
		if t.pos > 0 {
			t.pos--
			t.write("\x1b[D")
		}
	case 0x06:
		if t.pos < len(t.buf) {
			t.pos++
			t.write("\x1b[C")
		}
	case 0x0b:
		t.buf = t.buf[:t.pos]
		t.redraw()
	case 0x15:
		t.buf = t.buf[t.pos:]
		t.pos = 0
		t.redraw()
	case 0x17:
		i := t.pos
		for i > 0 && t.buf[i-1] == ' ' {
			i--
		}
		for i > 0 && t.buf[i-1] != ' ' {
			i--
		}
		t.buf = append(t.buf[:i], t.buf[t.pos:]...)
		t.pos = i
		t.redraw()
	case 0x0c:
		t.write("\x1b[2J\x1b[H")
		t.redraw()
	case 0x03:
		t.write("^C\r\n")
		t.buf, t.pos = nil, 0
		t.pending = ""
		t.prompt()
	case 0x04:
		if len(t.buf) == 0 {
			t.write("\r\n")
			t.Close()
		}
	case 0x10:
		t.histMove(-1)
	case 0x0e:
		t.histMove(1)
	case '\t':
		line := string(t.buf[:t.pos])
		nl, opts := t.cli.completions(line)
		if nl != line {
			rest := t.buf[t.pos:]
			t.buf = append([]rune(nl), rest...)
			t.pos = len([]rune(nl))
			t.redraw()
		} else if len(opts) > 1 || t.lastTab {
			t.write("\r\n")
			t.cli.printCols(opts)
			t.redraw()
		}
		t.lastTab = true
	case '?':
		if strings.Count(string(t.buf[:t.pos]), "\"")%2 == 0 {
			t.showHelp()
			return
		}
		fallthrough
	default:
		if b < 32 {
			return
		}
		if b >= 0x80 {
			t.u8 = append(t.u8, b)
			if utf8.FullRune(t.u8) {
				r, _ := utf8.DecodeRune(t.u8)
				t.u8 = nil
				t.insert(r)
			} else if len(t.u8) > 4 {
				t.u8 = nil
			}
			return
		}
		t.insert(rune(b))
	}
}

func (t *Term) insert(r rune) {
	t.buf = append(t.buf[:t.pos], append([]rune{r}, t.buf[t.pos:]...)...)
	t.pos++
	if t.pos == len(t.buf) {
		t.write(string(r))
	} else {
		t.redraw()
	}
}

func (t *Term) showHelp() {
	t.write("\r\n")
	t.cli.help(string(t.buf[:t.pos]))
	t.write("\r\n")
	t.redraw()
}

func (t *Term) histMove(d int) {
	if len(t.hist) == 0 {
		return
	}
	t.hidx += d
	if t.hidx < 0 {
		t.hidx = 0
	}
	if t.hidx >= len(t.hist) {
		t.hidx = len(t.hist)
		t.buf = nil
	} else {
		t.buf = []rune(t.hist[t.hidx])
	}
	t.pos = len(t.buf)
	t.redraw()
}

func (t *Term) exec(line string) {
	t.bmu.Lock()
	t.busy = true
	t.bmu.Unlock()
	go func() {
		defer func() {
			if p := recover(); p != nil {
				t.write(fmt.Sprintf("\x1b[31minternal error: %v\x1b[0m\r\n", p))
			}
			for len(t.cli.keys) > 0 {
				<-t.cli.keys
			}
			t.kmu.Lock()
			defer t.kmu.Unlock()
			t.bmu.Lock()
			t.busy = false
			ahead := t.ahead
			t.ahead = nil
			t.bmu.Unlock()
			if t.cli.exit {
				t.Close()
				return
			}
			t.prompt()
			if len(ahead) > 0 {
				t.feed(ahead)
			}
		}()
		t.cli.RunLine(line)
	}()
}

func (t *Term) Close() {
	t.wmu.Lock()
	if t.closed {
		t.wmu.Unlock()
		return
	}
	t.closed = true
	t.wmu.Unlock()
	if t.onClose != nil {
		t.onClose()
	}
}

// ---------------- Telnet ----------------

func serveTelnet(r *Router, ln net.Listener) {
	for {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		go handleTelnet(r, c)
	}
}

type telnetReader struct {
	rd    *bufio.Reader
	state int
	sb    []byte
	width func(int)
}

func (tr *telnetReader) next() ([]byte, error) {
	buf := make([]byte, 512)
	n, err := tr.rd.Read(buf)
	if err != nil {
		return nil, err
	}
	var out []byte
	for _, b := range buf[:n] {
		switch tr.state {
		case 0:
			if b == 255 {
				tr.state = 1
			} else if b != 0 {
				out = append(out, b)
			}
		case 1:
			switch b {
			case 251, 252, 253, 254:
				tr.state = 2
			case 250:
				tr.state = 3
				tr.sb = nil
			case 255:
				out = append(out, 255)
				tr.state = 0
			default:
				tr.state = 0
			}
		case 2:
			tr.state = 0
		case 3:
			if b == 255 {
				tr.state = 4
			} else {
				tr.sb = append(tr.sb, b)
			}
		case 4:
			if b == 240 {
				if len(tr.sb) >= 5 && tr.sb[0] == 31 && tr.width != nil {
					tr.width(int(binary.BigEndian.Uint16(tr.sb[1:3])))
				}
				tr.state = 0
			} else {
				tr.sb = append(tr.sb, b)
				tr.state = 3
			}
		}
	}
	return out, nil
}

func handleTelnet(r *Router, c net.Conn) {
	defer c.Close()
	r.mu.Lock()
	running := r.state == "running"
	r.mu.Unlock()
	if !running {
		return
	}
	kid := r.onKick(func() { c.Close() })
	defer r.offKick(kid)
	c.Write([]byte{255, 251, 1, 255, 251, 3, 255, 253, 31})
	width := 100
	tr := &telnetReader{rd: bufio.NewReader(c), width: func(w int) { width = w }}
	peer := hostOnly(c.RemoteAddr().String())
	readLine := func(echo bool) (string, error) {
		var line []byte
		for {
			c.SetReadDeadline(time.Now().Add(2 * time.Minute))
			b, err := tr.next()
			if err != nil {
				return "", err
			}
			for _, ch := range b {
				switch {
				case ch == '\r' || ch == '\n':
					c.Write([]byte("\r\n"))
					return string(line), nil
				case ch == 0x7f || ch == 0x08:
					if len(line) > 0 {
						line = line[:len(line)-1]
						if echo {
							c.Write([]byte("\b \b"))
						}
					}
				case ch >= 32:
					line = append(line, ch)
					if echo {
						c.Write([]byte{ch})
					}
				}
			}
		}
	}
	var user string
	for attempt := 0; ; attempt++ {
		c.Write([]byte("Login: "))
		u, err := readLine(true)
		if err != nil {
			return
		}
		c.Write([]byte("Password: "))
		p, err := readLine(false)
		if err != nil {
			return
		}
		if err := r.checkUser(u, p, "telnet", peer); err == nil {
			user = strings.SplitN(u, "+", 2)[0]
			break
		}
		time.Sleep(time.Second)
		c.Write([]byte("Login failed, incorrect username or password\r\n\r\n"))
		if attempt >= 2 {
			return
		}
	}
	sid := r.userLogin(user, "telnet", peer)
	defer r.userLogout(sid)
	done := make(chan struct{})
	t := newTerm(r, user, "telnet", peer, c, width)
	t.onClose = func() {
		c.Write([]byte("\r\nConnection closed.\r\n"))
		c.Close()
		select {
		case <-done:
		default:
			close(done)
		}
	}
	t.Start()
	for {
		c.SetReadDeadline(time.Time{})
		b, err := tr.next()
		if err != nil {
			return
		}
		t.SetWidth(width)
		t.Input(b)
	}
}

// ---------------- SSH ----------------

func sshHostKeys(dir string) []ssh.Signer {
	var out []ssh.Signer
	edPath := filepath.Join(dir, "ssh_host_ed25519.pem")
	var edKey ed25519.PrivateKey
	if b, err := os.ReadFile(edPath); err == nil {
		if blk, _ := pem.Decode(b); blk != nil {
			if k, err := x509.ParsePKCS8PrivateKey(blk.Bytes); err == nil {
				edKey, _ = k.(ed25519.PrivateKey)
			}
		}
	}
	if edKey == nil {
		_, edKey, _ = ed25519.GenerateKey(rand.Reader)
		if der, err := x509.MarshalPKCS8PrivateKey(edKey); err == nil {
			os.WriteFile(edPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: der}), 0600)
		}
	}
	if s, err := ssh.NewSignerFromKey(edKey); err == nil {
		out = append(out, s)
	}
	rsaPath := filepath.Join(dir, "ssh_host_rsa.pem")
	var rk *rsa.PrivateKey
	if b, err := os.ReadFile(rsaPath); err == nil {
		if blk, _ := pem.Decode(b); blk != nil {
			rk, _ = x509.ParsePKCS1PrivateKey(blk.Bytes)
		}
	}
	if rk == nil {
		rk, _ = rsa.GenerateKey(rand.Reader, 2048)
		os.WriteFile(rsaPath, pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(rk)}), 0600)
	}
	if s, err := ssh.NewSignerFromKey(rk); err == nil {
		out = append(out, s)
	}
	return out
}

func serveSSH(r *Router, ln net.Listener, keys []ssh.Signer) {
	for {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		go handleSSH(r, c, keys)
	}
}

func handleSSH(r *Router, nc net.Conn, keys []ssh.Signer) {
	defer nc.Close()
	r.mu.Lock()
	running := r.state == "running"
	r.mu.Unlock()
	if !running {
		return
	}
	peer := hostOnly(nc.RemoteAddr().String())
	cfg := &ssh.ServerConfig{
		ServerVersion: "SSH-2.0-ROSSSH",
		PasswordCallback: func(m ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
			if err := r.checkUser(m.User(), string(pass), "ssh", peer); err != nil {
				time.Sleep(500 * time.Millisecond)
				return nil, err
			}
			return nil, nil
		},
		KeyboardInteractiveCallback: func(m ssh.ConnMetadata, ch ssh.KeyboardInteractiveChallenge) (*ssh.Permissions, error) {
			ans, err := ch("", "", []string{"Password: "}, []bool{false})
			if err != nil || len(ans) != 1 {
				return nil, fmt.Errorf("auth failed")
			}
			if err := r.checkUser(m.User(), ans[0], "ssh", peer); err != nil {
				return nil, err
			}
			return nil, nil
		},
	}
	for _, k := range keys {
		cfg.AddHostKey(k)
	}
	nc.SetDeadline(time.Now().Add(30 * time.Second))
	conn, chans, reqs, err := ssh.NewServerConn(nc, cfg)
	if err != nil {
		return
	}
	nc.SetDeadline(time.Time{})
	defer conn.Close()
	kid := r.onKick(func() { conn.Close() })
	defer r.offKick(kid)
	user := strings.SplitN(conn.User(), "+", 2)[0]
	sid := r.userLogin(user, "ssh", peer)
	defer r.userLogout(sid)
	go ssh.DiscardRequests(reqs)
	for nch := range chans {
		if nch.ChannelType() != "session" {
			nch.Reject(ssh.UnknownChannelType, "unsupported")
			continue
		}
		ch, creqs, err := nch.Accept()
		if err != nil {
			continue
		}
		go sshSession(r, user, peer, ch, creqs)
	}
}

func sshSession(r *Router, user, peer string, ch ssh.Channel, reqs <-chan *ssh.Request) {
	defer ch.Close()
	defer func() {
		if p := recover(); p != nil {
			fmt.Fprintf(ch, "internal error: %v\r\n", p)
			fmt.Println("  ! ssh session error:", p)
		}
	}()
	width := 100
	var t *Term
	for req := range reqs {
		switch req.Type {
		case "pty-req":
			if len(req.Payload) > 4 {
				l := binary.BigEndian.Uint32(req.Payload[0:4])
				if int(4+l+4) <= len(req.Payload) {
					width = int(binary.BigEndian.Uint32(req.Payload[4+l : 8+l]))
				}
			}
			req.Reply(true, nil)
		case "window-change":
			if len(req.Payload) >= 4 {
				width = int(binary.BigEndian.Uint32(req.Payload[0:4]))
				if t != nil {
					t.SetWidth(width)
				}
			}
		case "env":
			req.Reply(true, nil)
		case "shell":
			req.Reply(true, nil)
			t = newTerm(r, user, "ssh", peer, ch, width)
			t.onClose = func() { ch.Close() }
			t.Start()
			go func() {
				buf := make([]byte, 1024)
				for {
					n, err := ch.Read(buf)
					if err != nil {
						t.Close()
						return
					}
					t.Input(buf[:n])
				}
			}()
		case "exec":
			req.Reply(true, nil)
			var cmd string
			if len(req.Payload) > 4 {
				cmd = string(req.Payload[4:])
			}
			if strings.HasPrefix(cmd, "scp ") {
				status := make([]byte, 4)
				status[3] = byte(scpServe(r, user, peer, ch, cmd))
				ch.CloseWrite()
				ch.SendRequest("exit-status", false, status)
				return
			}
			cli := newCLI(r, user, "ssh", peer, crlfOut{ch}, false)
			cli.color = false
			cli.runTerminal(cmd)
			status := make([]byte, 4)
			if cli.errors > 0 {
				status[3] = 1
			}
			ch.SendRequest("exit-status", false, status)
			return
		default:
			if req.WantReply {
				req.Reply(false, nil)
			}
		}
	}
}

type crlfOut struct{ w io.Writer }

func (c crlfOut) Write(p []byte) (int, error) {
	c.w.Write([]byte(strings.ReplaceAll(string(p), "\n", "\r\n")))
	return len(p), nil
}
