package main

// Parser for the RouterOS script language.

import (
	"fmt"
	"sort"
	"strings"
)

type Source struct {
	text  []rune
	lines []int // offset of each line start
}

func newSource(s string) *Source {
	src := &Source{text: []rune(strings.ReplaceAll(s, "\r\n", "\n"))}
	src.lines = []int{0}
	for i, r := range src.text {
		if r == '\n' {
			src.lines = append(src.lines, i+1)
		}
	}
	return src
}

func (s *Source) lineCol(pos int) (int, int) {
	i := sort.Search(len(s.lines), func(i int) bool { return s.lines[i] > pos }) - 1
	if i < 0 {
		i = 0
	}
	return i + 1, pos - s.lines[i] + 1
}

type Block struct {
	Stmts []*Stmt
	Src   *Source
	Text  string // the source between the braces
}

type Stmt struct {
	Args  []*Arg
	Block *Block
	Where Expr
	Pos   int
	Src   *Source
}

type Arg struct {
	Key  string // name=value / name~value
	Op   string
	Val  Expr // nil for a bare word
	Bare string
	Pos  int
}

type Expr interface{}

type (
	ELit   struct{ V Value }
	EWord  struct{ S string; Where bool }
	EStr   struct{ Parts []Expr }
	EVar   struct{ Name string }
	ECmd   struct{ B *Block }
	EBrace struct{ B *Block }
	EBin   struct {
		Op   string
		L, R Expr
	}
	EUn struct {
		Op string
		X  Expr
	}
	ECat struct{ Parts []Expr }
)

type parser struct {
	s *Source
	r []rune
	i int
}

type syntaxErr struct {
	pos int
	msg string
}

func (e *syntaxErr) Error() string { return e.msg }

func (p *parser) fail(msg string) {
	panic(&syntaxErr{p.i, msg})
}

// parseScript parses a whole script. Errors read like RouterOS's own.
func parseScript(text string) (b *Block, err error) {
	src := newSource(text)
	p := &parser{s: src, r: src.text}
	defer func() {
		if x := recover(); x != nil {
			se, ok := x.(*syntaxErr)
			if !ok {
				panic(x)
			}
			l, c := src.lineCol(se.pos)
			msg := "syntax error"
			if se.msg != "" && se.msg != "syntax error" {
				msg = se.msg
			}
			err = &ScriptError{Msg: fmt.Sprintf("%s (line %d column %d)", msg, l, c), Line: l, Col: c, Syntax: true}
		}
	}()
	b = p.block(0)
	if p.i < len(p.r) {
		p.fail("syntax error")
	}
	b.Text = text
	return b, nil
}

func (p *parser) peek() rune {
	if p.i < len(p.r) {
		return p.r[p.i]
	}
	return 0
}

func (p *parser) at(off int) rune {
	if p.i+off < len(p.r) {
		return p.r[p.i+off]
	}
	return 0
}

// skipSpace skips blanks and line continuations, not newlines.
func (p *parser) skipSpace() {
	for p.i < len(p.r) {
		switch c := p.r[p.i]; {
		case c == ' ' || c == '\t' || c == '\r':
			p.i++
		case c == '\\' && (p.at(1) == '\n' || p.at(1) == '\r' && p.at(2) == '\n'):
			p.i += 2
			if p.at(-1) == '\r' {
				p.i++
			}
		default:
			return
		}
	}
}

func (p *parser) skipSpaceNL() {
	for {
		p.skipSpace()
		if p.peek() == '\n' {
			p.i++
			continue
		}
		return
	}
}

func (p *parser) block(end rune) *Block {
	b := &Block{Src: p.s}
	for {
		for {
			p.skipSpace()
			if c := p.peek(); c == '\n' || c == ';' {
				p.i++
				continue
			}
			break
		}
		c := p.peek()
		if c == 0 {
			if end != 0 {
				p.fail("missing " + string(end))
			}
			return b
		}
		if c == end {
			return b
		}
		if c == '#' {
			for p.i < len(p.r) && p.r[p.i] != '\n' {
				p.i++
			}
			continue
		}
		b.Stmts = append(b.Stmts, p.stmt(end))
	}
}

func (p *parser) expect(c rune) {
	if p.peek() != c {
		p.fail("syntax error")
	}
	p.i++
}

func (p *parser) stmt(end rune) *Stmt {
	st := &Stmt{Pos: p.i, Src: p.s}
	if p.peek() == '{' {
		p.i++
		start := p.i
		st.Block = p.block('}')
		st.Block.Text = string(p.r[start:p.i])
		p.expect('}')
		return st
	}
	for {
		p.skipSpace()
		c := p.peek()
		if c == 0 || c == '\n' || c == ';' || c == end {
			return st
		}
		if c == ']' || c == '}' || c == ')' {
			p.fail("syntax error")
		}
		if len(st.Args) > 0 && p.isWord("where") {
			p.i += 5
			st.Where = p.expr(0, true, end)
			continue
		}
		st.Args = append(st.Args, p.arg(end))
	}
}

func (p *parser) isWord(w string) bool {
	n := len([]rune(w))
	if p.i+n > len(p.r) || string(p.r[p.i:p.i+n]) != w {
		return false
	}
	c := p.at(n)
	return c == 0 || c == ' ' || c == '\t' || c == '\n' || c == '(' || c == '!' || c == ';' || c == ']' || c == '\r'
}

func isNameChar(c rune) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_'
}

func (p *parser) dollarStarts() bool {
	n := p.at(1)
	return isNameChar(n) || n == '"' || n == '[' || n == '('
}

func isKeyWord(w string) bool {
	if w == "" || strings.HasPrefix(w, "/") || strings.HasPrefix(w, ":") || strings.HasPrefix(w, "!") {
		return false
	}
	for _, c := range w {
		if !(isNameChar(c) || c == '-' || c == '.') {
			return false
		}
	}
	return true
}

// word reads an unquoted word in command position.
func (p *parser) word(inValue bool) string {
	start := p.i
	for p.i < len(p.r) {
		c := p.r[p.i]
		switch c {
		case ' ', '\t', '\n', '\r', ';', '"', '[', ']', '(', ')', '{', '}':
			return string(p.r[start:p.i])
		case '$':
			if p.dollarStarts() {
				return string(p.r[start:p.i])
			}
		case '=':
			if !inValue && p.i > start {
				return string(p.r[start:p.i])
			}
		case '~':
			if !inValue && p.i > start && p.at(1) == '"' {
				return string(p.r[start:p.i])
			}
		case '\\':
			if p.at(1) == '\n' || p.at(1) == '\r' {
				return string(p.r[start:p.i])
			}
		}
		p.i++
	}
	return string(p.r[start:p.i])
}

func (p *parser) arg(end rune) *Arg {
	pos := p.i
	switch p.peek() {
	case '"', '[', '(', '{', '$':
		return &Arg{Val: p.adjacent(end), Pos: pos}
	}
	w := p.word(false)
	if w == "" {
		p.fail("syntax error")
	}
	if (p.peek() == '=' || p.peek() == '~') && isKeyWord(w) {
		op := string(p.peek())
		p.i++
		c := p.peek()
		if c == 0 || c == ' ' || c == '\t' || c == '\n' || c == ';' || c == end || c == '\r' {
			return &Arg{Key: w, Op: op, Val: ELit{vStr("")}, Pos: pos}
		}
		return &Arg{Key: w, Op: op, Val: p.adjacent(end), Pos: pos}
	}
	if c := p.peek(); c == '"' || c == '$' && p.dollarStarts() {
		parts := []Expr{EWord{S: w}}
		parts = append(parts, p.adjacentParts(end)...)
		return &Arg{Val: ECat{parts}, Pos: pos}
	}
	return &Arg{Bare: w, Pos: pos}
}

func (p *parser) adjacentParts(end rune) []Expr {
	var parts []Expr
	for {
		c := p.peek()
		switch {
		case c == '"' || c == '[' || c == '(' || c == '{':
			parts = append(parts, p.term())
		case c == '$':
			if !p.dollarStarts() {
				parts = append(parts, EWord{S: p.word(true)})
				continue
			}
			parts = append(parts, p.term())
		case c == 0 || c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == ';' || c == ']' || c == '}' || c == ')' || c == end:
			return parts
		case c == '\\' && (p.at(1) == '\n' || p.at(1) == '\r'):
			return parts
		default:
			w := p.word(true)
			if w == "" {
				return parts
			}
			parts = append(parts, EWord{S: w})
		}
	}
}

func (p *parser) adjacent(end rune) Expr {
	parts := p.adjacentParts(end)
	if len(parts) == 1 {
		return parts[0]
	}
	if len(parts) == 0 {
		return ELit{vStr("")}
	}
	return ECat{parts}
}

func (p *parser) term() Expr {
	switch p.peek() {
	case '"':
		return p.str()
	case '[':
		p.i++
		b := p.block(']')
		p.expect(']')
		return ECmd{b}
	case '(':
		p.i++
		p.skipSpaceNL()
		if p.peek() == ')' {
			p.i++
			return ELit{vNothing}
		}
		e := p.expr(0, false, ')')
		p.skipSpaceNL()
		p.expect(')')
		return e
	case '{':
		p.i++
		start := p.i
		b := p.block('}')
		b.Text = string(p.r[start:p.i])
		p.expect('}')
		return EBrace{b}
	case '$':
		return p.variable()
	}
	return EWord{S: p.word(true)}
}

func (p *parser) variable() Expr {
	p.i++ // $
	switch p.peek() {
	case '"':
		e := p.str()
		if l, ok := e.(ELit); ok {
			return EVar{l.V.S}
		}
		p.fail("syntax error")
	case '[', '(':
		return p.term()
	}
	start := p.i
	for p.i < len(p.r) && isNameChar(p.r[p.i]) {
		p.i++
	}
	if p.i == start {
		return ELit{vStr("$")}
	}
	return EVar{string(p.r[start:p.i])}
}

func isHexR(c rune) bool {
	return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F'
}

func hexVal(c rune) byte {
	switch {
	case c >= '0' && c <= '9':
		return byte(c - '0')
	case c >= 'a' && c <= 'f':
		return byte(c - 'a' + 10)
	}
	return byte(c - 'A' + 10)
}

func (p *parser) str() Expr {
	p.i++ // opening quote
	var parts []Expr
	var buf []byte
	flush := func() {
		if len(buf) > 0 {
			parts = append(parts, ELit{vStr(string(buf))})
			buf = nil
		}
	}
	for {
		if p.i >= len(p.r) {
			p.fail("syntax error")
		}
		c := p.r[p.i]
		switch c {
		case '"':
			p.i++
			flush()
			if len(parts) == 0 {
				return ELit{vStr("")}
			}
			if len(parts) == 1 {
				if l, ok := parts[0].(ELit); ok {
					return l
				}
			}
			return EStr{parts}
		case '\\':
			n := p.at(1)
			p.i += 2
			switch n {
			case 'n':
				buf = append(buf, '\n')
			case 'r':
				buf = append(buf, '\r')
			case 't':
				buf = append(buf, '\t')
			case '_':
				buf = append(buf, ' ')
			case 'a':
				buf = append(buf, 7)
			case 'b':
				buf = append(buf, 8)
			case 'f':
				buf = append(buf, 12)
			case 'v':
				buf = append(buf, 11)
			case '\n':
			case '\r':
				if p.peek() == '\n' {
					p.i++
				}
			default:
				if isHexR(n) && isHexR(p.peek()) {
					buf = append(buf, hexVal(n)<<4|hexVal(p.peek()))
					p.i++
				} else {
					buf = append(buf, string(n)...)
				}
			}
		case '$':
			if p.dollarStarts() {
				flush()
				parts = append(parts, p.variable())
				continue
			}
			buf = append(buf, '$')
			p.i++
		default:
			buf = append(buf, string(c)...)
			p.i++
		}
	}
}

// ---------- expressions ----------

var opPrec = map[string]int{
	"->": 100,
	"*":  70, "/": 70, "%": 70,
	"+": 60, "-": 60, ".": 60,
	"<<": 55, ">>": 55,
	"<": 50, ">": 50, "<=": 50, ">=": 50, "in": 50, "~": 50,
	"=": 45, "!=": 45,
	"&": 40, "^": 35, "|": 30,
	"&&": 20, "and": 20,
	"||": 10, "or": 10,
	",": 5,
}

func (p *parser) skipExpr(where bool) {
	if where {
		p.skipSpace()
	} else {
		p.skipSpaceNL()
	}
}

func (p *parser) peekOp(where bool, end rune) (string, int) {
	c := p.peek()
	if c == 0 || c == ')' || c == end || c == ']' || c == '}' || c == ';' || c == '\n' {
		return "", 0
	}
	for _, op := range []string{"->", "&&", "||", "!=", "<=", ">=", "<<", ">>"} {
		if strings.HasPrefix(string(p.r[p.i:min(len(p.r), p.i+2)]), op) {
			return op, 2
		}
	}
	switch c {
	case '+', '-', '*', '/', '%', '.', ',', '=', '<', '>', '~', '&', '|', '^':
		return string(c), 1
	}
	for _, w := range []string{"and", "or", "in"} {
		if p.isWord(w) || p.isWord(w) {
			return w, len(w)
		}
		n := len(w)
		if p.i+n <= len(p.r) && string(p.r[p.i:p.i+n]) == w && (p.at(n) == '$' || p.at(n) == '"' || p.at(n) == '[') {
			return w, n
		}
	}
	return "", 0
}

func (p *parser) expr(minPrec int, where bool, end rune) Expr {
	left := p.unary(where, end)
	for {
		p.skipExpr(where)
		op, n := p.peekOp(where, end)
		if op == "" {
			return left
		}
		prec := opPrec[op]
		if prec < minPrec {
			return left
		}
		p.i += n
		if op == "->" {
			p.skipExpr(where)
			left = EBin{"->", left, p.primary(where, end)}
			continue
		}
		right := p.expr(prec+1, where, end)
		left = EBin{op, left, right}
	}
}

func (p *parser) unary(where bool, end rune) Expr {
	p.skipExpr(where)
	switch c := p.peek(); {
	case c == '!' && p.at(1) != '=':
		p.i++
		return EUn{"!", p.unary(where, end)}
	case c == '-' && (p.at(1) == '$' || p.at(1) == '(' || p.at(1) == '['):
		p.i++
		return EUn{"-", p.unary(where, end)}
	}
	return p.primary(where, end)
}

func isExprWordChar(c rune) bool {
	return isNameChar(c) || c == '.' || c == ':' || c == '/' || c == '*' || c == '-' || c == '@' || c == '#' || c == '?'
}

func (p *parser) primary(where bool, end rune) Expr {
	p.skipExpr(where)
	switch c := p.peek(); c {
	case '"', '[', '(', '{', '$':
		return p.term()
	case 0, ')', ']', '}', ';', '\n':
		p.fail("syntax error")
	}
	start := p.i
	if p.peek() == '-' {
		p.i++
	}
	for p.i < len(p.r) && isExprWordChar(p.r[p.i]) {
		// a "." or "-" followed by a blank is an operator, not part of the word
		if (p.r[p.i] == '.' || p.r[p.i] == '-' || p.r[p.i] == '/' || p.r[p.i] == '*') && p.i > start && (p.at(1) == ' ' || p.at(1) == '\t') {
			break
		}
		p.i++
	}
	if p.i == start {
		p.fail("syntax error")
	}
	return EWord{S: string(p.r[start:p.i]), Where: where}
}

// scriptComplete reports whether text can be run as it is, or the terminal
// should wait for more lines (open braces, quotes, or a trailing backslash).
func scriptComplete(text string) bool {
	depth, inq, atStart := 0, false, true
	r := []rune(text)
	for i := 0; i < len(r); i++ {
		c := r[i]
		if inq {
			if c == '\\' {
				i++
			} else if c == '"' {
				inq = false
			}
			continue
		}
		switch c {
		case '#':
			if atStart {
				for i < len(r) && r[i] != '\n' {
					i++
				}
				atStart = true
				continue
			}
		case '"':
			inq = true
		case '{', '[', '(':
			depth++
		case '}', ']', ')':
			depth--
		case '\\':
			if i+1 < len(r) && r[i+1] == '\n' {
				i++
				continue
			}
			if i == len(r)-1 {
				return false
			}
		}
		if c == '\n' || c == ';' || c == '{' {
			atStart = true
		} else if c != ' ' && c != '\t' {
			atStart = false
		}
	}
	t := strings.TrimRight(text, " \t\r\n")
	return depth <= 0 && !inq && !strings.HasSuffix(t, "\\")
}
