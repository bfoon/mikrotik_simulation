package main

// WireGuard for /interface wireguard, in userspace: no driver and no
// administrator rights. It follows the WireGuard paper (Noise_IKpsk2), so a
// simulated router can join a real WireGuard network such as TapTap Tunnel.
// Traffic inside the tunnel is answered by a small TCP/IP stack
// (netstack.go) that hands connections to the simulator's own services.

import (
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"net"
	"net/netip"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/blake2s"
	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/curve25519"
)

const (
	wgConstruction   = "Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s"
	wgIdentifier     = "WireGuard v1 zx2c4 Jason@zx2c4.com"
	wgLabelMAC1      = "mac1----"
	wgLabelCookie    = "cookie--"
	rekeyAfterTime   = 120 * time.Second
	rejectAfterTime  = 180 * time.Second
	rekeyTimeout     = 5 * time.Second
	keepaliveTimeout = 10 * time.Second
	rekeyAttemptTime = 90 * time.Second
	cookieLifetime   = 120 * time.Second
)

var (
	wgCInit = wgHash([]byte(wgConstruction))
	wgHInit = wgHash(wgCInit[:], []byte(wgIdentifier))
)

func blake2sNew() hash.Hash { h, _ := blake2s.New256(nil); return h }

func wgHash(parts ...[]byte) (out [32]byte) {
	h := blake2sNew()
	for _, p := range parts {
		h.Write(p)
	}
	copy(out[:], h.Sum(nil))
	return
}

func wgHMAC(key []byte, parts ...[]byte) (out [32]byte) {
	m := hmac.New(blake2sNew, key)
	for _, p := range parts {
		m.Write(p)
	}
	copy(out[:], m.Sum(nil))
	return
}

// wgKDF returns n 32-byte outputs of HKDF with HMAC-BLAKE2s.
func wgKDF(n int, key, input []byte) [][32]byte {
	t0 := wgHMAC(key, input)
	out := make([][32]byte, 0, n)
	var prev []byte
	for i := 1; i <= n; i++ {
		t := wgHMAC(t0[:], prev, []byte{byte(i)})
		out = append(out, t)
		prev = t[:]
	}
	return out
}

func wgMAC(key, data []byte) (out [16]byte) {
	h, _ := blake2s.New128(key)
	h.Write(data)
	copy(out[:], h.Sum(nil))
	return
}

func wgAEAD(key [32]byte) cipher.AEAD {
	a, _ := chacha20poly1305.New(key[:])
	return a
}

func wgNonce(counter uint64) []byte {
	n := make([]byte, 12)
	binary.LittleEndian.PutUint64(n[4:], counter)
	return n
}

func wgSeal(key [32]byte, counter uint64, plain, ad []byte) []byte {
	return wgAEAD(key).Seal(nil, wgNonce(counter), plain, ad)
}

func wgOpen(key [32]byte, counter uint64, ct, ad []byte) ([]byte, error) {
	return wgAEAD(key).Open(nil, wgNonce(counter), ct, ad)
}

// ---------- keys ----------

func wgNewPrivate() (k [32]byte) {
	rand.Read(k[:])
	k[0] &= 248
	k[31] = (k[31] & 127) | 64
	return
}

func wgPublic(priv [32]byte) (pub [32]byte) {
	p, _ := curve25519.X25519(priv[:], curve25519.Basepoint)
	copy(pub[:], p)
	return
}

func wgDH(priv, pub [32]byte) ([32]byte, error) {
	var out [32]byte
	s, err := curve25519.X25519(priv[:], pub[:])
	if err != nil {
		return out, err
	}
	copy(out[:], s)
	return out, nil
}

func wgKeyB64(k [32]byte) string { return base64.StdEncoding.EncodeToString(k[:]) }

func wgParseKey(s string) ([32]byte, bool) {
	var k [32]byte
	b, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil || len(b) != 32 {
		return k, false
	}
	copy(k[:], b)
	return k, true
}

func tai64n(t time.Time) (b [12]byte) {
	binary.BigEndian.PutUint64(b[0:8], 0x400000000000000a+uint64(t.Unix()))
	binary.BigEndian.PutUint32(b[8:12], uint32(t.Nanosecond()))
	return
}

// ---------- state ----------

type wgKeypair struct {
	send, recv   cipher.AEAD
	sendCounter  atomic.Uint64
	localIndex   uint32
	remoteIndex  uint32
	created      time.Time
	initiator    bool
	replayMu     sync.Mutex
	replayTop    uint64
	replayBitmap [32]uint64 // 2048-packet window
	replayInit   bool
}

func (kp *wgKeypair) replayOK(c uint64) bool {
	kp.replayMu.Lock()
	defer kp.replayMu.Unlock()
	const window = 2048
	if !kp.replayInit {
		kp.replayInit = true
		kp.replayTop = c
		kp.replayBitmap = [32]uint64{}
		kp.setBit(c)
		return true
	}
	if c > kp.replayTop {
		diff := c - kp.replayTop
		if diff >= window {
			kp.replayBitmap = [32]uint64{}
		} else {
			for i := kp.replayTop + 1; i <= c; i++ {
				kp.clearBit(i)
			}
		}
		kp.replayTop = c
		kp.setBit(c)
		return true
	}
	if kp.replayTop-c >= window || kp.bit(c) {
		return false
	}
	kp.setBit(c)
	return true
}

func (kp *wgKeypair) setBit(c uint64)   { i := c % 2048; kp.replayBitmap[i/64] |= 1 << (i % 64) }
func (kp *wgKeypair) clearBit(c uint64) { i := c % 2048; kp.replayBitmap[i/64] &^= 1 << (i % 64) }
func (kp *wgKeypair) bit(c uint64) bool { i := c % 2048; return kp.replayBitmap[i/64]&(1<<(i%64)) != 0 }

type wgHandshake struct {
	sent          bool // an initiation of ours is waiting for its response
	localIndex    uint32
	h, ck         [32]byte
	ePriv, ePub   [32]byte
	lastMAC1      [16]byte
	lastTimestamp [12]byte
}

type wgPeer struct {
	ifc        *wgIface
	id         string // .id of the peer item
	pub        [32]byte
	psk        [32]byte
	ss         [32]byte // static-static DH
	mac1Key    [32]byte
	cookieKey  [32]byte
	endpoint   *net.UDPAddr
	epHost     string
	epPort     int
	allowed    []netip.Prefix
	keepalive  time.Duration
	disabled   bool
	mu         sync.Mutex
	hs         wgHandshake
	cur, prev  *wgKeypair
	next       *wgKeypair // responder keys, used once the initiator sends data
	lastHS     time.Time
	lastSent   time.Time
	lastRecv   time.Time
	lastData   time.Time
	attemptAt  time.Time // when the current series of initiations started
	initAt     time.Time
	cookie     [16]byte
	cookieAt   time.Time
	queue      [][]byte
	rx, tx     atomic.Uint64
	resolvedAt time.Time
}

type wgIface struct {
	mgr     *WGManager
	name    string
	priv    [32]byte
	pub     [32]byte
	mac1Key [32]byte
	port    int
	conn    *net.UDPConn
	mtu     int
	mu      sync.Mutex
	peers   []*wgPeer
	index   map[uint32]*wgIndex
	addrs   []netip.Prefix
	stack   *ipStack
	closed  atomic.Bool
	err     string
}

type wgIndex struct {
	peer *wgPeer
	kp   *wgKeypair // nil while it names a handshake
}

func (w *wgIface) newIndex(e *wgIndex) uint32 {
	for {
		var b [4]byte
		rand.Read(b[:])
		i := binary.LittleEndian.Uint32(b[:])
		if _, used := w.index[i]; !used && i != 0 {
			w.index[i] = e
			return i
		}
	}
}

func (w *wgIface) dropIndex(i uint32) {
	if i != 0 {
		delete(w.index, i)
	}
}

// ---------- the handshake ----------

func (p *wgPeer) buildInitiation() []byte {
	w := p.ifc
	hs := &p.hs
	w.dropIndex(hs.localIndex)
	hs.localIndex = w.newIndex(&wgIndex{peer: p})
	hs.ePriv = wgNewPrivate()
	hs.ePub = wgPublic(hs.ePriv)
	hs.ck = wgCInit
	hs.h = wgHash(wgHInit[:], p.pub[:])

	msg := make([]byte, 148)
	msg[0] = 1
	binary.LittleEndian.PutUint32(msg[4:], hs.localIndex)
	copy(msg[8:40], hs.ePub[:])
	hs.ck = wgKDF(1, hs.ck[:], hs.ePub[:])[0]
	hs.h = wgHash(hs.h[:], hs.ePub[:])
	es, _ := wgDH(hs.ePriv, p.pub)
	k := wgKDF(2, hs.ck[:], es[:])
	hs.ck = k[0]
	encStatic := wgSeal(k[1], 0, w.pub[:], hs.h[:])
	copy(msg[40:88], encStatic)
	hs.h = wgHash(hs.h[:], encStatic)
	k = wgKDF(2, hs.ck[:], p.ss[:])
	hs.ck = k[0]
	ts := tai64n(time.Now())
	encTS := wgSeal(k[1], 0, ts[:], hs.h[:])
	copy(msg[88:116], encTS)
	hs.h = wgHash(hs.h[:], encTS)
	mac1 := wgMAC(p.mac1Key[:], msg[:116])
	copy(msg[116:132], mac1[:])
	hs.lastMAC1 = mac1
	if !p.cookieAt.IsZero() && time.Since(p.cookieAt) < cookieLifetime {
		mac2 := wgMAC(p.cookie[:], msg[:132])
		copy(msg[132:148], mac2[:])
	}
	hs.sent = true
	return msg
}

func (w *wgIface) handleInitiation(msg []byte, from *net.UDPAddr) {
	if len(msg) != 148 {
		return
	}
	if mac1 := wgMAC(w.mac1Key[:], msg[:116]); !hmac.Equal(mac1[:], msg[116:132]) {
		return
	}
	ck := wgCInit
	h := wgHash(wgHInit[:], w.pub[:])
	var eIn [32]byte
	copy(eIn[:], msg[8:40])
	ck = wgKDF(1, ck[:], eIn[:])[0]
	h = wgHash(h[:], eIn[:])
	es, err := wgDH(w.priv, eIn)
	if err != nil {
		return
	}
	k := wgKDF(2, ck[:], es[:])
	ck = k[0]
	static, err := wgOpen(k[1], 0, msg[40:88], h[:])
	if err != nil {
		return
	}
	h = wgHash(h[:], msg[40:88])
	var sIn [32]byte
	copy(sIn[:], static)
	w.mu.Lock()
	var p *wgPeer
	for _, x := range w.peers {
		if x.pub == sIn && !x.disabled {
			p = x
		}
	}
	w.mu.Unlock()
	if p == nil {
		return
	}
	k = wgKDF(2, ck[:], p.ss[:])
	ck = k[0]
	ts, err := wgOpen(k[1], 0, msg[88:116], h[:])
	if err != nil {
		return
	}
	h = wgHash(h[:], msg[88:116])

	w.mu.Lock()
	defer w.mu.Unlock()
	p.mu.Lock()
	defer p.mu.Unlock()
	var tsa [12]byte
	copy(tsa[:], ts)
	if string(tsa[:]) <= string(p.hs.lastTimestamp[:]) && p.hs.lastTimestamp != ([12]byte{}) {
		return // replayed initiation
	}
	p.hs.lastTimestamp = tsa
	remoteIndex := binary.LittleEndian.Uint32(msg[4:8])

	// response
	ePriv := wgNewPrivate()
	ePub := wgPublic(ePriv)
	resp := make([]byte, 92)
	resp[0] = 2
	kp := &wgKeypair{created: time.Now(), remoteIndex: remoteIndex}
	kp.localIndex = w.newIndex(&wgIndex{peer: p, kp: kp})
	binary.LittleEndian.PutUint32(resp[4:], kp.localIndex)
	binary.LittleEndian.PutUint32(resp[8:], remoteIndex)
	copy(resp[12:44], ePub[:])
	ck = wgKDF(1, ck[:], ePub[:])[0]
	h = wgHash(h[:], ePub[:])
	ee, _ := wgDH(ePriv, eIn)
	ck = wgKDF(1, ck[:], ee[:])[0]
	se, _ := wgDH(ePriv, sIn)
	ck = wgKDF(1, ck[:], se[:])[0]
	k3 := wgKDF(3, ck[:], p.psk[:])
	ck = k3[0]
	h = wgHash(h[:], k3[1][:])
	empty := wgSeal(k3[2], 0, nil, h[:])
	copy(resp[44:60], empty)
	mac1 := wgMAC(p.mac1Key[:], resp[:60])
	copy(resp[60:76], mac1[:])
	if !p.cookieAt.IsZero() && time.Since(p.cookieAt) < cookieLifetime {
		mac2 := wgMAC(p.cookie[:], resp[:76])
		copy(resp[76:92], mac2[:])
	}
	t := wgKDF(2, ck[:], nil)
	kp.recv, kp.send = wgAEAD(t[0]), wgAEAD(t[1])
	if p.next != nil {
		w.dropIndex(p.next.localIndex)
	}
	p.next = kp
	p.endpoint = from
	w.send(p, resp)
}

func (w *wgIface) handleResponse(msg []byte, from *net.UDPAddr) {
	if len(msg) != 92 {
		return
	}
	if mac1 := wgMAC(w.mac1Key[:], msg[:60]); !hmac.Equal(mac1[:], msg[60:76]) {
		return
	}
	recvIdx := binary.LittleEndian.Uint32(msg[8:12])
	w.mu.Lock()
	defer w.mu.Unlock()
	e := w.index[recvIdx]
	if e == nil || e.kp != nil {
		return
	}
	p := e.peer
	p.mu.Lock()
	defer p.mu.Unlock()
	hs := &p.hs
	if !hs.sent || hs.localIndex != recvIdx {
		return
	}
	var eR [32]byte
	copy(eR[:], msg[12:44])
	ck, h := hs.ck, hs.h
	ck = wgKDF(1, ck[:], eR[:])[0]
	h = wgHash(h[:], eR[:])
	ee, err := wgDH(hs.ePriv, eR)
	if err != nil {
		return
	}
	ck = wgKDF(1, ck[:], ee[:])[0]
	se, err := wgDH(w.priv, eR)
	if err != nil {
		return
	}
	ck = wgKDF(1, ck[:], se[:])[0]
	k3 := wgKDF(3, ck[:], p.psk[:])
	ck = k3[0]
	h = wgHash(h[:], k3[1][:])
	if _, err := wgOpen(k3[2], 0, msg[44:60], h[:]); err != nil {
		return
	}
	t := wgKDF(2, ck[:], nil)
	kp := &wgKeypair{created: time.Now(), initiator: true, localIndex: recvIdx, remoteIndex: binary.LittleEndian.Uint32(msg[4:8])}
	kp.send, kp.recv = wgAEAD(t[0]), wgAEAD(t[1])
	e.kp = kp
	hs.sent = false
	hs.localIndex = 0
	p.install(kp)
	p.lastHS = time.Now()
	p.attemptAt = time.Time{}
	p.endpoint = from
	// confirm the keys at once: queued packets, or a keepalive
	q := p.queue
	p.queue = nil
	if len(q) == 0 {
		w.sendData(p, nil)
	}
	for _, pkt := range q {
		w.sendData(p, pkt)
	}
}

func (p *wgPeer) install(kp *wgKeypair) {
	w := p.ifc
	if p.prev != nil {
		w.dropIndex(p.prev.localIndex)
	}
	p.prev, p.cur = p.cur, kp
}

func (w *wgIface) handleCookie(msg []byte) {
	if len(msg) != 64 {
		return
	}
	idx := binary.LittleEndian.Uint32(msg[4:8])
	w.mu.Lock()
	defer w.mu.Unlock()
	e := w.index[idx]
	if e == nil {
		return
	}
	p := e.peer
	p.mu.Lock()
	defer p.mu.Unlock()
	a, err := chacha20poly1305.NewX(p.cookieKey[:])
	if err != nil {
		return
	}
	c, err := a.Open(nil, msg[8:32], msg[32:64], p.hs.lastMAC1[:])
	if err != nil || len(c) != 16 {
		return
	}
	copy(p.cookie[:], c)
	p.cookieAt = time.Now()
}

// ---------- data ----------

func (w *wgIface) handleData(msg []byte, from *net.UDPAddr) {
	if len(msg) < 32 {
		return
	}
	idx := binary.LittleEndian.Uint32(msg[4:8])
	counter := binary.LittleEndian.Uint64(msg[8:16])
	w.mu.Lock()
	e := w.index[idx]
	w.mu.Unlock()
	if e == nil || e.kp == nil {
		return
	}
	kp, p := e.kp, e.peer
	if time.Since(kp.created) > rejectAfterTime {
		return
	}
	plain, err := kp.recv.Open(nil, wgNonce(counter), msg[16:], nil)
	if err != nil || !kp.replayOK(counter) {
		return
	}
	w.mu.Lock()
	p.mu.Lock()
	if p.next == kp {
		p.next = nil
		p.install(kp)
		p.lastHS = time.Now()
	}
	p.endpoint = from
	p.lastRecv = time.Now()
	p.rx.Add(uint64(len(msg)))
	if len(plain) > 0 {
		p.lastData = time.Now()
	}
	p.mu.Unlock()
	w.mu.Unlock()
	if len(plain) == 0 {
		return // keepalive
	}
	pkt := ipPacketLen(plain)
	if pkt == nil {
		return
	}
	src, ok := netip.AddrFromSlice(pkt[12:16])
	if !ok || !p.allows(src) {
		return
	}
	w.stack.input(pkt)
}

func ipPacketLen(b []byte) []byte {
	if len(b) < 20 || b[0]>>4 != 4 {
		return nil
	}
	n := int(binary.BigEndian.Uint16(b[2:4]))
	if n < 20 || n > len(b) {
		return nil
	}
	return b[:n]
}

func (p *wgPeer) allows(a netip.Addr) bool {
	for _, pr := range p.allowed {
		if pr.Contains(a) {
			return true
		}
	}
	return false
}

// sendData encrypts one IP packet (or a keepalive when pkt is nil) for p.
// Called with w.mu and p.mu held.
func (w *wgIface) sendData(p *wgPeer, pkt []byte) bool {
	kp := p.cur
	if kp == nil || time.Since(kp.created) > rejectAfterTime || p.endpoint == nil {
		return false
	}
	n := kp.sendCounter.Add(1) - 1
	padded := pkt
	if pad := (16 - len(pkt)%16) % 16; pad > 0 && len(pkt)+pad <= max(w.mtu, len(pkt)+pad) {
		padded = append(append([]byte{}, pkt...), make([]byte, pad)...)
	}
	out := make([]byte, 16, 16+len(padded)+16)
	out[0] = 4
	binary.LittleEndian.PutUint32(out[4:], kp.remoteIndex)
	binary.LittleEndian.PutUint64(out[8:], n)
	out = kp.send.Seal(out, wgNonce(n), padded, nil)
	w.send(p, out)
	return true
}

func (w *wgIface) send(p *wgPeer, b []byte) {
	if p.endpoint == nil || w.conn == nil {
		return
	}
	if _, err := w.conn.WriteToUDP(b, p.endpoint); err == nil {
		p.lastSent = time.Now()
		p.tx.Add(uint64(len(b)))
	}
}

// sendIP routes a packet from the stack to the peer whose allowed-address
// covers its destination.
func (w *wgIface) sendIP(pkt []byte) {
	dst, ok := netip.AddrFromSlice(pkt[16:20])
	if !ok {
		return
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	var best *wgPeer
	bestBits := -1
	for _, p := range w.peers {
		if p.disabled {
			continue
		}
		for _, pr := range p.allowed {
			if pr.Contains(dst) && pr.Bits() > bestBits {
				best, bestBits = p, pr.Bits()
			}
		}
	}
	if best == nil {
		return
	}
	p := best
	p.mu.Lock()
	defer p.mu.Unlock()
	if w.sendData(p, pkt) {
		if p.cur != nil && p.cur.initiator && time.Since(p.cur.created) > rekeyAfterTime && !p.hs.sent {
			w.initiate(p)
		}
		return
	}
	if len(p.queue) < 128 {
		p.queue = append(p.queue, append([]byte{}, pkt...))
	}
	if !p.hs.sent {
		w.initiate(p)
	}
}

// initiate sends a handshake initiation. Called with w.mu and p.mu held.
func (w *wgIface) initiate(p *wgPeer) {
	if p.endpoint == nil || p.disabled {
		return
	}
	if p.attemptAt.IsZero() {
		p.attemptAt = time.Now()
	}
	p.initAt = time.Now()
	w.send(p, p.buildInitiation())
}

// tick runs the WireGuard timers: retries, keepalives, rekeying, expiry.
func (w *wgIface) tick() {
	w.mu.Lock()
	defer w.mu.Unlock()
	now := time.Now()
	for _, p := range w.peers {
		p.mu.Lock()
		switch {
		case p.disabled || p.endpoint == nil:
		case p.hs.sent && now.Sub(p.initAt) > rekeyTimeout+time.Duration(time.Now().UnixNano()%333)*time.Millisecond:
			if now.Sub(p.attemptAt) > rekeyAttemptTime && p.keepalive == 0 {
				p.hs.sent = false
				p.attemptAt = time.Time{}
				p.queue = nil
			} else {
				w.initiate(p)
			}
		case !p.hs.sent && (p.cur == nil || now.Sub(p.cur.created) > rejectAfterTime) && (p.keepalive > 0 || len(p.queue) > 0):
			w.initiate(p)
		case !p.hs.sent && p.cur != nil && p.cur.initiator && now.Sub(p.cur.created) > rekeyAfterTime:
			w.initiate(p)
		case !p.hs.sent && p.cur != nil && !p.cur.initiator && now.Sub(p.cur.created) > rejectAfterTime-keepaliveTimeout-rekeyTimeout:
			w.initiate(p)
		}
		if p.cur != nil && now.Sub(p.cur.created) <= rejectAfterTime {
			if p.keepalive > 0 && now.Sub(p.lastSent) >= p.keepalive {
				w.sendData(p, nil)
			} else if !p.lastData.IsZero() && p.lastData.After(p.lastSent) && now.Sub(p.lastData) >= keepaliveTimeout {
				w.sendData(p, nil)
			}
		}
		if p.cur != nil && now.Sub(p.cur.created) > 3*rejectAfterTime {
			w.dropIndex(p.cur.localIndex)
			p.cur = nil
		}
		p.mu.Unlock()
	}
}

func (w *wgIface) readLoop() {
	buf := make([]byte, 65536)
	for !w.closed.Load() {
		n, from, err := w.conn.ReadFromUDP(buf)
		if err != nil {
			if w.closed.Load() {
				return
			}
			time.Sleep(50 * time.Millisecond)
			continue
		}
		if n < 4 {
			continue
		}
		msg := append([]byte{}, buf[:n]...)
		switch msg[0] {
		case 1:
			w.handleInitiation(msg, from)
		case 2:
			w.handleResponse(msg, from)
		case 3:
			w.handleCookie(msg)
		case 4:
			w.handleData(msg, from)
		}
	}
}

func (w *wgIface) close() {
	if w.closed.Swap(true) {
		return
	}
	if w.conn != nil {
		w.conn.Close()
	}
	if w.stack != nil {
		w.stack.close()
	}
}

// ---------- configuration from /interface wireguard ----------

type wgPeerCfg struct {
	id, pub, psk, host string
	port               int
	allowed            []netip.Prefix
	keepalive          time.Duration
	disabled           bool
}

type wgIfaceCfg struct {
	name, priv string
	port, mtu  int
	disabled   bool
	addrs      []netip.Prefix
	peers      []wgPeerCfg
}

type WGManager struct {
	r      *Router
	mu     sync.Mutex
	ifaces map[string]*wgIface
}

func (r *Router) wgConfig() (cfg []wgIfaceCfg, running bool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	running = r.state == "running"
	for _, it := range r.list(MenuMap["/interface/wireguard"]) {
		if priv, ok := wgParseKey(it["private-key"]); ok {
			if pub := wgKeyB64(wgPublic(priv)); it["public-key"] != pub {
				it["public-key"] = pub // configurations saved by older versions had a random one
			}
		}
		c := wgIfaceCfg{name: it["name"], priv: it["private-key"], disabled: it.B("disabled")}
		c.port, _ = strconv.Atoi(it["listen-port"])
		c.mtu, _ = strconv.Atoi(firstNonEmpty(it["mtu"], "1420"))
		for _, a := range r.list(MenuMap["/ip/address"]) {
			if a["interface"] == c.name && !a.B("disabled") {
				if pr, err := netip.ParsePrefix(a["address"]); err == nil && pr.Addr().Is4() {
					c.addrs = append(c.addrs, pr)
				}
			}
		}
		for _, p := range r.list(MenuMap["/interface/wireguard/peers"]) {
			if p["interface"] != c.name {
				continue
			}
			pc := wgPeerCfg{id: p[".id"], pub: p["public-key"], psk: p["preshared-key"], host: p["endpoint-address"], disabled: p.B("disabled")}
			pc.port, _ = strconv.Atoi(p["endpoint-port"])
			if d, ok := parseROSTime(p["persistent-keepalive"]); ok {
				pc.keepalive = d
			} else if d, ok := parseDur(p["persistent-keepalive"]); ok {
				pc.keepalive = d
			}
			for _, s := range strings.Split(p["allowed-address"], ",") {
				s = strings.TrimSpace(s)
				if s == "" {
					continue
				}
				if !strings.Contains(s, "/") {
					s += "/32"
				}
				if pr, err := netip.ParsePrefix(s); err == nil {
					pc.allowed = append(pc.allowed, pr.Masked())
				}
			}
			c.peers = append(c.peers, pc)
		}
		cfg = append(cfg, c)
	}
	return
}

// wgLoop keeps the userspace tunnels in step with the configuration and
// writes their counters back, once a second.
func (r *Router) wgLoop() {
	m := &WGManager{r: r, ifaces: map[string]*wgIface{}}
	r.mu.Lock()
	r.wg = m
	r.mu.Unlock()
	for range time.Tick(time.Second) {
		func() {
			defer func() {
				if p := recover(); p != nil {
					fmt.Println("  ! wireguard error:", p)
				}
			}()
			m.sync()
		}()
	}
}

func (m *WGManager) sync() {
	cfg, running := m.r.wgConfig()
	m.mu.Lock()
	want := map[string]bool{}
	for _, c := range cfg {
		if !running || c.disabled {
			continue
		}
		priv, ok := wgParseKey(c.priv)
		if !ok {
			continue
		}
		want[c.name] = true
		w := m.ifaces[c.name]
		if w != nil && (w.priv != priv || (c.port != 0 && w.port != c.port && w.err == "")) {
			w.close()
			w = nil
		}
		if w == nil {
			w = m.start(c.name, priv, c.port)
			m.ifaces[c.name] = w
		}
		w.update(c)
	}
	for name, w := range m.ifaces {
		if !want[name] {
			w.close()
			delete(m.ifaces, name)
		}
	}
	ifaces := make([]*wgIface, 0, len(m.ifaces))
	for _, w := range m.ifaces {
		ifaces = append(ifaces, w)
	}
	m.mu.Unlock()
	for _, w := range ifaces {
		w.tick()
	}
	m.writeStats(ifaces)
}

func (m *WGManager) start(name string, priv [32]byte, port int) *wgIface {
	w := &wgIface{mgr: m, name: name, priv: priv, pub: wgPublic(priv), index: map[uint32]*wgIndex{}, mtu: 1420}
	w.mac1Key = wgHash([]byte(wgLabelMAC1), w.pub[:])
	tries := []int{port}
	if port == 0 {
		tries = []int{0}
	} else {
		tries = append(tries, 0)
	}
	var err error
	for _, p := range tries {
		w.conn, err = net.ListenUDP("udp", &net.UDPAddr{Port: p})
		if err == nil {
			w.port = w.conn.LocalAddr().(*net.UDPAddr).Port
			if p != 0 && w.port != port {
				w.err = "listen-port " + strconv.Itoa(port) + " in use on this PC"
			}
			if p == 0 && port != 0 {
				w.err = fmt.Sprintf("listen-port %d is in use on this PC, using %d", port, w.port)
			}
			break
		}
	}
	if w.conn == nil {
		w.err = err.Error()
		w.closed.Store(true)
		return w
	}
	w.stack = newIPStack(m.r, w)
	go w.readLoop()
	return w
}

func (w *wgIface) update(c wgIfaceCfg) {
	w.mu.Lock()
	defer w.mu.Unlock()
	if c.mtu >= 1280 {
		w.mtu = c.mtu
	}
	w.addrs = c.addrs
	if w.stack != nil {
		w.stack.setAddrs(c.addrs, w.mtu)
	}
	old := map[[32]byte]*wgPeer{}
	for _, p := range w.peers {
		old[p.pub] = p
	}
	var peers []*wgPeer
	for _, pc := range c.peers {
		pub, ok := wgParseKey(pc.pub)
		if !ok {
			continue
		}
		p := old[pub]
		if p == nil {
			p = &wgPeer{ifc: w, pub: pub}
			p.ss, _ = wgDH(w.priv, pub)
			p.mac1Key = wgHash([]byte(wgLabelMAC1), pub[:])
			p.cookieKey = wgHash([]byte(wgLabelCookie), pub[:])
		}
		delete(old, pub)
		p.mu.Lock()
		p.id = pc.id
		if psk, ok := wgParseKey(pc.psk); ok {
			p.psk = psk
		} else {
			p.psk = [32]byte{}
		}
		p.allowed = pc.allowed
		p.keepalive = pc.keepalive
		if pc.disabled && !p.disabled {
			p.cur, p.prev, p.next = nil, nil, nil
			p.hs.sent = false
		}
		p.disabled = pc.disabled
		if pc.host != "" && pc.port > 0 && (pc.host != p.epHost || pc.port != p.epPort || (p.endpoint == nil && time.Since(p.resolvedAt) > 10*time.Second)) {
			p.epHost, p.epPort = pc.host, pc.port
			p.resolvedAt = time.Now()
			if a, err := net.ResolveUDPAddr("udp4", net.JoinHostPort(pc.host, strconv.Itoa(pc.port))); err == nil {
				p.endpoint = a
			}
		}
		p.mu.Unlock()
		peers = append(peers, p)
	}
	for _, p := range old {
		for i, e := range w.index {
			if e.peer == p {
				delete(w.index, i)
			}
		}
	}
	w.peers = peers
}

func (m *WGManager) writeStats(ifaces []*wgIface) {
	type stat struct {
		last         time.Time
		rx, tx       uint64
		epAddr, epPt string
	}
	stats := map[string]stat{}
	run := map[string]string{}
	for _, w := range ifaces {
		w.mu.Lock()
		for _, p := range w.peers {
			p.mu.Lock()
			s := stat{last: p.lastHS, rx: p.rx.Load(), tx: p.tx.Load()}
			if p.endpoint != nil {
				s.epAddr, s.epPt = p.endpoint.IP.String(), strconv.Itoa(p.endpoint.Port)
			}
			p.mu.Unlock()
			stats[p.id] = s
		}
		w.mu.Unlock()
		run[w.name] = map[bool]string{true: "true", false: "false"}[!w.closed.Load()]
	}
	r := m.r
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, it := range r.list(MenuMap["/interface/wireguard/peers"]) {
		s, ok := stats[it[".id"]]
		if !ok {
			continue
		}
		if !s.last.IsZero() {
			it["last-handshake"] = fmtDur(time.Since(s.last).Truncate(time.Second))
		}
		it["rx"] = strconv.FormatUint(s.rx, 10)
		it["tx"] = strconv.FormatUint(s.tx, 10)
		it["current-endpoint-address"] = s.epAddr
		it["current-endpoint-port"] = s.epPt
	}
	for _, it := range r.list(MenuMap["/interface/wireguard"]) {
		if v, ok := run[it["name"]]; ok {
			it["running"] = v
		} else if it.B("disabled") {
			it["running"] = "false"
		}
	}
}

// wgIfaceFor returns the tunnel that owns a local address (for diagnostics).
func (m *WGManager) list() []*wgIface {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]*wgIface, 0, len(m.ifaces))
	for _, w := range m.ifaces {
		out = append(out, w)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].name < out[j].name })
	return out
}

var errNoKey = errors.New("bad key")
