package main

// A small IPv4 stack for addresses that live inside a userspace WireGuard
// tunnel: it answers ping and accepts TCP connections, which it hands to the
// simulator's services (API, API-SSL, SSH, Telnet, WebFig/WinBox, FTP) as
// ordinary net.Conns. The TCP is a server-side implementation with
// retransmission, flow control and orderly close; it is meant for the
// management traffic a router receives, not for bulk transfers.

import (
	"bytes"
	"crypto/rand"
	"crypto/tls"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"net/netip"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type tcpKey struct {
	laddr, raddr netip.AddrPort
}

type ipStack struct {
	r      *Router
	w      *wgIface
	mu     sync.Mutex
	addrs  []netip.Prefix
	mtu    int
	conns  map[tcpKey]*tcpConn
	ipID   uint16
	closed bool
	https  map[string]*chanListener
}

func newIPStack(r *Router, w *wgIface) *ipStack {
	return &ipStack{r: r, w: w, conns: map[tcpKey]*tcpConn{}, mtu: 1420, https: map[string]*chanListener{}}
}

func (s *ipStack) setAddrs(a []netip.Prefix, mtu int) {
	s.mu.Lock()
	s.addrs = a
	s.mtu = mtu
	s.mu.Unlock()
}

func (s *ipStack) local(a netip.Addr) bool {
	for _, p := range s.addrs {
		if p.Addr() == a {
			return true
		}
	}
	return false
}

func (s *ipStack) close() {
	s.mu.Lock()
	s.closed = true
	conns := make([]*tcpConn, 0, len(s.conns))
	for _, c := range s.conns {
		conns = append(conns, c)
	}
	for _, l := range s.https {
		l.Close()
	}
	s.mu.Unlock()
	for _, c := range conns {
		c.abort(io.EOF)
	}
}

func csum(b []byte, initial uint32) uint16 {
	sum := initial
	for i := 0; i+1 < len(b); i += 2 {
		sum += uint32(b[i])<<8 | uint32(b[i+1])
	}
	if len(b)%2 == 1 {
		sum += uint32(b[len(b)-1]) << 8
	}
	for sum>>16 != 0 {
		sum = sum&0xffff + sum>>16
	}
	return ^uint16(sum)
}

func (s *ipStack) output(proto byte, src, dst netip.Addr, payload []byte) {
	s.mu.Lock()
	s.ipID++
	id := s.ipID
	s.mu.Unlock()
	pkt := make([]byte, 20+len(payload))
	pkt[0] = 0x45
	binary.BigEndian.PutUint16(pkt[2:], uint16(len(pkt)))
	binary.BigEndian.PutUint16(pkt[4:], id)
	binary.BigEndian.PutUint16(pkt[6:], 0x4000)
	pkt[8] = 64
	pkt[9] = proto
	s4, d4 := src.As4(), dst.As4()
	copy(pkt[12:16], s4[:])
	copy(pkt[16:20], d4[:])
	binary.BigEndian.PutUint16(pkt[10:], csum(pkt[:20], 0))
	copy(pkt[20:], payload)
	s.w.sendIP(pkt)
}

func (s *ipStack) input(pkt []byte) {
	ihl := int(pkt[0]&0x0f) * 4
	if ihl < 20 || len(pkt) < ihl {
		return
	}
	if binary.BigEndian.Uint16(pkt[6:8])&0x3fff != 0 {
		return // fragments are not reassembled
	}
	src, _ := netip.AddrFromSlice(pkt[12:16])
	dst, _ := netip.AddrFromSlice(pkt[16:20])
	s.mu.Lock()
	mine := s.local(dst)
	s.mu.Unlock()
	if !mine {
		return
	}
	body := pkt[ihl:]
	switch pkt[9] {
	case 1:
		if len(body) >= 8 && body[0] == 8 { // echo request
			rep := append([]byte{}, body...)
			rep[0] = 0
			rep[2], rep[3] = 0, 0
			binary.BigEndian.PutUint16(rep[2:], csum(rep, 0))
			s.output(1, dst, src, rep)
		}
	case 6:
		s.tcpInput(src, dst, body)
	}
}

// ---------- TCP ----------

const (
	tcpFIN = 0x01
	tcpSYN = 0x02
	tcpRST = 0x04
	tcpPSH = 0x08
	tcpACK = 0x10
)

const (
	stSynRcvd = iota
	stEstablished
	stClosing // FIN sent and/or received, waiting for both directions
	stClosed
)

const tcpRecvBuf = 256 << 10

func tcpChecksum(src, dst netip.Addr, seg []byte) uint16 {
	s4, d4 := src.As4(), dst.As4()
	var ph uint32
	ph += uint32(s4[0])<<8 | uint32(s4[1])
	ph += uint32(s4[2])<<8 | uint32(s4[3])
	ph += uint32(d4[0])<<8 | uint32(d4[1])
	ph += uint32(d4[2])<<8 | uint32(d4[3])
	ph += 6
	ph += uint32(len(seg))
	return csum(seg, ph)
}

func seqLT(a, b uint32) bool  { return int32(a-b) < 0 }
func seqLEQ(a, b uint32) bool { return int32(a-b) <= 0 }

type tcpConn struct {
	s           *ipStack
	key         tcpKey
	mu          sync.Mutex
	cond        *sync.Cond
	state       int
	iss         uint32
	sndUna      uint32
	sndNxt      uint32
	sndWnd      uint32
	mss         int
	sndBuf      []byte // bytes from sndUna onwards
	rcvNxt      uint32
	rcvBuf      bytes.Buffer
	finRcvd     bool
	closeReq    bool
	finSent     bool
	finSeq      uint32
	finAcked    bool
	err         error
	rto         time.Duration
	retries     int
	timer       *time.Timer
	rdDeadline  time.Time
	wrDeadline  time.Time
	established chan struct{}
}

func (s *ipStack) tcpInput(src, dst netip.Addr, seg []byte) {
	if len(seg) < 20 || tcpChecksum(src, dst, seg) != 0 {
		return
	}
	sport := binary.BigEndian.Uint16(seg[0:2])
	dport := binary.BigEndian.Uint16(seg[2:4])
	seq := binary.BigEndian.Uint32(seg[4:8])
	ack := binary.BigEndian.Uint32(seg[8:12])
	off := int(seg[12]>>4) * 4
	flags := seg[13]
	wnd := uint32(binary.BigEndian.Uint16(seg[14:16]))
	if off < 20 || off > len(seg) {
		return
	}
	data := seg[off:]
	key := tcpKey{netip.AddrPortFrom(dst, dport), netip.AddrPortFrom(src, sport)}
	s.mu.Lock()
	c := s.conns[key]
	closed := s.closed
	s.mu.Unlock()
	if closed {
		return
	}
	if c == nil {
		if flags&tcpRST != 0 {
			return
		}
		if flags&tcpSYN == 0 || flags&tcpACK != 0 {
			s.sendRST(key, seq, ack, flags, len(data))
			return
		}
		if !s.r.tunnelAccepts(int(dport), src) {
			s.sendRST(key, seq, ack, flags, len(data))
			return
		}
		c = &tcpConn{s: s, key: key, state: stSynRcvd, rcvNxt: seq + 1, sndWnd: wnd, mss: 536, rto: time.Second, established: make(chan struct{})}
		c.cond = sync.NewCond(&c.mu)
		var b [4]byte
		rand.Read(b[:])
		c.iss = binary.BigEndian.Uint32(b[:])
		c.sndUna, c.sndNxt = c.iss, c.iss+1
		// options: MSS
		opts := seg[20:off]
		for i := 0; i < len(opts); {
			switch opts[i] {
			case 0:
				i = len(opts)
			case 1:
				i++
			default:
				if i+1 >= len(opts) || opts[i+1] < 2 {
					i = len(opts)
					continue
				}
				if opts[i] == 2 && opts[i+1] == 4 && i+3 < len(opts) {
					c.mss = int(binary.BigEndian.Uint16(opts[i+2:]))
				}
				i += int(opts[i+1])
			}
		}
		s.mu.Lock()
		mtu := s.mtu
		s.conns[key] = c
		s.mu.Unlock()
		c.mss = min(c.mss, mtu-40)
		c.mu.Lock()
		c.sendSegment(c.iss, tcpSYN|tcpACK, nil, true)
		c.armTimer()
		c.mu.Unlock()
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	c.segment(seq, ack, flags, wnd, data)
}

func (s *ipStack) sendRST(key tcpKey, seq, ack uint32, flags byte, dlen int) {
	h := make([]byte, 20)
	binary.BigEndian.PutUint16(h[0:], key.laddr.Port())
	binary.BigEndian.PutUint16(h[2:], key.raddr.Port())
	if flags&tcpACK != 0 {
		binary.BigEndian.PutUint32(h[4:], ack)
		h[13] = tcpRST
	} else {
		n := uint32(dlen)
		if flags&tcpSYN != 0 {
			n++
		}
		if flags&tcpFIN != 0 {
			n++
		}
		binary.BigEndian.PutUint32(h[8:], seq+n)
		h[13] = tcpRST | tcpACK
	}
	h[12] = 5 << 4
	binary.BigEndian.PutUint16(h[16:], tcpChecksum(key.laddr.Addr(), key.raddr.Addr(), h))
	s.output(6, key.laddr.Addr(), key.raddr.Addr(), h)
}

func (c *tcpConn) window() uint16 {
	free := tcpRecvBuf - c.rcvBuf.Len()
	if free < 0 {
		free = 0
	}
	return uint16(min(free, 65535))
}

// sendSegment builds and sends one segment. Called with c.mu held.
func (c *tcpConn) sendSegment(seq uint32, flags byte, data []byte, mssOpt bool) {
	hl := 20
	if mssOpt {
		hl = 24
	}
	seg := make([]byte, hl+len(data))
	binary.BigEndian.PutUint16(seg[0:], c.key.laddr.Port())
	binary.BigEndian.PutUint16(seg[2:], c.key.raddr.Port())
	binary.BigEndian.PutUint32(seg[4:], seq)
	if flags&tcpACK != 0 {
		binary.BigEndian.PutUint32(seg[8:], c.rcvNxt)
	}
	seg[12] = byte(hl/4) << 4
	seg[13] = flags
	binary.BigEndian.PutUint16(seg[14:], c.window())
	if mssOpt {
		seg[20], seg[21] = 2, 4
		binary.BigEndian.PutUint16(seg[22:], uint16(c.mss))
	}
	copy(seg[hl:], data)
	binary.BigEndian.PutUint16(seg[16:], tcpChecksum(c.key.laddr.Addr(), c.key.raddr.Addr(), seg))
	c.s.output(6, c.key.laddr.Addr(), c.key.raddr.Addr(), seg)
}

func (c *tcpConn) armTimer() {
	if c.timer != nil {
		c.timer.Stop()
	}
	c.timer = time.AfterFunc(c.rto, c.onTimer)
}

func (c *tcpConn) onTimer() {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.state == stClosed {
		return
	}
	outstanding := c.sndNxt != c.sndUna || c.state == stSynRcvd || (c.finSent && !c.finAcked)
	if !outstanding && !(len(c.sndBuf) > 0 && c.sndWnd == 0) {
		return
	}
	c.retries++
	if c.retries > 10 {
		c.fail(errors.New("connection timed out"))
		return
	}
	c.rto = min(c.rto*2, 30*time.Second)
	if c.state == stSynRcvd {
		c.sendSegment(c.iss, tcpSYN|tcpACK, nil, true)
	} else {
		// go back to the first unacknowledged byte
		c.sndNxt = c.sndUna
		if c.finSent && !c.finAcked && len(c.sndBuf) == 0 {
			c.finSent = false
		}
		if c.sndWnd == 0 && len(c.sndBuf) > 0 {
			c.sendSegment(c.sndNxt, tcpACK, c.sndBuf[:1], false) // window probe
		} else {
			c.push()
		}
	}
	c.armTimer()
}

// push sends what the peer's window allows. Called with c.mu held.
func (c *tcpConn) push() {
	if c.state == stSynRcvd || c.state == stClosed {
		return
	}
	sent := false
	for {
		inFlight := c.sndNxt - c.sndUna
		if int(inFlight) >= len(c.sndBuf) {
			break
		}
		avail := int(c.sndWnd) - int(inFlight)
		if avail <= 0 {
			break
		}
		n := min(c.mss, len(c.sndBuf)-int(inFlight), avail, 64<<10)
		data := c.sndBuf[int(inFlight) : int(inFlight)+n]
		flags := byte(tcpACK)
		if int(inFlight)+n == len(c.sndBuf) {
			flags |= tcpPSH
		}
		c.sendSegment(c.sndNxt, flags, data, false)
		c.sndNxt += uint32(n)
		sent = true
	}
	if c.closeReq && !c.finSent && int(c.sndNxt-c.sndUna) == len(c.sndBuf) {
		c.finSeq = c.sndNxt
		c.sendSegment(c.sndNxt, tcpFIN|tcpACK, nil, false)
		c.sndNxt++
		c.finSent = true
		sent = true
	}
	if sent && (c.timer == nil || c.retries == 0) {
		c.armTimer()
	}
}

func (c *tcpConn) segment(seq, ack uint32, flags byte, wnd uint32, data []byte) {
	if flags&tcpRST != 0 {
		c.fail(io.EOF)
		return
	}
	if flags&tcpSYN != 0 {
		if c.state == stSynRcvd && seq+1 == c.rcvNxt {
			c.sendSegment(c.iss, tcpSYN|tcpACK, nil, true) // our SYN-ACK was lost
		}
		return
	}
	if flags&tcpACK == 0 {
		return
	}
	if c.state == stSynRcvd {
		if ack != c.iss+1 {
			return
		}
		c.state = stEstablished
		c.sndUna = ack
		c.sndWnd = wnd
		c.retries = 0
		c.rto = time.Second
		close(c.established)
		go c.s.r.tunnelServe(c)
	}
	// acknowledgement of our data
	if seqLT(c.sndUna, ack) && seqLEQ(ack, c.sndNxt) {
		n := int(ack - c.sndUna)
		if c.finSent && ack == c.finSeq+1 {
			c.finAcked = true
			n--
		}
		if n > len(c.sndBuf) {
			n = len(c.sndBuf)
		}
		c.sndBuf = c.sndBuf[n:]
		c.sndUna = ack
		c.retries = 0
		c.rto = time.Second
		if c.sndUna == c.sndNxt && c.timer != nil {
			c.timer.Stop()
		} else {
			c.armTimer()
		}
		c.cond.Broadcast()
	}
	if seqLEQ(c.sndUna, ack) {
		c.sndWnd = wnd
	}
	// incoming data
	needAck := false
	if len(data) > 0 {
		needAck = true
		switch {
		case seq == c.rcvNxt:
		case seqLT(seq, c.rcvNxt) && seqLT(c.rcvNxt, seq+uint32(len(data))):
			data = data[c.rcvNxt-seq:]
			seq = c.rcvNxt
		default:
			data = nil // out of order or already seen: the ACK below asks again
		}
		if len(data) > 0 && !c.finRcvd {
			room := tcpRecvBuf - c.rcvBuf.Len()
			if len(data) > room {
				data = data[:max(0, room)]
			}
			c.rcvBuf.Write(data)
			c.rcvNxt += uint32(len(data))
			c.cond.Broadcast()
		}
	}
	if flags&tcpFIN != 0 && c.finRcvd {
		needAck = true // our ACK of their FIN was lost
	}
	if flags&tcpFIN != 0 && seq+uint32(len(data)) == c.rcvNxt && !c.finRcvd {
		c.rcvNxt++
		c.finRcvd = true
		needAck = true
		c.cond.Broadcast()
	}
	if needAck {
		c.sendSegment(c.sndNxt, tcpACK, nil, false)
	}
	c.push()
	if c.finRcvd && c.finSent && c.finAcked {
		c.finish()
	}
}

func (c *tcpConn) fail(err error) {
	if c.err == nil {
		c.err = err
	}
	c.finish()
}

func (c *tcpConn) finish() {
	if c.state == stClosed {
		return
	}
	c.state = stClosed
	if c.timer != nil {
		c.timer.Stop()
	}
	c.cond.Broadcast()
	select {
	case <-c.established:
	default:
		close(c.established)
	}
	go func() {
		time.Sleep(2 * time.Second) // keep answering retransmitted FINs briefly
		c.s.mu.Lock()
		if c.s.conns[c.key] == c {
			delete(c.s.conns, c.key)
		}
		c.s.mu.Unlock()
	}()
}

func (c *tcpConn) abort(err error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.state != stClosed {
		h := byte(tcpRST | tcpACK)
		c.sendSegment(c.sndNxt, h, nil, false)
	}
	c.fail(err)
}

// ---------- net.Conn ----------

type deadlineErr struct{}

func (deadlineErr) Error() string   { return "i/o timeout" }
func (deadlineErr) Timeout() bool   { return true }
func (deadlineErr) Temporary() bool { return true }

func (c *tcpConn) waitUntil(deadline time.Time) bool {
	if deadline.IsZero() {
		c.cond.Wait()
		return true
	}
	d := time.Until(deadline)
	if d <= 0 {
		return false
	}
	t := time.AfterFunc(d, func() {
		c.mu.Lock()
		c.cond.Broadcast()
		c.mu.Unlock()
	})
	c.cond.Wait()
	t.Stop()
	return time.Now().Before(deadline)
}

func (c *tcpConn) Read(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for c.rcvBuf.Len() == 0 {
		if c.finRcvd || c.state == stClosed {
			if c.err != nil && c.err != io.EOF {
				return 0, c.err
			}
			return 0, io.EOF
		}
		if !c.waitUntil(c.rdDeadline) {
			return 0, os.ErrDeadlineExceeded
		}
	}
	before := c.window()
	n, _ := c.rcvBuf.Read(b)
	if before < uint16(c.mss) && c.window() >= uint16(c.mss) {
		c.sendSegment(c.sndNxt, tcpACK, nil, false) // window update
	}
	return n, nil
}

func (c *tcpConn) Write(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	written := 0
	for written < len(b) {
		if c.state == stClosed || c.closeReq {
			if c.err != nil {
				return written, c.err
			}
			return written, net.ErrClosed
		}
		room := 512<<10 - len(c.sndBuf)
		if room <= 0 {
			if !c.waitUntil(c.wrDeadline) {
				return written, os.ErrDeadlineExceeded
			}
			continue
		}
		n := min(room, len(b)-written)
		c.sndBuf = append(c.sndBuf, b[written:written+n]...)
		written += n
		c.push()
	}
	return written, nil
}

func (c *tcpConn) Close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.state == stClosed || c.closeReq {
		return nil
	}
	c.closeReq = true
	c.push()
	c.cond.Broadcast()
	go func() {
		time.Sleep(60 * time.Second)
		c.mu.Lock()
		defer c.mu.Unlock()
		c.finish()
	}()
	return nil
}

func (c *tcpConn) LocalAddr() net.Addr  { return net.TCPAddrFromAddrPort(c.key.laddr) }
func (c *tcpConn) RemoteAddr() net.Addr { return net.TCPAddrFromAddrPort(c.key.raddr) }
func (c *tcpConn) SetDeadline(t time.Time) error {
	c.SetReadDeadline(t)
	return c.SetWriteDeadline(t)
}
func (c *tcpConn) SetReadDeadline(t time.Time) error {
	c.mu.Lock()
	c.rdDeadline = t
	c.cond.Broadcast()
	c.mu.Unlock()
	return nil
}
func (c *tcpConn) SetWriteDeadline(t time.Time) error {
	c.mu.Lock()
	c.wrDeadline = t
	c.cond.Broadcast()
	c.mu.Unlock()
	return nil
}

// ---------- handing connections to the services ----------

// tunnelService finds the enabled /ip service on a port.
func (r *Router) tunnelService(port int) (name, allowed string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, it := range r.list(MenuMap["/ip/service"]) {
		if it["port"] == strconv.Itoa(port) && !it.B("disabled") {
			return it["name"], it["address"]
		}
	}
	return "", ""
}

func addrAllowed(ip netip.Addr, list string) bool {
	if strings.TrimSpace(list) == "" {
		return true
	}
	for _, s := range strings.Split(list, ",") {
		s = strings.TrimSpace(s)
		if !strings.Contains(s, "/") {
			s += "/32"
		}
		if p, err := netip.ParsePrefix(s); err == nil && p.Contains(ip) {
			return true
		}
	}
	return false
}

func (r *Router) tunnelAccepts(port int, src netip.Addr) bool {
	name, allowed := r.tunnelService(port)
	return name != "" && addrAllowed(src, allowed) && r.svc != nil
}

func (r *Router) tunnelServe(c *tcpConn) {
	name, _ := r.tunnelService(int(c.key.laddr.Port()))
	sv := r.svc
	if name == "" || sv == nil {
		c.abort(io.EOF)
		return
	}
	switch name {
	case "api":
		handleAPI(r, c, "api")
	case "api-ssl":
		handleAPI(r, tls.Server(c, sv.tlsCfg), "api-ssl")
	case "ssh":
		handleSSH(r, c, sv.keys)
	case "telnet":
		handleTelnet(r, c)
	case "ftp":
		handleFTP(r, c)
	case "www", "winbox", "www-ssl":
		c.s.httpListener(name, sv).push(c)
	default:
		c.abort(io.EOF)
	}
}

type chanListener struct {
	ch     chan net.Conn
	addr   net.Addr
	once   sync.Once
	closed chan struct{}
}

func (l *chanListener) Accept() (net.Conn, error) {
	select {
	case c := <-l.ch:
		return c, nil
	case <-l.closed:
		return nil, net.ErrClosed
	}
}

func (l *chanListener) Close() error {
	l.once.Do(func() { close(l.closed) })
	return nil
}

func (l *chanListener) Addr() net.Addr { return l.addr }

func (l *chanListener) push(c net.Conn) {
	select {
	case l.ch <- c:
	case <-l.closed:
		c.Close()
	}
}

func (s *ipStack) httpListener(name string, sv *Services) *chanListener {
	s.mu.Lock()
	defer s.mu.Unlock()
	if l := s.https[name]; l != nil {
		return l
	}
	l := &chanListener{ch: make(chan net.Conn), addr: &net.TCPAddr{}, closed: make(chan struct{})}
	s.https[name] = l
	srv := &http.Server{Handler: sv.web.handler(name), ReadHeaderTimeout: 20 * time.Second}
	if name == "www-ssl" {
		srv.TLSConfig = sv.tlsCfg
		go srv.ServeTLS(l, "", "")
	} else {
		go srv.Serve(l)
	}
	return l
}
