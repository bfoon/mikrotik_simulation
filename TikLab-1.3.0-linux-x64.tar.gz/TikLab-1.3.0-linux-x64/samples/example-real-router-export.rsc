# 2025-10-14 18:22:51 by RouterOS 7.16.1
# software id = 4H8K-2NQX
#
# model = RB750Gr3
# serial number = HE30A8K2Q7P
/interface bridge
add admin-mac=48:8F:5A:11:22:33 auto-mac=no comment=defconf name=bridge
add name=bridge-hs
/interface ethernet
set [ find default-name=ether1 ] comment="WAN - Africell"
/interface list
add comment=defconf name=WAN
add comment=defconf name=LAN
/interface wireless security-profiles
set [ find default=yes ] supplicant-identity=MikroTik
/ip hotspot profile
add dns-name=wifi.kombo hotspot-address=10.20.0.1 html-directory=flash/hotspot \
    login-by=http-chap,http-pap name=hsprof1
/ip hotspot user profile
set [ find default=yes ] rate-limit=1M/1M
add name=3HRS on-login=":put (\",rem,5,3h,5,,Enable,Disable,\"); \
    {:local date [ /system clock get date ];}" rate-limit=2M/2M \
    shared-users=1 status-autorefresh=1m transparent-proxy=yes
add name=1DAY rate-limit=3M/3M shared-users=1
/ip pool
add name=default-dhcp ranges=192.168.88.10-192.168.88.254
add name=hs-pool-14 ranges=10.20.0.2-10.20.3.254
/ip dhcp-server
add address-pool=default-dhcp interface=bridge name=defconf
add address-pool=hs-pool-14 interface=bridge-hs lease-time=1h name=dhcp1
/ip hotspot
add address-pool=hs-pool-14 disabled=no interface=bridge-hs name=hotspot1 \
    profile=hsprof1
/ppp profile
add local-address=172.16.0.1 name=PPPOE-5M rate-limit=5M/5M remote-address=\
    hs-pool-14
/queue type
add kind=pcq name=pcq-down pcq-classifier=dst-address pcq-rate=2M
/routing ospf instance
add disabled=no name=default-v2
/interface bridge port
add bridge=bridge comment=defconf interface=ether2
add bridge=bridge comment=defconf interface=ether3
add bridge=bridge-hs interface=ether4
add bridge=bridge-hs interface=ether5
/ip neighbor discovery-settings
set discover-interface-list=LAN
/interface list member
add comment=defconf interface=bridge list=LAN
add comment=defconf interface=ether1 list=WAN
/interface pppoe-server server
add default-profile=PPPOE-5M disabled=no interface=bridge one-session-per-host=yes \
    service-name=pppoe-kombo
/ip address
add address=192.168.88.1/24 comment=defconf interface=bridge network=\
    192.168.88.0
add address=10.20.0.1/22 interface=bridge-hs network=10.20.0.0
/ip dhcp-client
add comment=defconf interface=ether1
/ip dhcp-server network
add address=10.20.0.0/22 comment="hotspot network" gateway=10.20.0.1
add address=192.168.88.0/24 comment=defconf dns-server=192.168.88.1 gateway=192.168.88.1
/ip dns
set allow-remote-requests=yes servers=8.8.8.8,8.8.4.4
/ip firewall filter
add action=passthrough chain=unused-hs-chain comment=\
    "place hotspot rules here" disabled=yes
add action=accept chain=input comment=\
    "defconf: accept established,related,untracked" connection-state=\
    established,related,untracked
add action=drop chain=input comment="defconf: drop all not coming from LAN" \
    in-interface-list=!LAN
/ip firewall nat
add action=passthrough chain=unused-hs-chain comment=\
    "place hotspot rules here" disabled=yes
add action=masquerade chain=srcnat comment="defconf: masquerade" \
    ipsec-policy=out,none out-interface-list=WAN
add action=masquerade chain=srcnat comment="masquerade hotspot network" \
    src-address=10.20.0.0/22
/ip hotspot ip-binding
add mac-address=AA:BB:CC:DD:EE:01 type=bypassed comment="office printer"
/ip hotspot user
add name=admin1 password=x9Kd2 profile=1DAY
add limit-uptime=3h name=k8m2p password=k8m2p profile=3HRS server=hotspot1
add limit-uptime=3h name=q4zt7 password=q4zt7 profile=3HRS server=hotspot1
/ip hotspot walled-garden
add dst-host=*.taptap.gm comment="payment page"
/ip service
set telnet disabled=yes
set ftp disabled=yes
set www port=8081
set ssh port=2200
set winbox disabled=yes
/ppp secret
add name=lamin password=1234 profile=PPPOE-5M service=pppoe
add name=fatou password=5678 profile=PPPOE-5M service=pppoe caller-id=DC:2C:6E:11:22:33
/system clock
set time-zone-name=Africa/Banjul
/system identity
set name=Kombo-Hotspot
/system scheduler
add interval=1d name=daily-clean on-event=cleanup policy=\
    ftp,reboot,read,write,policy,test,password,sniff,sensitive,romon \
    start-time=03:00:00
/tool mac-server
set allowed-interface-list=LAN
/tool mac-server mac-winbox
set allowed-interface-list=LAN
