#!/bin/sh
# Start the TikLab router simulator. Pass options through, e.g. ./start-tiklab.sh -model hap-ax2
cd "$(dirname "$0")" || exit 1
exec ./tiklab "$@"
