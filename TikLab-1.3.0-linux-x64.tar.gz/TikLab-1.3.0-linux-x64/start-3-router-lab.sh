#!/bin/sh
# Three simulated routers for a training lab (Ctrl+C stops all).
cd "$(dirname "$0")" || exit 1
./tiklab -no-browser & P1=$!
sleep 2
./tiklab -instance 1 -model hap-ac2 -no-browser & P2=$!
./tiklab -instance 2 -model hex-s -no-browser & P3=$!
trap "kill $P1 $P2 $P3" INT TERM
echo "Consoles: http://127.0.0.1:8291  http://127.0.0.1:8301  http://127.0.0.1:8311"
wait
